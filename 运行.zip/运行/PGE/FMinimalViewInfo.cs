﻿namespace PGE
{
    public struct FMinimalViewInfo
    {
        public Vector3 Location;

        public FRotator Rotation;

        public float FOV;
    }
}
