﻿namespace PGE
{
    public struct FCameraCacheData
    {
        public FMinimalViewInfo POV;
    }
}
