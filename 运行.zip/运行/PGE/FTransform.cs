﻿namespace PGE
{
    public struct FTransform
    {
        public Vector4 Rotation;

        public Vector4 Translation;

        public Vector3 Scale3D;

        public D3DMATRIX ToMatrixWithScale()
        {
            D3DMATRIX result = default(D3DMATRIX);
            result._41 = Translation.x;
            result._42 = Translation.y;
            result._43 = Translation.z;
            float num = Rotation.x + Rotation.x;
            float num2 = Rotation.y + Rotation.y;
            float num3 = Rotation.z + Rotation.z;
            float num4 = Rotation.x * num;
            float num5 = Rotation.y * num2;
            float num6 = Rotation.z * num3;
            result._11 = (1f - (num5 + num6)) * Scale3D.x;
            result._22 = (1f - (num4 + num6)) * Scale3D.y;
            result._33 = (1f - (num4 + num5)) * Scale3D.z;
            float num7 = Rotation.y * num3;
            float num8 = Rotation.w * num;
            result._32 = (num7 - num8) * Scale3D.z;
            result._23 = (num7 + num8) * Scale3D.y;
            float num9 = Rotation.x * num2;
            float num10 = Rotation.w * num3;
            result._21 = (num9 - num10) * Scale3D.y;
            result._12 = (num9 + num10) * Scale3D.x;
            float num11 = Rotation.x * num3;
            float num12 = Rotation.w * num2;
            result._31 = (num11 + num12) * Scale3D.z;
            result._13 = (num11 - num12) * Scale3D.x;
            result._14 = 0f;
            result._24 = 0f;
            result._34 = 0f;
            result._44 = 1f;
            return result;
        }
    }
}
