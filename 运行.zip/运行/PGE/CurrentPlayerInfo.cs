﻿namespace PGE;

public class CurrentPlayerInfo
{
    public uint 本人观战 { get; set; }

    public bool IsGaming { get; set; } = false;

    public int FOV { get; set; } = 0;

}