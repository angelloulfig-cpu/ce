﻿namespace PGE;

public class Actor人物
{
    public ulong addr;

    public bool use;

    public Dictionary<int, uint> BoneStatus;

    public long time;

    public ulong Playname;

    public ulong 视角;

    public ulong 人物状态;

    public string name = "";

    public string 段位 = "";

    public string KD = "";

    public string 场伤 = "";

    public ulong ulong_4;

    public float 伤害 = 0;

    public float 人物血量;

    public float 倒地血量;

    public uint 合作者;

    public uint 生存大等级;

    public uint 生存等级;

    public uint 等级;

    public uint TeamID;

    public uint TeamSeq;

    public float 人物位面;

    public uint 人物杀敌;

    public uint 观战人数;

    public int 人机;

    public int 被瞄准;

    public uint 距离;

    public string 高度 = "";

    public int 是否可视;

    public ulong Bone;

    public ulong VehicleRiderComponentAddr;

    public ulong CharacterMovementAddr;

    public ulong LastVehiclePawnAddr;

    public uint 是否友军;

    public uint Isself;

    public ulong key;

    public ulong 武器控制;

    public ulong 武器基址;

    public ulong 当前武器;

    public byte byte_b = byte.MaxValue;

    public byte 血量加密;

    public uint 血量加密2;

    public byte 血量3;

    public float 血量4;

    public byte 血量5;

    public uint 血量6;

    public string 类名 = "";

    public string 武器名称name = "";

    public string 武器名称 = "";

    public int 武器类型 = 99;

    public bool 存活 = true;

    public int 迷雾 = 1;

    public uint 武器id;

    public uint 标点;

    public bool IsBlackList;

    public string 状态 = "?";

    public Vector3 speed;

    public Vector2 队友标点坐标;

    public FTransform Actor_Bone;

    public FTransform 瞄准_Bone;

    public FTransform 头部_Bone;

    public FTransform 颈部_Bone;

    public FTransform 胸部_Bone;

    public FTransform 左肘_Bone;

    public FTransform 右肘_Bone;

    public FTransform 左手_Bone;

    public FTransform 右手_Bone;

    public FTransform 骨盆_Bone;

    public FTransform 左膝_Bone;

    public FTransform 右膝_Bone;

    public FTransform 左脚跟_Bone;

    public FTransform 右脚跟_Bone;

    public FTransform 左肩_Bone;

    public FTransform 右肩_Bone;

    public FTransform 左胯_Bone;

    public FTransform 右胯_Bone;

    public Vector2 瞄准;

    public Vector2 头部;

    public Vector2 颈部;

    public Vector2 胸部;

    public Vector2 左肘;

    public Vector2 右肘;

    public Vector2 左手;

    public Vector2 右手;

    public Vector2 骨盆;

    public Vector2 左膝;

    public Vector2 右膝;

    public Vector2 左脚跟;

    public Vector2 右脚跟;

    public Vector2 左肩;

    public Vector2 右肩;

    public Vector2 左胯;

    public Vector2 右胯;

    public Vector2 中心;

    public Vector3 vector3_1;

    public Vector3 vector3_头部;

    public Vector3 vector3_颈部;

    public Vector3 vector3_胸部;

    public Vector3 vector3_左肘;

    public Vector3 vector3_右肘;

    public Vector3 vector3_左手;

    public Vector3 vector3_右手;

    public Vector3 vector3_骨盆;

    public Vector3 vector3_左膝;

    public Vector3 vector3_右膝;

    public Vector3 vector3_左脚跟;

    public Vector3 vector3_右脚跟;

    public Vector3 vector3_左肩;

    public Vector3 vector3_右肩;

    public Vector3 vector3_左胯;

    public Vector3 vector3_右胯;

    public Vector3 人物方向;

    public Vector3 人物雷达坐标;

    public Vector3 距离坐标;

    public Vector2 vector3_小地图;

    public Vector2 vector3_大地图;

    public Vector3 中心坐标;



}