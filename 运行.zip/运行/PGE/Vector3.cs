﻿namespace PGE
{
    public struct Vector3
    {
        public float x;

        public float y;

        public float z;

        public float Dot(Vector3 v)
        {
            return x * v.x + y * v.y + z * v.z;
        }
    }
}
