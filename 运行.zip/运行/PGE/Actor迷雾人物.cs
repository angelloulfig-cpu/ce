﻿namespace PGE;

public class Actor迷雾人物
{
    public ulong 迷雾视角;
    public ulong Components;
}