﻿namespace PGE.Common;

public class 透视Config
{
    public EspConfig EspConfig { get; set; } = new EspConfig();

}