﻿using Newtonsoft.Json;

namespace PGE.Common;

public class CommonProperty
{
    public static Vector2 预瞄点 = new Vector2();
    public static bool 预瞄点开关 = true;
    public static uint winlogonpid;
    public static ulong gafAsyncKeyStateAddress;
    //public static byte[] 热键 = new byte[64];
    public static bool 热键监控 = false;
    public static Vector2 中心;
    public static long time;
    public static int 迷雾人数;
    public static 透视Config espconfig = new 透视Config();
    public static string path;
    public static HashSet<string> Hash_黑名单 = new HashSet<string>();
    public static HashSet<string> HashSet_白名单 = new HashSet<string>();
    public static HashSet<uint> hashSet_友军 = new HashSet<uint>();
    public static HashSet<string> Hash_队友 = new HashSet<string>();
    //public static Dictionary<ulong, 玩家列表> 玩家列表s = new Dictionary<ulong, 玩家列表>();
    public static List<玩家列表> 玩家列表s = new List<玩家列表>();
    public static List<ulong> 玩家列表ss = new List<ulong>();
    public static AutoResetEvent Esp投掷物 = new(false);
    public static AutoResetEvent EspResetEventSlim = new(false);
    public static AutoResetEvent EspVehicleResetEventSlim = new(false);
    public static AutoResetEvent EspGameItemResetEventSlim = new(false);
    public static AutoResetEvent EspItemResetEventSlim = new(false);
    public static AutoResetEvent GameStartSlim = new(false);
    public static bool 菜单 = true;
    public static bool 自瞄配置2 = false;
    public static bool 玩家列表 = true;
    public static bool showGameItems = false;
    public static bool showVehicles = false;
    public static string jiemi = "";
    public static string 段位ip = "";
    public static string jiemi2 = "";
    public static string username = "";
    public static bool 自瞄优先 = true;
    public static string MqttServer1 = "";
    public static string MqttServer2 = "";
    public static string MqttServer3 = "";
    public static string MqttServer4 = "";
    public static string WebServer = "";
    public static string NOMqttserver = "";
    public static string Gnames加 = "";
    public static string 到期时间 = "";
    public static string mqtt状态 = "";
    public static bool 单排 = false;
    public static bool 保存物资 = false;
    public static bool 战斗模式 = true;
    public static bool 垂直同步 = true;
    public static bool 融合器黑背景 = false;
    public static int X分辨率;
    public static int Y分辨率;
    public static float fov;
    public static float fov2;
    public static uint 本人观战人数;
    public static float 手雷倒计时 = 5;
    public static bool 物资A;
    public static bool 物资B;
    public static bool 物资C;
    public static bool 物资D;
    public static int 刷新1 = 400;
    public static int 刷新2 = 1420;
    public static bool 随机自瞄 = true;
    public static bool 刷新列表 = false;
    public static bool 获取战绩 = false;
    public static bool mqttserver = false;
    public static bool ThreadRunning = true;
    public static bool IsShow = false;
    public static bool IsShow2 = false;
    public static bool 心跳验证 = true;

    //public static bool 心跳验证 = true;

    public CommonProperty()
    {
        if (File.Exists(CommonProperty.path + "config\\透视配置.json"))
        {
            espconfig = JsonConvert.DeserializeObject<透视Config>(System.IO.File.ReadAllText(CommonProperty.path + "config\\透视配置.json"))!;
        }
    }

    public static void SaveConfig()
    {
        System.IO.File.WriteAllText(CommonProperty.path + "config\\透视配置.json", JsonConvert.SerializeObject(espconfig));
    }

}