﻿namespace PGE.Common;
public class CommonMethod
{
    public static uint GetImGuiColor(float r, float g, float b, float w = 1f)
    {
        byte red = (byte)(r);
        byte green = (byte)(g);
        byte blue = (byte)(b);
        byte alpha = (byte)(w);
        return (uint)((alpha << 24) | (blue << 16) | (green << 8) | red);
    }


    public static uint GetImGuiColor(System.Numerics.Vector3 v3, float w = 1f)
    {
        byte red = (byte)(v3.X * 255);
        byte green = (byte)(v3.Y * 255);
        byte blue = (byte)(v3.Z * 255);
        byte alpha = (byte)(w * 255);
        return (uint)((alpha << 24) | (blue << 16) | (green << 8) | red);
    }

    public static void GetRGBAFromImGuiColor(uint imGuiColor, out float r, out float g, out float b)
    {
        byte red = (byte)(imGuiColor & 0xff);
        byte green = (byte)((imGuiColor >> 8) & 0xff);
        byte blue = (byte)((imGuiColor >> 16) & 0xff);
        //byte alpha = (byte)((imGuiColor >> 24) & 0xff);

        r = red;
        g = green;
        b = blue;
        //w = alpha;
    }

    public static System.Numerics.Vector3 GetRGBAFromImGuiColor(uint imGuiColor)
    {
        byte red = (byte)(imGuiColor & 0xff);
        byte green = (byte)((imGuiColor >> 8) & 0xff);
        byte blue = (byte)((imGuiColor >> 16) & 0xff);
        //byte alpha = (byte)((imGuiColor >> 24) & 0xff);

        return new System.Numerics.Vector3()
        {
            X = red / (float)255,
            Y = green / (float)255,
            Z = blue / (float)255
        };
        //w = alpha;
    }

    public static IList<T> Clone<T>(IList<T> listToClone) where T : ICloneable
    {
        return listToClone.Select(item => (T)item.Clone()).ToList();
    }

}