﻿namespace PGE.Common;

public class EspConfig
{
    public Vector3 手持颜色 { get; set; }
    public Vector3 队伍编号 { get; set; }

    public Vector3 倒地 { get; set; }

    public Vector3 可视 { get; set; }

    public Vector3 不可视 { get; set; }

    public Vector3 危险 { get; set; }

    public Vector3 合作者 { get; set; }

    public uint 黑名单颜色 { get; set; }

    public Vector3 人机 { get; set; }

    public Vector3 字体 { get; set; }

    public bool 显示骨骼 { get; set; } = true;

    public bool 自瞄配置2 { get; set; } = false;

    public bool 观战 { get; set; } = false;

    public bool 手持 { get; set; } = true;

    public bool 段位 { get; set; } = false;

    public bool 投掷物 { get; set; } = true;

    public bool 骨骼 { get; set; } = true;

    public bool KD { get; set; } = false;

    public bool 距离 { get; set; } = true;

    public bool 射线 { get; set; } = true;

    public bool ID { get; set; } = false;

    public bool 等级 { get; set; } = false;

    public bool 队伍 { get; set; } = true;

    public bool 杀敌 { get; set; } = false;

    public bool 小地图 { get; set; } = true;

    public bool 大地图 { get; set; } = true;

    public bool 血条 { get; set; } = true;
    public bool 串流透视 { get; set; } = true;
    public bool 融合器黑背景填充 { get; set; } = false;

    public bool 粗字体 { get; set; } = true;

    public bool 玩家列表 { get; set; } = false;

    public bool 预警 { get; set; } = true;

    public bool 融合器模式 { get; set; } = false;
    public bool FOV { get; set; } = false;

    public bool 提前量 { get; set; } = false;
    public bool 透视载具 { get; set; } = false;
    public bool 骨灰盒 { get; set; } = false;
    public bool 空投 { get; set; } = false;
    public bool 大地图载具 { get; set; } = false;
    public bool 透视物资 { get; set; } = false;
    public float 骨骼粗细 { get; set; } = 1.5f;
    public int 字体大小 { get; set; } = 15;
    public int 物资字体大小 { get; set; } = 15;
    public float 小地图大小 { get; set; } = 5;
    public float 大地图大小 { get; set; } = 9;
    public int 手持距离 { get; set; } = 100;
    public int 透视距离 { get; set; } = 600;
    public int 载具距离 { get; set; } = 300;
    public int 物资距离 { get; set; } = 50;
    public int 帧延迟 { get; set; } = 0;

    public Vector3 A物资 { get; set; }
    public Vector3 B物资 { get; set; }
    public Vector3 C物资 { get; set; }
    public Vector3 D物资 { get; set; }
    public Vector3 col载具 { get; set; }
    public Vector3 col投掷物 { get; set; }

}