﻿namespace PGE
{
    public struct Vector3Int
    {
        public int x;

        public int y;

        public int z;
    }
}
