﻿namespace PGE;

public class 玩家列表
{
    public ulong addr;

    public string name = "";

    public uint TeamID = 12345;

    public uint 等级 = 12345;

    public float 伤害 = 0;

    public string 状态 = "?";

    public bool 死亡 = false;

    public int 人机 = 0;

    public string 段位 = "";

    public string KD = "";
}