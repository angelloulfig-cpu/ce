﻿using PGE;

public class Class4
{
    public ulong ADDR;

    public ulong DroppedItemGroup;

    public string 种类 = "";

    public ulong DroppedItemGroup_2;

    public string name = "";

    public uint 距离;

    public float 时间 = 0;

    public ulong key;

    public Vector3 vector3_原坐标;

    public Vector3 vector3_大地图;

    public Vector3 vector3_雷达坐标;

    public Vector2 透视坐标;

    public string ShortName { get; set; }

    public int group { get; set; }

}
