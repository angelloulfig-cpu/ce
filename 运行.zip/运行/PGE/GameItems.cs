﻿using PGE;

public class GameItems
{
    public ulong ulong_0;

    public ulong ulong_1;

    public ulong ulong_2;

    public ulong ulong_3;

    public ulong ulong_4;

    public uint uint_0;

    public string name = "";

    public ulong key;

    public uint 距离;

    public Vector3 vector3_0;

    public Vector3 vector3_1;

    public Vector2 透视坐标;

    public string ShortName { get; set; }

    public int group { get; set; }
}
