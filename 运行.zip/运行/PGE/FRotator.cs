﻿namespace PGE
{
    public struct FRotator
    {
        public float Pitch;

        public float Yaw;

        public float Roll;

        public D3DMATRIX GetAxes()
        {
            return Matrix();
        }

        public D3DMATRIX Matrix()
        {
            Vector3 vector = default(Vector3);
            vector.x = 0f;
            vector.y = 0f;
            vector.z = 0f;
            Vector3 vector2 = vector;
            float num = Pitch * 3.1415925f / 180f;
            float num2 = Yaw * 3.1415925f / 180f;
            float num3 = Roll * 3.1415925f / 180f;
            float num4 = (float)Math.Sin(num);
            float num5 = (float)Math.Cos(num);
            float num6 = (float)Math.Sin(num2);
            float num7 = (float)Math.Cos(num2);
            float num8 = (float)Math.Sin(num3);
            float num9 = (float)Math.Cos(num3);
            D3DMATRIX result = default(D3DMATRIX);
            result._11 = num5 * num7;
            result._12 = num5 * num6;
            result._13 = num4;
            result._14 = 0f;
            result._21 = num8 * num4 * num7 - num9 * num6;
            result._22 = num8 * num4 * num6 + num9 * num7;
            result._23 = (0f - num8) * num5;
            result._24 = 0f;
            result._31 = 0f - (num9 * num4 * num7 + num8 * num6);
            result._32 = num7 * num8 - num9 * num4 * num6;
            result._33 = num9 * num5;
            result._34 = 0f;
            result._41 = vector2.x;
            result._42 = vector2.y;
            result._43 = vector2.z;
            result._44 = 1f;
            return result;
        }
    }
}
