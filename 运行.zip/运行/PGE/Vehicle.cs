﻿using PGE;

public class Vehicle
{
    public ulong ulong_0;

    public ulong ulong_1;

    public string string_0 = "";

    public ulong ulong_2;

    public string name = "";

    public ulong ulong_3;

    public Vector3 YLJKi5MSGo;

    public Vector2 透视坐标;

    public Vector3 原始坐标;

    public uint 距离;

    public string ShortName;

}
