﻿namespace PGE
{
    public struct D3DMATRIX
    {
        public float _11;

        public float _12;

        public float _13;

        public float _14;

        public float _21;

        public float _22;

        public float _23;

        public float _24;

        public float _31;

        public float _32;

        public float _33;

        public float _34;

        public float _41;

        public float _42;

        public float _43;

        public float _44;
    }
}
