﻿namespace PGE
{
    public struct FMargin
    {
        public float Left;

        public float Top;

        public float Right;

        public float Bottom;
    }
}