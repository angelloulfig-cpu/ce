﻿namespace PGE
{
    public struct Vector2
    {
        public float x;

        public float y;
    }
}
