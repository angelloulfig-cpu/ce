﻿using System.Globalization;
using System.IO.Compression;
using System.Management;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace RAIN
{
    public class 写入读取配置文件
    {
        private static string string_0;

        public static byte[] DownloadWebDavFile(string remoteFile, string userName, string passWord)
        {
            WebRequest webRequest = WebRequest.Create(new Uri(remoteFile));
            webRequest.Method = "GET";
            webRequest.Credentials = new NetworkCredential(userName, passWord);
            WebResponse response = webRequest.GetResponse();
            BinaryReader binaryReader = new BinaryReader(response.GetResponseStream());
            byte[] array = new byte[8192];
            byte[] array2 = new byte[(int)response.ContentLength];
            try
            {
                int num = 0;
                int num2 = 0;
                while ((num = binaryReader.Read(array, 0, array.Length)) > 0)
                {
                    Array.Copy(array, 0, array2, num2, num);
                    num2 += num;
                }
                return array2;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                if (binaryReader != null)
                {
                    binaryReader.Close();
                }
            }
        }

        public static string GetMachineID()
        {
            string s = CpuID();
            string s2 = DiskID();
            ulong result = 0uL;
            ulong result2 = 0uL;
            int num = 0;
            try
            {
                if (!ulong.TryParse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result))
                {
                    num = 1 / num;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("CPUID Parse Wrong!");
                Application.Exit();
            }
            try
            {
                if (!ulong.TryParse(s2, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result2))
                {
                    num = 1 / num;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("DISKID Parse Wrong!");
                Application.Exit();
            }
            return (result + result2).ToString("x4").ToUpper().PadLeft(16, 'F')
                .Substring(0, 16);
        }

        public static string Md5(string str)
        {
            try
            {
                using (MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider())
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(str);
                    byte[] array = mD5CryptoServiceProvider.ComputeHash(bytes);
                    mD5CryptoServiceProvider.Clear();
                    string text = "";
                    for (int i = 0; i < array.Length; i++)
                    {
                        text += array[i].ToString("X").PadLeft(2, '0');
                    }
                    str = text.ToLower();
                    return str;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return str;
            }
        }

        public static string Md5(byte[] byteValue)
        {
            string result = "";
            if (byteValue != null && byteValue.Length != 0)
            {
                try
                {
                    using (MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider())
                    {
                        byte[] array = mD5CryptoServiceProvider.ComputeHash(byteValue);
                        mD5CryptoServiceProvider.Clear();
                        string text = "";
                        for (int i = 0; i < array.Length; i++)
                        {
                            text += array[i].ToString("X").PadLeft(2, '0');
                        }
                        result = text.ToLower();
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return result;
                }
            }
            return result;
        }

        public static string Sha256(byte[] buffer)
        {
            string result = "";
            if (buffer == null && buffer.Length != 0)
            {
                using (SHA256 sHA = SHA256.Create())
                {
                    return BitConverter.ToString(sHA.ComputeHash(buffer)).Replace("-", string.Empty);
                }
            }
            return result;
        }

        public static string Sha256(string str)
        {
            try
            {
                using (SHA256 sHA = SHA256.Create())
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(str);
                    str = BitConverter.ToString(sHA.ComputeHash(bytes)).Replace("-", string.Empty);
                    return str;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return str;
            }
        }

        public static byte[] Compress(byte[] inputBytes)
        {
            using (MemoryStream memoryStream = new MemoryStream())
            {
                using (GZipStream gZipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
                {
                    gZipStream.Write(inputBytes, 0, inputBytes.Length);
                    gZipStream.Close();
                }
                return memoryStream.ToArray();
            }
        }

        public static byte[] Decompress(byte[] inputBytes)
        {
            using (MemoryStream stream = new MemoryStream(inputBytes))
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (GZipStream gZipStream = new GZipStream(stream, CompressionMode.Decompress))
                    {
                        gZipStream.CopyTo(memoryStream);
                        gZipStream.Close();
                    }
                    return memoryStream.ToArray();
                }
            }
        }

        public static string Compress(string input)
        {
            return Convert.ToBase64String(Compress(Encoding.UTF8.GetBytes(input)));
        }

        public static string Decompress(string input)
        {
            byte[] bytes = Decompress(Convert.FromBase64String(input));
            return Encoding.UTF8.GetString(bytes);
        }

        public static string DiskID()
        {
            string text = Environment.GetEnvironmentVariable("windir").Substring(0, 1);
            new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObject managementObject = new ManagementObject("win32_logicaldisk.deviceid=\"" + text + ":\"");
            managementObject.Get();
            return managementObject.GetPropertyValue("VolumeSerialNumber").ToString();
        }

        public static string CpuID()
        {
            string result = null;
            try
            {
                using (ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator = new ManagementClass("win32_Processor").GetInstances().GetEnumerator())
                {
                    if (managementObjectEnumerator.MoveNext())
                    {
                        return ((ManagementObject)managementObjectEnumerator.Current).Properties["Processorid"].Value.ToString();
                    }
                    return result;
                }
            }
            catch
            {
                return "BFEBFBFF000506E3";
            }
        }

        public static string AESEncrypt(string plainStr, string Key = "=kAppek8_d21asj1")
        {
            byte[] bytes = Encoding.UTF8.GetBytes(Key.PadLeft(16, 'F').Substring(0, 16));
            byte[] bytes2 = Encoding.UTF8.GetBytes(plainStr);
            using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
            {
                rijndaelManaged.Key = bytes;
                rijndaelManaged.Mode = CipherMode.ECB;
                rijndaelManaged.Padding = PaddingMode.PKCS7;
                byte[] array = rijndaelManaged.CreateEncryptor().TransformFinalBlock(bytes2, 0, bytes2.Length);
                return Convert.ToBase64String(array, 0, array.Length);
            }
        }

        public static string AESDEncrypt(string encryptStr, string Key = "=kAppek8_d21asj1")
        {
            byte[] bytes = Encoding.UTF8.GetBytes(Key.PadLeft(16, 'F').Substring(0, 16));
            byte[] array = Convert.FromBase64String(encryptStr);
            using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
            {
                rijndaelManaged.Key = bytes;
                rijndaelManaged.Mode = CipherMode.ECB;
                rijndaelManaged.Padding = PaddingMode.PKCS7;
                byte[] bytes2 = rijndaelManaged.CreateDecryptor().TransformFinalBlock(array, 0, array.Length);
                return Encoding.UTF8.GetString(bytes2);
            }
        }

        [DllImport("kernel32")]
        private static extern bool WritePrivateProfileString(string lpAppName, string lpKeyName, string lpString, string lpFileName);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, byte[] lpReturnedString, int nSize, string lpFileName);

        public static void 初始化配置文件(string AFileName)
        {
            FileInfo fileInfo = new FileInfo(AFileName);
            if (!fileInfo.Exists)
            {
                using (StreamWriter streamWriter = new StreamWriter(AFileName, false, Encoding.Default))
                {
                    try
                    {
                        streamWriter.Write("#RAIN config file.");
                        streamWriter.Close();
                    }
                    catch
                    {
                        throw new ApplicationException("Ini文件不存在");
                    }
                }
            }
            string_0 = fileInfo.FullName;
        }

        public static void 写入配置文件(string Section, string Ident, string Value)
        {
            if (!WritePrivateProfileString(Section, Ident, Value, string_0))
            {
                throw new ApplicationException("写Ini文件出错");
            }
        }

        public static string 读取配置文件(string Section, string Ident, string Default)
        {
            byte[] array = new byte[65535];
            int privateProfileString = GetPrivateProfileString(Section, Ident, Default, array, array.GetUpperBound(0), string_0);
            return Encoding.GetEncoding(0).GetString(array).Substring(0, privateProfileString)
                .Trim();
        }
    }
}
