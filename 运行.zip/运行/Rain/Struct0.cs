﻿internal struct Struct0
{
    public ulong ulong_0;

    public ulong ulong_1;

    public ulong Widget;
}
