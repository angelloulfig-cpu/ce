﻿internal class 雷达
{
    public string 玩家;

    public string 物资;

    public string 载具;

    public string 盒子;

    public string 地图;

    public string 毒圈;

    public string 玩家信息;

    public string 标记;

    public string 雷达数据()
    {
        return "{\"Player\":[" + 玩家 + "],\"Goods\":[" + 物资 + "],\"Box\":[" + 盒子 + "],\"Car\":[" + 载具 + "],\"Control\":[" + 玩家信息 + "],\"Marker\":[" + 标记 + "],\"Maps\":" + 地图 + ",\"Game\":[" + 毒圈 + "]}";
    }

    public void 雷达初始化数据()
    {
        玩家 = "";
        物资 = "";
        载具 = "";
        地图 = "";
        盒子 = "";
        毒圈 = "";
        玩家信息 = "";
        标记 = "";
    }
}
