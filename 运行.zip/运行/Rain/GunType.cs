﻿namespace RAIN
{
    public class GunType
    {
        public int TypeID = 99;

        public string TypeName = "投掷物";

        public int AIMKEY1 = 0;

        public int AIMKEY2 = 0;

        public int AIM部位 = 0;

        public int Recoil;

        public int LOCKKEY = 0;

        public int LOCK部位 = 0;

        public int 倒地KEY = 0;

        public int AimDelay = 0;

        public int AimDistince = 0;

        public int AimRange = 0;

        public int AimSmooth = 1;

        public int AimAdjust;

        public int MoveX = 100;

        public bool UseY = true;

        public int MoveY = 100;

        public bool AimRandom;

        public int RandomValue = 100;

        public int Aim优先级;

        public bool 动态范围;

        public bool 跳过击杀;

        public bool 开镜自瞄;
    }
}
