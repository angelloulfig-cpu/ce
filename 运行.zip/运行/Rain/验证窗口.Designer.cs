﻿using ReaLTaiizor.Controls;

namespace PUBG
{
    partial class 验证窗口
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            poisonTabControl1 = new PoisonTabControl();
            tabPage3 = new System.Windows.Forms.TabPage();
            aloneButton4 = new AloneButton();
            dungeonHeaderLabel5 = new DungeonHeaderLabel();
            dungeonHeaderLabel6 = new DungeonHeaderLabel();
            aloneButton1 = new AloneButton();
            smallTextBox2 = new SmallTextBox();
            smallTextBox3 = new SmallTextBox();
            tabPage4 = new System.Windows.Forms.TabPage();
            dungeonHeaderLabel3 = new DungeonHeaderLabel();
            dungeonHeaderLabel2 = new DungeonHeaderLabel();
            dungeonHeaderLabel1 = new DungeonHeaderLabel();
            aloneButton2 = new AloneButton();
            smallTextBox4 = new SmallTextBox();
            smallTextBox5 = new SmallTextBox();
            smallTextBox6 = new SmallTextBox();
            tabPage2 = new System.Windows.Forms.TabPage();
            dungeonHeaderLabel4 = new DungeonHeaderLabel();
            dungeonHeaderLabel7 = new DungeonHeaderLabel();
            aloneButton3 = new AloneButton();
            smallTextBox1 = new SmallTextBox();
            smallTextBox7 = new SmallTextBox();
            poisonTabControl1.SuspendLayout();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // poisonTabControl1
            // 
            poisonTabControl1.Controls.Add(tabPage3);
            poisonTabControl1.Controls.Add(tabPage4);
            poisonTabControl1.Controls.Add(tabPage2);
            poisonTabControl1.Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold);
            poisonTabControl1.Location = new Point(1, 62);
            poisonTabControl1.MaximumSize = new Size(267, 209);
            poisonTabControl1.MinimumSize = new Size(267, 209);
            poisonTabControl1.Name = "poisonTabControl1";
            poisonTabControl1.Padding = new Point(6, 8);
            poisonTabControl1.SelectedIndex = 0;
            poisonTabControl1.Size = new Size(267, 209);
            poisonTabControl1.TabIndex = 2;
            poisonTabControl1.UseSelectable = true;
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.Transparent;
            tabPage3.Controls.Add(aloneButton4);
            tabPage3.Controls.Add(dungeonHeaderLabel5);
            tabPage3.Controls.Add(dungeonHeaderLabel6);
            tabPage3.Controls.Add(aloneButton1);
            tabPage3.Controls.Add(smallTextBox2);
            tabPage3.Controls.Add(smallTextBox3);
            tabPage3.Location = new Point(4, 38);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(259, 167);
            tabPage3.TabIndex = 0;
            tabPage3.Text = "登录";
            // 
            // aloneButton4
            // 
            aloneButton4.EnabledCalc = true;
            aloneButton4.Font = new Font("Segoe UI", 9F);
            aloneButton4.ForeColor = Color.FromArgb(124, 133, 142);
            aloneButton4.Location = new Point(18, 126);
            aloneButton4.Name = "aloneButton4";
            aloneButton4.Size = new Size(40, 30);
            aloneButton4.TabIndex = 131;
            aloneButton4.Text = "换绑";
            // 
            // dungeonHeaderLabel5
            // 
            dungeonHeaderLabel5.AutoSize = true;
            dungeonHeaderLabel5.BackColor = Color.Transparent;
            dungeonHeaderLabel5.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dungeonHeaderLabel5.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonHeaderLabel5.Location = new Point(18, 75);
            dungeonHeaderLabel5.Name = "dungeonHeaderLabel5";
            dungeonHeaderLabel5.Size = new Size(60, 20);
            dungeonHeaderLabel5.TabIndex = 130;
            dungeonHeaderLabel5.Text = "密码：";
            // 
            // dungeonHeaderLabel6
            // 
            dungeonHeaderLabel6.AutoSize = true;
            dungeonHeaderLabel6.BackColor = Color.Transparent;
            dungeonHeaderLabel6.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dungeonHeaderLabel6.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonHeaderLabel6.Location = new Point(18, 33);
            dungeonHeaderLabel6.Name = "dungeonHeaderLabel6";
            dungeonHeaderLabel6.Size = new Size(60, 20);
            dungeonHeaderLabel6.TabIndex = 129;
            dungeonHeaderLabel6.Text = "账号：";
            // 
            // aloneButton1
            // 
            aloneButton1.EnabledCalc = true;
            aloneButton1.Font = new Font("Segoe UI", 9F);
            aloneButton1.ForeColor = Color.FromArgb(124, 133, 142);
            aloneButton1.Location = new Point(160, 126);
            aloneButton1.Name = "aloneButton1";
            aloneButton1.Size = new Size(81, 30);
            aloneButton1.TabIndex = 128;
            aloneButton1.Text = "登录";
            // 
            // smallTextBox2
            // 
            smallTextBox2.BackColor = Color.Transparent;
            smallTextBox2.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox2.CustomBGColor = Color.White;
            smallTextBox2.Font = new Font("Tahoma", 11F);
            smallTextBox2.ForeColor = Color.DimGray;
            smallTextBox2.Location = new Point(84, 72);
            smallTextBox2.MaxLength = 32767;
            smallTextBox2.Multiline = false;
            smallTextBox2.Name = "smallTextBox2";
            smallTextBox2.ReadOnly = false;
            smallTextBox2.Size = new Size(157, 28);
            smallTextBox2.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox2.TabIndex = 126;
            smallTextBox2.TextAlignment = HorizontalAlignment.Left;
            smallTextBox2.UseSystemPasswordChar = true;
            // 
            // smallTextBox3
            // 
            smallTextBox3.BackColor = Color.Transparent;
            smallTextBox3.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox3.CustomBGColor = Color.White;
            smallTextBox3.Font = new Font("Tahoma", 11F);
            smallTextBox3.ForeColor = Color.DimGray;
            smallTextBox3.Location = new Point(84, 30);
            smallTextBox3.MaxLength = 32767;
            smallTextBox3.Multiline = false;
            smallTextBox3.Name = "smallTextBox3";
            smallTextBox3.ReadOnly = false;
            smallTextBox3.Size = new Size(157, 28);
            smallTextBox3.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox3.TabIndex = 125;
            smallTextBox3.TextAlignment = HorizontalAlignment.Left;
            smallTextBox3.UseSystemPasswordChar = false;
            // 
            // tabPage4
            // 
            tabPage4.BackColor = Color.Transparent;
            tabPage4.Controls.Add(dungeonHeaderLabel3);
            tabPage4.Controls.Add(dungeonHeaderLabel2);
            tabPage4.Controls.Add(dungeonHeaderLabel1);
            tabPage4.Controls.Add(aloneButton2);
            tabPage4.Controls.Add(smallTextBox4);
            tabPage4.Controls.Add(smallTextBox5);
            tabPage4.Controls.Add(smallTextBox6);
            tabPage4.Location = new Point(4, 36);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(192, 60);
            tabPage4.TabIndex = 1;
            tabPage4.Text = "注册";
            // 
            // dungeonHeaderLabel3
            // 
            dungeonHeaderLabel3.AutoSize = true;
            dungeonHeaderLabel3.BackColor = Color.Transparent;
            dungeonHeaderLabel3.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dungeonHeaderLabel3.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonHeaderLabel3.Location = new Point(17, 91);
            dungeonHeaderLabel3.Name = "dungeonHeaderLabel3";
            dungeonHeaderLabel3.Size = new Size(60, 20);
            dungeonHeaderLabel3.TabIndex = 124;
            dungeonHeaderLabel3.Text = "卡密：";
            // 
            // dungeonHeaderLabel2
            // 
            dungeonHeaderLabel2.AutoSize = true;
            dungeonHeaderLabel2.BackColor = Color.Transparent;
            dungeonHeaderLabel2.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dungeonHeaderLabel2.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonHeaderLabel2.Location = new Point(17, 57);
            dungeonHeaderLabel2.Name = "dungeonHeaderLabel2";
            dungeonHeaderLabel2.Size = new Size(60, 20);
            dungeonHeaderLabel2.TabIndex = 123;
            dungeonHeaderLabel2.Text = "密码：";
            // 
            // dungeonHeaderLabel1
            // 
            dungeonHeaderLabel1.AutoSize = true;
            dungeonHeaderLabel1.BackColor = Color.Transparent;
            dungeonHeaderLabel1.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dungeonHeaderLabel1.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonHeaderLabel1.Location = new Point(17, 23);
            dungeonHeaderLabel1.Name = "dungeonHeaderLabel1";
            dungeonHeaderLabel1.Size = new Size(60, 20);
            dungeonHeaderLabel1.TabIndex = 122;
            dungeonHeaderLabel1.Text = "账号：";
            // 
            // aloneButton2
            // 
            aloneButton2.EnabledCalc = true;
            aloneButton2.Font = new Font("Segoe UI", 9F);
            aloneButton2.ForeColor = Color.FromArgb(124, 133, 142);
            aloneButton2.Location = new Point(160, 126);
            aloneButton2.Name = "aloneButton2";
            aloneButton2.Size = new Size(81, 30);
            aloneButton2.TabIndex = 8;
            aloneButton2.Text = "注册";
            // 
            // smallTextBox4
            // 
            smallTextBox4.BackColor = Color.Transparent;
            smallTextBox4.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox4.CustomBGColor = Color.White;
            smallTextBox4.Font = new Font("Tahoma", 11F);
            smallTextBox4.ForeColor = Color.DimGray;
            smallTextBox4.Location = new Point(83, 88);
            smallTextBox4.MaxLength = 32767;
            smallTextBox4.Multiline = false;
            smallTextBox4.Name = "smallTextBox4";
            smallTextBox4.ReadOnly = false;
            smallTextBox4.Size = new Size(157, 28);
            smallTextBox4.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox4.TabIndex = 7;
            smallTextBox4.TextAlignment = HorizontalAlignment.Left;
            smallTextBox4.UseSystemPasswordChar = false;
            // 
            // smallTextBox5
            // 
            smallTextBox5.BackColor = Color.Transparent;
            smallTextBox5.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox5.CustomBGColor = Color.White;
            smallTextBox5.Font = new Font("Tahoma", 11F);
            smallTextBox5.ForeColor = Color.DimGray;
            smallTextBox5.Location = new Point(83, 54);
            smallTextBox5.MaxLength = 32767;
            smallTextBox5.Multiline = false;
            smallTextBox5.Name = "smallTextBox5";
            smallTextBox5.ReadOnly = false;
            smallTextBox5.Size = new Size(157, 28);
            smallTextBox5.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox5.TabIndex = 6;
            smallTextBox5.TextAlignment = HorizontalAlignment.Left;
            smallTextBox5.UseSystemPasswordChar = false;
            // 
            // smallTextBox6
            // 
            smallTextBox6.BackColor = Color.Transparent;
            smallTextBox6.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox6.CustomBGColor = Color.White;
            smallTextBox6.Font = new Font("Tahoma", 11F);
            smallTextBox6.ForeColor = Color.DimGray;
            smallTextBox6.Location = new Point(83, 20);
            smallTextBox6.MaxLength = 32767;
            smallTextBox6.Multiline = false;
            smallTextBox6.Name = "smallTextBox6";
            smallTextBox6.ReadOnly = false;
            smallTextBox6.Size = new Size(157, 28);
            smallTextBox6.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox6.TabIndex = 5;
            smallTextBox6.TextAlignment = HorizontalAlignment.Left;
            smallTextBox6.UseSystemPasswordChar = false;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.Transparent;
            tabPage2.Controls.Add(dungeonHeaderLabel4);
            tabPage2.Controls.Add(dungeonHeaderLabel7);
            tabPage2.Controls.Add(aloneButton3);
            tabPage2.Controls.Add(smallTextBox1);
            tabPage2.Controls.Add(smallTextBox7);
            tabPage2.Location = new Point(4, 36);
            tabPage2.Name = "tabPage2";
            tabPage2.Size = new Size(192, 60);
            tabPage2.TabIndex = 2;
            tabPage2.Text = "充值";
            // 
            // dungeonHeaderLabel4
            // 
            dungeonHeaderLabel4.AutoSize = true;
            dungeonHeaderLabel4.BackColor = Color.Transparent;
            dungeonHeaderLabel4.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dungeonHeaderLabel4.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonHeaderLabel4.Location = new Point(18, 75);
            dungeonHeaderLabel4.Name = "dungeonHeaderLabel4";
            dungeonHeaderLabel4.Size = new Size(60, 20);
            dungeonHeaderLabel4.TabIndex = 135;
            dungeonHeaderLabel4.Text = "卡密：";
            // 
            // dungeonHeaderLabel7
            // 
            dungeonHeaderLabel7.AutoSize = true;
            dungeonHeaderLabel7.BackColor = Color.Transparent;
            dungeonHeaderLabel7.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dungeonHeaderLabel7.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonHeaderLabel7.Location = new Point(18, 33);
            dungeonHeaderLabel7.Name = "dungeonHeaderLabel7";
            dungeonHeaderLabel7.Size = new Size(60, 20);
            dungeonHeaderLabel7.TabIndex = 134;
            dungeonHeaderLabel7.Text = "账号：";
            // 
            // aloneButton3
            // 
            aloneButton3.EnabledCalc = true;
            aloneButton3.Font = new Font("Segoe UI", 9F);
            aloneButton3.ForeColor = Color.FromArgb(124, 133, 142);
            aloneButton3.Location = new Point(160, 126);
            aloneButton3.Name = "aloneButton3";
            aloneButton3.Size = new Size(81, 30);
            aloneButton3.TabIndex = 133;
            aloneButton3.Text = "充值";
            // 
            // smallTextBox1
            // 
            smallTextBox1.BackColor = Color.Transparent;
            smallTextBox1.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox1.CustomBGColor = Color.White;
            smallTextBox1.Font = new Font("Tahoma", 11F);
            smallTextBox1.ForeColor = Color.DimGray;
            smallTextBox1.Location = new Point(84, 72);
            smallTextBox1.MaxLength = 32767;
            smallTextBox1.Multiline = false;
            smallTextBox1.Name = "smallTextBox1";
            smallTextBox1.ReadOnly = false;
            smallTextBox1.Size = new Size(157, 28);
            smallTextBox1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox1.TabIndex = 132;
            smallTextBox1.TextAlignment = HorizontalAlignment.Left;
            smallTextBox1.UseSystemPasswordChar = false;
            // 
            // smallTextBox7
            // 
            smallTextBox7.BackColor = Color.Transparent;
            smallTextBox7.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox7.CustomBGColor = Color.White;
            smallTextBox7.Font = new Font("Tahoma", 11F);
            smallTextBox7.ForeColor = Color.DimGray;
            smallTextBox7.Location = new Point(84, 30);
            smallTextBox7.MaxLength = 32767;
            smallTextBox7.Multiline = false;
            smallTextBox7.Name = "smallTextBox7";
            smallTextBox7.ReadOnly = false;
            smallTextBox7.Size = new Size(157, 28);
            smallTextBox7.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox7.TabIndex = 131;
            smallTextBox7.TextAlignment = HorizontalAlignment.Left;
            smallTextBox7.UseSystemPasswordChar = false;
            // 
            // 验证窗口
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(270, 272);
            Controls.Add(poisonTabControl1);
            MaximumSize = new Size(270, 272);
            MinimumSize = new Size(270, 272);
            Name = "验证窗口";
            Opacity = 0D;
            Text = "Rain";
            Load += Form2_Load;
            poisonTabControl1.ResumeLayout(false);
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private ReaLTaiizor.Controls.PoisonTabControl poisonTabControl1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private ReaLTaiizor.Controls.AloneButton aloneButton2;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox4;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox5;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox6;
        private System.Windows.Forms.TabPage tabPage2;
        private ReaLTaiizor.Controls.DungeonHeaderLabel dungeonHeaderLabel5;
        private ReaLTaiizor.Controls.DungeonHeaderLabel dungeonHeaderLabel6;
        private ReaLTaiizor.Controls.AloneButton aloneButton1;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox2;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox3;
        private ReaLTaiizor.Controls.DungeonHeaderLabel dungeonHeaderLabel3;
        private ReaLTaiizor.Controls.DungeonHeaderLabel dungeonHeaderLabel2;
        private ReaLTaiizor.Controls.DungeonHeaderLabel dungeonHeaderLabel1;
        private ReaLTaiizor.Controls.DungeonHeaderLabel dungeonHeaderLabel4;
        private ReaLTaiizor.Controls.DungeonHeaderLabel dungeonHeaderLabel7;
        private ReaLTaiizor.Controls.AloneButton aloneButton3;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox1;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox7;
        private ReaLTaiizor.Controls.AloneButton aloneButton4;
    }
}