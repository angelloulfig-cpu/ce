using Rain;


internal static class Program
{
    public static Rains mainForm_0;

    [STAThread]
    private static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.SetCompatibleTextRenderingDefault(false);
        mainForm_0 = new Rains();
        mainForm_0.StartPosition = FormStartPosition.CenterScreen;
        Application.Run(mainForm_0);
    }
}