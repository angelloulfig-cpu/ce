﻿internal class 物资
{
    public ulong ulong_0;

    public uint 距离;

    public ulong key;

    public Dictionary<ulong, GameItems> dictionary_物资 = new Dictionary<ulong, GameItems>();
}
