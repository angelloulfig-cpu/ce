﻿using PGE.Common;
using ReaLTaiizor.Forms;
using System.ComponentModel;
using System.Reflection;

namespace Rain
{
    public partial class 人物列表窗口 : MaterialForm
    {
        private System.Windows.Forms.Timer timer2;

        private ListSortDirection sortdirection = ListSortDirection.Ascending;

        private DataGridViewColumn 记忆排序列 = null;

        private int sortColindex = -1;

        private int VerticalScrollIndex = 0;

        public 人物列表窗口()
        {
            InitializeComponent();
            Type dgvtype = dataGridView_用户列表.GetType();
            PropertyInfo pi = dgvtype.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(dataGridView_用户列表, true, null);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            try
            {
                if (CommonProperty.刷新列表)
                {
                    读取玩家列表数据30s一次();
                }
            }
            catch { }
        }

        private void dataGridView_用户列表_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || !(dataGridView_用户列表.Columns[e.ColumnIndex] is DataGridViewButtonColumn))
            {
                return;
            }

            string name = dataGridView_用户列表.Rows[e.RowIndex].Cells["NameColumn"].Value.ToString();

            if (CommonProperty.Hash_黑名单.Contains(name))
            {
                CommonProperty.Hash_黑名单.Remove(name);
                CommonProperty.Hash_队友.Add(name);
                dataGridView_用户列表.Rows[e.RowIndex].Cells["类型"].ToolTipText = "白名单";
            }
            else if (CommonProperty.Hash_队友.Contains(name))
            {
                CommonProperty.Hash_黑名单.Remove(name);
                CommonProperty.Hash_队友.Remove(name);
                dataGridView_用户列表.Rows[e.RowIndex].Cells["类型"].ToolTipText = "普通";
            }
            else
            {
                CommonProperty.Hash_黑名单.Add(name);
                dataGridView_用户列表.Rows[e.RowIndex].Cells["类型"].ToolTipText = "黑名单";
            }

            using (StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "\\config\\BlackList.ini"))
            {
                foreach (string item in CommonProperty.Hash_黑名单)
                {
                    streamWriter.WriteLine(item.Trim());
                }
            }
            using (StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "\\config\\whitelist.ini"))
            {
                foreach (string item in CommonProperty.HashSet_白名单)
                {
                    streamWriter.WriteLine(item.Trim());
                }
            }
            //CommonProperty.刷新列表 = true;
            读取玩家列表数据30s一次();

        }



        private void 读取玩家列表数据30s一次()
        {
            if (CommonProperty.玩家列表s.Count == 0)
            {
                dataGridView_用户列表.Rows.Clear();
                CommonProperty.刷新列表 = false;
                return;
            }
            else
            {
                try
                {
                    for (int i = 0; i < CommonProperty.玩家列表s.Count; i++)
                    {
                        var player = CommonProperty.玩家列表s[i];
                        if (player.name == "Driver" || player.name == "")
                        {
                            if (player.人机 == 1)
                            {
                                player.name = "人机" + i;
                            }
                            else
                            {
                                continue;
                            }
                        }
                        bool flag = false;
                        string name = player.name;
                        string 存活 = "存活";
                        var btnText = "普通";
                        if (CommonProperty.Hash_黑名单.Contains(name))
                        {
                            btnText = "黑名单";
                        }
                        else if (CommonProperty.Hash_队友.Contains(name))
                        {
                            btnText = "白名单";
                        }
                        if (player.死亡)
                        {
                            存活 = "死亡";
                        }
                        //0 TeamID 1 name  2等级 3KD 4段位   5伤害  6存活 7黑名单
                        foreach (DataGridViewRow item2 in dataGridView_用户列表.Rows)
                        {
                            if (item2.Cells[1].Value != null && item2.Cells[1].Value.ToString() == name)
                            {
                                item2.Cells[0].Value = player.TeamID;
                                item2.Cells[2].Value = player.等级;
                                item2.Cells[3].Value = player.KD;
                                item2.Cells[4].Value = player.段位;
                                item2.Cells[5].Value = player.伤害;
                                item2.Cells[6].Value = 存活;
                                item2.Cells[7].Value = btnText;
                                flag = true;
                                break;
                            }
                        }
                        if (!flag)
                        {
                            DataGridViewRow dataGridViewRow2 = new DataGridViewRow();
                            dataGridViewRow2.CreateCells(dataGridView_用户列表, player.TeamID, player.name, player.等级, player.KD, player.段位, player.伤害, 存活, btnText);
                            dataGridView_用户列表.Rows.Add(dataGridViewRow2);
                        }
                    }
                    CommonProperty.刷新列表 = false;

                    //记忆排序
                    if (记忆排序列 == null)
                    {
                        记忆排序列 = dataGridView_用户列表.Columns["TeamIDColumn"];
                    }

                    dataGridView_用户列表.Sort(记忆排序列, sortdirection);

                    //记忆滚动条
                    if (VerticalScrollIndex < CommonProperty.玩家列表s.Count)
                    {
                        dataGridView_用户列表.FirstDisplayedScrollingRowIndex = VerticalScrollIndex;
                    }
                }
                catch
                {
                    return;
                    //MessageBox.Show(ex.Message);
                }
            }
        }


        private void dataGridView_用户列表_Sorted(object sender, EventArgs e)
        {
            记忆排序列 = dataGridView_用户列表.SortedColumn;
            sortColindex = 记忆排序列.Index;
            sortdirection = dataGridView_用户列表.SortOrder == SortOrder.Ascending ? ListSortDirection.Ascending : ListSortDirection.Descending;
        }

        private void dataGridView_用户列表_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow dgr = dataGridView_用户列表.Rows[e.RowIndex];
                try
                {
                    if (dgr.Cells[6].Value.ToString() == "死亡")
                    {
                        e.CellStyle.ForeColor = Color.Red;
                    }
                }
                catch
                {

                }
            }
        }

        private void dataGridView_用户列表_Scroll(object sender, ScrollEventArgs e)
        {
            if (e.ScrollOrientation == ScrollOrientation.VerticalScroll)
            {
                VerticalScrollIndex = e.NewValue;
            }
        }
    }
}
