﻿namespace RAIN
{
    public class 物资info
    {
        public string shortName = "";

        public bool showItem;

        public int group;
    }
}
