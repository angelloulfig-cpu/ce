using System.Runtime.CompilerServices;

namespace RAIN
{
    public class 血量json
    {
        [CompilerGenerated]
        private uint v1;

        [CompilerGenerated]
        private uint v2;

        [CompilerGenerated]
        private uint v3;

        [CompilerGenerated]
        private uint v4;

        [CompilerGenerated]
        private uint v5;

        [CompilerGenerated]
        private uint v6;

        [CompilerGenerated]
        private uint v7;

        [CompilerGenerated]
        private uint v8;

        [CompilerGenerated]
        private uint v9;

        [CompilerGenerated]
        private uint v10;

        [CompilerGenerated]
        private uint v11;

        [CompilerGenerated]
        private uint v12;

        [CompilerGenerated]
        private uint v13;

        [CompilerGenerated]
        private uint v14;

        [CompilerGenerated]
        private uint v15;

        [CompilerGenerated]
        private uint v16;

        public uint V1
        {
            [CompilerGenerated]
            get
            {
                return this.v1;
            }
            [CompilerGenerated]
            set
            {
                this.v1 = value;
            }
        }

        public uint V2
        {
            [CompilerGenerated]
            get
            {
                return this.v2;
            }
            [CompilerGenerated]
            set
            {
                this.v2 = value;
            }
        }

        public uint V3
        {
            [CompilerGenerated]
            get
            {
                return this.v3;
            }
            [CompilerGenerated]
            set
            {
                this.v3 = value;
            }
        }

        public uint V4
        {
            [CompilerGenerated]
            get
            {
                return this.v4;
            }
            [CompilerGenerated]
            set
            {
                this.v4 = value;
            }
        }

        public uint V5
        {
            [CompilerGenerated]
            get
            {
                return this.v5;
            }
            [CompilerGenerated]
            set
            {
                this.v5 = value;
            }
        }

        public uint V6
        {
            [CompilerGenerated]
            get
            {
                return this.v6;
            }
            [CompilerGenerated]
            set
            {
                this.v6 = value;
            }
        }

        public uint V7
        {
            [CompilerGenerated]
            get
            {
                return this.v7;
            }
            [CompilerGenerated]
            set
            {
                this.v7 = value;
            }
        }

        public uint V8
        {
            [CompilerGenerated]
            get
            {
                return this.v8;
            }
            [CompilerGenerated]
            set
            {
                this.v8 = value;
            }
        }

        public uint V9
        {
            [CompilerGenerated]
            get
            {
                return this.v9;
            }
            [CompilerGenerated]
            set
            {
                this.v9 = value;
            }
        }


        public uint V10
        {
            [CompilerGenerated]
            get
            {
                return this.v10;
            }
            [CompilerGenerated]
            set
            {
                this.v10 = value;
            }
        }

        public uint V11
        {
            [CompilerGenerated]
            get
            {
                return this.v11;
            }
            [CompilerGenerated]
            set
            {
                this.v11 = value;
            }
        }

        public uint V12
        {
            [CompilerGenerated]
            get
            {
                return this.v12;
            }
            [CompilerGenerated]
            set
            {
                this.v12 = value;
            }
        }

        public uint V13
        {
            [CompilerGenerated]
            get
            {
                return this.v13;
            }
            [CompilerGenerated]
            set
            {
                this.v13 = value;
            }
        }

        public uint V14
        {
            [CompilerGenerated]
            get
            {
                return this.v14;
            }
            [CompilerGenerated]
            set
            {
                this.v14 = value;
            }
        }

        public uint V15
        {
            [CompilerGenerated]
            get
            {
                return this.v15;
            }
            [CompilerGenerated]
            set
            {
                this.v15 = value;
            }
        }

        public uint V16
        {
            [CompilerGenerated]
            get
            {
                return this.v16;
            }
            [CompilerGenerated]
            set
            {
                this.v16 = value;
            }
        }
    }
}
