using System.Runtime.CompilerServices;

namespace RAIN
{
    public class offset
    {
        [CompilerGenerated]
        private ulong Shield0;

        [CompilerGenerated]
        private ulong Uworld0;

        [CompilerGenerated]
        private ulong GNames0;

        [CompilerGenerated]
        private ulong Leve0;

        [CompilerGenerated]
        private ulong GameInstence0;

        [CompilerGenerated]
        private ulong LocalPlayer0;

        [CompilerGenerated]
        private ulong PlayerController0;

        [CompilerGenerated]
        private ulong Actor0;

        [CompilerGenerated]
        private ulong AcknowledgedPawn0;

        [CompilerGenerated]
        private ulong ObjID0;

        [CompilerGenerated]
        private ulong IDD0;

        [CompilerGenerated]
        private ulong TeamNumber0;

        [CompilerGenerated]
        private ulong Health0;

        [CompilerGenerated]
        private ulong HealthDie0;

        [CompilerGenerated]
        private ulong Audience0;

        [CompilerGenerated]
        private ulong Playname0;

        [CompilerGenerated]
        private ulong PlayerState0;

        [CompilerGenerated]
        private ulong PlayerSatisitc0;

        [CompilerGenerated]
        private ulong Mesh0;

        [CompilerGenerated]
        private ulong Position0;

        [CompilerGenerated]
        private ulong DroppedItemGroup0;

        [CompilerGenerated]
        private ulong DroppedItemGroup_UItem0;

        [CompilerGenerated]
        private ulong 物品一0;

        [CompilerGenerated]
        private ulong 物品二0;

        [CompilerGenerated]
        private ulong 世界转小地图0;

        [CompilerGenerated]
        private ulong 被瞄偏移0;

        [CompilerGenerated]
        private ulong GameState0;

        [CompilerGenerated]
        private ulong LerpSafetyZonePosition0;

        [CompilerGenerated]
        private ulong LerpSafetyZoneRadius0;

        [CompilerGenerated]
        private ulong PoisonGasWarningPosition0;

        [CompilerGenerated]
        private ulong PoisonGasWarningRadius0;

        [CompilerGenerated]
        private ulong RedZonePosition0;

        [CompilerGenerated]
        private ulong RedZoneRadius0;

        [CompilerGenerated]
        private bool ROR0;

        [CompilerGenerated]
        private uint DecryptOne0;

        [CompilerGenerated]
        private int TableOne0;

        [CompilerGenerated]
        private int TableTwo0;

        [CompilerGenerated]
        private uint DecryptTwo0;

        [CompilerGenerated]
        private ulong PlayerCameraManager0;

        [CompilerGenerated]
        private ulong CameraPos0;

        [CompilerGenerated]
        private ulong CameraRot0;

        [CompilerGenerated]
        private ulong CameraFov0;

        [CompilerGenerated]
        private ulong Bone0;

        [CompilerGenerated]
        private ulong BoneArry0;

        [CompilerGenerated]
        private ulong Eyes0;

        [CompilerGenerated]
        private ulong WeaponProcessor0;

        [CompilerGenerated]
        private ulong EquippedWeapons0;

        [CompilerGenerated]
        private ulong CurrentWeaponIndex0;

        [CompilerGenerated]
        private ulong WeaponTrajectoryData0;

        [CompilerGenerated]
        private ulong TrajectoryConfig0;

        [CompilerGenerated]
        private ulong AnimScriptInstance0;

        [CompilerGenerated]
        private ulong ControlRotationCP0;

        [CompilerGenerated]
        private ulong RecoilADSRotationCP0;

        [CompilerGenerated]
        private ulong VehicleRiderComponent0;

        [CompilerGenerated]
        private ulong LastVehiclePawn0;

        [CompilerGenerated]
        private ulong ActorRootComp0;

        [CompilerGenerated]
        private ulong ReplicatedMovement0;

        [CompilerGenerated]
        private ulong Veloctity0;

        [CompilerGenerated]
        private ulong 背包状态0;

        [CompilerGenerated]
        private ulong MapMarker0;

        [CompilerGenerated]
        private ulong PartnerLevel0;

        [CompilerGenerated]
        private ulong SurvivalLevel0;

        [CompilerGenerated]
        private ulong BWasKicked0;

        private ulong WidgetStateMap0;

        private ulong MyHUD0;

        private ulong BlockInputWidgetList0;

        [CompilerGenerated]
        private ulong SelectMinimapSizeIndex0;

        private ulong DroppedItem0;
        private ulong CurrentAmmoData0;
        private ulong ElapsedCookingTime0;
        private ulong TimeTillExplosion0;
        private ulong TrainingMapGrid0;
        private ulong Visibility0;
        private ulong Slot0;
        private ulong LayoutData0;
        private ulong Offsets0;
        private ulong Alignment0;
        private ulong 地图判断0;
        private ulong PlayerArray0;
        private ulong PlayerName0;
        private ulong PlayerTeamid0;
        private ulong DamageDealtOnEnemy0;
        private ulong bIsSpectator0;
        private ulong MatchShortGuid0;

        private ulong AntiCheatCharacterSyncManager0;
        private ulong DormantSoundOnClient0;
        private ulong SoundDataList0;
        private ulong DormantSoundDataSize0;
        private ulong CharacterAkComponent0;
        private ulong AttachParent0;
        private ulong RelativeLocation0;

        [CompilerGenerated]
        private uint v1;

        [CompilerGenerated]
        private uint v2;

        [CompilerGenerated]
        private uint v3;

        [CompilerGenerated]
        private uint v4;

        [CompilerGenerated]
        private uint v5;

        [CompilerGenerated]
        private uint v6;

        [CompilerGenerated]
        private uint v7;

        [CompilerGenerated]
        private uint v8;

        [CompilerGenerated]
        private uint v9;

        [CompilerGenerated]
        private uint v10;

        [CompilerGenerated]
        private uint v11;

        [CompilerGenerated]
        private uint v12;

        [CompilerGenerated]
        private uint v13;

        [CompilerGenerated]
        private uint v14;

        [CompilerGenerated]
        private uint v15;

        [CompilerGenerated]
        private uint v16;

        [CompilerGenerated]
        private ulong MapGrid0;

        public uint V1
        {
            [CompilerGenerated]
            get
            {
                return this.v1;
            }
            [CompilerGenerated]
            set
            {
                this.v1 = value;
            }
        }

        public uint V2
        {
            [CompilerGenerated]
            get
            {
                return this.v2;
            }
            [CompilerGenerated]
            set
            {
                this.v2 = value;
            }
        }

        public uint V3
        {
            [CompilerGenerated]
            get
            {
                return this.v3;
            }
            [CompilerGenerated]
            set
            {
                this.v3 = value;
            }
        }

        public uint V4
        {
            [CompilerGenerated]
            get
            {
                return this.v4;
            }
            [CompilerGenerated]
            set
            {
                this.v4 = value;
            }
        }

        public uint V5
        {
            [CompilerGenerated]
            get
            {
                return this.v5;
            }
            [CompilerGenerated]
            set
            {
                this.v5 = value;
            }
        }

        public uint V6
        {
            [CompilerGenerated]
            get
            {
                return this.v6;
            }
            [CompilerGenerated]
            set
            {
                this.v6 = value;
            }
        }

        public uint V7
        {
            [CompilerGenerated]
            get
            {
                return this.v7;
            }
            [CompilerGenerated]
            set
            {
                this.v7 = value;
            }
        }

        public uint V8
        {
            [CompilerGenerated]
            get
            {
                return this.v8;
            }
            [CompilerGenerated]
            set
            {
                this.v8 = value;
            }
        }

        public uint V9
        {
            [CompilerGenerated]
            get
            {
                return this.v9;
            }
            [CompilerGenerated]
            set
            {
                this.v9 = value;
            }
        }


        public uint V10
        {
            [CompilerGenerated]
            get
            {
                return this.v10;
            }
            [CompilerGenerated]
            set
            {
                this.v10 = value;
            }
        }

        public uint V11
        {
            [CompilerGenerated]
            get
            {
                return this.v11;
            }
            [CompilerGenerated]
            set
            {
                this.v11 = value;
            }
        }

        public uint V12
        {
            [CompilerGenerated]
            get
            {
                return this.v12;
            }
            [CompilerGenerated]
            set
            {
                this.v12 = value;
            }
        }

        public uint V13
        {
            [CompilerGenerated]
            get
            {
                return this.v13;
            }
            [CompilerGenerated]
            set
            {
                this.v13 = value;
            }
        }

        public uint V14
        {
            [CompilerGenerated]
            get
            {
                return this.v14;
            }
            [CompilerGenerated]
            set
            {
                this.v14 = value;
            }
        }

        public uint V15
        {
            [CompilerGenerated]
            get
            {
                return this.v15;
            }
            [CompilerGenerated]
            set
            {
                this.v15 = value;
            }
        }

        public uint V16
        {
            [CompilerGenerated]
            get
            {
                return this.v16;
            }
            [CompilerGenerated]
            set
            {
                this.v16 = value;
            }
        }


        public ulong Shield
        {
            [CompilerGenerated]
            get
            {
                return this.Shield0;
            }
            [CompilerGenerated]
            set
            {
                this.Shield0 = value;
            }
        }

        public ulong Uworld
        {
            [CompilerGenerated]
            get
            {
                return this.Uworld0;
            }
            [CompilerGenerated]
            set
            {
                this.Uworld0 = value;
            }
        }

        public ulong GNames
        {
            [CompilerGenerated]
            get
            {
                return this.GNames0;
            }
            [CompilerGenerated]
            set
            {
                this.GNames0 = value;
            }
        }

        public ulong Leve
        {
            [CompilerGenerated]
            get
            {
                return this.Leve0;
            }
            [CompilerGenerated]
            set
            {
                this.Leve0 = value;
            }
        }

        public ulong GameInstence
        {
            [CompilerGenerated]
            get
            {
                return this.GameInstence0;
            }
            [CompilerGenerated]
            set
            {
                this.GameInstence0 = value;
            }
        }

        public ulong LocalPlayer
        {
            [CompilerGenerated]
            get
            {
                return this.LocalPlayer0;
            }
            [CompilerGenerated]
            set
            {
                this.LocalPlayer0 = value;
            }
        }

        public ulong PlayerController
        {
            [CompilerGenerated]
            get
            {
                return this.PlayerController0;
            }
            [CompilerGenerated]
            set
            {
                this.PlayerController0 = value;
            }
        }

        public ulong Actor
        {
            [CompilerGenerated]
            get
            {
                return this.Actor0;
            }
            [CompilerGenerated]
            set
            {
                this.Actor0 = value;
            }
        }

        public ulong AcknowledgedPawn
        {
            [CompilerGenerated]
            get
            {
                return this.AcknowledgedPawn0;
            }
            [CompilerGenerated]
            set
            {
                this.AcknowledgedPawn0 = value;
            }
        }

        public ulong ObjID
        {
            [CompilerGenerated]
            get
            {
                return this.ObjID0;
            }
            [CompilerGenerated]
            set
            {
                this.ObjID0 = value;
            }
        }

        public ulong IDD
        {
            [CompilerGenerated]
            get
            {
                return this.IDD0;
            }
            [CompilerGenerated]
            set
            {
                this.IDD0 = value;
            }
        }

        public ulong TeamNumber
        {
            [CompilerGenerated]
            get
            {
                return this.TeamNumber0;
            }
            [CompilerGenerated]
            set
            {
                this.TeamNumber0 = value;
            }
        }

        public ulong Health
        {
            [CompilerGenerated]
            get
            {
                return this.Health0;
            }
            [CompilerGenerated]
            set
            {
                this.Health0 = value;
            }
        }

        public ulong HealthDie
        {
            [CompilerGenerated]
            get
            {
                return this.HealthDie0;
            }
            [CompilerGenerated]
            set
            {
                this.HealthDie0 = value;
            }
        }

        public ulong Audience
        {
            [CompilerGenerated]
            get
            {
                return this.Audience0;
            }
            [CompilerGenerated]
            set
            {
                this.Audience0 = value;
            }
        }

        public ulong Playname
        {
            [CompilerGenerated]
            get
            {
                return this.Playname0;
            }
            [CompilerGenerated]
            set
            {
                this.Playname0 = value;
            }
        }

        public ulong PlayerState
        {
            [CompilerGenerated]
            get
            {
                return this.PlayerState0;
            }
            [CompilerGenerated]
            set
            {
                this.PlayerState0 = value;
            }
        }

        public ulong PlayerSatisitc
        {
            [CompilerGenerated]
            get
            {
                return this.PlayerSatisitc0;
            }
            [CompilerGenerated]
            set
            {
                this.PlayerSatisitc0 = value;
            }
        }

        public ulong Mesh
        {
            [CompilerGenerated]
            get
            {
                return this.Mesh0;
            }
            [CompilerGenerated]
            set
            {
                this.Mesh0 = value;
            }
        }

        public ulong Position
        {
            [CompilerGenerated]
            get
            {
                return this.Position0;
            }
            [CompilerGenerated]
            set
            {
                this.Position0 = value;
            }
        }

        public ulong DroppedItemGroup
        {
            [CompilerGenerated]
            get
            {
                return this.DroppedItemGroup0;
            }
            [CompilerGenerated]
            set
            {
                this.DroppedItemGroup0 = value;
            }
        }

        public ulong DroppedItemGroup_UItem
        {
            [CompilerGenerated]
            get
            {
                return this.DroppedItemGroup_UItem0;
            }
            [CompilerGenerated]
            set
            {
                this.DroppedItemGroup_UItem0 = value;
            }
        }

        public ulong 物品一
        {
            [CompilerGenerated]
            get
            {
                return this.物品一0;
            }
            [CompilerGenerated]
            set
            {
                this.物品一0 = value;
            }
        }

        public ulong 物品二
        {
            [CompilerGenerated]
            get
            {
                return this.物品二0;
            }
            [CompilerGenerated]
            set
            {
                this.物品二0 = value;
            }
        }

        public ulong 世界转小地图
        {
            [CompilerGenerated]
            get
            {
                return this.世界转小地图0;
            }
            [CompilerGenerated]
            set
            {
                this.世界转小地图0 = value;
            }
        }

        public ulong 被瞄偏移
        {
            [CompilerGenerated]
            get
            {
                return this.被瞄偏移0;
            }
            [CompilerGenerated]
            set
            {
                this.被瞄偏移0 = value;
            }
        }


        public ulong GameState
        {
            [CompilerGenerated]
            get
            {
                return this.GameState0;
            }
            [CompilerGenerated]
            set
            {
                this.GameState0 = value;
            }
        }

        public ulong LerpSafetyZonePosition
        {
            [CompilerGenerated]
            get
            {
                return this.LerpSafetyZonePosition0;
            }
            [CompilerGenerated]
            set
            {
                this.LerpSafetyZonePosition0 = value;
            }
        }

        public ulong LerpSafetyZoneRadius
        {
            [CompilerGenerated]
            get
            {
                return this.LerpSafetyZoneRadius0;
            }
            [CompilerGenerated]
            set
            {
                this.LerpSafetyZoneRadius0 = value;
            }
        }

        public ulong PoisonGasWarningPosition
        {
            [CompilerGenerated]
            get
            {
                return this.PoisonGasWarningPosition0;
            }
            [CompilerGenerated]
            set
            {
                this.PoisonGasWarningPosition0 = value;
            }
        }

        public ulong PoisonGasWarningRadius
        {
            [CompilerGenerated]
            get
            {
                return this.PoisonGasWarningRadius0;
            }
            [CompilerGenerated]
            set
            {
                this.PoisonGasWarningRadius0 = value;
            }
        }

        public ulong RedZonePosition
        {
            [CompilerGenerated]
            get
            {
                return this.RedZonePosition0;
            }
            [CompilerGenerated]
            set
            {
                this.RedZonePosition0 = value;
            }
        }

        public ulong RedZoneRadius
        {
            [CompilerGenerated]
            get
            {
                return this.RedZoneRadius0;
            }
            [CompilerGenerated]
            set
            {
                this.RedZoneRadius0 = value;
            }
        }

        public bool ROR
        {
            [CompilerGenerated]
            get
            {
                return this.ROR0;
            }
            [CompilerGenerated]
            set
            {
                this.ROR0 = value;
            }
        }

        public uint DecryptOne
        {
            [CompilerGenerated]
            get
            {
                return this.DecryptOne0;
            }
            [CompilerGenerated]
            set
            {
                this.DecryptOne0 = value;
            }
        }

        public int TableOne
        {
            [CompilerGenerated]
            get
            {
                return this.TableOne0;
            }
            [CompilerGenerated]
            set
            {
                this.TableOne0 = value;
            }
        }

        public int TableTwo
        {
            [CompilerGenerated]
            get
            {
                return this.TableTwo0;
            }
            [CompilerGenerated]
            set
            {
                this.TableTwo0 = value;
            }
        }

        public uint DecryptTwo
        {
            [CompilerGenerated]
            get
            {
                return this.DecryptTwo0;
            }
            [CompilerGenerated]
            set
            {
                this.DecryptTwo0 = value;
            }
        }

        public ulong PlayerCameraManager
        {
            [CompilerGenerated]
            get
            {
                return this.PlayerCameraManager0;
            }
            [CompilerGenerated]
            set
            {
                this.PlayerCameraManager0 = value;
            }
        }

        public ulong CameraPos
        {
            [CompilerGenerated]
            get
            {
                return this.CameraPos0;
            }
            [CompilerGenerated]
            set
            {
                this.CameraPos0 = value;
            }
        }

        public ulong CameraRot
        {
            [CompilerGenerated]
            get
            {
                return this.CameraRot0;
            }
            [CompilerGenerated]
            set
            {
                this.CameraRot0 = value;
            }
        }

        public ulong CameraFov
        {
            [CompilerGenerated]
            get
            {
                return this.CameraFov0;
            }
            [CompilerGenerated]
            set
            {
                this.CameraFov0 = value;
            }
        }

        public ulong BoneArry
        {
            [CompilerGenerated]
            get
            {
                return this.BoneArry0;
            }
            [CompilerGenerated]
            set
            {
                this.BoneArry0 = value;
            }
        }

        public ulong Eyes
        {
            [CompilerGenerated]
            get
            {
                return this.Eyes0;
            }
            [CompilerGenerated]
            set
            {
                this.Eyes0 = value;
            }
        }

        public ulong WeaponProcessor
        {
            [CompilerGenerated]
            get
            {
                return this.WeaponProcessor0;
            }
            [CompilerGenerated]
            set
            {
                this.WeaponProcessor0 = value;
            }
        }

        public ulong EquippedWeapons
        {
            [CompilerGenerated]
            get
            {
                return this.EquippedWeapons0;
            }
            [CompilerGenerated]
            set
            {
                this.EquippedWeapons0 = value;
            }
        }

        public ulong CurrentWeaponIndex
        {
            [CompilerGenerated]
            get
            {
                return this.CurrentWeaponIndex0;
            }
            [CompilerGenerated]
            set
            {
                this.CurrentWeaponIndex0 = value;
            }
        }

        public ulong WeaponTrajectoryData
        {
            [CompilerGenerated]
            get
            {
                return this.WeaponTrajectoryData0;
            }
            [CompilerGenerated]
            set
            {
                this.WeaponTrajectoryData0 = value;
            }
        }

        public ulong Bone
        {
            [CompilerGenerated]
            get
            {
                return this.Bone0;
            }
            [CompilerGenerated]
            set
            {
                this.Bone0 = value;
            }
        }

        public ulong TrajectoryConfig
        {
            [CompilerGenerated]
            get
            {
                return this.TrajectoryConfig0;
            }
            [CompilerGenerated]
            set
            {
                this.TrajectoryConfig0 = value;
            }
        }

        public ulong AnimScriptInstance
        {
            [CompilerGenerated]
            get
            {
                return this.AnimScriptInstance0;
            }
            [CompilerGenerated]
            set
            {
                this.AnimScriptInstance0 = value;
            }
        }

        public ulong ControlRotationCP
        {
            [CompilerGenerated]
            get
            {
                return this.ControlRotationCP0;
            }
            [CompilerGenerated]
            set
            {
                this.ControlRotationCP0 = value;
            }
        }

        public ulong RecoilADSRotationCP
        {
            [CompilerGenerated]
            get
            {
                return this.RecoilADSRotationCP0;
            }
            [CompilerGenerated]
            set
            {
                this.RecoilADSRotationCP0 = value;
            }
        }

        public ulong VehicleRiderComponent
        {
            [CompilerGenerated]
            get
            {
                return this.VehicleRiderComponent0;
            }
            [CompilerGenerated]
            set
            {
                this.VehicleRiderComponent0 = value;
            }
        }

        public ulong LastVehiclePawn
        {
            [CompilerGenerated]
            get
            {
                return this.LastVehiclePawn0;
            }
            [CompilerGenerated]
            set
            {
                this.LastVehiclePawn0 = value;
            }
        }

        public ulong ActorRootComp
        {
            [CompilerGenerated]
            get
            {
                return this.ActorRootComp0;
            }
            [CompilerGenerated]
            set
            {
                this.ActorRootComp0 = value;
            }
        }

        public ulong ReplicatedMovement
        {
            [CompilerGenerated]
            get
            {
                return this.ReplicatedMovement0;
            }
            [CompilerGenerated]
            set
            {
                this.ReplicatedMovement0 = value;
            }
        }

        public ulong Veloctity
        {
            [CompilerGenerated]
            get
            {
                return this.Veloctity0;
            }
            [CompilerGenerated]
            set
            {
                this.Veloctity0 = value;
            }
        }


        public ulong MapMarker
        {
            [CompilerGenerated]
            get
            {
                return this.MapMarker0;
            }
            [CompilerGenerated]
            set
            {
                this.MapMarker0 = value;
            }
        }

        public ulong PartnerLevel
        {
            [CompilerGenerated]
            get
            {
                return this.PartnerLevel0;
            }
            [CompilerGenerated]
            set
            {
                this.PartnerLevel0 = value;
            }
        }

        public ulong SurvivalLevel
        {
            [CompilerGenerated]
            get
            {
                return this.SurvivalLevel0;
            }
            [CompilerGenerated]
            set
            {
                this.SurvivalLevel0 = value;
            }
        }

        public ulong BWasKicked
        {
            [CompilerGenerated]
            get
            {
                return this.BWasKicked0;
            }
            [CompilerGenerated]
            set
            {
                this.BWasKicked0 = value;
            }
        }

        public ulong CurrentAmmoData
        {
            [CompilerGenerated]
            get
            {
                return this.CurrentAmmoData0;
            }
            [CompilerGenerated]
            set
            {
                this.CurrentAmmoData0 = value;
            }
        }


        public ulong ElapsedCookingTime
        {
            [CompilerGenerated]
            get
            {
                return this.ElapsedCookingTime0;
            }
            [CompilerGenerated]
            set
            {
                this.ElapsedCookingTime0 = value;
            }
        }

        public ulong TimeTillExplosion
        {
            [CompilerGenerated]
            get
            {
                return this.TimeTillExplosion0;
            }
            [CompilerGenerated]
            set
            {
                this.TimeTillExplosion0 = value;
            }
        }

        public ulong 背包状态
        {
            [CompilerGenerated]
            get
            {
                return this.背包状态0;
            }
            [CompilerGenerated]
            set
            {
                this.背包状态0 = value;
            }
        }


        public ulong WidgetStateMap
        {
            [CompilerGenerated]
            get
            {
                return this.WidgetStateMap0;
            }
            [CompilerGenerated]
            set
            {
                this.WidgetStateMap0 = value;
            }
        }

        public ulong MyHUD
        {
            [CompilerGenerated]
            get
            {
                return this.MyHUD0;
            }
            [CompilerGenerated]
            set
            {
                this.MyHUD0 = value;
            }
        }

        public ulong BlockInputWidgetList
        {
            [CompilerGenerated]
            get
            {
                return this.BlockInputWidgetList0;
            }
            [CompilerGenerated]
            set
            {
                this.BlockInputWidgetList0 = value;
            }
        }


        public ulong SelectMinimapSizeIndex
        {
            [CompilerGenerated]
            get
            {
                return this.SelectMinimapSizeIndex0;
            }
            [CompilerGenerated]
            set
            {
                this.SelectMinimapSizeIndex0 = value;
            }
        }


        public ulong DroppedItem
        {
            [CompilerGenerated]
            get
            {
                return this.DroppedItem0;
            }
            [CompilerGenerated]
            set
            {
                this.DroppedItem0 = value;
            }
        }


        public ulong TrainingMapGrid
        {
            [CompilerGenerated]
            get
            {
                return this.TrainingMapGrid0;
            }
            [CompilerGenerated]
            set
            {
                this.TrainingMapGrid0 = value;
            }
        }


        public ulong Visibility
        {
            [CompilerGenerated]
            get
            {
                return this.Visibility0;
            }
            [CompilerGenerated]
            set
            {
                this.Visibility0 = value;
            }
        }


        public ulong Slot
        {
            [CompilerGenerated]
            get
            {
                return this.Slot0;
            }
            [CompilerGenerated]
            set
            {
                this.Slot0 = value;
            }
        }


        public ulong Offsets
        {
            [CompilerGenerated]
            get
            {
                return this.Offsets0;
            }
            [CompilerGenerated]
            set
            {
                this.Offsets0 = value;
            }
        }

        public ulong Alignment
        {
            [CompilerGenerated]
            get
            {
                return this.Alignment0;
            }
            [CompilerGenerated]
            set
            {
                this.Alignment0 = value;
            }
        }

        public ulong 地图判断
        {
            [CompilerGenerated]
            get
            {
                return this.地图判断0;
            }
            [CompilerGenerated]
            set
            {
                this.地图判断0 = value;
            }
        }

        public ulong LayoutData
        {
            [CompilerGenerated]
            get
            {
                return this.LayoutData0;
            }
            [CompilerGenerated]
            set
            {
                this.LayoutData0 = value;
            }
        }

        public ulong PlayerArray
        {
            [CompilerGenerated]
            get
            {
                return this.PlayerArray0;
            }
            [CompilerGenerated]
            set
            {
                this.PlayerArray0 = value;
            }
        }

        public ulong PlayerName
        {
            [CompilerGenerated]
            get
            {
                return this.PlayerName0;
            }
            [CompilerGenerated]
            set
            {
                this.PlayerName0 = value;
            }
        }

        public ulong PlayerTeamid
        {
            [CompilerGenerated]
            get
            {
                return this.PlayerTeamid0;
            }
            [CompilerGenerated]
            set
            {
                this.PlayerTeamid0 = value;
            }
        }

        public ulong DamageDealtOnEnemy
        {
            [CompilerGenerated]
            get
            {
                return this.DamageDealtOnEnemy0;
            }
            [CompilerGenerated]
            set
            {
                this.DamageDealtOnEnemy0 = value;
            }
        }


        public ulong bIsSpectator
        {
            [CompilerGenerated]
            get
            {
                return this.bIsSpectator0;
            }
            [CompilerGenerated]
            set
            {
                this.bIsSpectator0 = value;
            }
        }

        public ulong MatchShortGuid
        {
            [CompilerGenerated]
            get
            {
                return this.MatchShortGuid0;
            }
            [CompilerGenerated]
            set
            {
                this.MatchShortGuid0 = value;
            }
        }

        public ulong AntiCheatCharacterSyncManager
        {
            [CompilerGenerated]
            get
            {
                return this.AntiCheatCharacterSyncManager0;
            }
            [CompilerGenerated]
            set
            {
                this.AntiCheatCharacterSyncManager0 = value;
            }
        }

        public ulong DormantSoundOnClient
        {
            [CompilerGenerated]
            get
            {
                return this.DormantSoundOnClient0;
            }
            [CompilerGenerated]
            set
            {
                this.DormantSoundOnClient0 = value;
            }
        }

        public ulong SoundDataList
        {
            [CompilerGenerated]
            get
            {
                return this.SoundDataList0;
            }
            [CompilerGenerated]
            set
            {
                this.SoundDataList0 = value;
            }
        }

        public ulong DormantSoundDataSize
        {
            [CompilerGenerated]
            get
            {
                return this.DormantSoundDataSize0;
            }
            [CompilerGenerated]
            set
            {
                this.DormantSoundDataSize0 = value;
            }
        }

        public ulong CharacterAkComponent
        {
            [CompilerGenerated]
            get
            {
                return this.CharacterAkComponent0;
            }
            [CompilerGenerated]
            set
            {
                this.CharacterAkComponent0 = value;
            }
        }

        public ulong AttachParent
        {
            [CompilerGenerated]
            get
            {
                return this.AttachParent0;
            }
            [CompilerGenerated]
            set
            {
                this.AttachParent0 = value;
            }
        }

        public ulong RelativeLocation
        {
            [CompilerGenerated]
            get
            {
                return this.RelativeLocation0;
            }
            [CompilerGenerated]
            set
            {
                this.RelativeLocation0 = value;
            }
        }

        public ulong MapGrids
        {
            [CompilerGenerated]
            get
            {
                return this.MapGrid0;
            }
            [CompilerGenerated]
            set
            {
                this.MapGrid0 = value;
            }
        }
    }
}
