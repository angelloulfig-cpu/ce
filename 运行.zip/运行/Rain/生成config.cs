﻿using PGE.Common;
using System.Reflection;

internal static class 生成config
{
    public static void config()
    {
        try
        {
            Directory.CreateDirectory(CommonProperty.path + "config");
        }
        catch
        {
        }
        string[] manifestResourceNames = Assembly.GetExecutingAssembly().GetManifestResourceNames();
        foreach (string text in manifestResourceNames)
        {
            if (!text.StartsWith("Rain.config"))
            {
                continue;
            }
            string path = text.Replace("Rain.config.", CommonProperty.path + "config/");
            if (File.Exists(path))
            {
                continue;
            }
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(text))
            {
                using (FileStream destination = File.Create(path))
                {
                    stream.CopyTo(destination);
                }
            }
        }
    }
}
