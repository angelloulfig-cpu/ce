﻿using MultiThreadedOverlay;
using Newtonsoft.Json;
using PGE.Common;
using PUBG;
using RAIN;
using ReaLTaiizor.Colors;
using ReaLTaiizor.Forms;
using ReaLTaiizor.Manager;
using ReaLTaiizor.Util;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO.Ports;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using vmmsharp;

namespace Rain
{
    [Obfuscation(Feature = "virtualization", Exclude = false)]
    public partial class Rains : MaterialForm
    {

        [DllImport("/dependent/msdk.dll", EntryPoint = "M_Open", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr M_Open(int port);

        [DllImport("/dependent/msdk.dll", EntryPoint = "M_MoveR", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern int M_MoveR(IntPtr M_hdl, int x, int y);

        [DllImport("/dependent/ddll64.dll", EntryPoint = "MoveR", CallingConvention = CallingConvention.Cdecl)]
        public static extern int MoveR(int dx, int dy);

        [DllImport("/dependent/ddll64.dll", EntryPoint = "OpenDevice", CallingConvention = CallingConvention.Cdecl)]
        public static extern int OpenDevice(string deviceName);

        [DllImport("/dependent/ddll64.dll", EntryPoint = "Close", CallingConvention = CallingConvention.Cdecl)]
        public static extern void Close();

        [DllImport("/dependent/ddll64.dll", EntryPoint = "EnableAccurateDelay", CallingConvention = CallingConvention.Cdecl)]
        public static extern void EnableAccurateDelay();

        [DllImport("/dependent/ddll64.dll", EntryPoint = "SetScreenScale", CallingConvention = CallingConvention.Cdecl)]
        public static extern int SetScreenScale(int X, int Y);

        [DllImport("/dependent/PUBG.dll")]
        private static extern int kmNet_mouse_move(short short_0, short short_1);

        [DllImport("/dependent/PUBG.dll")]
        private static extern int kmNet_init(string string_0, string string_1, string string_2);

        [DllImport("/dependent/PUBG.dll")]
        private static extern int kmNet_keyup(int int_1);

        private readonly MaterialSkinManager materialSkinManager;

        public Vmm vmm;

        private int num001 = 0;

        private int num002 = 0;

        public SerialPort KM_COM = new SerialPort();

        public int 魔盒 = 0;

        public IntPtr M_Handle = IntPtr.Zero;

        private SampleOverlay overlay;

        private NumericUpDown numericUpDown_AimAdjust;

        public ConcurrentQueue<KeyValuePair<string, object>> UICHANGE = new ConcurrentQueue<KeyValuePair<string, object>>();

        public Dictionary<string, GunInfo> GunList = new Dictionary<string, GunInfo>();

        public Dictionary<int, GunType> GunTypeList = new Dictionary<int, GunType>();

        public Dictionary<int, GunType> GunTypeList2 = new Dictionary<int, GunType>();

        public AutoResetEvent are_UICHANGE = new AutoResetEvent(false);

        private ListSortDirection sortdirection = ListSortDirection.Ascending;

        private DataGridViewColumn 记忆排序列 = null;

        private int VerticalScrollIndex = 0;

        public string MqttServer = "";

        public string WebServer = "";

        public string TeamAdd = "";

        public string KDMODE = "20";

        public string qiang = "步枪";

        public int 热键_战斗模式;

        public int 热键_显示物资组0;

        public int 热键_显示物资组1;

        public int 热键_显示物资组2;

        public int 热键_显示物资组3;

        public int 热键_缩小;

        public int 热键_放大;

        public int 热键_自瞄配置2;

        public int 热键_脖子;

        public int 热键_胸部;

        public int 热键_车辆;

        public int 热键_刷新;

        public int 热键_ESP;

        public int 热键_黑名单;

        public int 热键_用户信息;

        public int 添加黑名单;

        public int 热键_显示名字;

        public bool bool_雷达物资 = false;

        public bool bool_雷达载具 = false;

        public bool bool_跳过击杀;

        public bool bool_开镜自瞄;

        public bool bool_动态fov;

        public bool ShowPlayerInfo;

        public bool ShowName;

        public bool ShowAudience;

        public bool ShowKillNum;

        public bool ShowKD;

        public bool ShowDamageAvg;

        public bool ShowRedZone;

        public bool ShowSurvivalLevel;

        public bool ShowDistance;

        public bool ShowRank;

        public bool 显示物资;

        public bool 显示物资组0;

        public bool 显示物资组1;

        public bool 显示物资组2;

        public bool 显示物资组3;

        public bool ShowESP;

        public int 延时;

        public int ControlMode;

        public int ControlHID;

        public int ScreenX;

        public int ScreenY;

        public string 波动率;

        Dictionary<string, 物资info> 物资infoDict;
        public Rains()
        {
            CommonProperty.path = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint, true);
            if (File.Exists(CommonProperty.path + "config/枪.ini"))
            {
                File.Delete(CommonProperty.path + "config/枪.ini");
            }
            if (File.Exists(CommonProperty.path + "config/载具.json"))
            {
                File.Delete(CommonProperty.path + "config/载具.json");
            }
            if (File.Exists(CommonProperty.path + "config/地图.ini"))
            {
                File.Delete(CommonProperty.path + "config/地图.ini");
            }
            if (File.Exists(CommonProperty.path + "config/盒子.ini"))
            {
                File.Delete(CommonProperty.path + "config/盒子.ini");
            }
            if (File.Exists(CommonProperty.path + "config/人机类.ini"))
            {
                File.Delete(CommonProperty.path + "config/人机类.ini");
            }
            if (File.Exists(CommonProperty.path + "config/玩家类.ini"))
            {
                File.Delete(CommonProperty.path + "config/玩家类.ini");
            }

            InitializeComponent();
            materialSkinManager = MaterialSkinManager.Instance;
            //materialSkinManager.AddFormToManage(this);
            //materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new MaterialColorScheme(
                       MaterialPrimary.Green600,
                       MaterialPrimary.Green700,
                       MaterialPrimary.Green200,
                       MaterialAccent.Red100,
                       MaterialTextShade.LIGHT);
            生成config.config();
            写入读取配置文件.初始化配置文件(CommonProperty.path + "config/Config.ini");
            //Type dgvtype = dataGridView_用户列表.GetType();
            //PropertyInfo pi = dgvtype.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);

            System.Timers.Timer timer = new System.Timers.Timer(500.0);
            timer.AutoReset = true;
            timer.Enabled = true;
            if (new 验证窗口 { StartPosition = FormStartPosition.CenterScreen }.ShowDialog() == DialogResult.OK)
            {
                //到期时间.Text = "到期时间: " + CommonProperty.到期时间;
                comboBox_WebServer.Items.AddRange(new global::System.Object[] { $"http://{CommonProperty.WebServer}/" });
                comboBox_MqttServer.Items.AddRange(new object[] { "127.0.0.1", GetIP() });
                读取配置文件();
                using (StreamReader streamReader7 = new StreamReader(CommonProperty.path + "config/物资配置.json"))
                {
                    物资infoDict = JsonConvert.DeserializeObject<Dictionary<string, 物资info>>(streamReader7.ReadToEnd());
                    DataTable dt = new DataTable();
                    DataColumn dc1 = new DataColumn("显示");
                    DataColumn dc2 = new DataColumn("物资名称");
                    DataColumn dc3 = new DataColumn("分组");
                    dt.Columns.Add(dc1);
                    dt.Columns.Add(dc2);
                    dt.Columns.Add(dc3);
                    foreach (KeyValuePair<string, 物资info> item2 in 物资infoDict)
                    {
                        DataRow dr = dt.NewRow();
                        dr[0] = item2.Value.showItem ? "ON" : "OFF";
                        dr[1] = item2.Value.shortName;
                        dr[2] = item2.Value.group == 0 ? "A" :
                            item2.Value.group == 1 ? "B" :
                            item2.Value.group == 2 ? "C" : "D";
                        dt.Rows.Add(dr);
                    }
                    this.poisonDataGridView3.DataSource = dt;
                    //状态2("物资载入成功!Item List Loaded!");
                    Control.CheckForIllegalCrossThreadCalls = false;
                }
            }
            else
            {
                结束进程();
            }
        }

        private void poisonDataGridView物资开关_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                if (this.poisonDataGridView3.Rows[e.RowIndex].Cells[0].Value.Equals("ON"))
                {
                    this.poisonDataGridView3.Rows[e.RowIndex].Cells[0].Value = "OFF";
                }
                else
                {
                    this.poisonDataGridView3.Rows[e.RowIndex].Cells[0].Value = "ON";
                }

                保存物资();
            }
        }

        private void button_Start_Click(object sender, EventArgs e)
        {
            WebServer = comboBox_WebServer.Text;
            if (WebServer == "")
            {
                WebServer = $"http://{CommonProperty.WebServer}/";
                comboBox_WebServer.Text = WebServer;
            }
            保存参数();
            button_Start.Enabled = false;
            comboBox_MqttServer.Enabled = false;
            textBox_ScreenX.Enabled = false;
            textBox_ScreenY.Enabled = false;
            MqttServer = comboBox_MqttServer.Text;

            ScreenX = int.Parse(textBox_ScreenX.Text);
            ScreenY = int.Parse(textBox_ScreenY.Text);
            CommonProperty.X分辨率 = ScreenX;
            CommonProperty.Y分辨率 = ScreenY;

            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            System.IO.Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory + "//MQTT");
            string luj = (System.IO.Directory.GetCurrentDirectory());
            process.StartInfo.FileName = "mqtt.exe";
            process.StartInfo.Arguments = "-c mqtt.conf";
            process.Start();

            if (CommonProperty.NOMqttserver.Split("|").Contains(MqttServer))
            {
                MessageBox.Show("共享服务器错误");
                结束进程();
                return;
            }
            if (MqttServer.Split(".")[0].Length == 4)
            {
                CommonProperty.username = MqttServer.Split(".")[0];
            }

            textBox_URL.Text = WebServer + "?" + CommonProperty.username + "&addr=" + MqttServer;

            Thread thread = new Thread(接收主线程数据);
            thread.IsBackground = true;
            thread.Start();
            Thread threadGameStart = new Thread(GameStart);
            threadGameStart.IsBackground = true;
            threadGameStart.Start();

            textBox_URL.Enabled = true;
            COPYURL.Enabled = true;
            OPENURL.Enabled = true;

        }

        public void GameStart()
        {
            while (true)
            {
                Game class11 = null;
                try
                {
                    UICHANGE.Enqueue(new KeyValuePair<string, object>("地图", "未检测到游戏"));
                    UICHANGE.Enqueue(new KeyValuePair<string, object>("延迟", ""));
                    UICHANGE.Enqueue(new KeyValuePair<string, object>("自瞄状态", ""));
                    are_UICHANGE.Set();
                    class11 = new Game();
                }
                catch
                {

                }
                finally
                {
                    CommonProperty.GameStartSlim.WaitOne();
                    class11?.StopAll();
                    Thread.Sleep(1000);
                    class11 = null;
                    EspOverlay.人物Clear();
                    EspOverlay.载具Clear();
                    EspOverlay.物资Clear();
                    EspOverlay.投掷物Clear();
                    EspOverlay.人物Clear1();
                    CommonProperty.菜单 = true;
                }
                Thread.Sleep(1000);
            }
        }

        private void 接收主线程数据()
        {
            while (true)
            {
                if (CommonProperty.自瞄配置2)
                {
                    if (!CommonProperty.espconfig.EspConfig.自瞄配置2)
                    {
                        if (!GunTypeList.ContainsKey(GetGunTabsType()))
                        {
                            GunTypeList[GetGunTabsType()] = new GunType();
                        }
                        comboBox_AimKey1.SelectedIndex = GunTypeList[GetGunTabsType()].AIMKEY1;
                        comboBox_AimKey2.SelectedIndex = GunTypeList[GetGunTabsType()].AIMKEY2;
                        comboBox_AimAt.SelectedIndex = GunTypeList[GetGunTabsType()].AIM部位;
                        comboBox_LockKey.SelectedIndex = GunTypeList[GetGunTabsType()].LOCKKEY;
                        comboBox_AimLock.SelectedIndex = GunTypeList[GetGunTabsType()].LOCK部位;
                        comboBox_LockGrobbyKey.SelectedIndex = GunTypeList[GetGunTabsType()].倒地KEY;
                        numericUpDown_AimDistince.Value = GunTypeList[GetGunTabsType()].AimDistince;
                        numericUpDown_AimDelay.Value = GunTypeList[GetGunTabsType()].AimDelay;
                        numericUpDown_Recoil.Value = GunTypeList[GetGunTabsType()].Recoil;
                        numericUpDown_AimRange.Value = GunTypeList[GetGunTabsType()].AimRange;
                        numericUpDown_AimSmooth.Value = GunTypeList[GetGunTabsType()].AimSmooth;
                        radioButton_AimUseDistince.Checked = !radioButton_AimUseRange.Checked;
                        numericUpDown_AimX.Value = GunTypeList[GetGunTabsType()].MoveX;
                        numericUpDown_AimY.Value = GunTypeList[GetGunTabsType()].MoveY;
                        radioButton_AimUseRange.Checked = (GunTypeList[GetGunTabsType()].Aim优先级 == 0) ? true : false;
                        checkBox动态FOV.Checked = GunTypeList[GetGunTabsType()].动态范围;
                        checkBox跳过击杀.Checked = GunTypeList[GetGunTabsType()].跳过击杀;
                        checkBox开镜自瞄.Checked = GunTypeList[GetGunTabsType()].开镜自瞄;
                    }
                    else
                    {
                        if (!GunTypeList2.ContainsKey(GetGunTabsType()))
                        {
                            GunTypeList2[GetGunTabsType()] = new GunType();
                        }
                        comboBox_AimKey1.SelectedIndex = GunTypeList2[GetGunTabsType()].AIMKEY1;
                        comboBox_AimKey2.SelectedIndex = GunTypeList2[GetGunTabsType()].AIMKEY2;
                        comboBox_AimAt.SelectedIndex = GunTypeList2[GetGunTabsType()].AIM部位;
                        comboBox_LockKey.SelectedIndex = GunTypeList2[GetGunTabsType()].LOCKKEY;
                        comboBox_AimLock.SelectedIndex = GunTypeList2[GetGunTabsType()].LOCK部位;
                        comboBox_LockGrobbyKey.SelectedIndex = GunTypeList2[GetGunTabsType()].倒地KEY;
                        numericUpDown_AimDistince.Value = GunTypeList2[GetGunTabsType()].AimDistince;
                        numericUpDown_AimDelay.Value = GunTypeList2[GetGunTabsType()].AimDelay;
                        numericUpDown_Recoil.Value = GunTypeList2[GetGunTabsType()].Recoil;
                        numericUpDown_AimRange.Value = GunTypeList2[GetGunTabsType()].AimRange;
                        numericUpDown_AimSmooth.Value = GunTypeList2[GetGunTabsType()].AimSmooth;
                        radioButton_AimUseDistince.Checked = !radioButton_AimUseRange.Checked;
                        numericUpDown_AimX.Value = GunTypeList2[GetGunTabsType()].MoveX;
                        numericUpDown_AimY.Value = GunTypeList2[GetGunTabsType()].MoveY;
                        radioButton_AimUseRange.Checked = (GunTypeList2[GetGunTabsType()].Aim优先级 == 0) ? true : false;
                        checkBox动态FOV.Checked = GunTypeList2[GetGunTabsType()].动态范围;
                        checkBox跳过击杀.Checked = GunTypeList2[GetGunTabsType()].跳过击杀;
                        checkBox开镜自瞄.Checked = GunTypeList2[GetGunTabsType()].开镜自瞄;

                    }
                }
                if (UICHANGE.Count > 0)
                {
                    KeyValuePair<string, object> keyValuePair_0;
                    if (!UICHANGE.TryDequeue(out keyValuePair_0))
                    {
                        continue;
                    }
                    string key = keyValuePair_0.Key;
                    if (key == null)
                    {
                        continue;
                    }

                    switch (key.Length)
                    {
                        case 2:
                            switch (key[0])
                            {
                                case '网':
                                    if (!(key == "网页") || !(textBox_URL.Text != (string)keyValuePair_0.Value))
                                    {
                                        break;
                                    }
                                    if (!base.InvokeRequired)
                                    {
                                        toolStripStatusLabel_自瞄状态.Text = (string)keyValuePair_0.Value;
                                        COPYURL.Enabled = true;
                                        OPENURL.Enabled = true;
                                        break;
                                    }
                                    BeginInvoke(delegate
                                    {
                                        textBox_URL.Text = (string)keyValuePair_0.Value;
                                        COPYURL.Enabled = true;
                                        OPENURL.Enabled = true;
                                    });
                                    break;
                                case '延':
                                    if (!(key == "延迟") || !(UnxXuvxlhp.Text != (string)keyValuePair_0.Value))
                                    {
                                        break;
                                    }
                                    if (!base.InvokeRequired)
                                    {
                                        UnxXuvxlhp.Text = (string)keyValuePair_0.Value;
                                        break;
                                    }
                                    BeginInvoke(delegate
                                    {
                                        UnxXuvxlhp.Text = (string)keyValuePair_0.Value;
                                    });
                                    break;
                                case '地':
                                    if (!(key == "地图") || !(toolStripStatusLabel_MapName.Text != (string)keyValuePair_0.Value))
                                    {
                                        break;
                                    }
                                    if (base.InvokeRequired)
                                    {
                                        BeginInvoke(delegate
                                        {
                                            toolStripStatusLabel_MapName.Text = (string)keyValuePair_0.Value;
                                        });
                                    }
                                    else
                                    {
                                        toolStripStatusLabel_MapName.Text = (string)keyValuePair_0.Value;
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            switch (key[0])
                            {
                                case '自':
                                    if (!(key == "自瞄状态") || !(toolStripStatusLabel_自瞄状态.Text != (string)keyValuePair_0.Value))
                                    {
                                        break;
                                    }
                                    if (!base.InvokeRequired)
                                    {
                                        toolStripStatusLabel_自瞄状态.Text = (string)keyValuePair_0.Value;
                                        break;
                                    }
                                    BeginInvoke(delegate
                                    {
                                        toolStripStatusLabel_自瞄状态.Text = (string)keyValuePair_0.Value;
                                    });
                                    break;
                            }
                            break;
                        case 6:
                            switch (key[5])
                            {
                                case '0':
                                    if (!(key == "显示物资组0"))
                                    {
                                        break;
                                    }
                                    显示物资组0 = bool.Parse((string)keyValuePair_0.Value);
                                    if (base.InvokeRequired)
                                    {
                                        BeginInvoke(delegate
                                        {
                                            checkBox_itemgroup0.Checked = 显示物资组0;
                                        });
                                    }
                                    else
                                    {
                                        checkBox_itemgroup0.Checked = 显示物资组0;
                                    }
                                    break;
                                case '1':
                                    if (!(key == "显示物资组1"))
                                    {
                                        break;
                                    }
                                    显示物资组1 = bool.Parse((string)keyValuePair_0.Value);
                                    if (base.InvokeRequired)
                                    {
                                        BeginInvoke(delegate
                                        {
                                            checkBox_itemgroup1.Checked = 显示物资组1;
                                        });
                                    }
                                    else
                                    {
                                        checkBox_itemgroup1.Checked = 显示物资组1;
                                    }
                                    break;
                                case '2':
                                    if (!(key == "显示物资组2"))
                                    {
                                        break;
                                    }
                                    显示物资组2 = bool.Parse((string)keyValuePair_0.Value);
                                    if (base.InvokeRequired)
                                    {
                                        BeginInvoke(delegate
                                        {
                                            checkBox_itemgroup2.Checked = 显示物资组2;
                                        });
                                    }
                                    else
                                    {
                                        checkBox_itemgroup2.Checked = 显示物资组2;
                                    }
                                    break;
                                case '3':
                                    if (!(key == "显示物资组3"))
                                    {
                                        break;
                                    }
                                    显示物资组3 = bool.Parse((string)keyValuePair_0.Value);
                                    if (base.InvokeRequired)
                                    {
                                        BeginInvoke(delegate
                                        {
                                            checkBox_itemgroup3.Checked = 显示物资组3;
                                        });
                                    }
                                    else
                                    {
                                        checkBox_itemgroup3.Checked = 显示物资组3;
                                    }
                                    break;
                            }
                            break;
                        case 7:
                            switch (key[0])
                            {
                                case '清':
                                    if (!(key == "清理友军黑名单"))
                                    {
                                        break;
                                    }
                                    if (!base.InvokeRequired)
                                    {
                                        textBox_TeamAdd.Text = "";
                                        //listBox_临时队友.Items.Clear();
                                        break;
                                    }
                                    BeginInvoke(delegate
                                    {
                                        textBox_TeamAdd.Text = "";
                                        //listBox_临时队友.Items.Clear();
                                    });
                                    break;
                                case 'S':
                                    if (!(key == "ShowESP"))
                                    {
                                        break;
                                    }
                                    ShowESP = bool.Parse((string)keyValuePair_0.Value);
                                    if (!base.InvokeRequired)
                                    {
                                        checkBox_ESPEnable.Checked = ShowESP;
                                        break;
                                    }
                                    BeginInvoke(delegate
                                    {
                                        checkBox_ESPEnable.Checked = ShowESP;
                                    });
                                    break;
                            }
                            break;
                        case 8:
                            if (!(key == "ShowName"))
                            {
                                break;
                            }
                            ShowName = bool.Parse((string)keyValuePair_0.Value);
                            if (base.InvokeRequired)
                            {
                                BeginInvoke(delegate
                                {
                                    checkBox_ShowName.Checked = ShowName;
                                });
                            }
                            else
                            {
                                checkBox_ShowName.Checked = ShowName;
                            }
                            break;
                        case 12:
                            if (!(key == "ShowVehicles"))
                            {
                                break;
                            }
                            bool_雷达载具 = bool.Parse((string)keyValuePair_0.Value);
                            if (!base.InvokeRequired)
                            {
                                checkBox_ShowVehicles.Checked = bool_雷达载具;
                                break;
                            }
                            BeginInvoke(delegate
                            {
                                checkBox_ShowVehicles.Checked = bool_雷达载具;
                            });
                            break;
                        case 14:
                            if (!(key == "ShowPlayerInfo"))
                            {
                                break;
                            }
                            ShowPlayerInfo = bool.Parse((string)keyValuePair_0.Value);
                            if (base.InvokeRequired)
                            {
                                BeginInvoke(delegate
                                {
                                    checkBox_PlayerInfo.Checked = ShowPlayerInfo;
                                });
                            }
                            else
                            {
                                checkBox_PlayerInfo.Checked = ShowPlayerInfo;
                            }
                            break;
                    }
                }
                else
                {
                    are_UICHANGE.WaitOne();
                    Thread.Sleep(10);
                }
            }
        }

        private void 保存物资()
        {
            foreach (var 物资info in 物资infoDict)
            {
                foreach (DataGridViewRow dataGridViewRow in poisonDataGridView3.Rows)
                {
                    if (dataGridViewRow.Cells[1].Value.Equals(物资info.Value.shortName))
                    {
                        if (!dataGridViewRow.Cells[0].Value.Equals(物资info.Value.showItem ? "ON" : "OFF"))
                        {
                            物资info.Value.showItem = !物资info.Value.showItem;
                        }
                        if (!dataGridViewRow.Cells[2].Value.Equals(物资info.Value.group == 0 ? "A" :
                                物资info.Value.group == 1 ? "B" :
                                物资info.Value.group == 2 ? "C" : "D"))
                        {
                            物资info.Value.group = dataGridViewRow.Cells[2].Value.Equals("A") ? 0 :
                                dataGridViewRow.Cells[2].Value.Equals("B") ? 1 :
                                dataGridViewRow.Cells[2].Value.Equals("C") ? 2 : 3;
                        }
                    }
                }
            }

            System.IO.File.WriteAllText(CommonProperty.path + "config/物资配置.json", JsonConvert.SerializeObject(物资infoDict));

            CommonProperty.保存物资 = true;
            //MessageBox.Show("保存成功!");
        }

        private string GetIP()
        {
            Process cmd = new Process();
            cmd.StartInfo.FileName = "ipconfig.exe";//设置程序名
            cmd.StartInfo.Arguments = "/all";  //自瞄参数
            cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.UseShellExecute = false;
            cmd.StartInfo.CreateNoWindow = true;//不显示窗口（控制台程序是黑屏）
            cmd.Start();
            string info = cmd.StandardOutput.ReadToEnd();
            string pattern = @"\b(?:\d{1,3}\.){3}\d{1,3}\b";
            Match match = Regex.Match(info, pattern);
            if (match.Success)
            {
                string ipAddress = match.Value;
                return ipAddress;
            }
            cmd.WaitForExit();
            cmd.Close();
            return "";
        }

        private void 结束进程()
        {
            if (vmm != null)
            {
                Vmm.CloseAll();
            }
            string environmentVariable = Environment.GetEnvironmentVariable("SystemRoot");
            using (Process process = new Process())
            {
                ProcessStartInfo startInfo = new ProcessStartInfo(environmentVariable + "\\System32\\taskkill.exe", "/f /im mqtt.exe");
                process.StartInfo = startInfo;
                process.StartInfo.UseShellExecute = true;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
            }

            using (Process process = new Process())
            {
                ProcessStartInfo startInfo = new ProcessStartInfo(environmentVariable + "\\System32\\taskkill.exe", "/f /im " + AppDomain.CurrentDomain.FriendlyName);
                process.StartInfo = startInfo;
                process.StartInfo.UseShellExecute = true;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
                process.WaitForExit();
            }

            using (Process process = new Process())
            {
                ProcessStartInfo startInfo = new ProcessStartInfo(environmentVariable + "\\System32\\taskkill.exe", "/f /im Rain.exe ");
                process.StartInfo = startInfo;
                process.StartInfo.UseShellExecute = true;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
                process.WaitForExit();
            }

            Process.GetCurrentProcess().Kill();

            if (overlay != null)
            {
                overlay.Close();
                overlay.Dispose();
                overlay = null;
                EspOverlay.人物Clear();
                EspOverlay.载具Clear();
                EspOverlay.物资Clear();
            }
        }

        private void 保存参数()
        {
            延时 = (int)自瞄延时.Value;
            if (radioButton_KDTPP.Checked)
            {
                写入读取配置文件.写入配置文件("config", "KDGET", "1");
            }
            if (radioButton_KDFPP.Checked)
            {
                写入读取配置文件.写入配置文件("config", "KDGET", "2");
            }
            写入读取配置文件.写入配置文件("config", "ControlMode", ControlMode.ToString());
            写入读取配置文件.写入配置文件("config", "ScreenX", textBox_ScreenX.Text);
            写入读取配置文件.写入配置文件("config", "ScreenY", textBox_ScreenY.Text);
            写入读取配置文件.写入配置文件("config", "ControlHID", ControlHID.ToString());
            写入读取配置文件.写入配置文件("config", "MVPNETTXT", MVPNETTXT.Text);
            写入读取配置文件.写入配置文件("config", "MqttServer", comboBox_MqttServer.Text);
            写入读取配置文件.写入配置文件("config", "WebServer", comboBox_WebServer.Text);
            写入读取配置文件.写入配置文件("config", "ESPEnable", checkBox_ESPEnable.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "wuzi", checkBox_物资.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "PlayerInfo", checkBox_PlayerInfo.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "ShowName", checkBox_ShowName.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "Audience", checkBox_Audience.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "KillNum", checkBox_KillNum.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "KD", checkBox_KD.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "DamageAvg", checkBox_DamageAvg.Checked.ToString());
            //写入读取配置文件.写入配置文件("INFO", "RedZone", checkBox_RedZone.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "SurvivalLevel", checkBox_SurvivalLevel.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "Distance", checkBox_Distance.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "Rank", checkBox_Rank.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "danpai", checkBox_单排.Checked.ToString());
            //写入读取配置文件.写入配置文件("INFO", "FontSize", numericUpDown_FontSize.Value.ToString());
            写入读取配置文件.写入配置文件("INFO", "ShowVehicles", checkBox_ShowVehicles.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "ItemGroup0", checkBox_itemgroup0.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "ItemGroup1", checkBox_itemgroup1.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "ItemGroup2", checkBox_itemgroup2.Checked.ToString());
            写入读取配置文件.写入配置文件("INFO", "ItemGroup3", checkBox_itemgroup3.Checked.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimKey1", comboBox_AimKey1.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimKey2", comboBox_AimKey2.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimAt", comboBox_AimAt.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("AIM", "LockKey", comboBox_LockKey.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimLock", comboBox_AimLock.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("AIM", "LockGrobbyKey", comboBox_LockGrobbyKey.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimDistince", numericUpDown_AimDistince.Value.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimDelay", numericUpDown_AimDelay.Value.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimRange", numericUpDown_AimRange.Value.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimSmooth", numericUpDown_AimSmooth.Value.ToString());
            //写入读取配置文件.写入配置文件("AIM", "AimAdjust", numericUpDown_AimAdjust.Value.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimUseRange", radioButton_AimUseRange.Checked.ToString());
            写入读取配置文件.写入配置文件("AIM", "AimUseDistince", radioButton_AimUseDistince.Checked.ToString());
            //写入读取配置文件.写入配置文件("AIM", "DTFOV", checkBox动态FOV.Checked.ToString());
            //写入读取配置文件.写入配置文件("AIM", "TGJS", checkBox跳过击杀.Checked.ToString());
            写入读取配置文件.写入配置文件("AIM", "ZMYS", 自瞄延时.Value.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ShowItem", 战斗模式.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ShowItemGroup0", comboBox_热键_显示物资组0.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ShowItemGroup1", comboBox_热键_显示物资组1.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ShowItemGroup2", comboBox_热键_显示物资组2.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ShowItemGroup3", comboBox_热键_显示物资组3.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ZoonIn", comboBox_热键_雷达放大.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ZoonOut", comboBox_热键_雷达缩小.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("AIM", "type2", comboBox_热键_自瞄配置2.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ReFlesh", comboBox_热键_数据刷新.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ESP", comboBox_热键_透视开关.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "PlayerInfo", comboBox_热键_玩家信息.SelectedIndex.ToString());
            写入读取配置文件.写入配置文件("HOTKEY", "ADDBlacklist", comboBox_热键_加黑名单.SelectedIndex.ToString());
        }

        private void 读取配置文件()
        {
            if (File.Exists(CommonProperty.path + "config/Blacklist.ini"))
            {
                using (StreamReader streamReader = new StreamReader(CommonProperty.path + "config/Blacklist.ini"))
                {
                    string text = "";
                    while ((text = streamReader.ReadLine()) != null)
                    {
                        if (text.Trim() != "")
                        {
                            CommonProperty.Hash_黑名单.Add(text.Trim());
                        }
                    }
                }
            }
            if (File.Exists(CommonProperty.path + "config/Whitelist.ini"))
            {
                using (StreamReader streamReader2 = new StreamReader(CommonProperty.path + "config/Whitelist.ini"))
                {
                    string text2 = "";
                    while ((text2 = streamReader2.ReadLine()) != null)
                    {
                        if (text2.Trim() != "")
                        {
                            CommonProperty.Hash_队友.Add(text2.Trim());
                        }
                    }
                }
            }
            if (File.Exists(CommonProperty.path + "config/枪.ini"))
            {
                using (StreamReader streamReader3 = new StreamReader(CommonProperty.path + "config/枪.ini"))
                {
                    string text3 = "";
                    while ((text3 = streamReader3.ReadLine()) != null)
                    {
                        GunInfo gunInfo = JsonConvert.DeserializeObject<GunInfo>(text3);
                        GunList[gunInfo.Name] = gunInfo;
                    }
                }
            }
            if (File.Exists(CommonProperty.path + "config/自瞄配置1.ini"))
            {
                string text4 = "";
                using (StreamReader streamReader4 = new StreamReader(CommonProperty.path + "config/自瞄配置1.ini"))
                {
                    while ((text4 = streamReader4.ReadLine()) != null)
                    {
                        GunType gunType = JsonConvert.DeserializeObject<GunType>(text4);
                        if (!GunTypeList.ContainsKey(gunType.TypeID))
                        {
                            GunTypeList[gunType.TypeID] = gunType;
                        }
                    }
                }
            }
            if (File.Exists(CommonProperty.path + "config/自瞄配置2.ini"))
            {
                string text42 = "";
                using (StreamReader streamReader42 = new StreamReader(CommonProperty.path + "config/自瞄配置2.ini"))
                {
                    while ((text42 = streamReader42.ReadLine()) != null)
                    {
                        GunType gunType = JsonConvert.DeserializeObject<GunType>(text42);
                        if (!GunTypeList2.ContainsKey(gunType.TypeID))
                        {
                            GunTypeList2[gunType.TypeID] = gunType;
                        }
                    }
                }
            }
            ControlMode = int.Parse(写入读取配置文件.读取配置文件("config", "ControlMode", "5"));
            ControlHID = int.Parse(写入读取配置文件.读取配置文件("config", "ControlHID", "0"));
            switch (ControlHID)
            {
                case 0:
                    关闭自瞄.Checked = true;
                    break;
                default:
                    break;
                case 2:
                    radioButton_CtrlBlack.Checked = true;
                    break;
                case 3:
                    radioButton_CtrlKmbox.Checked = true;
                    break;
                case 4:
                    radioButton_易键鼠.Checked = true;
                    break;
                case 5:
                    radioButton_魔盒.Checked = true;
                    break;
                case 6:
                    radioButton_MVPNET.Checked = true;
                    MVPNETTXT.Text = 写入读取配置文件.读取配置文件("config", "MVPNETTXT", "");
                    break;
            }
            switch (写入读取配置文件.读取配置文件("config", "KDGET", "1"))
            {
                case "2":
                    radioButton_KDFPP.Checked = true;
                    break;
                case "1":
                    radioButton_KDTPP.Checked = true;
                    break;
            }
            textBox_ScreenX.Text = 写入读取配置文件.读取配置文件("config", "ScreenX", "1920");
            textBox_ScreenY.Text = 写入读取配置文件.读取配置文件("config", "ScreenY", "1080");
            comboBox_MqttServer.Text = 写入读取配置文件.读取配置文件("config", "MqttServer", "127.0.0.1");
            comboBox_WebServer.Text = 写入读取配置文件.读取配置文件("config", "WebServer", $"http://{CommonProperty.WebServer}/");
            checkBox_ESPEnable.Checked = bool.Parse(写入读取配置文件.读取配置文件("config", "ESPEnable", "false"));
            checkBox_PlayerInfo.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "PlayerInfo", "false"));
            checkBox_ShowName.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "ShowName", "false"));
            checkBox_Audience.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "Audience", "false"));
            checkBox_KillNum.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "KillNum", "false"));
            checkBox_KD.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "KD", "false"));
            checkBox_DamageAvg.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "DamageAvg", "false"));
            //checkBox_RedZone.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "RedZone", "false"));
            checkBox_物资.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "wuzi", "false"));
            checkBox_SurvivalLevel.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "SurvivalLevel", "false"));
            checkBox_Distance.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "Distance", "false"));
            checkBox_Rank.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "Rank", "true"));
            checkBox_单排.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "danpai", "false"));
            //numericUpDown_FontSize.Text = 写入读取配置文件.读取配置文件("INFO", "FontSize", "14");
            checkBox_ShowVehicles.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "ShowVehicles", "false"));
            checkBox_itemgroup0.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "ItemGroup0", "false"));
            checkBox_itemgroup1.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "ItemGroup1", "false"));
            checkBox_itemgroup2.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "ItemGroup2", "false"));
            checkBox_itemgroup3.Checked = bool.Parse(写入读取配置文件.读取配置文件("INFO", "ItemGroup3", "false"));
            //串流自瞄 = bool.Parse(写入读取配置文件.读取配置文件("AIM", "CompatibilityMode", "false"));
            comboBox_AimKey1.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("AIM", "AimKey1", "1"));
            comboBox_AimKey2.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("AIM", "AimKey2", "2"));
            comboBox_AimAt.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("AIM", "AimAt", "1"));
            comboBox_LockKey.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("AIM", "LockKey", "160"));
            comboBox_AimLock.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("AIM", "AimAt", "0"));
            comboBox_LockGrobbyKey.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("AIM", "LockGrobbyKey", "162"));
            numericUpDown_AimDistince.Value = decimal.Parse(写入读取配置文件.读取配置文件("AIM", "AimDistince", "600"));
            numericUpDown_AimDelay.Value = decimal.Parse(写入读取配置文件.读取配置文件("AIM", "AimDelay", "15"));
            numericUpDown_AimRange.Value = decimal.Parse(写入读取配置文件.读取配置文件("AIM", "AimRange", "60"));
            numericUpDown_AimSmooth.Value = decimal.Parse(写入读取配置文件.读取配置文件("AIM", "AimSmooth", "1"));
            //numericUpDown_AimAdjust.Value = decimal.Parse(写入读取配置文件.读取配置文件("AIM", "AimAdjust", "0"));
            radioButton_AimUseRange.Checked = bool.Parse(写入读取配置文件.读取配置文件("AIM", "AimUseRange", "true"));
            radioButton_AimUseDistince.Checked = bool.Parse(写入读取配置文件.读取配置文件("AIM", "AimUseDistince", "false"));
            //checkBox动态FOV.Checked = bool.Parse(写入读取配置文件.读取配置文件("AIM", "DTFOV", "true"));
            //checkBox跳过击杀.Checked = bool.Parse(写入读取配置文件.读取配置文件("AIM", "TGJS", "true"));
            自瞄延时.Value = decimal.Parse(写入读取配置文件.读取配置文件("AIM", "ZMYS", "100"));
            战斗模式.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ShowItem", "80"));
            comboBox_热键_显示物资组0.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ShowItemGroup0", "37"));
            comboBox_热键_显示物资组1.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ShowItemGroup1", "40"));
            comboBox_热键_显示物资组2.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ShowItemGroup2", "39"));
            comboBox_热键_显示物资组3.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ShowItemGroup3", "38"));
            //comboBox_热键_车辆.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "Vehicles", "0"));
            comboBox_热键_雷达放大.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ZoonIn", "112"));
            comboBox_热键_雷达缩小.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ZoonOut", "113"));
            comboBox_热键_自瞄配置2.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("AIM", "type2", "0"));
            //comboBox_热键_脖子.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "Neck", "0"));
            //comboBox_热键_胸部.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "Chest", "0"));
            comboBox_热键_数据刷新.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ReFlesh", "120"));
            comboBox_热键_透视开关.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ESP", "123"));
            //comboBox_热键_黑名单.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "BlackList", "116"));
            comboBox_热键_玩家信息.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "PlayerInfo", "117"));
            //comboBox_热键_显示名字.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ShowName", "0"));
            comboBox_热键_加黑名单.SelectedIndex = int.Parse(写入读取配置文件.读取配置文件("HOTKEY", "ADDBlacklist", "0"));
        }

        private void comboBox_WebServer_SelectedIndexChanged(object sender, EventArgs e)
        {
            WebServer = comboBox_WebServer.Text;
        }

        private void comboBox_MqttServer_SelectedIndexChanged(object sender, EventArgs e)
        {
            MqttServer = comboBox_MqttServer.Text;
        }

        private void aloneComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_刷新 = comboBox_热键_数据刷新.SelectedIndex;
        }

        private void comboBox_热键_战斗模式_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_战斗模式 = 战斗模式.SelectedIndex;
        }

        private void comboBox_热键_透视开关_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_ESP = comboBox_热键_透视开关.SelectedIndex;
        }

        private void comboBox_热键_加黑名单_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_黑名单 = comboBox_热键_加黑名单.SelectedIndex;
        }

        private void comboBox_热键_雷达放大_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_放大 = comboBox_热键_雷达放大.SelectedIndex;
        }

        private void comboBox_热键_雷达缩小_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_缩小 = comboBox_热键_雷达缩小.SelectedIndex;
        }

        private void comboBox_热键_玩家信息_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_用户信息 = comboBox_热键_玩家信息.SelectedIndex;
        }

        private void comboBox_热键_A组物资_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_显示物资组0 = comboBox_热键_显示物资组0.SelectedIndex;
        }

        private void comboBox_热键_B组物资_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_显示物资组1 = comboBox_热键_显示物资组1.SelectedIndex;
        }

        private void comboBox_热键_C组物资_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_显示物资组2 = comboBox_热键_显示物资组2.SelectedIndex;
        }

        private void comboBox_热键_D组物资_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_显示物资组3 = comboBox_热键_显示物资组3.SelectedIndex;
        }

        private void airCheckBox14_CheckedChanged(object sender)
        {
            bool_雷达物资 = checkBox_物资.Checked;
        }

        private void airCheckBox16_CheckedChanged(object sender)
        {
            bool_雷达载具 = checkBox_ShowVehicles.Checked;
        }

        private void checkBox_PlayerInfo_CheckedChanged(object sender)
        {
            ShowPlayerInfo = checkBox_PlayerInfo.Checked;
        }

        private void checkBox_ShowName_CheckedChanged(object sender)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void checkBox_Distance_CheckedChanged(object sender)
        {
            ShowDistance = checkBox_Distance.Checked;
        }

        private void checkBox_SurvivalLevel_CheckedChanged(object sender)
        {
            ShowSurvivalLevel = checkBox_SurvivalLevel.Checked;
        }

        private void checkBox_KillNum_CheckedChanged(object sender)
        {
            ShowKillNum = checkBox_KillNum.Checked;
        }

        private void checkBox_Audience_CheckedChanged(object sender)
        {
            ShowAudience = checkBox_Audience.Checked;
        }

        private void checkBox_KD_CheckedChanged(object sender)
        {
            ShowKD = checkBox_KD.Checked;
        }

        private void checkBox_DamageAvg_CheckedChanged(object sender)
        {
            ShowDamageAvg = checkBox_DamageAvg.Checked;
        }

        private void checkBox_Rank_CheckedChanged(object sender)
        {
            ShowRank = checkBox_Rank.Checked;
        }

        private void checkBox_itemgroup0_CheckedChanged(object sender)
        {
            显示物资组0 = checkBox_itemgroup0.Checked;
            CommonProperty.物资A = 显示物资组0;
            显示物资 = 显示物资组0 || 显示物资组1 || 显示物资组2 || 显示物资组3;
        }

        private void checkBox_itemgroup1_CheckedChanged(object sender)
        {
            显示物资组1 = checkBox_itemgroup1.Checked;
            CommonProperty.物资B = 显示物资组1;
            显示物资 = 显示物资组0 || 显示物资组1 || 显示物资组2 || 显示物资组3;
        }

        private void checkBox_itemgroup2_CheckedChanged(object sender)
        {
            显示物资组2 = checkBox_itemgroup2.Checked;
            CommonProperty.物资C = 显示物资组2;

            显示物资 = 显示物资组0 || 显示物资组1 || 显示物资组2 || 显示物资组3;
        }

        private void checkBox_itemgroup3_CheckedChanged(object sender)
        {
            显示物资组3 = checkBox_itemgroup3.Checked;
            CommonProperty.物资D = 显示物资组3;
            显示物资 = 显示物资组0 || 显示物资组1 || 显示物资组2 || 显示物资组3;
        }

        private void checkBox_ESPEnable_CheckedChanged()
        {
            ShowESP = checkBox_ESPEnable.Checked;
            try
            {
                Thread thread2 = null;
                if (ShowESP)
                {
                    new CommonProperty();
                    thread2 = new Thread(() =>
                    {
                        EspOverlay.人物Clear();
                        EspOverlay.载具Clear();
                        EspOverlay.物资Clear();
                        EspOverlay.投掷物Clear();
                        overlay = new SampleOverlay();
                        overlay.Run();
                    });
                    thread2.IsBackground = true;
                    thread2.Start();
                }


                else
                {
                    if (overlay != null)
                    {
                        overlay.Close();
                        thread2?.Abort();
                        overlay.Dispose();
                        overlay = null;
                        EspOverlay.人物Clear();
                        EspOverlay.载具Clear();
                        EspOverlay.物资Clear();
                        EspOverlay.投掷物Clear();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void 复制雷达URL(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(textBox_URL.Text);
        }

        private void 打开雷达URL(object sender, EventArgs e)
        {
            if (textBox_URL.Text == "")
            {
                return;
            }
            if (File.Exists("CentBrowser\\Chrome.exe"))
            {
                Process.Start("CentBrowser\\Chrome.exe", "--start-fullscreen " + textBox_URL.Text);
            }
            else
            {
                Process.Start("explorer.exe", "\"" + textBox_URL.Text + "\"");
            }
        }

        private void 保存参数_Click(object sender, EventArgs e)
        {
            保存参数();
        }

        private void checkBox_单排_CheckedChanged(object sender)
        {
            if (checkBox_单排.Checked)
            {
                CommonProperty.单排 = true;
            }
            else
            {
                CommonProperty.单排 = false;
            }
        }

        private void 获取COM()
        {
            comboBox_COM.Items.Clear();
            string[] portNames = SerialPort.GetPortNames();
            for (int i = 0; i < portNames.Length; i++)
            {
                comboBox_COM.Items.Add(portNames[i]);
            }
            if (comboBox_COM.Items.Count > 0)
            {
                comboBox_COM.SelectedIndex = comboBox_COM.Items.Count - 1;
            }
        }

        private void KMBOX_CheckedChanged(object sender)
        {
            if (radioButton_CtrlKmbox.Checked)
            {
                ControlMode = 1;
                ControlHID = 3;
                ScreenX = int.Parse(textBox_ScreenX.Text);
                ScreenY = int.Parse(textBox_ScreenY.Text);
                波动率 = "115200";
                获取COM();
            }
        }

        private void KMNET_CheckedChanged(object sender)
        {
            if (radioButton_MVPNET.Checked)
            {
                ControlMode = 1;
                ControlHID = 6;
                ScreenX = int.Parse(textBox_ScreenX.Text);
                ScreenY = int.Parse(textBox_ScreenY.Text);
                MVPNETTXT.Visible = true;
            }
            else
            {
                //
                //
                //
                //
                //.Visible = false;
            }
        }

        private void radioButton_魔盒_CheckedChanged(object sender)
        {
            if (radioButton_魔盒.Checked)
            {
                ControlMode = 1;
                ControlHID = 5;
                ScreenX = int.Parse(textBox_ScreenX.Text);
                ScreenY = int.Parse(textBox_ScreenY.Text);
                获取COM();
            }
        }

        private void LUERKER控制器_CheckedChanged(object sender)
        {
            if (radioButton_CtrlBlack.Checked)
            {
                ControlMode = 1;
                ControlHID = 2;
                ScreenX = int.Parse(textBox_ScreenX.Text);
                ScreenY = int.Parse(textBox_ScreenY.Text);
                波动率 = "57600";
                获取COM();
            }
        }

        private void 易键鼠_CheckedChanged(object sender)
        {
            if (radioButton_易键鼠.Checked)
            {
                ControlMode = 1;
                ControlHID = 4;
                ScreenX = int.Parse(textBox_ScreenX.Text);
                ScreenY = int.Parse(textBox_ScreenY.Text);
                波动率 = "57600";
                获取COM();
            }
        }

        private void radioButton关闭自瞄_CheckedChanged(object sender)
        {
            if (关闭自瞄.Checked)
            {
                KM_COM.Close();
                ControlHID = 0;
                ControlMode = 5;
                if (KM_COM.IsOpen)
                {
                    KM_COM.Close();
                }
                if (魔盒 == 1)
                {
                    Close();
                    魔盒 = 0;
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //更新状态 正常返回5031  到期5030  超时5026 超时或者没有登录请登录1049
            string info = 验证窗口.BSPHP.AppEn_timeout();

            if (info != "5031")
            {
                while ((info == "" || (info != "5030" && info != "5026" && info != "1049")) && num002 < 10)
                {
                    info = 验证窗口.BSPHP.AppEn_timeout();
                    num002++;
                    Thread.Sleep(1000);
                }
                if (info != "5031" && info != "")
                {
                    num001++;
                }
                if (num001 == 2)
                {
                    CommonProperty.心跳验证 = false;
                    MessageBox.Show("账号已到期5030");
                    结束进程();
                    //if (info == "5030")
                    //{
                    //    CommonProperty.心跳验证 = false;
                    //    MessageBox.Show("账号已到期5030");
                    //    结束进程();
                    //}
                    //else if (info == "5026")
                    //{
                    //    CommonProperty.心跳验证 = false;
                    //    MessageBox.Show("心跳验证超时请重新登录5026");
                    //    结束进程();
                    //}
                    //else if (info == "1049")
                    //{
                    //    CommonProperty.心跳验证 = false;
                    //    MessageBox.Show("心跳验证超时请重新登录1049");
                    //    结束进程();
                    //}
                    //else
                    //{
                    //    CommonProperty.心跳验证 = false;
                    //    MessageBox.Show("因网络问题导致心跳验证异常请重新登录");
                    //    结束进程();
                    //}
                }
            }
            else
            {
                num001 = 0;
                num002 = 0;
            }
        }


        private void checkBox跳过击杀_CheckedChanged(object sender)
        {
            bool_跳过击杀 = checkBox跳过击杀.Checked;
        }

        private void checkBox动态FOV_CheckedChanged(object sender)
        {
            bool_动态fov = checkBox动态FOV.Checked;
        }

        private async void aloneButton2_Click(object sender, EventArgs e)
        {
            TeamAdd = textBox_TeamAdd.Text;
            await Task.Delay(1000);
        }

        private void radioButton_KDTPP_CheckedChanged(object sender)
        {
            checkBox_Rank.Visible = true;
            if (radioButton_KDTPP.Checked)
            {
                KDMODE = "tpp";
            }
        }

        private void radioButton_KDFPP_CheckedChanged(object sender)
        {
            checkBox_Rank.Visible = true;
            if (radioButton_KDFPP.Checked)
            {
                KDMODE = "fpp";
            }
        }

        private int GetGunTabsType()
        {
            int key = 0;
            qiang = 枪类型.SelectedTab.Text;
            switch (qiang)
            {
                case "步枪":
                    key = 0;
                    break;
                case "连狙":
                    key = 1;
                    break;
                case "栓狙":
                    key = 2;
                    break;
                case "散弹":
                    key = 3;
                    break;
                case "其它":
                    key = 4;
                    break;
            }
            return key;
        }

        private void 主菜单_SelectedIndexChanged(object sender, EventArgs e)
        {
            //读取配置文件();
            if (!CommonProperty.espconfig.EspConfig.自瞄配置2)
            {
                if (!GunTypeList.ContainsKey(GetGunTabsType()))
                {
                    GunTypeList[GetGunTabsType()] = new GunType();
                }
                comboBox_AimKey1.SelectedIndex = GunTypeList[GetGunTabsType()].AIMKEY1;
                comboBox_AimKey2.SelectedIndex = GunTypeList[GetGunTabsType()].AIMKEY2;
                comboBox_AimAt.SelectedIndex = GunTypeList[GetGunTabsType()].AIM部位;
                comboBox_LockKey.SelectedIndex = GunTypeList[GetGunTabsType()].LOCKKEY;
                comboBox_AimLock.SelectedIndex = GunTypeList[GetGunTabsType()].LOCK部位;
                comboBox_LockGrobbyKey.SelectedIndex = GunTypeList[GetGunTabsType()].倒地KEY;
                numericUpDown_AimDistince.Value = GunTypeList[GetGunTabsType()].AimDistince;
                numericUpDown_AimDelay.Value = GunTypeList[GetGunTabsType()].AimDelay;
                numericUpDown_Recoil.Value = GunTypeList[GetGunTabsType()].Recoil;
                numericUpDown_AimRange.Value = GunTypeList[GetGunTabsType()].AimRange;
                numericUpDown_AimSmooth.Value = GunTypeList[GetGunTabsType()].AimSmooth;
                radioButton_AimUseDistince.Checked = !radioButton_AimUseRange.Checked;
                numericUpDown_AimX.Value = GunTypeList[GetGunTabsType()].MoveX;
                numericUpDown_AimY.Value = GunTypeList[GetGunTabsType()].MoveY;
                radioButton_AimUseRange.Checked = (GunTypeList[GetGunTabsType()].Aim优先级 == 0) ? true : false;
                checkBox动态FOV.Checked = GunTypeList[GetGunTabsType()].动态范围;
                checkBox跳过击杀.Checked = GunTypeList[GetGunTabsType()].跳过击杀;
                checkBox开镜自瞄.Checked = GunTypeList[GetGunTabsType()].开镜自瞄;
            }
            else
            {
                if (!GunTypeList2.ContainsKey(GetGunTabsType()))
                {
                    GunTypeList2[GetGunTabsType()] = new GunType();
                }
                comboBox_AimKey1.SelectedIndex = GunTypeList2[GetGunTabsType()].AIMKEY1;
                comboBox_AimKey2.SelectedIndex = GunTypeList2[GetGunTabsType()].AIMKEY2;
                comboBox_AimAt.SelectedIndex = GunTypeList2[GetGunTabsType()].AIM部位;
                comboBox_LockKey.SelectedIndex = GunTypeList2[GetGunTabsType()].LOCKKEY;
                comboBox_AimLock.SelectedIndex = GunTypeList2[GetGunTabsType()].LOCK部位;
                comboBox_LockGrobbyKey.SelectedIndex = GunTypeList2[GetGunTabsType()].倒地KEY;
                numericUpDown_AimDistince.Value = GunTypeList2[GetGunTabsType()].AimDistince;
                numericUpDown_AimDelay.Value = GunTypeList2[GetGunTabsType()].AimDelay;
                numericUpDown_Recoil.Value = GunTypeList2[GetGunTabsType()].Recoil;
                numericUpDown_AimRange.Value = GunTypeList2[GetGunTabsType()].AimRange;
                numericUpDown_AimSmooth.Value = GunTypeList2[GetGunTabsType()].AimSmooth;
                radioButton_AimUseDistince.Checked = !radioButton_AimUseRange.Checked;
                numericUpDown_AimX.Value = GunTypeList2[GetGunTabsType()].MoveX;
                numericUpDown_AimY.Value = GunTypeList2[GetGunTabsType()].MoveY;
                radioButton_AimUseRange.Checked = (GunTypeList2[GetGunTabsType()].Aim优先级 == 0) ? true : false;
                checkBox动态FOV.Checked = GunTypeList2[GetGunTabsType()].动态范围;
                checkBox跳过击杀.Checked = GunTypeList2[GetGunTabsType()].跳过击杀;
                checkBox开镜自瞄.Checked = GunTypeList2[GetGunTabsType()].开镜自瞄;

            }
        }

        private void 连接控制器(object sender, EventArgs e)
        {
            try
            {
                if (ControlHID == 1 || ControlHID == 2 || ControlHID == 3)
                {
                    KM_COM.Close();
                    if (!KM_COM.IsOpen)
                    {
                        KM_COM.PortName = comboBox_COM.SelectedItem.ToString();
                        KM_COM.DataBits = 8;
                        KM_COM.StopBits = StopBits.One;
                        KM_COM.Parity = Parity.None;
                        KM_COM.BaudRate = int.Parse(波动率);
                        KM_COM.Open();
                    }
                }
                if (ControlHID == 4)
                {
                    if (M_Handle == IntPtr.Zero)
                    {
                        M_Handle = M_Open(1);
                    }
                }
                if (ControlHID == 5)
                {
                    Close();
                    魔盒 = 0;
                    if (魔盒 != 1)
                    {
                        魔盒 = OpenDevice(comboBox_COM.SelectedItem.ToString());
                        if (魔盒 == 1)
                        {
                            EnableAccurateDelay();
                        }
                    }
                }
                switch (ControlHID)
                {
                    case 1:
                        KM_COM.WriteLine("[MM820,20]");
                        break;
                    case 2:
                        {
                            byte[] buffer = new byte[7] { 87, 171, 2, 0, 21, 21, 0 };
                            KM_COM.Write(buffer, 0, 7);
                            break;
                        }
                    case 3:
                        KM_COM.Write("km.move(20,20)\r\n");
                        Thread.Sleep(10);
                        KM_COM.WriteLine("km.up(224)\r\n");
                        break;
                    case 4:
                        M_MoveR(M_Handle, 20, 20);
                        break;
                    case 5:
                        MoveR(20, 20);
                        break;
                    case 6:
                        {
                            string[] array = MVPNETTXT.Text.Trim().Split(':');
                            if (array.Length != 3)
                            {
                                MessageBox.Show("控制器连接失败!参数错误");
                            }
                            else if (kmNet_init(array[0], array[1], array[2]) == 0)
                            {
                                kmNet_mouse_move(20, 20);
                                kmNet_keyup(224);
                            }
                            else
                            {
                                MessageBox.Show("控制器连接失败!参数错误");
                            }
                            break;
                        }
                }
            }
            catch
            {

            }
        }

        private void aloneButton6_Click(object sender, EventArgs e)
        {
            if (!CommonProperty.espconfig.EspConfig.自瞄配置2)
            {
                GunTypeList[GetGunTabsType()].AIMKEY1 = comboBox_AimKey1.SelectedIndex;
                GunTypeList[GetGunTabsType()].AIMKEY2 = comboBox_AimKey2.SelectedIndex;
                GunTypeList[GetGunTabsType()].AIM部位 = comboBox_AimAt.SelectedIndex;
                GunTypeList[GetGunTabsType()].LOCKKEY = comboBox_LockKey.SelectedIndex;
                GunTypeList[GetGunTabsType()].LOCK部位 = comboBox_AimLock.SelectedIndex;
                GunTypeList[GetGunTabsType()].倒地KEY = comboBox_LockGrobbyKey.SelectedIndex;
                GunTypeList[GetGunTabsType()].AimDelay = (int)numericUpDown_AimDelay.Value;
                GunTypeList[GetGunTabsType()].AimDistince = (int)numericUpDown_AimDistince.Value;
                GunTypeList[GetGunTabsType()].AimRange = (int)numericUpDown_AimRange.Value;
                GunTypeList[GetGunTabsType()].AimSmooth = (int)numericUpDown_AimSmooth.Value;
                GunTypeList[GetGunTabsType()].Recoil = (int)numericUpDown_Recoil.Value;
                GunTypeList[GetGunTabsType()].MoveX = (int)numericUpDown_AimX.Value;
                GunTypeList[GetGunTabsType()].MoveY = (int)numericUpDown_AimY.Value;
                GunTypeList[GetGunTabsType()].Aim优先级 = (!radioButton_AimUseRange.Checked) ? 1 : 0;
                GunTypeList[GetGunTabsType()].动态范围 = bool_动态fov;
                GunTypeList[GetGunTabsType()].跳过击杀 = bool_跳过击杀;
                GunTypeList[GetGunTabsType()].开镜自瞄 = bool_开镜自瞄;
                GunTypeList[GetGunTabsType()].TypeID = GetGunTabsType();
                using (StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "config/自瞄配置1.ini"))
                {
                    foreach (GunType value in GunTypeList.Values)
                    {
                        streamWriter.WriteLine(JsonConvert.SerializeObject(value));
                    }
                }
            }
            else
            {
                GunTypeList2[GetGunTabsType()].AIMKEY1 = comboBox_AimKey1.SelectedIndex;
                GunTypeList2[GetGunTabsType()].AIMKEY2 = comboBox_AimKey2.SelectedIndex;
                GunTypeList2[GetGunTabsType()].AIM部位 = comboBox_AimAt.SelectedIndex;
                GunTypeList2[GetGunTabsType()].LOCKKEY = comboBox_LockKey.SelectedIndex;
                GunTypeList2[GetGunTabsType()].LOCK部位 = comboBox_AimLock.SelectedIndex;
                GunTypeList2[GetGunTabsType()].倒地KEY = comboBox_LockGrobbyKey.SelectedIndex;
                GunTypeList2[GetGunTabsType()].AimDelay = (int)numericUpDown_AimDelay.Value;
                GunTypeList2[GetGunTabsType()].AimDistince = (int)numericUpDown_AimDistince.Value;
                GunTypeList2[GetGunTabsType()].AimRange = (int)numericUpDown_AimRange.Value;
                GunTypeList2[GetGunTabsType()].AimSmooth = (int)numericUpDown_AimSmooth.Value;
                GunTypeList2[GetGunTabsType()].Recoil = (int)numericUpDown_Recoil.Value;
                GunTypeList2[GetGunTabsType()].MoveX = (int)numericUpDown_AimX.Value;
                GunTypeList2[GetGunTabsType()].MoveY = (int)numericUpDown_AimY.Value;
                GunTypeList2[GetGunTabsType()].Aim优先级 = (!radioButton_AimUseRange.Checked) ? 1 : 0;
                GunTypeList2[GetGunTabsType()].动态范围 = bool_动态fov;
                GunTypeList2[GetGunTabsType()].跳过击杀 = bool_跳过击杀;
                GunTypeList2[GetGunTabsType()].开镜自瞄 = bool_开镜自瞄;
                GunTypeList2[GetGunTabsType()].TypeID = GetGunTabsType();
                using (StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "config/自瞄配置2.ini"))
                {
                    foreach (GunType value in GunTypeList2.Values)
                    {
                        streamWriter.WriteLine(JsonConvert.SerializeObject(value));
                    }
                }
            }
            保存参数();
        }

        private void aloneButton1_Click(object sender, EventArgs e)
        {
            人物列表窗口 f = new 人物列表窗口();
            f.Show();
        }

        private void Rains_FormClosing(object sender, FormClosingEventArgs e)
        {
            结束进程();
        }

        private void comboBox_热键_自瞄配置2_SelectedIndexChanged(object sender, EventArgs e)
        {
            热键_自瞄配置2 = comboBox_热键_自瞄配置2.SelectedIndex;
        }

        private void checkBox开镜自瞄_CheckedChanged(object sender)
        {
            bool_开镜自瞄 = checkBox开镜自瞄.Checked;
        }
    }
}
