﻿internal class 读写22
{
    public ulong UyhpMogdQl;

    public uint uint_0;

    public ulong[] ulongs_0 = new ulong[2];
}
