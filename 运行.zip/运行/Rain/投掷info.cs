﻿namespace RAIN
{
    public class 投掷info
    {
        public string shortName = "";

        public bool showItem;

        public int group;
    }
}
