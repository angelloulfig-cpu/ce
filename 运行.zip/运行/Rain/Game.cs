﻿using MultiThreadedOverlay;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PGE;
using PGE.Common;
using RAIN;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO.Compression;
using System.IO.Ports;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using TestNet;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Exceptions;
using vmmsharp;

internal class Game
{
    public delegate ulong DecryptData(ulong c);

    [Flags]
    public enum AllocationType
    {
        Commit = 0x1000
    }

    [Flags]
    public enum MemoryProtection
    {
        ExecuteReadWrite = 0x40
    }

    public static VmmScatter TS;

    public static VmmScatter HS;

    public static VmmScatter TS1;

    public static VmmScatter TS2;

    //游戏状态
    private bool ThreadRunning = true;

    private byte[] 热键 = new byte[64];

    private PlayerRankManger playerRankManger = new PlayerRankManger();

    public static DecryptData decryptFunc;

    private float MapSize = 0f;

    private Vector2 WorldMapPosition;

    private float WorldMapZoomFactor;

    private ulong GroggyHealth;

    private string 房间号 = "";

    private string local房间号;

    private IntPtr M_Handle;

    private int 魔盒;

    private uint flags_ = 307u;

    private uint flags = 50u;

    private uint 相机;

    private string 雷达url = "";

    private string 当前地图 = "";

    public static Vmm vmm;

    private string username = "";

    public static uint pid;

    private ulong GameNULL;

    private ulong DecryptThis;

    private ulong sGNames;

    private ulong MapAddr;

    private ulong MinimapCanvasWidgetAddr;

    private ulong MapGrid;

    private int int_0;

    private int 自瞄延时;

    private bool 串流自瞄;

    private Vector3Int 全地图XY;

    private byte ammoData;

    private float 手雷倒计时;

    private uint TargetHead = 15u;

    private uint TargetNeck = 20u;

    private uint TargetChest = 40u;

    private uint TargetPelvis = 30u;

    private uint TargetArm = 10u;

    private int 头部 = 15;

    private int 颈部 = 5;

    private int 胸部 = 4;

    private int 左肩 = 88;

    private int 右肩 = 115;

    private int 左肘 = 89;

    private int 右肘 = 116;

    private int 左手 = 90;

    private int 右手 = 117;

    private int 骨盆 = 1;

    private int 左胯 = 172;

    private int 右胯 = 178;

    private int 左膝 = 173;

    private int 右膝 = 179;

    private int 左脚 = 174;

    private int 右脚 = 180;

    private int 左胯1 = 168;

    private int 右胯1 = 174;

    private int 左膝1 = 169;

    private int 右膝1 = 175;

    private int 左脚1 = 170;

    private int 右脚1 = 176;

    private ulong aimPlayer;

    private bool 瞄准;

    private bool 屏幕中心是否有人;

    private 自瞄数据 武器参数 = new 自瞄数据();

    private HashSet<string> hashSet_地图 = new HashSet<string>();

    private HashSet<string> hashSet_物资 = new HashSet<string>();

    private Dictionary<string, 投掷info> dictionary_投掷物 = new Dictionary<string, 投掷info>();

    private Dictionary<string, 载具info> dictionary_载具 = new Dictionary<string, 载具info>();

    private HashSet<string> hashSet_人物 = new HashSet<string>();

    private HashSet<string> hashSet_人机 = new HashSet<string>();

    private HashSet<string> hashSet_盒子 = new HashSet<string>();

    private HashSet<string> hashSet_载具 = new HashSet<string>();

    private HashSet<string> hashSet_投掷物 = new HashSet<string>();

    private HashSet<string> hashSet_雷达信息 = new HashSet<string>();

    private ConcurrentQueue<string> concurrentQueue_雷达信息 = new ConcurrentQueue<string>();

    private static Dictionary<string, 物资info> dictionary_物资;

    private AutoResetEvent autoResetEvent_雷达信息 = new AutoResetEvent(initialState: false);

    private ConcurrentQueue<string> concurrentQueue_网页雷达 = new ConcurrentQueue<string>();

    private AutoResetEvent autoResetEvent_1 = new AutoResetEvent(initialState: false);

    private ConcurrentQueue<List<Actor人物>> concurrentQueue_人物 = new ConcurrentQueue<List<Actor人物>>();

    private ConcurrentQueue<List<Class4>> concurrentQueue_地图资源 = new ConcurrentQueue<List<Class4>>();

    private List<ulong> ulongs = new List<ulong>();

    private Dictionary<ulong, Actor人物> dictionary_人物 = new Dictionary<ulong, Actor人物>();

    private List<string> 玩家列表2 = new List<string>();

    private Dictionary<uint, KeyValuePair<string, string>> dictionary_5 = new Dictionary<uint, KeyValuePair<string, string>>();

    private static Dictionary<Type, object> RolByType;

    private Dictionary<ulong, Class4> dictionary盒子载具 = new Dictionary<ulong, Class4>();

    private Dictionary<ulong, Class4> dictionary投掷物 = new Dictionary<ulong, Class4>();

    private Dictionary<ulong, 物资> dictionary物资 = new Dictionary<ulong, 物资>();

    private Dictionary<ulong, GameItems> dictionary丢弃的物资 = new Dictionary<ulong, GameItems>();

    private Dictionary<ulong, 全> 全部对象 = new Dictionary<ulong, 全>();

    private Dictionary<int, int> dictionary_骨骼点 = new Dictionary<int, int>();

    private List<string> strings_人物 = new List<string>();

    private List<string> strings_物资 = new List<string>();

    private List<string> strings_盒子 = new List<string>();

    private List<string> strings_载具 = new List<string>();

    private List<string> strings_雷达信息 = new List<string>();

    private List<string> strings_人物标点 = new List<string>();

    private Dictionary<uint, string> ActorClassNameList = new Dictionary<uint, string>();

    private bool debug;

    private bool 透视开关;

    private bool 透视;

    private bool 融合器;

    private bool 融合器1;

    private bool 透视投掷物;

    private bool 透视载具;

    //private bool 动态FOV;

    //private bool 跳过击杀;

    //private bool 开镜自瞄;

    private bool 雷达载具;

    private bool 雷达物资;

    private bool 物资0;

    private bool 物资1;

    private bool 物资2;

    private bool 物资3;

    private bool 自瞄2;

    private bool 中心是否有人;

    private string string_4 = 写入读取配置文件.读取配置文件("config", "MqttServer", "127.0.0.1");

    private static Vector2 vector2_0;

    private static Vector2 vector2_1;

    private static float float_0;

    private static float float_1;

    private static Vector2 vector2_2;

    private static Vector2 vector2_3;

    private static Vector2 vector2_4;

    private static Vector2 vector2_5;

    private static Vector2 vector2_6;

    private bool 小地图放大;

    private ulong 基准值;

    private List<ulong> 迷雾指针 = new List<ulong>();

    private Dictionary<ulong, Actor迷雾人物> 迷雾视角 = new Dictionary<ulong, Actor迷雾人物>();

    private int 热键_战斗模式;

    private int 热键_显示物资组0;

    private int 热键_显示物资组1;

    private int 热键_显示物资组2;

    private int 热键_显示物资组3;

    private int 热键_缩小;

    private int 热键_放大;

    private int 热键_自瞄配置2;

    private int 热键_添加黑名单;

    private bool 添加黑名单;

    private int 热键_脖子;

    private int 热键_胸部;

    private int 热键_车辆;

    private int 热键_刷新;

    private int 热键_ESP;

    private int 热键_黑名单;

    private int 热键_用户信息;

    private int 热键_显示名字;

    private bool AutoJump;

    private bool bool_16 = true;

    private bool 左键按下;

    private bool 热键战斗模式;

    private bool 热键显示物资组0;

    private bool 热键显示物资组1;

    private bool 热键显示物资组2;

    private bool 热键显示物资组3;

    private bool 热键缩小;

    private bool 热键放大;

    private bool 自瞄头热键;

    private bool 自瞄脖热键;

    private bool 自瞄胸热键;

    private bool 热键车辆;

    private bool 数据刷新;

    private bool 热键ESP;

    private bool 热键黑名单;

    private bool 热键用户信息;

    private bool 热键显示名字;

    private bool 自瞄;

    private bool 子骨骼自瞄;

    private bool 自瞄倒地;

    private int X分辨率;

    private int Y分辨率;

    private int 自瞄模式;

    private int ControlHID;

    private string COM端口 = "";

    private string MVPNET = "";

    private string 波动率 = "";

    private SerialPort KM_COM;

    private string MqttServer = "";

    private bool 玩家信息;

    private bool 游戏ID;

    private bool ShowAudience;

    private bool ShowKillNum;

    private bool 轰炸区;

    private bool ShowKD;

    private bool ShowRank;

    private string KDMODE = "";

    private bool ShowDamageAvg;

    private bool ShowSurvivalLevel;

    private bool ShowDistance;

    private int 字体大小 = 14;

    private string WebServer = "";

    private 本人 本人 = new 本人();

    private string 白名单_队伍 = "";

    private string string_白名单 = "";

    private int 地图状态计数 = 0;

    private int E;

    private int Q;

    private uint V1;

    private uint V2;

    private uint V3;

    private uint V4;

    private uint V5;

    private uint V6;

    private uint V7;

    private uint V8;

    private uint V9;

    private uint V10;

    private uint V11;

    private uint V12;

    private uint V13;

    private uint V14;

    private uint V15;

    private uint V16;

    private ulong MapGrids;

    private ulong Shield;

    private ulong Uworld;

    private ulong GNames;

    private ulong Leve;

    private ulong GameInstence;

    private ulong LocalPlayer;

    private ulong PlayerController;

    private ulong Actor;

    private ulong AcknowledgedPawn;

    private ulong ObjID;

    private ulong IDD;

    private ulong TeamNumber;

    private ulong Health;

    private ulong HealthDie;

    private ulong Audience;

    private ulong Playname;

    private ulong PlayerState;

    private ulong PlayerSatisitc;

    private ulong Mesh;

    private ulong Position;

    private ulong DroppedItemGroup;

    private ulong DroppedItemGroupUItem;

    private ulong 物品一;

    private ulong 物品二;

    private ulong 世界转小地图;

    private ulong 被瞄偏移;

    private ulong GameState;

    private ulong LerpSafetyZonePosition;

    private ulong LerpSafetyZoneRadius;

    private ulong PoisonGasWarningPosition;

    private ulong PoisonGasWarningRadius;

    private ulong RedZonePosition;

    private ulong RedZoneRadius;

    private bool ROR;

    private uint DecryptOne;

    private int TableOne;

    private int TableTwo;

    private uint DecryptTwo;

    private ulong PlayerCameraManager;

    private ulong CameraPos;

    private ulong CameraRot;

    private ulong CameraFov;

    private ulong Bone;

    private ulong BoneArry;

    private ulong Eyes;

    private ulong WeaponProcessor;

    private ulong EquippedWeapons;

    private ulong CurrentWeaponIndex;

    private ulong WeaponTrajectoryData;

    private ulong TrajectoryConfig;

    private ulong AnimScriptInstance;

    private ulong ControlRotationCP;

    private ulong RecoilADSRotationCP;

    private ulong VehicleRiderComponent;

    private ulong LastVehiclePawn;

    private ulong ActorRootComp;

    private ulong ReplicatedMovement;

    private ulong Veloctity;

    private ulong 背包状态;

    private ulong MapMarker;

    private ulong PartnerLevel;

    private ulong SurvivalLevel;

    private ulong bVisible;

    private ulong WidgetStateMap;

    private ulong MyHUD;

    private ulong BlockInputWidgetList;

    private ulong SelectMinimapSizeIndex;

    private ulong DroppedItem;

    private ulong CurrentAmmoData;

    private ulong ElapsedCookingTime;

    private ulong TimeTillExplosion;

    private ulong TrainingMapGrid;

    private ulong Visibility;

    private ulong Slot;

    private ulong Slot1;

    private ulong LayoutData;

    private ulong Offsets;

    private ulong Alignment;

    private ulong PlayerArray;

    private ulong PlayerName;

    private ulong PlayerTeamid;

    private ulong DamageDealtOnEnemy;

    private ulong bIsSpectator;

    private ulong AActorRole;

    private ulong AntiCheatCharacterSyncManager;

    private ulong CharacterId;

    private ulong Health2;

    private ulong Health3;

    private ulong Health4;

    private ulong Health5;

    private ulong Health6;

    private uint 读本人数据计数 = 0u;

    private ulong PlayerArray1 = 0uL;

    private uint PlayerNum = 0u;

    private ulong 角色指针 = 0uL;

    private uint 角色数量 = 0u;

    private ulong 循环次数 = 0uL;

    private int 延迟_主线程 = 0;

    private 雷达 网页雷达 = new 雷达();

    private SampleOverlay overlay;

    [DllImport("/dependent/msdk.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
    public static extern IntPtr M_Open(int port);

    [DllImport("/dependent/msdk.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
    public static extern int M_Close(IntPtr m_hdl);

    [DllImport("/dependent/msdk.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
    public static extern int M_MoveR(IntPtr M_hdl, int x, int y);

    [DllImport("/dependent/ddll64.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern int MoveR(int dx, int dy);

    [DllImport("/dependent/ddll64.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern int OpenDevice(string deviceName);

    [DllImport("/dependent/ddll64.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void Close();

    [DllImport("/dependent/ddll64.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void EnableAccurateDelay();

    [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
    public static extern IntPtr VirtualAlloc(IntPtr lpAddress, int dwSize, AllocationType flAllocationType, MemoryProtection flProtect);

    [DllImport("user32.dll")]
    private static extern int GetAsyncKeyState(int vKey);

    [DllImport("/dependent/PUBG.dll")]
    private static extern int InitD(byte[] bytes_1, ulong ulong_71);

    [DllImport("/dependent/PUBG.dll")]
    private static extern ulong Decrypt(ulong ulong_70, ulong ulong_71);

    [DllImport("/dependent/PUBG.dll")]
    private static extern uint ROL4(uint uint_8, int int_29);

    [DllImport("/dependent/PUBG.dll")]
    private static extern uint ROR4(ulong ulong_70, int int_29);

    [DllImport("/dependent/PUBG.dll")]
    private static extern uint AimBot(int int_29, int int_30);

    [DllImport("/dependent/PUBG.dll")]
    private static extern int kmNet_mouse_move_auto(int int_30, int int_31, int int_32);

    [DllImport("/dependent/PUBG.dll")]
    private static extern int kmNet_init(string string_13, string string_14, string string_15);

    private string MemGetName(uint uint_8)
    {
        if (sGNames == 0)
        {
            ulong gnm = Convert.ToUInt64(CommonProperty.Gnames加);
            sGNames = Decrypt_(Read<ulong>(Decrypt_(Read<ulong>(GameNULL + GNames)) + gnm));
            if (sGNames == 0)
            {
                return "";
            }


            //ulong tmp = Read<ulong>(GameNULL + GNames + gnm);
            //ulong v2 = Decrypt_(tmp);
            //ulong v3 = Decrypt_(Read<ulong>(v2));
            //sGNames = Decrypt_(Read<ulong>(v3));
            //if (sGNames == 0)
            //{
            //    return "";
            //}
        }
        return MemRead_Encoding_Default_GetString(Read<ulong>(Read<ulong>(sGNames + uint_8 / IDD * 8) + uint_8 % IDD * 8) + 16, 64u).Split('\0')[0].Trim();
    }
    private bool 游戏机按键是否按下(int vKey)
    {
        if ((热键[vKey * 2 / 8] & (1 << vKey % 4 * 2)) > 0)
        {
            return true;
        }
        return false;
    }

    private bool 雷达机按键是否按下(int int_29)
    {
        return (GetAsyncKeyState(int_29) & 0x8000) != 0;
    }

    private string MemRead_Encoding_Default_GetString(ulong ulong_70, uint uint_8)
    {
        byte[] array = vmm.MemRead(pid, ulong_70, uint_8, flags);
        if (array != null && array.Length == uint_8)
        {
            return Encoding.Default.GetString(array);
        }
        return "";
    }

    private string MemRead_Encoding_Unicode_GetString(ulong ulong_70, uint uint_8)
    {
        byte[] array = vmm.MemRead(pid, ulong_70, uint_8, flags);
        if (array == null || array.Length != uint_8)
        {
            return "";
        }
        return Encoding.Unicode.GetString(array).Split('\0')[0].Trim();
    }

    private ulong Decrypt_(ulong ulong_70)
    {
        return Decrypt(ulong_70, DecryptThis);
    }

    private ulong Decrypt_1(ulong ulong_70)
    {
        try
        {
            return decryptFunc(ulong_70);
        }
        catch
        {
            return 0uL;
        }
    }

    private static T __ROL__<T>(T value, int count) where T : struct
    {
        Func<T, int, T> rol;
        if (!RolByType.TryGetValue(typeof(T), out object tmp))
        {
            int nbits = Marshal.SizeOf(typeof(T)) * 8;
            ParameterExpression valParam = Expression.Parameter(typeof(T));
            ParameterExpression countParam = Expression.Parameter(typeof(int));
            ParameterExpression lowHighVar = Expression.Variable(typeof(T));
            rol = Expression.Lambda<Func<T, int, T>>(Expression.Block(new ParameterExpression[1] { lowHighVar }, Expression.IfThenElse(Expression.GreaterThan(countParam, Expression.Constant(0)), Expression.Block(Expression.ModuloAssign(countParam, Expression.Constant(nbits)), Expression.Assign(lowHighVar, Expression.RightShift(valParam, Expression.Subtract(Expression.Constant(nbits), countParam))), Expression.IfThen(Expression.LessThan(Expression.Convert(Expression.Constant(-1), typeof(T)), Expression.Constant(default(T))), Expression.AndAssign(lowHighVar, Expression.Not(Expression.LeftShift(Expression.Convert(Expression.Constant(-1), typeof(T)), countParam)))), Expression.LeftShiftAssign(valParam, countParam)), Expression.Block(Expression.Assign(countParam, Expression.Modulo(Expression.Negate(countParam), Expression.Constant(nbits))), Expression.Assign(lowHighVar, Expression.LeftShift(valParam, Expression.Subtract(Expression.Constant(nbits), countParam))), Expression.RightShiftAssign(valParam, countParam))), Expression.Or(valParam, lowHighVar)), new ParameterExpression[2] { valParam, countParam }).Compile();
            RolByType.Add(typeof(T), rol);
        }
        else
        {
            rol = (Func<T, int, T>)tmp;
        }
        return rol(value, count);
    }

    public static uint __ROR4__(uint value, int count)
    {
        return __ROL__(value, -count);
    }

    public static uint __ROL4__(uint value, int count)
    {
        return __ROL__(value, count);
    }

    //private uint DecryptCIndex1(uint uint_8)
    //{
    //    if (!ROR)
    //    {
    //        uint num = __ROL4__(uint_8 ^ DecryptOne, TableOne);
    //        return num ^ (num << TableTwo) ^ DecryptTwo;
    //    }
    //    uint num2 = __ROR4__(uint_8 ^ DecryptOne, TableOne);
    //    return num2 ^ (num2 << TableTwo) ^ DecryptTwo;
    //}




    private uint DecryptCIndex(uint uint_8)
    {

        //uint ecx = ((uint_8 ^ DecryptOne) << 15) & 0xFFFF0000 ^ ROR4(uint_8 ^ 0x12B9FA0D, 1) ^ 0x9D248AD;
        //return ecx;

        if (!ROR)
        {
            uint num = ROL4(uint_8 ^ DecryptOne, TableOne);
            return num ^ (num << TableTwo) ^ DecryptTwo;
        }
        uint num2 = ROR4(uint_8 ^ DecryptOne, TableOne);
        return num2 ^ (num2 << TableTwo) ^ DecryptTwo;
    }

    private void 帧率锁(int int_29)
    {
        Stopwatch stopwatch = new Stopwatch();
        stopwatch.Start();
        while ((int)stopwatch.Elapsed.TotalMilliseconds < int_29)
        {
            SpinWait.SpinUntil(() => true, int_29);
        }
    }

    public void 状态(string string_12, object object_0, bool bool_50 = true)
    {
        Program.mainForm_0.UICHANGE.Enqueue(new KeyValuePair<string, object>(string_12, object_0));
        if (bool_50)
        {
            Program.mainForm_0.are_UICHANGE.Set();
        }
    }

    public long GetTimeStamp()
    {
        return Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalMilliseconds);
    }

    private void 雷达MQTT()
    {
        string text = string_4;
        MqttClient mqttClient = new MqttClient(text);
        string clientId = Guid.NewGuid().ToString();
        try
        {
            mqttClient.Connect(clientId);
        }
        catch (Exception)
        {
            MessageBox.Show("共享服务器异常,请更换共享服务器!");
            结束进程();
        }
        if (!ThreadRunning)
        {
            return;
        }
        string oldData = "";
        while (true)
        {
            try
            {
                while (true)
                {
                    if (concurrentQueue_网页雷达.Count > 0 && concurrentQueue_网页雷达.TryDequeue(out string result))
                    {
                        if (mqttClient != null && mqttClient.IsConnected && oldData != result)
                        {
                            string s = Utf_8(result);
                            mqttClient.Publish(username, Encoding.UTF8.GetBytes(s), 0, retain: false);
                            oldData = result;
                        }
                    }
                    else
                    {
                        autoResetEvent_1.WaitOne();
                    }
                }
            }
            catch (MqttClientException)
            {
                mqttClient = new MqttClient(text);
                clientId = Guid.NewGuid().ToString();
                mqttClient.Connect(clientId);
            }
        }
    }

    private string Utf_8(string string_12)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(string_12);
        return Convert.ToBase64String(Gzip(bytes));
    }

    private byte[] Gzip(byte[] bytes_0)
    {
        using MemoryStream memoryStream = new MemoryStream();
        using (GZipStream gZipStream = new GZipStream(memoryStream, CompressionMode.Compress, leaveOpen: true))
        {
            gZipStream.Write(bytes_0, 0, bytes_0.Length);
            gZipStream.Close();
        }
        return memoryStream.ToArray();
    }

    private bool 判断人物(string string_12)
    {
        if (hashSet_人物.Contains(string_12))
        {
            return true;
        }
        return false;
    }

    private bool 判断人机(string string_12)
    {
        if (hashSet_人机.Contains(string_12))
        {
            return true;
        }
        return false;
    }

    private bool 判断盒子(string string_12)
    {
        if (!hashSet_盒子.Contains(string_12) || !CommonProperty.战斗模式)
        {
            return false;
        }
        return true;
    }

    private bool 判断载具(string string_12)
    {
        if (!hashSet_载具.Contains(string_12) || !CommonProperty.战斗模式)
        {
            return false;
        }
        return true;
    }

    private bool 判断投掷(string string_12)
    {
        if (!hashSet_投掷物.Contains(string_12))
        {
            return false;
        }
        return true;
    }

    private bool 判断物资(string string_12)
    {
        if (hashSet_物资.Contains(string_12) || !CommonProperty.战斗模式)
        {
            return true;
        }
        return false;
    }

    private void 结束进程()
    {
        if (vmm != null)
        {
            Vmm.CloseAll();
        }
        string environmentVariable = Environment.GetEnvironmentVariable("SystemRoot");
        using (Process process2 = new Process())
        {
            ProcessStartInfo startInfo3 = new ProcessStartInfo(environmentVariable + "\\System32\\taskkill.exe", "/f /im mqtt.exe");
            process2.StartInfo = startInfo3;
            process2.StartInfo.UseShellExecute = true;
            process2.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            process2.Start();
        }
        using (Process process3 = new Process())
        {
            ProcessStartInfo startInfo2 = new ProcessStartInfo(environmentVariable + "\\System32\\taskkill.exe", "/f /im " + AppDomain.CurrentDomain.FriendlyName);
            process3.StartInfo = startInfo2;
            process3.StartInfo.UseShellExecute = true;
            process3.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            process3.Start();
            process3.WaitForExit();
        }
        using (Process process = new Process())
        {
            ProcessStartInfo startInfo = new ProcessStartInfo(environmentVariable + "\\System32\\taskkill.exe", "/f /im Rain.exe ");
            process.StartInfo = startInfo;
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            process.Start();
            process.WaitForExit();
        }
        if (overlay != null)
        {
            overlay.Close();
            overlay.Dispose();
            overlay = null;
            EspOverlay.人物Clear();
            EspOverlay.载具Clear();
            EspOverlay.物资Clear();
        }
    }

    private bool DMA()
    {
        if (vmm != null)
        {
            Vmm.CloseAll();
        }
        bool flag = false;
        if (File.Exists(CommonProperty.path + "config/mmap.txt"))
        {
            try
            {
                vmm = new Vmm("", "-device", "fpga", "-memmap", CommonProperty.path + "mmap.txt", "-norefresh");
                flag = true;
            }
            catch (Exception)
            {
            }
            if (flag)
            {
                return true;
            }
        }
        try
        {
            if (vmm != null)
            {
                Vmm.CloseAll();
            }
            vmm = new Vmm("", "-device", "fpga", "-norefresh");
        }
        catch (Exception)
        {
            return false;
        }
        Vmm.MAP_PHYSMEMENTRY[] array = vmm.Map_GetPhysMem();
        if (array.Length != 0)
        {
            using (StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "config/mmap.txt"))
            {
                Vmm.MAP_PHYSMEMENTRY[] array2 = array;
                for (int i = 0; i < array2.Length; i++)
                {
                    Vmm.MAP_PHYSMEMENTRY mAP_PHYSMEMENTRY = array2[i];
                    ulong pa = mAP_PHYSMEMENTRY.pa;
                    string value = string.Format("{0} {1}", pa.ToString("X").ToLower(), (mAP_PHYSMEMENTRY.pa + mAP_PHYSMEMENTRY.cb - 1).ToString("X").ToLower());
                    streamWriter.WriteLine(value);
                }
            }
            Vmm.CloseAll();
            if (File.Exists(CommonProperty.path + "config/mmap.txt"))
            {
                try
                {
                    if (vmm != null)
                    {
                        Vmm.CloseAll();
                    }
                    vmm = new Vmm("", "-device", "fpga", "-memmap", CommonProperty.path + "config/mmap.txt", "-norefresh");
                    flag = true;
                }
                catch (Exception)
                {
                    flag = false;
                }
                if (flag)
                {
                    return true;
                }
            }
            try
            {
                if (vmm != null)
                {
                    Vmm.CloseAll();
                }
                vmm = new Vmm("", "-device", "fpga", "-norefresh");
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }
        return true;
    }

    private bool 读取游戏进程()
    {
        uint[] array = vmm.PidList();
        uint[] array2 = array;
        foreach (uint item in array2)
        {
            if (vmm.ProcessGetInformation(item).szName == "TslGame.exe")
            {
                pid = item;
                GameNULL = vmm.ProcessGetModuleBase(pid, "TslGame.exe");
                if (Read<ulong>(GameNULL + Uworld) != 0)
                {
                    return true;
                }
            }
        }
        return false;
    }

    private bool kyZpsbAxnb(ulong ulong_70, ulong ulong_71)
    {
        if (ulong_70 != 0L && ulong_71 != 0)
        {
            return Math.Abs(ulong_70.ToString().Length - ulong_71.ToString().Length) < 5;
        }
        return false;
    }

    private T MemRead_bool<T>(ulong ulong_70, ref bool bool_50)
    {
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            byte[] array = vmm.MemRead(pid, ulong_70, (uint)num, flags_);
            if (array.Length != num)
            {
                bool_50 = false;
                return default(T);
            }
            Marshal.Copy(array, 0, intPtr, num);
            bool_50 = true;
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            bool_50 = false;
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    public static T GetStructure<T>(byte[] bytes)
    {
        GCHandle handle = GCHandle.Alloc(bytes, GCHandleType.Pinned);
        T structure = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
        handle.Free();
        return structure;
    }

    public T Read<T>(ulong addr)
    {
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            byte[] array = vmm.MemRead(pid, addr, (uint)num, flags);
            if (array == null)
            {
                return default(T);
            }
            if (array.Length != num)
            {
                return default(T);
            }
            Marshal.Copy(array, 0, intPtr, num);
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    private T MemRead<T>(ulong addr)
    {
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            byte[] array = vmm.MemRead(pid, addr, (uint)num, flags_);
            if (array != null)
            {
                if (array.Length != num)
                {
                    return default(T);
                }
                Marshal.Copy(array, 0, intPtr, num);
                return (T)Marshal.PtrToStructure(intPtr, typeof(T));
            }
            return default(T);
        }
        catch (Exception)
        {
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    private T Read1<T>(uint uint_8, ulong ulong_70)
    {
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            byte[] array = vmm.MemRead(uint_8, ulong_70, (uint)num, flags_);
            if (array.Length != num)
            {
                return default(T);
            }
            Marshal.Copy(array, 0, intPtr, num);
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    private string NAME(byte[] bytes_0)
    {
        int num = 0;
        int num2 = 0;
        string result = "";
        byte[] array = new byte[64];
        foreach (byte b in bytes_0)
        {
            if (b < 30 || b > 128)
            {
                num++;
            }
            else
            {
                num = 0;
                array[num2++] = b;
            }
            if (num == 2)
            {
                result = Encoding.Default.GetString(array).Split('\0')[0];
                break;
            }
        }
        return result;
    }

    private Vector3 相减(Vector3 vector3_0, Vector3 vector3_1)
    {
        Vector3 result = default(Vector3);
        result.x = vector3_0.x - vector3_1.x;
        result.y = vector3_0.y - vector3_1.y;
        result.z = vector3_0.z - vector3_1.z;
        return result;
    }

    private Vector3 method_31(Vector3 vector3_0, Vector3 vector3_1)
    {
        Vector3 vector = default(Vector3);
        vector.x = 0f;
        vector.y = 0f;
        vector.z = 0f;
        Vector3 result = vector;
        vector = default(Vector3);
        vector.x = 0f;
        vector.y = 0f;
        vector.z = 0f;
        Vector3 vector2 = vector;
        vector2.x = vector3_1.x - vector3_0.x;
        vector2.y = vector3_1.y - vector3_0.y;
        vector2.z = vector3_1.z - vector3_0.z;
        double num = 180.0 / Math.PI;
        result.x = (float)(Math.Atan2(vector2.y, vector2.x) * num);
        result.y = (float)(Math.Atan2(vector2.z, Math.Sqrt(vector2.x * vector2.x + vector2.y * vector2.y)) * num);
        return result;
    }

    private Vector3 判断是否在视角(Vector3 vector3_0)
    {
        Vector3 result = vector3_0;
        if (result.x > 180f)
        {
            result.x -= 360f;
        }
        else if (result.x < -180f)
        {
            result.x += 360f;
        }
        if (result.y > 180f)
        {
            result.y -= 360f;
        }
        else if (result.y < -180f)
        {
            result.y += 360f;
        }
        if (result.x < -89f)
        {
            result.x = -89f;
        }
        if (result.x > 89f)
        {
            result.x = 89f;
        }
        while (result.y < 180f)
        {
            result.y += 360f;
        }
        while (result.y > 180f)
        {
            result.y -= 360f;
        }
        result.z = 0f;
        return result;
    }

    private Vector3 加全地图坐标(Vector3 vector3)
    {
        Vector3 result = default(Vector3);
        result.x = (float)Math.Ceiling(vector3.x + 全地图XY.x);
        result.y = (float)Math.Ceiling(vector3.y + 全地图XY.y);
        result.z = (float)Math.Ceiling(vector3.z + 全地图XY.z);
        return result;
    }

    private uint 计算距离(Vector3 vector3_0)
    {
        return (uint)Math.Sqrt(vector3_0.x * vector3_0.x + vector3_0.y * vector3_0.y + vector3_0.z * vector3_0.z);
    }

    private D3DMATRIX method_35(D3DMATRIX d3DMATRIX_0, D3DMATRIX d3DMATRIX_1)
    {
        D3DMATRIX result = default(D3DMATRIX);
        result._11 = d3DMATRIX_0._11 * d3DMATRIX_1._11 + d3DMATRIX_0._12 * d3DMATRIX_1._21 + d3DMATRIX_0._13 * d3DMATRIX_1._31 + d3DMATRIX_0._14 * d3DMATRIX_1._41;
        result._12 = d3DMATRIX_0._11 * d3DMATRIX_1._12 + d3DMATRIX_0._12 * d3DMATRIX_1._22 + d3DMATRIX_0._13 * d3DMATRIX_1._32 + d3DMATRIX_0._14 * d3DMATRIX_1._42;
        result._13 = d3DMATRIX_0._11 * d3DMATRIX_1._13 + d3DMATRIX_0._12 * d3DMATRIX_1._23 + d3DMATRIX_0._13 * d3DMATRIX_1._33 + d3DMATRIX_0._14 * d3DMATRIX_1._43;
        result._14 = d3DMATRIX_0._11 * d3DMATRIX_1._14 + d3DMATRIX_0._12 * d3DMATRIX_1._24 + d3DMATRIX_0._13 * d3DMATRIX_1._34 + d3DMATRIX_0._14 * d3DMATRIX_1._44;
        result._21 = d3DMATRIX_0._21 * d3DMATRIX_1._11 + d3DMATRIX_0._22 * d3DMATRIX_1._21 + d3DMATRIX_0._23 * d3DMATRIX_1._31 + d3DMATRIX_0._24 * d3DMATRIX_1._41;
        result._22 = d3DMATRIX_0._21 * d3DMATRIX_1._12 + d3DMATRIX_0._22 * d3DMATRIX_1._22 + d3DMATRIX_0._23 * d3DMATRIX_1._32 + d3DMATRIX_0._24 * d3DMATRIX_1._42;
        result._23 = d3DMATRIX_0._21 * d3DMATRIX_1._13 + d3DMATRIX_0._22 * d3DMATRIX_1._23 + d3DMATRIX_0._23 * d3DMATRIX_1._33 + d3DMATRIX_0._24 * d3DMATRIX_1._43;
        result._24 = d3DMATRIX_0._21 * d3DMATRIX_1._14 + d3DMATRIX_0._22 * d3DMATRIX_1._24 + d3DMATRIX_0._23 * d3DMATRIX_1._34 + d3DMATRIX_0._24 * d3DMATRIX_1._44;
        result._31 = d3DMATRIX_0._31 * d3DMATRIX_1._11 + d3DMATRIX_0._32 * d3DMATRIX_1._21 + d3DMATRIX_0._33 * d3DMATRIX_1._31 + d3DMATRIX_0._34 * d3DMATRIX_1._41;
        result._32 = d3DMATRIX_0._31 * d3DMATRIX_1._12 + d3DMATRIX_0._32 * d3DMATRIX_1._22 + d3DMATRIX_0._33 * d3DMATRIX_1._32 + d3DMATRIX_0._34 * d3DMATRIX_1._42;
        result._33 = d3DMATRIX_0._31 * d3DMATRIX_1._13 + d3DMATRIX_0._32 * d3DMATRIX_1._23 + d3DMATRIX_0._33 * d3DMATRIX_1._33 + d3DMATRIX_0._34 * d3DMATRIX_1._43;
        result._34 = d3DMATRIX_0._31 * d3DMATRIX_1._14 + d3DMATRIX_0._32 * d3DMATRIX_1._24 + d3DMATRIX_0._33 * d3DMATRIX_1._34 + d3DMATRIX_0._34 * d3DMATRIX_1._44;
        result._41 = d3DMATRIX_0._41 * d3DMATRIX_1._11 + d3DMATRIX_0._42 * d3DMATRIX_1._21 + d3DMATRIX_0._43 * d3DMATRIX_1._31 + d3DMATRIX_0._44 * d3DMATRIX_1._41;
        result._42 = d3DMATRIX_0._41 * d3DMATRIX_1._12 + d3DMATRIX_0._42 * d3DMATRIX_1._22 + d3DMATRIX_0._43 * d3DMATRIX_1._32 + d3DMATRIX_0._44 * d3DMATRIX_1._42;
        result._43 = d3DMATRIX_0._41 * d3DMATRIX_1._13 + d3DMATRIX_0._42 * d3DMATRIX_1._23 + d3DMATRIX_0._43 * d3DMATRIX_1._33 + d3DMATRIX_0._44 * d3DMATRIX_1._43;
        result._44 = d3DMATRIX_0._41 * d3DMATRIX_1._14 + d3DMATRIX_0._42 * d3DMATRIX_1._24 + d3DMATRIX_0._43 * d3DMATRIX_1._34 + d3DMATRIX_0._44 * d3DMATRIX_1._44;
        return result;
    }

    private bool 串流自瞄计算是否在FOV(float float_2, Vector3 vector3_0, Vector3 vector3_1, Vector3 vector3_2, Vector3 vector3_3, ref Vector2 vector2_7)
    {
        vector3_1.y += (E - Q) * vector3_1.x / 3f;
        FRotator fRotator = default(FRotator);
        fRotator.Pitch = vector3_0.x + vector3_1.x;
        fRotator.Yaw = vector3_0.y + vector3_1.y;
        fRotator.Roll = vector3_0.z + vector3_1.z;
        FRotator fRotator2 = fRotator;
        D3DMATRIX d3DMATRIX = fRotator2.Matrix();
        Vector3 vector = default(Vector3);
        vector.x = d3DMATRIX._11;
        vector.y = d3DMATRIX._12;
        vector.z = d3DMATRIX._13;
        Vector3 v = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._21;
        vector.y = d3DMATRIX._22;
        vector.z = d3DMATRIX._23;
        Vector3 v2 = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._31;
        vector.y = d3DMATRIX._32;
        vector.z = d3DMATRIX._33;
        Vector3 v3 = vector;
        Vector3 vector2 = 相减(vector3_3, vector3_2);
        vector = default(Vector3);
        vector.x = vector2.Dot(v2);
        vector.y = vector2.Dot(v3);
        vector.z = vector2.Dot(v);
        Vector3 vector3 = vector;
        if (vector3.z < 1f)
        {
            vector3.z = 1f;
        }
        if (vector3.z / 100f < 0f)
        {
            return false;
        }
        vector2_7.x = (float)(960.0 + (double)(vector3.x * 1920f) / 2.0 / (double)(float)Math.Tan((double)float_2 * Math.PI / 360.0) / vector3.z);
        vector2_7.y = (float)(540.0 - (double)(vector3.y * 1920f) / 2.0 / (double)(float)Math.Tan((double)float_2 * Math.PI / 360.0) / vector3.z);
        if (vector2_7.x > 0f && vector2_7.y > 0f && vector2_7.x <= 1920.0 && vector2_7.y <= 1080.0)
        {
            return true;
        }
        return false;
    }

    private bool WorldToScreen(float fOV, Vector3 ControlRotation, float RecoilRotation, Vector3 vector3_2, Vector3 vector3_3, ref Vector2 AimPos)
    {
        ControlRotation.y += (E - Q) * RecoilRotation / 3f;
        FRotator fRotator = default(FRotator);
        fRotator.Pitch = ControlRotation.x + (RecoilRotation * 1.1f);
        fRotator.Yaw = ControlRotation.y;
        fRotator.Roll = ControlRotation.z;
        FRotator fRotator2 = fRotator;
        D3DMATRIX d3DMATRIX = fRotator2.Matrix();
        Vector3 vector = default(Vector3);
        vector.x = d3DMATRIX._11;
        vector.y = d3DMATRIX._12;
        vector.z = d3DMATRIX._13;
        Vector3 v = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._21;
        vector.y = d3DMATRIX._22;
        vector.z = d3DMATRIX._23;
        Vector3 v2 = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._31;
        vector.y = d3DMATRIX._32;
        vector.z = d3DMATRIX._33;
        Vector3 v3 = vector;
        Vector3 vector2 = 相减(vector3_3, vector3_2);
        vector = default(Vector3);
        vector.x = vector2.Dot(v2);
        vector.y = vector2.Dot(v3);
        vector.z = vector2.Dot(v);
        Vector3 vector3 = vector;
        if (vector3.z < 1f)
        {
            vector3.z = 1f;
        }
        if (vector3.z / 100f < 0f)
        {
            return false;
        }
        AimPos.x = (float)(X分辨率 / 2.0 + (double)(vector3.x * X分辨率) / 2.0 / (double)(float)Math.Tan((double)fOV * Math.PI / 360.0) / vector3.z);
        AimPos.y = (float)(Y分辨率 / 2.0 - (double)(vector3.y * X分辨率) / 2.0 / (double)(float)Math.Tan((double)fOV * Math.PI / 360.0) / vector3.z);

        if (AimPos.x > 0f && AimPos.y > 0f && AimPos.x <= (double)(float)X分辨率 / 2.0 * 2.0 && AimPos.y <= (double)(float)Y分辨率 / 2.0 * 2.0)
        {
            return true;
        }
        return false;
    }

    private Vector2 计算透视坐标(Vector3 vector3_0)
    {
        Vector2 result = default(Vector2);
        D3DMATRIX d3DMATRIX = 本人.fcameraCacheData.POV.Rotation.Matrix();
        Vector3 vector = default(Vector3);
        vector.x = d3DMATRIX._11;
        vector.y = d3DMATRIX._12;
        vector.z = d3DMATRIX._13;
        Vector3 v = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._21;
        vector.y = d3DMATRIX._22;
        vector.z = d3DMATRIX._23;
        Vector3 v2 = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._31;
        vector.y = d3DMATRIX._32;
        vector.z = d3DMATRIX._33;
        Vector3 v3 = vector;
        Vector3 vector2 = 相减(vector3_0, 本人.fcameraCacheData.POV.Location);
        vector = default(Vector3);
        vector.x = vector2.Dot(v2);
        vector.y = vector2.Dot(v3);
        vector.z = vector2.Dot(v);
        Vector3 vector3 = vector;
        if (vector3.z < 1f)
        {
            vector3.z = 1f;
        }
        float fOV = 本人.fcameraCacheData.POV.FOV;
        result.x = (float)((double)(X分辨率 / 2f) + vector3.x * ((double)(X分辨率 / 2f) / Math.Tan(fOV * (float)Math.PI / 360f)) / vector3.z);
        result.y = (float)((double)(Y分辨率 / 2f) - vector3.y * ((double)(X分辨率 / 2f) / Math.Tan(fOV * (float)Math.PI / 360f)) / vector3.z);
        return result;
    }

    private float method_40(float float_2, float float_3, float float_4, float float_5)
    {
        float_2 -= float_4;
        float_3 -= float_5;
        return (float)Math.Sqrt(float_2 * float_2 + float_3 * float_3);
    }

    private Vector3 预判(Vector3 worldLocation, float 距离, Vector3 speed)
    {
        if (本人.InitialSpeed == 0f)
        {
            本人.InitialSpeed = 800f;
        }
        float down = ((距离 < 50f) ? 武器参数.Gun50 : ((距离 < 100f) ? 武器参数.Gun100 : ((距离 < 150f) ? 武器参数.Gun150 : ((距离 < 200f) ? 武器参数.Gun200 : ((距离 < 250f) ? 武器参数.Gun250 : ((距离 < 300f) ? 武器参数.Gun300 : ((距离 < 350f) ? 武器参数.Gun350 : ((距离 < 400f) ? 武器参数.Gun400 : ((距离 < 450f) ? 武器参数.Gun450 : ((距离 < 500f) ? 武器参数.Gun500 : ((距离 < 550f) ? 武器参数.Gun550 : ((距离 < 600f) ? 武器参数.Gun600 : 武器参数.Gun999))))))))))));
        float TravelTime = 距离 / 本人.InitialSpeed * down;
        Vector3 result = default(Vector3);
        result.x = worldLocation.x + speed.x * TravelTime;
        result.y = worldLocation.y + speed.y * TravelTime;
        result.z = worldLocation.z + speed.z * TravelTime;
        result.z += 4.9f * (float)Math.Pow(TravelTime, 2.0) * (距离 / 5f) * 武器参数.初速度;
        return result;
    }

    private void 参数()
    {
        自瞄延时 = Program.mainForm_0.延时;
        KM_COM = Program.mainForm_0.KM_COM;
        M_Handle = Program.mainForm_0.M_Handle;
        魔盒 = Program.mainForm_0.魔盒;
        玩家信息 = Program.mainForm_0.ShowPlayerInfo;
        游戏ID = Program.mainForm_0.ShowName;
        ShowAudience = Program.mainForm_0.ShowAudience;
        ShowKillNum = Program.mainForm_0.ShowKillNum;
        轰炸区 = Program.mainForm_0.ShowRedZone;
        ShowKD = Program.mainForm_0.ShowKD;
        ShowDamageAvg = Program.mainForm_0.ShowDamageAvg;
        ShowSurvivalLevel = Program.mainForm_0.ShowSurvivalLevel;
        ShowDistance = Program.mainForm_0.ShowDistance;
        debug = false;
        ShowRank = Program.mainForm_0.ShowRank;
        白名单_队伍 = Program.mainForm_0.TeamAdd;
        MqttServer = Program.mainForm_0.MqttServer;
        WebServer = Program.mainForm_0.WebServer;
        串流自瞄 = false;
        自瞄模式 = Program.mainForm_0.ControlMode;
        ControlHID = Program.mainForm_0.ControlHID;
        X分辨率 = Program.mainForm_0.ScreenX;
        Y分辨率 = Program.mainForm_0.ScreenY;
        物资0 = Program.mainForm_0.显示物资组0;
        物资1 = Program.mainForm_0.显示物资组1;
        物资2 = Program.mainForm_0.显示物资组2;
        物资3 = Program.mainForm_0.显示物资组3;
        透视开关 = Program.mainForm_0.ShowESP;
        热键_战斗模式 = Program.mainForm_0.热键_战斗模式;
        热键_显示物资组0 = Program.mainForm_0.热键_显示物资组0;
        热键_显示物资组1 = Program.mainForm_0.热键_显示物资组1;
        热键_显示物资组2 = Program.mainForm_0.热键_显示物资组2;
        热键_显示物资组3 = Program.mainForm_0.热键_显示物资组3;
        热键_缩小 = Program.mainForm_0.热键_缩小;
        热键_放大 = Program.mainForm_0.热键_放大;
        热键_刷新 = Program.mainForm_0.热键_刷新;
        热键_ESP = Program.mainForm_0.热键_ESP;
        热键_用户信息 = Program.mainForm_0.热键_用户信息;
        热键_自瞄配置2 = Program.mainForm_0.热键_自瞄配置2;
        热键_添加黑名单 = Program.mainForm_0.添加黑名单;
        雷达物资 = Program.mainForm_0.bool_雷达物资;
        雷达载具 = Program.mainForm_0.bool_雷达载具;
        //动态FOV = Program.mainForm_0.bool_动态fov;
        //跳过击杀 = Program.mainForm_0.bool_跳过击杀;
        //开镜自瞄 = Program.mainForm_0.bool_开镜自瞄;
        if (string_白名单 != 白名单_队伍 || 白名单_队伍 == "")
        {
            string_白名单 = 白名单_队伍;
            CommonProperty.hashSet_友军.Clear();
            CommonProperty.HashSet_白名单.Clear();
            if (白名单_队伍 != "")
            {
                string[] array = 白名单_队伍.Split(',');
                string[] array2 = array;
                foreach (string text in array2)
                {
                    if (text.Trim() != "")
                    {
                        try
                        {
                            CommonProperty.hashSet_友军.Add(uint.Parse(text.Trim()));
                        }
                        catch
                        {
                            CommonProperty.HashSet_白名单.Add(text.Trim());
                        }
                    }
                }
            }
        }
        if (X分辨率 == 2560 && Y分辨率 == 1080)
        {
            vector2_0.x = 2560f;
            vector2_0.y = 1080f;
            vector2_1.x = 2529f;
            vector2_1.y = 1054f;
            vector2_2.x = vector2_1.x / vector2_0.x;
            vector2_2.y = vector2_1.y / vector2_0.y;
            vector2_3.x = float_0 / vector2_0.x;
            vector2_3.y = float_0 / vector2_0.y;
            vector2_4.x = vector2_2.x - vector2_3.x;
            vector2_4.y = vector2_2.y - vector2_3.y;
            vector2_5.x = float_1 / vector2_0.x;
            vector2_5.y = float_1 / vector2_0.y;
            vector2_6.x = vector2_2.x - vector2_5.x;
            vector2_6.y = vector2_2.y - vector2_5.y;
        }
        if (!CommonProperty.保存物资)
        {
            return;
        }
        using StreamReader streamReader8 = new StreamReader(CommonProperty.path + "config/物资配置.json");
        dictionary_物资.Clear();
        string value3 = streamReader8.ReadToEnd();
        dictionary_物资 = JsonConvert.DeserializeObject<Dictionary<string, 物资info>>(value3);
        foreach (KeyValuePair<string, 物资info> item3 in JsonConvert.DeserializeObject<Dictionary<string, 物资info>>(value3))
        {
            dictionary_物资[item3.Key.Replace("Item_", "")] = dictionary_物资[item3.Key];
        }
        foreach (KeyValuePair<string, 物资info> item4 in dictionary_物资)
        {
            if (item4.Value.showItem && item4.Value.shortName != "")
            {
                hashSet_物资.Add(item4.Key.Trim());
            }
        }
    }

    private void 按键()
    {
        E = 0;
        Q = 0;
        string zmpz = (CommonProperty.espconfig.EspConfig.自瞄配置2 ? " [2]" : " [1]");
        读写 @class = new 读写(pid, vmm);
        自瞄 = false;
        子骨骼自瞄 = false;
        自瞄倒地 = false;
        参数();
        CommonProperty.保存物资 = false;
        自瞄2 = false;
        左键按下 = false;
        热键战斗模式 = false;
        热键显示物资组0 = false;
        热键显示物资组1 = false;
        热键显示物资组2 = false;
        热键显示物资组3 = false;
        热键缩小 = false;
        热键放大 = false;
        数据刷新 = false;
        热键ESP = false;
        热键用户信息 = false;
        添加黑名单 = false;
        bool flag = false;
        CommonProperty.自瞄配置2 = false;
        热键[61] = 0;
        热键[62] = 0;
        热键[60] = 0;
        热键 = vmm.MemRead(CommonProperty.winlogonpid, CommonProperty.gafAsyncKeyStateAddress, 64u, 1u);
        if ((热键.Length != 64 && 热键[61] != 32) || 热键[62] != 128 || 热键[60] != 130)
        {
            状态("自瞄状态", "热键获取失败");
        }
        if (游戏机按键是否按下(1) || 雷达机按键是否按下(1))
        {
            左键按下 = true;
        }
        if (游戏机按键是否按下(热键_战斗模式) || 雷达机按键是否按下(热键_战斗模式))
        {
            热键战斗模式 = true;
            flag = true;
        }
        if (游戏机按键是否按下(热键_显示物资组0) || 雷达机按键是否按下(热键_显示物资组0))
        {
            热键显示物资组0 = true;
            flag = true;
        }
        if (游戏机按键是否按下(热键_显示物资组1) || 雷达机按键是否按下(热键_显示物资组1))
        {
            热键显示物资组1 = true;
            flag = true;
        }
        if (游戏机按键是否按下(热键_显示物资组2) || 雷达机按键是否按下(热键_显示物资组2))
        {
            热键显示物资组2 = true;
            flag = true;
        }
        if (游戏机按键是否按下(热键_显示物资组3) || 雷达机按键是否按下(热键_显示物资组3))
        {
            热键显示物资组3 = true;
            flag = true;
        }
        if (游戏机按键是否按下(热键_放大) || 雷达机按键是否按下(热键_放大))
        {
            热键放大 = true;
        }
        if (游戏机按键是否按下(热键_缩小) || 雷达机按键是否按下(热键_缩小))
        {
            热键缩小 = true;
        }
        if (游戏机按键是否按下(热键_刷新) || 雷达机按键是否按下(热键_刷新))
        {
            数据刷新 = true;
            flag = true;
        }
        if (游戏机按键是否按下(热键_ESP) || 雷达机按键是否按下(热键_ESP))
        {
            热键ESP = true;
            flag = true;
        }
        if (游戏机按键是否按下(热键_用户信息) || 雷达机按键是否按下(热键_用户信息))
        {
            热键用户信息 = true;
            flag = true;
        }
        if (游戏机按键是否按下(36) || 雷达机按键是否按下(36))
        {
            CommonProperty.菜单 = !CommonProperty.菜单;
            flag = true;
        }
        if (游戏机按键是否按下(热键_自瞄配置2) || 雷达机按键是否按下(热键_自瞄配置2))
        {
            自瞄2 = true;
            flag = true;
        }
        if (游戏机按键是否按下(热键_添加黑名单) || 雷达机按键是否按下(热键_添加黑名单))
        {
            添加黑名单 = true;
            flag = true;
        }
        if (!flag && !当前地图.Contains("TslLobby"))
        {

            if ((自瞄模式 == 1 && (ControlHID == 1 || ControlHID == 2 || ControlHID == 3) && !KM_COM.IsOpen) || (ControlHID == 4 && M_Handle == IntPtr.Zero) || (ControlHID == 5 && 魔盒 == 0) || 自瞄模式 == 5)
            {
                武器参数.自瞄FOV = 0;
                aimPlayer = 0uL;
                状态("自瞄状态", "请连接控制器");
            }
            else if (本人.WeaponName == "")
            {
                武器参数.自瞄FOV = 0;
                aimPlayer = 0uL;
                状态("自瞄状态", "未检测到武器 " + zmpz);
                if (武器参数.武器名称 == "")
                {
                    武器参数.武器名称 = 武器参数.string_0.Replace("Weapon", "").Replace("Weap", "").Replace("_C", "");
                }
            }
            else if (本人.WeaponName != "" && 本人.人物血量 > 0f && 自瞄模式 == 1)
            {
                string object_ = "自瞄配置:" + zmpz;
                状态("自瞄状态", object_);
                自瞄参数(本人.WeaponName);
                if (!游戏机按键是否按下(武器参数.自瞄按键1) && !游戏机按键是否按下(武器参数.自瞄按键2))
                {
                    aimPlayer = 0uL;
                    自瞄 = false;
                }
                else
                {
                    if (游戏机按键是否按下(69) || 雷达机按键是否按下(69))
                    {
                        E = 1;
                    }
                    if (游戏机按键是否按下(81) || 雷达机按键是否按下(69))
                    {
                        Q = 1;
                    }
                    @class.Add<byte>(本人.WeaponAddr + CurrentAmmoData);
                    @class.Finish();
                    ammoData = @class.Get<byte>(本人.WeaponAddr + CurrentAmmoData);
                    if (ammoData > 0)
                    {
                        if (武器参数.父骨骼 != 0)
                        {
                            自瞄 = true;
                        }
                        else if (游戏机按键是否按下(武器参数.自瞄子按键))
                        {
                            自瞄 = true;
                        }
                    }
                    else
                    {
                        aimPlayer = 0uL;
                        自瞄 = false;
                    }

                }
                if (游戏机按键是否按下(武器参数.自瞄子按键))
                {
                    子骨骼自瞄 = true;
                }
                if (游戏机按键是否按下(武器参数.自瞄倒地按键))
                {
                    自瞄倒地 = true;
                }
            }
            else
            {
                武器参数.自瞄FOV = 0;
                aimPlayer = 0uL;
                自瞄 = false;
            }
        }
        else
        {
            状态("自瞄状态", "");
        }
        if (自瞄2)
        {
            CommonProperty.espconfig.EspConfig.自瞄配置2 = !CommonProperty.espconfig.EspConfig.自瞄配置2;
            CommonProperty.自瞄配置2 = true;
        }
        if (热键战斗模式)
        {
            CommonProperty.战斗模式 = !CommonProperty.战斗模式;
        }
        if (热键显示物资组0)
        {
            物资0 = !物资0;
            状态("显示物资组0", 物资0.ToString());
        }
        if (热键显示物资组1)
        {
            物资1 = !物资1;
            状态("显示物资组1", 物资1.ToString());
        }
        if (热键显示物资组2)
        {
            物资2 = !物资2;
            状态("显示物资组2", 物资2.ToString());
        }
        if (热键显示物资组3)
        {
            物资3 = !物资3;
            状态("显示物资组3", 物资3.ToString());
        }
        if (热键用户信息)
        {
            玩家信息 = !玩家信息;
            状态("ShowPlayerInfo", 玩家信息.ToString());
        }
        if (热键ESP)
        {
            透视开关 = !透视开关;
            状态("ShowESP", 透视开关.ToString());
        }
        if (热键放大)
        {
            int_0 = 1;
        }
        if (热键缩小)
        {
            int_0 = -1;
        }
        是否透视();
        if (flag)
        {
            Thread.Sleep(150);
        }
    }

    private void 自瞄参数(string string_0)
    {
        if (武器参数 == null)
        {
            武器参数 = new 自瞄数据();
        }
        if (!CommonProperty.espconfig.EspConfig.自瞄配置2)
        {
            if (Program.mainForm_0.GunList.ContainsKey(string_0))
            {
                武器参数.string_0 = string_0;
                if (Program.mainForm_0.GunList[string_0].ShortName == "")
                {
                    Program.mainForm_0.GunList[string_0].ShortName = string_0.Replace("Weapon", "").Replace("Weap", "").Replace("_C", "");
                }
                武器参数.武器名称 = Program.mainForm_0.GunList[string_0].ShortName;
                武器参数.枪type = Program.mainForm_0.GunList[string_0].GunType;
                武器参数.初速度 = Program.mainForm_0.GunList[string_0].Raise;
                武器参数.Gun50 = Program.mainForm_0.GunList[string_0].Gun50;
                武器参数.Gun100 = Program.mainForm_0.GunList[string_0].Gun100;
                武器参数.Gun150 = Program.mainForm_0.GunList[string_0].Gun150;
                武器参数.Gun200 = Program.mainForm_0.GunList[string_0].Gun200;
                武器参数.Gun250 = Program.mainForm_0.GunList[string_0].Gun250;
                武器参数.Gun300 = Program.mainForm_0.GunList[string_0].Gun300;
                武器参数.Gun350 = Program.mainForm_0.GunList[string_0].Gun350;
                武器参数.Gun400 = Program.mainForm_0.GunList[string_0].Gun400;
                武器参数.Gun450 = Program.mainForm_0.GunList[string_0].Gun450;
                武器参数.Gun500 = Program.mainForm_0.GunList[string_0].Gun500;
                武器参数.Gun550 = Program.mainForm_0.GunList[string_0].Gun550;
                武器参数.Gun600 = Program.mainForm_0.GunList[string_0].Gun600;
                武器参数.Gun999 = Program.mainForm_0.GunList[string_0].Gun999;
            }
            else
            {
                武器参数.枪type = 8;
            }
            if (!Program.mainForm_0.GunTypeList.ContainsKey(武器参数.枪type))
            {
                Program.mainForm_0.GunTypeList[武器参数.枪type] = new GunType();
            }
            武器参数.抢类型 = Program.mainForm_0.GunTypeList[武器参数.枪type].TypeName;
            武器参数.自瞄按键1 = Program.mainForm_0.GunTypeList[武器参数.枪type].AIMKEY1;
            武器参数.自瞄按键2 = Program.mainForm_0.GunTypeList[武器参数.枪type].AIMKEY2;
            武器参数.自瞄子按键 = Program.mainForm_0.GunTypeList[武器参数.枪type].LOCKKEY;
            武器参数.自瞄倒地按键 = Program.mainForm_0.GunTypeList[武器参数.枪type].倒地KEY;
            武器参数.父骨骼 = dictionary_骨骼点[Program.mainForm_0.GunTypeList[武器参数.枪type].AIM部位];
            武器参数.子骨骼 = dictionary_骨骼点[Program.mainForm_0.GunTypeList[武器参数.枪type].LOCK部位];
            武器参数.自瞄响应 = Program.mainForm_0.GunTypeList[武器参数.枪type].AimDelay;
            武器参数.自瞄距离 = Program.mainForm_0.GunTypeList[武器参数.枪type].AimDistince;
            武器参数.自瞄FOV = Program.mainForm_0.GunTypeList[武器参数.枪type].AimRange;
            武器参数.自瞄平滑 = Program.mainForm_0.GunTypeList[武器参数.枪type].AimSmooth;
            武器参数.自瞄压枪 = Program.mainForm_0.GunTypeList[武器参数.枪type].Recoil;
            武器参数.X轴自瞄力度 = Program.mainForm_0.GunTypeList[武器参数.枪type].MoveX;
            武器参数.Y轴自瞄力度 = Program.mainForm_0.GunTypeList[武器参数.枪type].MoveY;
            武器参数.自瞄优先级 = Program.mainForm_0.GunTypeList[武器参数.枪type].Aim优先级;
            武器参数.动态范围 = Program.mainForm_0.GunTypeList[武器参数.枪type].动态范围;
            武器参数.跳过击杀 = Program.mainForm_0.GunTypeList[武器参数.枪type].跳过击杀;
            武器参数.开镜自瞄 = Program.mainForm_0.GunTypeList[武器参数.枪type].开镜自瞄;
            return;
        }
        if (Program.mainForm_0.GunList.ContainsKey(string_0))
        {
            武器参数.string_0 = string_0;
            if (Program.mainForm_0.GunList[string_0].ShortName == "")
            {
                Program.mainForm_0.GunList[string_0].ShortName = string_0.Replace("Weapon", "").Replace("Weap", "").Replace("_C", "");
            }
            武器参数.武器名称 = Program.mainForm_0.GunList[string_0].ShortName;
            武器参数.枪type = Program.mainForm_0.GunList[string_0].GunType;
            武器参数.初速度 = Program.mainForm_0.GunList[string_0].Raise;
            武器参数.Gun50 = Program.mainForm_0.GunList[string_0].Gun50;
            武器参数.Gun100 = Program.mainForm_0.GunList[string_0].Gun100;
            武器参数.Gun150 = Program.mainForm_0.GunList[string_0].Gun150;
            武器参数.Gun200 = Program.mainForm_0.GunList[string_0].Gun200;
            武器参数.Gun250 = Program.mainForm_0.GunList[string_0].Gun250;
            武器参数.Gun300 = Program.mainForm_0.GunList[string_0].Gun300;
            武器参数.Gun350 = Program.mainForm_0.GunList[string_0].Gun350;
            武器参数.Gun400 = Program.mainForm_0.GunList[string_0].Gun400;
            武器参数.Gun450 = Program.mainForm_0.GunList[string_0].Gun450;
            武器参数.Gun500 = Program.mainForm_0.GunList[string_0].Gun500;
            武器参数.Gun550 = Program.mainForm_0.GunList[string_0].Gun550;
            武器参数.Gun600 = Program.mainForm_0.GunList[string_0].Gun600;
            武器参数.Gun999 = Program.mainForm_0.GunList[string_0].Gun999;
        }
        else
        {
            武器参数.枪type = 8;
        }
        if (!Program.mainForm_0.GunTypeList2.ContainsKey(武器参数.枪type))
        {
            Program.mainForm_0.GunTypeList2[武器参数.枪type] = new GunType();
        }
        武器参数.抢类型 = Program.mainForm_0.GunTypeList2[武器参数.枪type].TypeName;
        武器参数.自瞄按键1 = Program.mainForm_0.GunTypeList2[武器参数.枪type].AIMKEY1;
        武器参数.自瞄按键2 = Program.mainForm_0.GunTypeList2[武器参数.枪type].AIMKEY2;
        武器参数.自瞄子按键 = Program.mainForm_0.GunTypeList2[武器参数.枪type].LOCKKEY;
        武器参数.自瞄倒地按键 = Program.mainForm_0.GunTypeList2[武器参数.枪type].倒地KEY;
        武器参数.父骨骼 = dictionary_骨骼点[Program.mainForm_0.GunTypeList2[武器参数.枪type].AIM部位];
        武器参数.子骨骼 = dictionary_骨骼点[Program.mainForm_0.GunTypeList2[武器参数.枪type].LOCK部位];
        武器参数.自瞄响应 = Program.mainForm_0.GunTypeList2[武器参数.枪type].AimDelay;
        武器参数.自瞄距离 = Program.mainForm_0.GunTypeList2[武器参数.枪type].AimDistince;
        武器参数.自瞄FOV = Program.mainForm_0.GunTypeList2[武器参数.枪type].AimRange;
        武器参数.自瞄平滑 = Program.mainForm_0.GunTypeList2[武器参数.枪type].AimSmooth;
        武器参数.自瞄压枪 = Program.mainForm_0.GunTypeList2[武器参数.枪type].Recoil;
        武器参数.X轴自瞄力度 = Program.mainForm_0.GunTypeList2[武器参数.枪type].MoveX;
        武器参数.Y轴自瞄力度 = Program.mainForm_0.GunTypeList2[武器参数.枪type].MoveY;
        武器参数.自瞄优先级 = Program.mainForm_0.GunTypeList2[武器参数.枪type].Aim优先级;
        武器参数.动态范围 = Program.mainForm_0.GunTypeList2[武器参数.枪type].动态范围;
        武器参数.跳过击杀 = Program.mainForm_0.GunTypeList2[武器参数.枪type].跳过击杀;
        武器参数.开镜自瞄 = Program.mainForm_0.GunTypeList2[武器参数.枪type].开镜自瞄;
    }

    private void 是否透视()
    {
        if (透视 != 透视开关)
        {
            透视 = 透视开关;
        }
    }

    private void 获取战绩()
    {
        while (ThreadRunning)
        {
            if (!当前地图.Contains("TslLobby") && 当前地图 != "")
            {
                try
                {
                    PlayerRankManger.mod = Program.mainForm_0.KDMODE;
                    PlayerRankManger.单排 = (CommonProperty.单排 ? "1" : "4");
                    if (CommonProperty.玩家列表s.Count > 0)
                    {
                        for (int i = 0; i < CommonProperty.玩家列表s.Count; i++)
                        {
                            玩家列表 info = CommonProperty.玩家列表s[i];
                            if (!(info.段位 != "") && !(info.KD != "") && !(info.name == ""))
                            {
                                playerRankManger.pull(info.name);
                                RankAPI rank = playerRankManger.get(info.name);
                                if (rank.expire_time > 0)
                                {
                                    info.KD = rank.kd.ToString() ?? "";
                                    info.段位 = rank.GetRankName();
                                }
                            }
                        }
                    }
                    Thread.Sleep(1000);
                }
                catch
                {
                }
            }
            Thread.Sleep(10);
        }
    }

    private void 控制器计算(int 自瞄X, int 自瞄Y)
    {
        int 平滑 = 武器参数.自瞄平滑 + 1;
        int X轴 = 自瞄X;
        int Y轴 = 自瞄Y;
        int num1 = 130;
        int num4 = 70;
        int num5 = 武器参数.自瞄响应;
        X轴 /= 平滑;
        int num2 = X轴 % 平滑;
        Y轴 /= 平滑;
        int num3 = Y轴 % 平滑;
        if (平滑 == 1)
        {
            if (X轴 != 0)
            {
                X轴 = X轴 * 100 / num1;
            }
            if (Y轴 != 0)
            {
                Y轴 = Y轴 * 100 / num1;
            }
        }
        else
        {
            if (X轴 != 0)
            {
                X轴 = X轴 * 100 / num4;
            }
            if (Y轴 != 0)
            {
                Y轴 = Y轴 * 100 / num4;
            }
        }
        X轴 = Math.Min(X轴, 50);
        Y轴 = Math.Min(Y轴, 50);

        if (武器参数.自瞄压枪 != 0 && 游戏机按键是否按下(1))
        {
            Y轴 += 武器参数.自瞄压枪;
        }
        if (ControlHID == 3)
        {
            int 分段 = new Random().Next((num5 <= 10) ? 1 : 5, (num5 - 5 < 1) ? 1 : (num5 - 5));
            if (分段 > 1)
            {
                MouseMove(X轴, Y轴, 分段);
            }
            else
            {
                MouseMove(X轴, Y轴);
            }
            return;
        }
        if (ControlHID == 6)
        {
            MouseMove(X轴, Y轴);
            return;
        }
        for (int i = 0; i < 平滑; i++)
        {
            MouseMove(X轴, Y轴);
        }
        if (num2 != 0 || num3 != 0)
        {
            MouseMove(num2, num3);
        }

        //int 平滑 = 武器参数.自瞄平滑 + 1;
        //int X轴 = 自瞄X;
        //int Y轴 = 自瞄Y;
        //int num1 = 130;
        //int num2 = 70;

        //if (平滑 == 1)
        //{
        //    if (X轴 != 0)
        //    {
        //        X轴 = ((X轴 / 平滑) * 100) / num1;
        //    }
        //    if (Y轴 != 0)
        //    {
        //        Y轴 = ((Y轴 / 平滑) * 100) / num1;
        //    }
        //}
        //else
        //{
        //    if (X轴 != 0)
        //    {
        //        X轴 = ((X轴 / 平滑) * 100) / num2;
        //    }
        //    if (Y轴 != 0)
        //    {
        //        Y轴 = ((Y轴 / 平滑) * 100) / num2;
        //    }
        //}

        //if (武器参数.自瞄压枪 != 0 && 游戏机按键是否按下(1))
        //{
        //    Y轴 = Y轴 + 武器参数.自瞄压枪;
        //}

        ////压枪Pid_Y.set(0.1f, 0.1f, 0.1f, 0.1f);
        ////压枪Pid_Y.input((int)(Y轴));
        ////Y轴 = 压枪Pid_Y.output();
        ////压枪Pid_X.set(0.1f, 0.1f, 0.1f, 0.1f);
        ////压枪Pid_X.input((int)(X轴));
        ////X轴 = 压枪Pid_X.output();

        //X轴 = Math.Min(X轴, 50);
        //Y轴 = Math.Min(Y轴, 50);

        //MouseMove(X轴, Y轴);
        //return;
    }

    private void MouseMove(int x, int y, int int_31 = 1)
    {
        try
        {
            switch (ControlHID)
            {
                case 0:
                    AimBot(x, y);
                    break;
                case 1:
                    {
                        string text2 = "";
                        if (x >= 0 || y <= 0)
                        {
                            if (x == 0 && y > 0)
                            {
                                text2 = $"[MM2{Math.Abs(y)}]";
                            }
                            else if (x > 0 && y > 0)
                            {
                                text2 = $"[MM8{Math.Abs(x)},{Math.Abs(y)}]";
                            }
                            else if (x > 0 && y < 0)
                            {
                                text2 = $"[MM7{Math.Abs(x)},{Math.Abs(y)}]";
                            }
                            else if (x < 0 && y < 0)
                            {
                                text2 = $"[MM5{Math.Abs(x)},{Math.Abs(y)}]";
                            }
                            else if (x == 0 && y < 0)
                            {
                                text2 = $"[MM1{Math.Abs(y)}]";
                            }
                            else if (x > 0 && y == 0)
                            {
                                text2 = $"[MM4{Math.Abs(x)}]";
                            }
                            else if (x < 0 && y == 0)
                            {
                                text2 = $"[MM3{Math.Abs(x)}]";
                            }
                        }
                        else
                        {
                            text2 = $"[MM6{Math.Abs(x)},{Math.Abs(y)}]";
                        }
                        KM_COM.WriteLine(text2);
                        break;
                    }
                case 2:
                    {
                        byte[] array = new byte[7] { 87, 171, 2, 0, 0, 0, 0 };
                        if (x > 0)
                        {
                            array[4] = (byte)Math.Abs(x);
                        }
                        if (x < 0)
                        {
                            array[4] = (byte)(256 - Math.Abs(x));
                        }
                        if (y > 0)
                        {
                            array[5] = (byte)Math.Abs(y);
                        }
                        if (y < 0)
                        {
                            array[5] = (byte)(256 - Math.Abs(y));
                        }
                        KM_COM.Write(array, 0, 7);
                        break;
                    }
                case 3:
                    {
                        string text = $"km.move({x},{y},{int_31})\r\n";
                        KM_COM.Write(text);
                        break;
                    }
                case 4:
                    M_MoveR(M_Handle, x, y);
                    break;
                case 5:
                    MoveR(x, y);
                    break;
                case 6:
                    kmNet_mouse_move_auto(x, y, int_31);
                    break;
            }
        }
        catch
        {
        }
    }


    [Obfuscation(Feature = "virtualization", Exclude = false)]
    private bool 登录验证()
    {
        try
        {
            string jiemi = CommonProperty.jiemi;
            offset obj = JsonConvert.DeserializeObject<offset>(jiemi);
            Shield = obj.Shield;
            Uworld = obj.Uworld;
            GNames = obj.GNames;
            Leve = obj.Leve;
            GameInstence = obj.GameInstence;
            LocalPlayer = obj.LocalPlayer;
            PlayerController = obj.PlayerController;
            Actor = obj.Actor;
            AcknowledgedPawn = obj.AcknowledgedPawn;
            ObjID = obj.ObjID;
            IDD = obj.IDD;
            TeamNumber = obj.TeamNumber;
            Health = obj.Health;
            HealthDie = obj.HealthDie;
            Audience = obj.Audience;
            Playname = obj.Playname;
            PlayerState = obj.PlayerState;
            PlayerSatisitc = obj.PlayerSatisitc;
            Mesh = obj.Mesh;
            Position = obj.Position;
            DroppedItemGroup = obj.DroppedItemGroup;
            DroppedItemGroupUItem = obj.DroppedItemGroup_UItem;
            物品一 = obj.物品一;
            物品二 = obj.物品二;
            世界转小地图 = obj.世界转小地图;
            被瞄偏移 = obj.被瞄偏移;
            GameState = obj.GameState;
            LerpSafetyZonePosition = obj.LerpSafetyZonePosition;
            LerpSafetyZoneRadius = obj.LerpSafetyZoneRadius;
            PoisonGasWarningPosition = obj.PoisonGasWarningPosition;
            PoisonGasWarningRadius = obj.PoisonGasWarningRadius;
            RedZonePosition = obj.RedZonePosition;
            RedZoneRadius = obj.RedZoneRadius;
            ROR = obj.ROR;
            DecryptOne = obj.DecryptOne;
            TableOne = obj.TableOne;
            TableTwo = obj.TableTwo;
            DecryptTwo = obj.DecryptTwo;
            PlayerCameraManager = obj.PlayerCameraManager;
            CameraPos = obj.CameraPos;
            CameraRot = obj.CameraRot;
            CameraFov = obj.CameraFov;
            Bone = obj.Bone;
            BoneArry = obj.BoneArry;
            Eyes = obj.Eyes;
            WeaponProcessor = obj.WeaponProcessor;
            EquippedWeapons = obj.EquippedWeapons;
            CurrentWeaponIndex = obj.CurrentWeaponIndex;
            WeaponTrajectoryData = obj.WeaponTrajectoryData;
            TrajectoryConfig = obj.TrajectoryConfig;
            AnimScriptInstance = obj.AnimScriptInstance;
            ControlRotationCP = obj.ControlRotationCP;
            RecoilADSRotationCP = obj.RecoilADSRotationCP;
            CurrentAmmoData = obj.CurrentAmmoData;
            ElapsedCookingTime = obj.ElapsedCookingTime;
            TimeTillExplosion = obj.TimeTillExplosion;
            TrainingMapGrid = obj.TrainingMapGrid;
            Visibility = obj.Visibility;
            Slot = obj.Slot;
            VehicleRiderComponent = obj.VehicleRiderComponent;
            LastVehiclePawn = obj.LastVehiclePawn;
            ActorRootComp = obj.ActorRootComp;
            ReplicatedMovement = obj.ReplicatedMovement;
            Veloctity = obj.Veloctity;
            背包状态 = obj.背包状态;
            MapMarker = obj.MapMarker;
            PartnerLevel = obj.PartnerLevel;
            SurvivalLevel = obj.SurvivalLevel;
            bVisible = obj.BWasKicked;
            WidgetStateMap = obj.WidgetStateMap;
            MyHUD = obj.MyHUD;
            BlockInputWidgetList = obj.BlockInputWidgetList;
            SelectMinimapSizeIndex = obj.SelectMinimapSizeIndex;
            DroppedItem = obj.DroppedItem;
            LayoutData = obj.LayoutData;
            Offsets = obj.Offsets;
            Alignment = obj.Alignment;
            GroggyHealth = obj.地图判断; //GroggyHealth
            PlayerArray = obj.PlayerArray;
            PlayerName = obj.PlayerName;
            PlayerTeamid = obj.PlayerTeamid;
            DamageDealtOnEnemy = obj.DamageDealtOnEnemy;
            bIsSpectator = obj.bIsSpectator;
            AActorRole = obj.MatchShortGuid;// AActorRole  328  808c
            AntiCheatCharacterSyncManager = obj.AntiCheatCharacterSyncManager;
            CharacterId = obj.DormantSoundOnClient;// CharacterId  9d0  2512
            Health2 = obj.SoundDataList;//Health2  9e0   2528
            Health3 = obj.DormantSoundDataSize;//Health3  9c4   2500
            Health4 = obj.CharacterAkComponent;//Health4  9b0    2480
            Health5 = obj.AttachParent;//Health5 9c5   2501
            Health6 = obj.RelativeLocation;//Health6 9c0   2496
            V1 = obj.V1;
            V2 = obj.V2;
            V3 = obj.V3;
            V4 = obj.V4;
            V5 = obj.V5;
            V6 = obj.V6;
            V7 = obj.V7;
            V8 = obj.V8;
            V9 = obj.V9;
            V10 = obj.V10;
            V11 = obj.V11;
            V12 = obj.V12;
            V13 = obj.V13;
            V14 = obj.V14;
            V15 = obj.V15;
            V16 = obj.V16;
            MapGrids = obj.MapGrids;
            return true;
        }
        catch (Exception)
        {
            MessageBox.Show("正在维护");
            return false;
        }
    }

    public Game()
    {
        try
        {
            if (!登录验证())
            {
                结束进程();
            }
            if (!DMA())
            {
                MessageBox.Show("DMA初始化失败");
                结束进程();
            }
            参数();
            if (!CommonProperty.热键监控)
            {
                Vmm.MAP_MODULEENTRY mAP_MODULEENTRY = vmm.Map_GetModuleFromName(4u, "win32ksgd.sys");
                if (mAP_MODULEENTRY.vaBase == 0)
                {
                    if (!vmm.PidGetFromName("winlogon.exe", out CommonProperty.winlogonpid))
                    {
                        MessageBox.Show("winlogon.exe WinPid Get Failed!Pls reboot Game PC!");
                        结束进程();
                    }
                    CommonProperty.winlogonpid |= 2147483648u;
                    ulong vaBase = vmm.Map_GetModuleFromName(CommonProperty.winlogonpid, "win32kbase.sys").vaBase;
                    Vmm.MAP_EATINFO EatInfo;
                    Vmm.MAP_EATENTRY[] array = vmm.Map_GetEAT(CommonProperty.winlogonpid, "win32kbase.sys", out EatInfo);
                    for (int i = 0; i < array.Length; i++)
                    {
                        Vmm.MAP_EATENTRY mAP_EATENTRY = array[i];
                        if (mAP_EATENTRY.wszFunction.Trim() == "gafAsyncKeyState")
                        {
                            CommonProperty.gafAsyncKeyStateAddress = mAP_EATENTRY.vaFunction;
                        }
                    }
                    if (CommonProperty.gafAsyncKeyStateAddress == 0)
                    {
                        if (!File.Exists(CommonProperty.path + "config/KeyState.ini"))
                        {
                            MessageBox.Show("(10)热键读取失败,请重启游戏机再试!!!");
                            结束进程();
                        }
                        else
                        {
                            using StreamReader streamReader = new StreamReader(CommonProperty.path + "config/KeyState.ini");
                            CommonProperty.gafAsyncKeyStateAddress = vaBase + ulong.Parse(streamReader.ReadLine());
                        }
                    }
                    else
                    {
                        using StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "config/KeyState.ini");
                        streamWriter.WriteLine((CommonProperty.gafAsyncKeyStateAddress - vaBase).ToString());
                    }
                }
                else
                {
                    ulong vaBase2 = mAP_MODULEENTRY.vaBase;
                    CommonProperty.gafAsyncKeyStateAddress = Read1<ulong>(CommonProperty.winlogonpid, Read1<ulong>(CommonProperty.winlogonpid, Read1<ulong>(CommonProperty.winlogonpid, vaBase2 + 12560)));
                    if (CommonProperty.gafAsyncKeyStateAddress == 0)
                    {
                        CommonProperty.winlogonpid = 4u;
                        CommonProperty.gafAsyncKeyStateAddress = Read1<ulong>(CommonProperty.winlogonpid, Read1<ulong>(CommonProperty.winlogonpid, Read1<ulong>(CommonProperty.winlogonpid, vaBase2 + 12560)));
                    }
                    if (CommonProperty.gafAsyncKeyStateAddress == 0)
                    {
                        CommonProperty.gafAsyncKeyStateAddress = Read1<ulong>(CommonProperty.winlogonpid, Read1<ulong>(CommonProperty.winlogonpid, Read1<ulong>(CommonProperty.winlogonpid, vaBase2 + 12568)));
                    }
                    CommonProperty.gafAsyncKeyStateAddress += 13968uL;
                }
                热键 = vmm.MemRead(CommonProperty.winlogonpid, CommonProperty.gafAsyncKeyStateAddress, 64u, 1u);
                if (热键[61] != 32 && 热键[62] != 128 && 热键[60] != 130)
                {
                    MessageBox.Show("(11)热键读取失败,请删除目录KeyState.ini后再试（win11-22h2用户建议更换21h2系统）!");
                    结束进程();
                }
                else
                {
                    CommonProperty.热键监控 = true;
                }
            }

            username = CommonProperty.username;
            if (!读取游戏进程())
            {
                CommonProperty.GameStartSlim.Set();
                return;
            }
            dictionary_骨骼点.Add(0, 15);
            dictionary_骨骼点.Add(1, 5);
            dictionary_骨骼点.Add(2, 4);
            dictionary_骨骼点.Add(3, 0);
            dictionary_骨骼点.Add(4, 16);
            DecryptThis = MemRead<ulong>(GameNULL + Shield);
            if (DecryptThis == 0)
            {
                CommonProperty.GameStartSlim.Set();
                return;
            }
            byte[] array2 = vmm.MemRead(pid, DecryptThis, 512u, flags_);
            InitD(array2, DecryptThis);
            using (StreamReader streamReader2 = new StreamReader(CommonProperty.path + "config/地图.ini"))
            {
                string text = "";
                while ((text = streamReader2.ReadLine()) != null)
                {
                    if (text.Trim() != "")
                    {
                        hashSet_地图.Add(text.Trim());
                    }
                }
            }
            using (StreamReader streamReader3 = new StreamReader(CommonProperty.path + "config/玩家类.ini"))
            {
                string text2 = "";
                while ((text2 = streamReader3.ReadLine()) != null)
                {
                    if (text2.Trim() != "")
                    {
                        hashSet_人物.Add(text2.Trim());
                    }
                }
            }
            using (StreamReader streamReader4 = new StreamReader(CommonProperty.path + "config/人机类.ini"))
            {
                string text3 = "";
                while ((text3 = streamReader4.ReadLine()) != null)
                {
                    if (text3.Trim() != "")
                    {
                        hashSet_人机.Add(text3.Trim());
                    }
                }
            }
            using (StreamReader streamReader5 = new StreamReader(CommonProperty.path + "config/盒子.ini"))
            {
                string text4 = "";
                while ((text4 = streamReader5.ReadLine()) != null)
                {
                    if (text4.Trim() != "")
                    {
                        hashSet_盒子.Add(text4.Trim());
                    }
                }
            }
            using (StreamReader streamReader6 = new StreamReader(CommonProperty.path + "config/载具.json"))
            {
                string value = streamReader6.ReadToEnd();
                dictionary_载具 = JsonConvert.DeserializeObject<Dictionary<string, 载具info>>(value);
                foreach (KeyValuePair<string, 载具info> item in dictionary_载具)
                {
                    if (item.Value.showItem && item.Value.shortName != "")
                    {
                        hashSet_载具.Add(item.Key.Trim());
                    }
                }
            }
            if (File.Exists(CommonProperty.path + "config/物资配置2.json"))
            {
                using StreamReader streamReader7 = new StreamReader(CommonProperty.path + "config/物资配置2.json");
                string value2 = streamReader7.ReadToEnd();
                dictionary_投掷物 = JsonConvert.DeserializeObject<Dictionary<string, 投掷info>>(value2);
                foreach (KeyValuePair<string, 投掷info> item2 in dictionary_投掷物)
                {
                    hashSet_投掷物.Add(item2.Key.Trim());
                }
            }
            using (StreamReader streamReader8 = new StreamReader(CommonProperty.path + "config/物资配置.json"))
            {
                string value3 = streamReader8.ReadToEnd();
                dictionary_物资 = JsonConvert.DeserializeObject<Dictionary<string, 物资info>>(value3);
                foreach (KeyValuePair<string, 物资info> item3 in JsonConvert.DeserializeObject<Dictionary<string, 物资info>>(value3))
                {
                    dictionary_物资[item3.Key.Replace("Item_", "")] = dictionary_物资[item3.Key];
                }
                foreach (KeyValuePair<string, 物资info> item4 in dictionary_物资)
                {
                    if (item4.Value.showItem && item4.Value.shortName != "")
                    {
                        hashSet_物资.Add(item4.Key.Trim());
                    }
                }
            }
            Thread thread = new Thread(雷达MQTT);
            thread.IsBackground = true;
            thread.Start();
            Thread thread2 = new Thread(Start);
            thread2.IsBackground = true;
            thread2.Start();
            Thread thread3 = new Thread(获取战绩);
            thread3.IsBackground = true;
            thread3.Start();
            Thread thread4 = new Thread(人物透视);
            thread4.IsBackground = true;
            thread4.Start();
            Thread thread5 = new Thread(刷新内存缓存);
            thread5.IsBackground = true;
            thread5.Start();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString());
        }
    }

    private void 等待游戏进程()
    {
        MapAddr = 0uL;
        MinimapCanvasWidgetAddr = 0uL;
        MapGrid = 0uL;
        Slot1 = 0uL;
        读本人数据计数 = 0u;
        地图状态计数 = 0;
        本人 = new 本人();
        ActorClassNameList.Clear();
        dictionary投掷物.Clear();
        dictionary_人物.Clear();
        dictionary物资.Clear();
        dictionary盒子载具.Clear();
        全部对象.Clear();
        状态("地图", "未检测到游戏", bool_50: false);
        状态("延迟", "", bool_50: false);
        状态("清理友军黑名单", "");
        if (透视)
        {
            EspOverlay.投掷物Clear();
            EspOverlay.物资Clear();
            EspOverlay.载具Clear();
            EspOverlay.人物Clear();
            EspOverlay.人物Clear1();
            CommonProperty.fov = 0f;
            CommonProperty.本人观战人数 = 0u;
            CommonProperty.菜单 = true;
        }
        CommonProperty.hashSet_友军.Clear();
        CommonProperty.HashSet_白名单.Clear();
        CommonProperty.玩家列表s = new List<玩家列表>();
        CommonProperty.玩家列表ss = new List<ulong>();
        if (!CommonProperty.刷新列表)
        {
            CommonProperty.刷新列表 = true;
        }
        网页雷达.雷达初始化数据();
        网页雷达.地图 = "\"Range_Main\"";
        concurrentQueue_网页雷达.Enqueue(网页雷达.雷达数据());
        autoResetEvent_1.Set();
        ThreadRunning = false;
        CommonProperty.GameStartSlim.Set();
    }

    private void 初始化数据()
    {
        MapAddr = 0uL;
        MinimapCanvasWidgetAddr = 0uL;
        MapGrid = 0uL;
        Slot1 = 0uL;
        地图状态计数 = 0;
        PlayerArray1 = 0uL;
        PlayerNum = 0u;
        角色指针 = 0uL;
        角色数量 = 0u;
        循环次数 = 0uL;
        延迟_主线程 = 0;
        本人 = new 本人();
        网页雷达.雷达初始化数据();
        ActorClassNameList.Clear();
        dictionary投掷物.Clear();
        dictionary_人物.Clear();
        dictionary物资.Clear();
        dictionary盒子载具.Clear();
        全部对象.Clear();
        hashSet_雷达信息.Clear();
        CommonProperty.hashSet_友军.Clear();
        CommonProperty.HashSet_白名单.Clear();
        CommonProperty.迷雾人数 = 0;
        if (透视)
        {
            CommonProperty.fov = 0f;
            CommonProperty.本人观战人数 = 0u;
            EspOverlay.投掷物Clear();
            EspOverlay.物资Clear();
            EspOverlay.载具Clear();
            EspOverlay.人物Clear();
            EspOverlay.人物Clear1();
        }
        CommonProperty.玩家列表s = new List<玩家列表>();
        CommonProperty.玩家列表ss = new List<ulong>();
        if (!CommonProperty.刷新列表)
        {
            CommonProperty.刷新列表 = true;
        }
    }

    private void 刷新内存缓存()
    {
        Stopwatch stopwatch = new Stopwatch();
        int 计时器1 = 0;
        int 计时器2 = 0;
        int 计时器3 = 0;
        int 计时器4 = 0;
        int 计时器5 = 0;
        while (true)
        {
            stopwatch.Reset();
            stopwatch.Start();
            Thread.Sleep(10);
            stopwatch.Stop();
            计时器1 += (int)stopwatch.Elapsed.TotalMilliseconds;
            计时器2 += (int)stopwatch.Elapsed.TotalMilliseconds;
            计时器3 += (int)stopwatch.Elapsed.TotalMilliseconds;
            计时器4 += (int)stopwatch.Elapsed.TotalMilliseconds;
            if (计时器3 > 4500 && (计时器1 > 350 || 计时器2 > 700))
            {
                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                计时器1 = 0;
                计时器2 = 0;
                计时器3 = 0;
            }
            if (计时器2 > 700 && 计时器1 > 350)
            {
                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB_PARTIAL, 1);
                计时器2 = 0;
                计时器1 = 0;
            }
            if (计时器1 > 350)
            {
                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM_PARTIAL, 1);
                计时器1 = 0;
            }
            if (计时器5 > 300000)
            {
                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_SLOW, 1);
                计时器5 = 0;
                计时器1 = 0;
                计时器2 = 0;
                计时器3 = 0;
            }
        }
    }

    private void 人物透视()
    {
        //TS1 = vmm.Scatter_Initialize(pid, Vmm.FLAG_NOCACHE);
        Stopwatch stopwatch_融合器线程 = new Stopwatch();
        List<Actor人物> 人物 = new List<Actor人物>();
        读写2 memGet = new 读写2(pid, vmm);
        while (ThreadRunning)
        {
            try
            {
                if (!当前地图.Contains("TslLobby"))
                {
                    stopwatch_融合器线程.Restart();
                    stopwatch_融合器线程.Start();
                    List<Actor人物> result = new List<Actor人物>();
                    memGet.Clear();
                    memGet.Add<float>(本人.投影相机 + CameraFov);
                    memGet.Add<FRotator>(本人.投影相机 + CameraRot);
                    memGet.Add<Vector3>(本人.投影相机 + CameraPos);
                    memGet.Finish();
                    本人.fcameraCacheData.POV.FOV = memGet.Get<float>(本人.投影相机 + CameraFov);
                    本人.fcameraCacheData.POV.Rotation = memGet.Get<FRotator>(本人.投影相机 + CameraRot);
                    本人.fcameraCacheData.POV.Location = memGet.Get<Vector3>(本人.投影相机 + CameraPos);
                    if (透视)
                    {
                        while (concurrentQueue_人物.TryDequeue(out result))
                        {
                            if (result != null && result.Count > 0)
                            {
                                人物 = result;
                            }
                        }
                    }
                    if (人物.Count > 0)
                    {
                        if (瞄准)
                        {
                            foreach (Actor人物 item in 人物)
                            {
                                if (item.存活 && item.骨盆.x > 0 && item.骨盆.y > 0 && item.骨盆.x < X分辨率 && item.骨盆.y < Y分辨率)
                                {
                                    memGet.Add<FTransform>(item.视角 + BoneArry);
                                    memGet.Add<ulong>(item.视角 + Bone);
                                }
                            }
                            memGet.Finish();
                            foreach (Actor人物 item in 人物)
                            {
                                if (item.存活 && item.骨盆.x > 0 && item.骨盆.y > 0 && item.骨盆.x < X分辨率 && item.骨盆.y < Y分辨率)
                                {
                                    item.Actor_Bone = memGet.Get<FTransform>(item.视角 + BoneArry);
                                    item.Bone = memGet.Get<ulong>(item.视角 + Bone);
                                    item.人物位面 = MemRead<float>(item.视角 + Eyes);
                                    item.是否可视 = ((item.人物位面 >= 本人.可视) ? 1 : 0);
                                }
                            }
                            foreach (KeyValuePair<ulong, Actor人物> item in dictionary_人物)
                            {
                                if (item.Value.存活 && Math.Ceiling(item.Value.人物血量 + item.Value.倒地血量) == 0.0)
                                {
                                    item.Value.存活 = false;
                                }
                            }
                            foreach (Actor人物 item in 人物)
                            {
                                if (item.存活 && item.距离 < CommonProperty.espconfig.EspConfig.透视距离 && item.骨盆.x > 0 && item.骨盆.y > 0 && item.骨盆.x < X分辨率 && item.骨盆.y < Y分辨率)
                                {
                                    memGet.Add<FTransform>(item.Bone + (ulong)头部 * 48L);
                                    memGet.Add<FTransform>(item.Bone + (ulong)骨盆 * 48L);
                                    if (CommonProperty.espconfig.EspConfig.骨骼)
                                    {
                                        memGet.Add<FTransform>(item.Bone + (ulong)颈部 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)胸部 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)左肘 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)右肘 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)左手 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)右手 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)左肩 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)右肩 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)左膝 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)右膝 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)左脚 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)右脚 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)左胯 * 48L);
                                        memGet.Add<FTransform>(item.Bone + (ulong)右胯 * 48L);

                                    }
                                }
                            }
                            memGet.Finish();
                            foreach (Actor人物 item in 人物)
                            {
                                if (item.存活 && item.距离 < CommonProperty.espconfig.EspConfig.透视距离 && item.骨盆.x > 0 && item.骨盆.y > 0 && item.骨盆.x < X分辨率 && item.骨盆.y < Y分辨率)
                                {
                                    item.头部_Bone = memGet.Get<FTransform>(item.Bone + (ulong)头部 * 48L);
                                    item.骨盆_Bone = memGet.Get<FTransform>(item.Bone + (ulong)骨盆 * 48L);
                                    if (CommonProperty.espconfig.EspConfig.骨骼)
                                    {
                                        item.颈部_Bone = memGet.Get<FTransform>(item.Bone + (ulong)颈部 * 48L);
                                        item.胸部_Bone = memGet.Get<FTransform>(item.Bone + (ulong)胸部 * 48L);
                                        item.左肘_Bone = memGet.Get<FTransform>(item.Bone + (ulong)左肘 * 48L);
                                        item.右肘_Bone = memGet.Get<FTransform>(item.Bone + (ulong)右肘 * 48L);
                                        item.左手_Bone = memGet.Get<FTransform>(item.Bone + (ulong)左手 * 48L);
                                        item.右手_Bone = memGet.Get<FTransform>(item.Bone + (ulong)右手 * 48L);
                                        item.左肩_Bone = memGet.Get<FTransform>(item.Bone + (ulong)左肩 * 48L);
                                        item.右肩_Bone = memGet.Get<FTransform>(item.Bone + (ulong)右肩 * 48L);
                                        item.左胯_Bone = memGet.Get<FTransform>(item.Bone + (ulong)左胯 * 48L);
                                        item.右胯_Bone = memGet.Get<FTransform>(item.Bone + (ulong)右胯 * 48L);
                                        item.左膝_Bone = memGet.Get<FTransform>(item.Bone + (ulong)左膝 * 48L);
                                        item.右膝_Bone = memGet.Get<FTransform>(item.Bone + (ulong)右膝 * 48L);
                                        item.左脚跟_Bone = memGet.Get<FTransform>(item.Bone + (ulong)左脚 * 48L);
                                        item.右脚跟_Bone = memGet.Get<FTransform>(item.Bone + (ulong)右脚 * 48L);

                                    }
                                }
                            }
                            foreach (Actor人物 item in 人物)
                            {
                                if (item.存活 && 透视 && item.距离 < CommonProperty.espconfig.EspConfig.透视距离 && item.骨盆.x > 0 && item.骨盆.y > 0 && item.骨盆.x < X分辨率 && item.骨盆.y < Y分辨率)
                                {
                                    item.中心坐标.x = item.Actor_Bone.Translation.x;
                                    item.中心坐标.y = item.Actor_Bone.Translation.y;
                                    item.中心坐标.z = item.Actor_Bone.Translation.z;
                                    D3DMATRIX d3DMATRIX_3 = item.骨盆_Bone.ToMatrixWithScale();
                                    D3DMATRIX d3DMATRIX2 = method_35(d3DMATRIX_3, item.Actor_Bone.ToMatrixWithScale());
                                    item.vector3_骨盆.x = d3DMATRIX2._41;
                                    item.vector3_骨盆.y = d3DMATRIX2._42;
                                    item.vector3_骨盆.z = d3DMATRIX2._43;
                                    D3DMATRIX d3DMATRIX_4 = item.头部_Bone.ToMatrixWithScale();
                                    D3DMATRIX d3DMATRIX3 = method_35(d3DMATRIX_4, item.Actor_Bone.ToMatrixWithScale());
                                    item.vector3_头部.x = d3DMATRIX3._41;
                                    item.vector3_头部.y = d3DMATRIX3._42;
                                    item.vector3_头部.z = d3DMATRIX3._43;
                                    if (CommonProperty.espconfig.EspConfig.骨骼)
                                    {
                                        D3DMATRIX d3DMATRIX_5 = item.颈部_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX4 = method_35(d3DMATRIX_5, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_颈部.x = d3DMATRIX4._41;
                                        item.vector3_颈部.y = d3DMATRIX4._42;
                                        item.vector3_颈部.z = d3DMATRIX4._43;
                                        D3DMATRIX d3DMATRIX_6 = item.胸部_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX5 = method_35(d3DMATRIX_6, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_胸部.x = d3DMATRIX5._41;
                                        item.vector3_胸部.y = d3DMATRIX5._42;
                                        item.vector3_胸部.z = d3DMATRIX5._43;
                                        D3DMATRIX d3DMATRIX_7 = item.左肘_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX6 = method_35(d3DMATRIX_7, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_左肘.x = d3DMATRIX6._41;
                                        item.vector3_左肘.y = d3DMATRIX6._42;
                                        item.vector3_左肘.z = d3DMATRIX6._43;
                                        D3DMATRIX d3DMATRIX_8 = item.右肘_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX7 = method_35(d3DMATRIX_8, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_右肘.x = d3DMATRIX7._41;
                                        item.vector3_右肘.y = d3DMATRIX7._42;
                                        item.vector3_右肘.z = d3DMATRIX7._43;
                                        D3DMATRIX d3DMATRIX_9 = item.左手_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX8 = method_35(d3DMATRIX_9, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_左手.x = d3DMATRIX8._41;
                                        item.vector3_左手.y = d3DMATRIX8._42;
                                        item.vector3_左手.z = d3DMATRIX8._43;
                                        D3DMATRIX d3DMATRIX_10 = item.右手_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX9 = method_35(d3DMATRIX_10, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_右手.x = d3DMATRIX9._41;
                                        item.vector3_右手.y = d3DMATRIX9._42;
                                        item.vector3_右手.z = d3DMATRIX9._43;
                                        D3DMATRIX d3DMATRIX_11 = item.左膝_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX10 = method_35(d3DMATRIX_11, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_左膝.x = d3DMATRIX10._41;
                                        item.vector3_左膝.y = d3DMATRIX10._42;
                                        item.vector3_左膝.z = d3DMATRIX10._43;
                                        D3DMATRIX d3DMATRIX_12 = item.右膝_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX11 = method_35(d3DMATRIX_12, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_右膝.x = d3DMATRIX11._41;
                                        item.vector3_右膝.y = d3DMATRIX11._42;
                                        item.vector3_右膝.z = d3DMATRIX11._43;
                                        D3DMATRIX d3DMATRIX_13 = item.左脚跟_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX12 = method_35(d3DMATRIX_13, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_左脚跟.x = d3DMATRIX12._41;
                                        item.vector3_左脚跟.y = d3DMATRIX12._42;
                                        item.vector3_左脚跟.z = d3DMATRIX12._43;
                                        D3DMATRIX d3DMATRIX_14 = item.右脚跟_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX13 = method_35(d3DMATRIX_14, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_右脚跟.x = d3DMATRIX13._41;
                                        item.vector3_右脚跟.y = d3DMATRIX13._42;
                                        item.vector3_右脚跟.z = d3DMATRIX13._43;
                                        D3DMATRIX d3DMATRIX_55 = item.左肩_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX44 = method_35(d3DMATRIX_55, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_左肩.x = d3DMATRIX44._41;
                                        item.vector3_左肩.y = d3DMATRIX44._42;
                                        item.vector3_左肩.z = d3DMATRIX44._43;
                                        D3DMATRIX d3DMATRIX_66 = item.右肩_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX55 = method_35(d3DMATRIX_66, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_右肩.x = d3DMATRIX55._41;
                                        item.vector3_右肩.y = d3DMATRIX55._42;
                                        item.vector3_右肩.z = d3DMATRIX55._43;
                                        D3DMATRIX d3DMATRIX_555 = item.左胯_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX444 = method_35(d3DMATRIX_555, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_左胯.x = d3DMATRIX444._41;
                                        item.vector3_左胯.y = d3DMATRIX444._42;
                                        item.vector3_左胯.z = d3DMATRIX444._43;
                                        D3DMATRIX d3DMATRIX_666 = item.右胯_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX555 = method_35(d3DMATRIX_666, item.Actor_Bone.ToMatrixWithScale());
                                        item.vector3_右胯.x = d3DMATRIX555._41;
                                        item.vector3_右胯.y = d3DMATRIX555._42;
                                        item.vector3_右胯.z = d3DMATRIX555._43;
                                    }
                                }
                            }

                            stopwatch_融合器线程.Stop();
                            int 融合器线程 = (int)stopwatch_融合器线程.Elapsed.TotalMilliseconds;
                            if (融合器线程 < 1000 / 360)
                            {
                                帧率锁((1000 / 360) - 融合器线程);
                            }

                        }
                        foreach (Actor人物 item7 in 人物)
                        {
                            if (item7.存活 && 透视 && item7.距离 < CommonProperty.espconfig.EspConfig.透视距离)
                            {
                                item7.中心 = 计算透视坐标(item7.中心坐标);
                                item7.骨盆 = 计算透视坐标(item7.vector3_骨盆);
                                item7.头部 = 计算透视坐标(item7.vector3_头部);
                                if (CommonProperty.espconfig.EspConfig.骨骼)
                                {
                                    item7.颈部 = 计算透视坐标(item7.vector3_颈部);
                                    item7.胸部 = 计算透视坐标(item7.vector3_胸部);
                                    item7.左肘 = 计算透视坐标(item7.vector3_左肘);
                                    item7.右肘 = 计算透视坐标(item7.vector3_右肘);
                                    item7.左手 = 计算透视坐标(item7.vector3_左手);
                                    item7.右手 = 计算透视坐标(item7.vector3_右手);
                                    item7.左膝 = 计算透视坐标(item7.vector3_左膝);
                                    item7.右膝 = 计算透视坐标(item7.vector3_右膝);
                                    item7.左脚跟 = 计算透视坐标(item7.vector3_左脚跟);
                                    item7.右脚跟 = 计算透视坐标(item7.vector3_右脚跟);
                                    item7.左肩 = 计算透视坐标(item7.vector3_左肩);
                                    item7.右肩 = 计算透视坐标(item7.vector3_右肩);
                                    item7.左胯 = 计算透视坐标(item7.vector3_左胯);
                                    item7.右胯 = 计算透视坐标(item7.vector3_右胯);
                                }
                            }
                        }
                        float 小地图透视距离 = 200f;
                        if (小地图放大)
                        {
                            小地图透视距离 *= float_1 / float_0;
                        }
                        Vector2 vector11 = (小地图放大 ? vector2_5 : vector2_3);
                        Vector2 vector12 = ((!小地图放大) ? vector2_4 : vector2_6);
                        Vector3 vector13 = default(Vector3);
                        Vector2 vector14 = default(Vector2);
                        List<Actor人物> espData = new List<Actor人物>();
                        foreach (Actor人物 item in 人物)
                        {
                            if (!item.存活 || item.是否友军 != 0)
                            {
                                continue;
                            }
                            if (CommonProperty.espconfig.EspConfig.小地图 && item.距离 <= 小地图透视距离 && 相机 == 0 && !本人.死亡 && MinimapCanvasWidgetAddr != 0L && !自瞄 && item.人物雷达坐标.x > 0f && item.人物雷达坐标.y > 0f)
                            {
                                vector13.x = (item.人物雷达坐标.x - 本人.距离坐标.x) * 0.01f;
                                vector13.y = (item.人物雷达坐标.y - 本人.距离坐标.y) * 0.01f;
                                vector14.x = vector12.x * X分辨率 + (1f + vector13.x / 小地图透视距离) * vector11.x / 2f * X分辨率;
                                vector14.y = vector12.y * Y分辨率 + (1f + vector13.y / 小地图透视距离) * vector11.y / 2f * Y分辨率;
                                item.vector3_小地图 = vector14;
                            }
                            else
                            {
                                item.vector3_小地图.x = 0f;
                                item.vector3_小地图.y = 0f;
                            }
                            if (CommonProperty.IsShow)
                            {
                                float MapSizeFactored = MapSize / WorldMapZoomFactor;
                                Vector3 vector15 = default(Vector3);
                                vector15.x = MapSize * (1f + WorldMapPosition.x);
                                vector15.y = MapSize * (1f + WorldMapPosition.y);
                                vector15.z = 0f;
                                Vector3 WorldCenterLocation = vector15;
                                Vector3 RadarPos = 相减(item.人物雷达坐标, WorldCenterLocation);
                                float x = X分辨率 / 2 + RadarPos.x / MapSizeFactored * (Y分辨率 / 2);
                                float y = Y分辨率 / 2 + RadarPos.y / MapSizeFactored * (Y分辨率 / 2);
                                if (x > 0f && y > 0f && x < X分辨率 && y < Y分辨率)
                                {
                                    item.vector3_大地图.x = x;
                                    item.vector3_大地图.y = y;
                                }
                                else
                                {
                                    item.vector3_大地图.x = 0f;
                                    item.vector3_大地图.y = 0f;
                                }
                            }
                            espData.Add(item);
                        }
                        if (espData.Count > 0)
                        {
                            EspOverlay.Esp人物Queue.Enqueue(espData);
                            CommonProperty.EspResetEventSlim.Set();
                        }
                        else
                        {
                            EspOverlay.人物Clear();
                        }
                    }
                    帧率锁(CommonProperty.espconfig.EspConfig.帧延迟);
                }
                else
                {
                    人物.Clear();
                    Thread.Sleep(1);
                }
            }
            catch
            {
            }
        }
    }

    private void Start()
    {
        读写 memGet = new 读写(pid, vmm);
        int 线程延迟 = 0;
        int 线程延迟2 = 0;
        int 计数器_地图 = 0;
        uint 自瞄循环次数 = 0u;
        Vector3 毒圈中心 = default(Vector3);
        Vector3 安全区中心 = default(Vector3);
        Vector3 轰炸区坐标 = default(Vector3);
        Stopwatch 主线程计时器 = new Stopwatch();
        Stopwatch 自瞄计时器 = new Stopwatch();
        while (ThreadRunning)
        {
            try
            {
                基准值 = Decrypt_(Read<ulong>(GameNULL + Uworld));
                当前地图 = MemGetName(DecryptCIndex(MemRead<uint>(基准值 + ObjID)));
                if (当前地图 == "")
                {
                    计数器_地图++;
                    if (计数器_地图 == 8)
                    {
                        等待游戏进程();
                        break;
                    }
                    Thread.Sleep(500);
                    continue;
                }
                计数器_地图 = 0;
                if (!当前地图.Contains("TslLobby"))
                {
                    if (!hashSet_地图.Contains(当前地图))
                    {
                        continue;
                    }
                    if (!CommonProperty.心跳验证)
                    {
                        this.状态("地图", "心跳验证失败");
                        Thread.Sleep(1000);
                        continue;
                    }
                    setMap();
                    this.状态("地图", "");
                    地图状态计数 = 0;
                    初始化数据();
                    线程延迟2 = 0;
                    ulong 对象指针 = Decrypt_(MemRead<ulong>(Decrypt_(MemRead<ulong>(基准值 + Leve)) + Actor));
                    if (!kyZpsbAxnb(对象指针, 基准值))
                    {
                        Thread.Sleep(500);
                        continue;
                    }
                    bool bool_ = false;
                    if (本人.addr == 0)
                    {
                        本人.玩家控制 = Decrypt_(Read<ulong>(Decrypt_(Read<ulong>(Read<ulong>(Decrypt_(Read<ulong>(基准值 + GameInstence)) + LocalPlayer))) + PlayerController));
                        本人.投影相机 = Read<ulong>(本人.玩家控制 + PlayerCameraManager);
                        本人.addr = Decrypt_(Read<ulong>(本人.玩家控制 + AcknowledgedPawn));
                    }
                    if (本人.addr != 0)
                    {
                        if (本人.TeamID == 19831029)
                        {
                            本人.TeamID = MemRead_bool<uint>(本人.addr + TeamNumber, ref bool_) % 100000u;
                            if (!bool_)
                            {
                                本人.TeamID = 19831029u;
                            }
                        }
                        if (本人.name == "")
                        {
                            本人.name = MemRead_Encoding_Unicode_GetString(MemRead<ulong>(本人.addr + this.Playname), 64u);
                            if (本人.name.Contains(" "))
                            {
                                本人.name = 本人.name.Split(' ')[1].Trim();
                            }
                        }
                    }
                    if (本人.name == "" && 读本人数据计数 < 10)
                    {
                        读本人数据计数++;
                        continue;
                    }
                    while (基准值 == Decrypt_(Read<ulong>(GameNULL + Uworld)))
                    {
                        主线程计时器.Reset();
                        主线程计时器.Start();
                        按键();
                        if (数据刷新)
                        {
                            MapAddr = 0uL;
                            MinimapCanvasWidgetAddr = 0uL;
                            MapGrid = 0uL;
                            Slot1 = 0uL;
                            循环次数 = 1001uL;
                            读本人数据计数 = 10u;
                            本人 = new 本人();
                            ActorClassNameList.Clear();
                            dictionary_人物.Clear();
                            dictionary盒子载具.Clear();
                            dictionary物资.Clear();
                            dictionary丢弃的物资.Clear();
                            全部对象.Clear();
                            EspOverlay.投掷物Clear();
                            EspOverlay.物资Clear();
                            EspOverlay.载具Clear();
                            EspOverlay.人物Clear();
                            EspOverlay.人物Clear1();
                        }
                        Vector3 继续自瞄3 = default(Vector3);
                        Vector3 继续自瞄4 = default(Vector3);
                        bool_ = false;
                        CommonProperty.预瞄点 = new Vector2();
                        //自瞄//
                        while (aimPlayer != 0)
                        {
                            自瞄计时器.Restart();
                            自瞄计时器.Start();
                            按键();
                            CommonProperty.fov = 0f;
                            if (武器参数.开镜自瞄 && !(本人.fcameraCacheData.POV.FOV < 75))
                            {
                                aimPlayer = 0uL;
                                break;
                            }
                            if (ammoData == 0)
                            {
                                aimPlayer = 0uL;
                                break;
                            }
                            自瞄循环次数++;
                            if (添加黑名单 && aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && dictionary_人物[aimPlayer].人机 == 0 && dictionary_人物[aimPlayer].name != "")
                            {
                                if (CommonProperty.Hash_黑名单.Contains(dictionary_人物[aimPlayer].name))
                                {
                                    CommonProperty.Hash_黑名单.Remove(dictionary_人物[aimPlayer].name);
                                }
                                else
                                {
                                    CommonProperty.Hash_黑名单.Add(dictionary_人物[aimPlayer].name);
                                }
                            }
                            memGet.Clear();
                            if (dictionary_人物.ContainsKey(aimPlayer))
                            {
                                memGet.Add<ulong>(dictionary_人物[aimPlayer].addr + Mesh);
                                memGet.Add<ulong>(dictionary_人物[aimPlayer].视角 + Bone);
                                memGet.Add<ulong>(dictionary_人物[aimPlayer].addr + VehicleRiderComponent);
                                memGet.Add<ulong>(dictionary_人物[aimPlayer].addr + ActorRootComp);
                                memGet.Add<ulong>(dictionary_人物[aimPlayer].VehicleRiderComponentAddr + LastVehiclePawn);
                                memGet.Add<Vector3>(dictionary_人物[aimPlayer].LastVehiclePawnAddr + ReplicatedMovement);
                                memGet.Add<Vector3>(dictionary_人物[aimPlayer].CharacterMovementAddr + Veloctity);
                                memGet.Add<float>(dictionary_人物[aimPlayer].addr + Health);
                                memGet.Add<float>(dictionary_人物[aimPlayer].addr + HealthDie);
                                memGet.Add<ulong>(本人.视角 + AnimScriptInstance);
                                memGet.Finish();
                                //dictionary_人物[aimPlayer].人物血量 = memGet.Get<float>(dictionary_人物[aimPlayer].addr + Health);
                                dictionary_人物[aimPlayer].人物血量 = 解密血量(dictionary_人物[aimPlayer].addr);
                                dictionary_人物[aimPlayer].倒地血量 = memGet.Get<float>(dictionary_人物[aimPlayer].addr + HealthDie);
                                if (dictionary_人物[aimPlayer].人物血量 > 100f || float.IsNaN(dictionary_人物[aimPlayer].人物血量))
                                {
                                    dictionary_人物[aimPlayer].人物血量 = 100f;
                                }
                                if (dictionary_人物[aimPlayer].倒地血量 > 100f || float.IsNaN(dictionary_人物[aimPlayer].倒地血量))
                                {
                                    dictionary_人物[aimPlayer].倒地血量 = 100f;
                                }
                                if (dictionary_人物[aimPlayer].人物血量 < 0f)
                                {
                                    dictionary_人物[aimPlayer].人物血量 = 0f;
                                }
                                if (dictionary_人物[aimPlayer].倒地血量 < 0f)
                                {
                                    dictionary_人物[aimPlayer].倒地血量 = 0f;
                                }
                                if (dictionary_人物[aimPlayer].人物血量 * 10000f + dictionary_人物[aimPlayer].倒地血量 * 10000f != 0f)
                                {
                                    ulong meshaddr = memGet.Get<ulong>(dictionary_人物[aimPlayer].addr + this.Mesh);
                                    if (meshaddr != 0 && dictionary_人物[aimPlayer].视角 == meshaddr)
                                    {
                                        dictionary_人物[aimPlayer].视角 = meshaddr;
                                        ulong Animasccript = memGet.Get<ulong>(本人.视角 + AnimScriptInstance);
                                        if (kyZpsbAxnb(Animasccript, 本人.addr))
                                        {
                                            本人.Animasccript = Animasccript;
                                            本人.可视 = MemRead<float>(本人.视角 + Eyes);
                                            dictionary_人物[aimPlayer].人物位面 = MemRead<float>(dictionary_人物[aimPlayer].视角 + Eyes);
                                            dictionary_人物[aimPlayer].是否可视 = ((dictionary_人物[aimPlayer].人物位面 >= 本人.可视) ? 1 : 0);
                                            if (dictionary_人物[aimPlayer].是否可视 != 0)
                                            {
                                                dictionary_人物[aimPlayer].Bone = memGet.Get<ulong>(dictionary_人物[aimPlayer].视角 + Bone);
                                                dictionary_人物[aimPlayer].VehicleRiderComponentAddr = memGet.Get<ulong>(dictionary_人物[aimPlayer].addr + VehicleRiderComponent);
                                                dictionary_人物[aimPlayer].CharacterMovementAddr = Decrypt_(memGet.Get<ulong>(dictionary_人物[aimPlayer].addr + ActorRootComp));
                                                dictionary_人物[aimPlayer].LastVehiclePawnAddr = memGet.Get<ulong>(dictionary_人物[aimPlayer].VehicleRiderComponentAddr + LastVehiclePawn);
                                                if (dictionary_人物[aimPlayer].LastVehiclePawnAddr != 0)
                                                {
                                                    dictionary_人物[aimPlayer].speed = memGet.Get<Vector3>(dictionary_人物[aimPlayer].LastVehiclePawnAddr + ReplicatedMovement);
                                                }
                                                else
                                                {
                                                    dictionary_人物[aimPlayer].speed = memGet.Get<Vector3>(dictionary_人物[aimPlayer].CharacterMovementAddr + Veloctity);
                                                }
                                                if (自瞄倒地 || dictionary_人物[aimPlayer].人物血量 * 10000f != 0f)
                                                {
                                                    //相机地址
                                                    相机 = MemRead<byte>(本人.玩家控制 + PlayerCameraManager + 392) % 2u;
                                                    if (相机 == 0)
                                                    {
                                                        if (!子骨骼自瞄)
                                                        {
                                                            if (武器参数.父骨骼 == 0)
                                                            {
                                                                aimPlayer = 0uL;
                                                                continue;
                                                            }
                                                            if (武器参数.父骨骼 == 16 && dictionary_人物[aimPlayer].距离 > 20 && 游戏机按键是否按下(1))  //16是随机
                                                            {
                                                                uint 随机数 = (uint)new Random().Next(1, 101);
                                                                if (随机数 <= TargetHead)
                                                                {
                                                                    dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + 720);
                                                                }
                                                                else if (TargetHead < 随机数 && 随机数 <= TargetNeck)
                                                                {
                                                                    dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + 240);
                                                                }
                                                                else if (TargetNeck < 随机数 && 随机数 <= TargetChest)
                                                                {
                                                                    dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + 192);
                                                                }
                                                                else if (TargetChest < 随机数 && 随机数 <= TargetPelvis)
                                                                {
                                                                    dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + 48);
                                                                }
                                                                else if (TargetPelvis < 随机数 && 随机数 <= TargetArm)
                                                                {
                                                                    if ((uint)new Random().Next(0, 2) % 2u == 0)
                                                                    {
                                                                        dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + 4272);
                                                                    }
                                                                    else
                                                                    {
                                                                        dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + 5568);
                                                                    }
                                                                }
                                                            }
                                                            else if (武器参数.父骨骼 == 16)
                                                            {
                                                                dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + (ulong)(武器参数.父骨骼 * 48L));
                                                            }
                                                            else
                                                            {
                                                                dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + (ulong)(武器参数.父骨骼 * 48L));
                                                            }
                                                        }
                                                        else
                                                        {
                                                            dictionary_人物[aimPlayer].瞄准_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].Bone + (ulong)(武器参数.子骨骼 * 48L));
                                                        }
                                                        dictionary_人物[aimPlayer].Actor_Bone = MemRead<FTransform>(dictionary_人物[aimPlayer].视角 + BoneArry);
                                                        Vector2 自瞄坐标 = default(Vector2);
                                                        D3DMATRIX d3DMATRIX_ = dictionary_人物[aimPlayer].瞄准_Bone.ToMatrixWithScale();
                                                        D3DMATRIX d3DMATRIX_15 = dictionary_人物[aimPlayer].Actor_Bone.ToMatrixWithScale();
                                                        D3DMATRIX d3DMATRIX = method_35(d3DMATRIX_, d3DMATRIX_15);
                                                        Vector3 vector16 = default(Vector3);
                                                        vector16.x = d3DMATRIX._41;
                                                        vector16.y = d3DMATRIX._42;
                                                        vector16.z = d3DMATRIX._43;
                                                        Vector3 骨骼坐标 = vector16;
                                                        继续自瞄3 = 骨骼坐标;
                                                        memGet.Clear();
                                                        memGet.Add<Vector3>(本人.Animasccript + ControlRotationCP, bool_1: true);
                                                        memGet.Add<Vector3>(本人.Animasccript + RecoilADSRotationCP, bool_1: true);
                                                        memGet.Finish();
                                                        本人.ControlRotation = MemRead<Vector3>(本人.Animasccript + ControlRotationCP);
                                                        本人.RecoilADSRotation = MemRead<float>(本人.Animasccript + RecoilADSRotationCP);
                                                        float 距离 = 计算距离(相减(本人.fcameraCacheData.POV.Location, 骨骼坐标)) / 100f;
                                                        Vector3 预判坐标 = 预判(骨骼坐标, 距离, dictionary_人物[aimPlayer].speed);
                                                        if (!WorldToScreen(本人.fcameraCacheData.POV.FOV, 本人.ControlRotation, 本人.RecoilADSRotation, 本人.fcameraCacheData.POV.Location, 预判坐标, ref 自瞄坐标))
                                                        {
                                                            continue;
                                                        }
                                                        if (CommonProperty.espconfig.EspConfig.提前量)
                                                        {
                                                            CommonProperty.预瞄点.x = 自瞄坐标.x;
                                                            CommonProperty.预瞄点.y = dictionary_人物[aimPlayer].头部.y;
                                                        }
                                                        int X = (int)Math.Round(自瞄坐标.x - X分辨率 / 2.0);
                                                        int Y = (int)Math.Round(自瞄坐标.y - Y分辨率 / 2.0);
                                                        if (Y != 0)
                                                        {
                                                            Y += 武器参数.自瞄修正;
                                                        }
                                                        int x轴绝对值2 = Math.Abs(X);
                                                        int y轴绝对值2 = Math.Abs(Y);
                                                        if (Math.Abs(X) > X分辨率 || Math.Abs(Y) > Y分辨率)
                                                        {
                                                            aimPlayer = 0uL;
                                                            break;
                                                        }
                                                        if (X == 0 && Y == 0)
                                                        {
                                                            continue;
                                                        }
                                                        if (x轴绝对值2 > 武器参数.X轴自瞄力度 && X != 0)
                                                        {
                                                            X = X / x轴绝对值2 * 武器参数.X轴自瞄力度;
                                                        }
                                                        if (y轴绝对值2 > 武器参数.Y轴自瞄力度 && Y != 0)
                                                        {
                                                            Y = Y / y轴绝对值2 * 武器参数.Y轴自瞄力度;
                                                        }
                                                        if (!武器参数.Y轴自瞄开关 && Y > 0)
                                                        {
                                                            Y = 0;
                                                        }
                                                        控制器计算(X, Y);
                                                        自瞄计时器.Stop();
                                                        int num4 = (int)自瞄计时器.Elapsed.TotalMilliseconds;
                                                        if (自瞄循环次数 % 50u == 0)
                                                        {
                                                            this.状态("延迟", "主延迟:" + num4.ToString("D3"));
                                                        }
                                                        if (武器参数.自瞄响应 > num4)
                                                        {
                                                            帧率锁(武器参数.自瞄响应 - num4);
                                                        }

                                                        瞄准 = true;
                                                        continue;
                                                    }
                                                    瞄准 = false;
                                                    aimPlayer = 0uL;
                                                    break;
                                                }
                                                aimPlayer = 0uL;
                                                int 计时2 = 0;
                                                //持续自瞄
                                                while (aimPlayer != 0)
                                                {
                                                    自瞄计时器.Restart();
                                                    自瞄计时器.Start();
                                                    按键();
                                                    if (自瞄 && 武器参数.跳过击杀)
                                                    {
                                                        float fov = 武器参数.自瞄FOV;
                                                        if (武器参数.动态范围 && 本人.fcameraCacheData.POV.FOV != 0f)
                                                        {
                                                            fov = 80f / 本人.fcameraCacheData.POV.FOV * 武器参数.自瞄FOV;
                                                        }
                                                        float 自瞄距离 = 武器参数.自瞄距离;
                                                        CommonProperty.fov = fov;
                                                        foreach (KeyValuePair<ulong, Actor人物> item48 in dictionary_人物)
                                                        {
                                                            D3DMATRIX d3DMATRIX_7 = item48.Value.Actor_Bone.ToMatrixWithScale();
                                                            D3DMATRIX d3DMATRIX_11 = item48.Value.瞄准_Bone.ToMatrixWithScale();
                                                            D3DMATRIX d3DMATRIX6 = method_35(d3DMATRIX_11, d3DMATRIX_7);
                                                            item48.Value.vector3_1.x = d3DMATRIX6._41;
                                                            item48.Value.vector3_1.y = d3DMATRIX6._42;
                                                            item48.Value.vector3_1.z = d3DMATRIX6._43;
                                                            item48.Value.瞄准 = 计算透视坐标(item48.Value.vector3_1);
                                                            if (item48.Value.Bone == 0L || item48.Value.人物血量 * 10000f + item48.Value.倒地血量 * 10000f == 0f || (!自瞄倒地 && item48.Value.人物血量 * 10000f == 0f && item48.Value.倒地血量 > 0f && item48.Value.倒地血量 < 100.1f) || item48.Value.是否友军 == 1)
                                                            {
                                                                continue;
                                                            }
                                                            uint 人物距离 = item48.Value.距离;
                                                            float 人物基于显示器的位置 = method_40(X分辨率 / 2f, Y分辨率 / 2f, item48.Value.瞄准.x, item48.Value.瞄准.y);
                                                            if (武器参数.自瞄优先级 == 0)
                                                            {
                                                                if (人物距离 <= 武器参数.自瞄距离 && 人物基于显示器的位置 < fov && item48.Value.是否可视 == 1)
                                                                {
                                                                    aimPlayer = item48.Value.addr;
                                                                    fov = 人物基于显示器的位置;
                                                                }
                                                            }
                                                            else if (!(人物基于显示器的位置 > fov) && 人物距离 < 自瞄距离 && item48.Value.是否可视 == 1)
                                                            {
                                                                aimPlayer = item48.Value.addr;
                                                                自瞄距离 = 人物距离;
                                                            }
                                                        }
                                                        if (aimPlayer != 0)
                                                        {
                                                            aimPlayer = 0uL;
                                                            break;
                                                        }
                                                    }
                                                    if (自瞄)
                                                    {
                                                        Vector2 自瞄坐标 = default(Vector2);
                                                        memGet.Clear();
                                                        memGet.Add<Vector3>(本人.Animasccript + ControlRotationCP, bool_1: true);
                                                        memGet.Add<Vector3>(本人.Animasccript + RecoilADSRotationCP, bool_1: true);
                                                        memGet.Finish();
                                                        本人.ControlRotation = MemRead<Vector3>(本人.Animasccript + ControlRotationCP);
                                                        本人.RecoilADSRotation = MemRead<float>(本人.Animasccript + RecoilADSRotationCP);
                                                        float float_人物距离 = 计算距离(相减(本人.fcameraCacheData.POV.Location, 继续自瞄3)) / 100f;
                                                        Vector3 预判坐标 = 预判(继续自瞄3, float_人物距离, 继续自瞄4);

                                                        if (!WorldToScreen(本人.fcameraCacheData.POV.FOV, 本人.ControlRotation, 本人.RecoilADSRotation, 本人.fcameraCacheData.POV.Location, 预判坐标, ref 自瞄坐标))
                                                        {
                                                            continue;
                                                        }
                                                        vector2_1 = 自瞄坐标;
                                                        int x轴 = (int)Math.Round(自瞄坐标.x - X分辨率 / 2.0);
                                                        int Y轴 = (int)Math.Round(自瞄坐标.y - Y分辨率 / 2.0);
                                                        if (Y轴 != 0)
                                                        {
                                                            Y轴 += 武器参数.自瞄修正;
                                                        }
                                                        int x轴绝对值 = Math.Abs(x轴);
                                                        int y轴绝对值 = Math.Abs(Y轴);
                                                        if (Math.Abs(x轴) > X分辨率 || Math.Abs(Y轴) > Y分辨率)
                                                        {
                                                            aimPlayer = 0uL;
                                                            break;
                                                        }
                                                        if (x轴 == 0 && Y轴 == 0)
                                                        {
                                                            continue;
                                                        }
                                                        if (x轴绝对值 > 武器参数.X轴自瞄力度 && x轴 != 0)
                                                        {
                                                            x轴 = x轴 / x轴绝对值 * 武器参数.X轴自瞄力度;
                                                        }
                                                        if (y轴绝对值 > 武器参数.Y轴自瞄力度 && Y轴 != 0)
                                                        {
                                                            Y轴 = Y轴 / y轴绝对值 * 武器参数.Y轴自瞄力度;
                                                        }
                                                        if (!武器参数.Y轴自瞄开关 && Y轴 > 0)
                                                        {
                                                            Y轴 = 0;
                                                        }
                                                        控制器计算(x轴, Y轴);
                                                        自瞄计时器.Stop();
                                                        int num3 = (int)自瞄计时器.Elapsed.TotalMilliseconds;
                                                        计时2 += num3;
                                                        if (自瞄循环次数 % 50u == 0)
                                                        {
                                                            this.状态("延迟", "主延迟:" + num3.ToString("D3"));
                                                        }
                                                        if (武器参数.自瞄响应 - 1 > num3)
                                                        {
                                                            帧率锁(武器参数.自瞄响应 - 1 - num3);
                                                        }
                                                        if (计时2 > 自瞄延时)
                                                        {
                                                            瞄准 = false;
                                                            aimPlayer = 0uL;
                                                            break;
                                                        }
                                                        瞄准 = true;
                                                        continue;
                                                    }
                                                    瞄准 = false;
                                                    aimPlayer = 0uL;
                                                    break;
                                                }
                                                break;
                                            }
                                            瞄准 = false;
                                            aimPlayer = 0uL;
                                            break;
                                        }
                                        瞄准 = false;
                                        aimPlayer = 0uL;
                                        break;
                                    }
                                    瞄准 = false;
                                    aimPlayer = 0uL;
                                    break;
                                }
                                aimPlayer = 0uL;
                                int 计时 = 0;
                                while (自瞄)
                                {
                                    自瞄计时器.Restart();
                                    自瞄计时器.Start();
                                    按键();
                                    if (自瞄 && 武器参数.跳过击杀)
                                    {
                                        float fov2 = 武器参数.自瞄FOV;
                                        if (武器参数.动态范围 && 本人.fcameraCacheData.POV.FOV != 0f)
                                        {
                                            fov2 = 80f / 本人.fcameraCacheData.POV.FOV * 武器参数.自瞄FOV;
                                        }
                                        float 自瞄距离2 = 武器参数.自瞄距离;
                                        CommonProperty.fov = fov2;
                                        foreach (KeyValuePair<ulong, Actor人物> item49 in dictionary_人物)
                                        {
                                            D3DMATRIX d3DMATRIX_8 = item49.Value.Actor_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX_12 = item49.Value.瞄准_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX7 = method_35(d3DMATRIX_12, d3DMATRIX_8);
                                            item49.Value.vector3_1.x = d3DMATRIX7._41;
                                            item49.Value.vector3_1.y = d3DMATRIX7._42;
                                            item49.Value.vector3_1.z = d3DMATRIX7._43;
                                            item49.Value.瞄准 = 计算透视坐标(item49.Value.vector3_1);
                                            if (item49.Value.Bone == 0L || item49.Value.人物血量 * 10000f + item49.Value.倒地血量 * 10000f == 0f || (!自瞄倒地 && item49.Value.人物血量 * 10000f == 0f && item49.Value.倒地血量 > 0f && item49.Value.倒地血量 < 100.1f) || item49.Value.是否友军 == 1)
                                            {
                                                continue;
                                            }
                                            uint 人物距离2 = item49.Value.距离;
                                            float 人物基于显示器的位置2 = method_40(X分辨率 / 2f, Y分辨率 / 2f, item49.Value.瞄准.x, item49.Value.瞄准.y);
                                            if (武器参数.自瞄优先级 == 0)
                                            {
                                                if (人物距离2 <= 武器参数.自瞄距离 && 人物基于显示器的位置2 < fov2 && item49.Value.是否可视 == 1)
                                                {
                                                    aimPlayer = item49.Value.addr;
                                                    fov2 = 人物基于显示器的位置2;
                                                }
                                            }
                                            else if (!(人物基于显示器的位置2 > fov2) && 人物距离2 < 自瞄距离2 && item49.Value.是否可视 == 1)
                                            {
                                                aimPlayer = item49.Value.addr;
                                                自瞄距离2 = 人物距离2;
                                            }
                                        }
                                        if (aimPlayer != 0)
                                        {
                                            aimPlayer = 0uL;
                                            break;
                                        }
                                    }
                                    if (自瞄)
                                    {
                                        Vector2 自瞄坐标 = default(Vector2);
                                        memGet.Clear();
                                        memGet.Add<Vector3>(本人.Animasccript + ControlRotationCP, bool_1: true);
                                        memGet.Add<Vector3>(本人.Animasccript + RecoilADSRotationCP, bool_1: true);
                                        memGet.Finish();
                                        本人.ControlRotation = MemRead<Vector3>(本人.Animasccript + ControlRotationCP);
                                        本人.RecoilADSRotation = MemRead<float>(本人.Animasccript + RecoilADSRotationCP);
                                        float float_人物距离3 = 计算距离(相减(本人.fcameraCacheData.POV.Location, 继续自瞄3)) / 100f;
                                        Vector3 预判坐标 = 预判(继续自瞄3, float_人物距离3, 继续自瞄4);

                                        if (!WorldToScreen(本人.fcameraCacheData.POV.FOV, 本人.ControlRotation, 本人.RecoilADSRotation, 本人.fcameraCacheData.POV.Location, 预判坐标, ref 自瞄坐标))
                                        {
                                            continue;
                                        }
                                        vector2_1 = 自瞄坐标;
                                        int X3 = (int)Math.Round(自瞄坐标.x - X分辨率 / 2.0);
                                        int Y3 = (int)Math.Round(自瞄坐标.y - Y分辨率 / 2.0);
                                        if (Y3 != 0)
                                        {
                                            Y3 += 武器参数.自瞄修正;
                                        }
                                        int x轴绝对值3 = Math.Abs(X3);
                                        int y轴绝对值3 = Math.Abs(Y3);
                                        if (Math.Abs(X3) > X分辨率 || Math.Abs(Y3) > Y分辨率)
                                        {
                                            aimPlayer = 0uL;
                                            break;
                                        }
                                        if (X3 == 0 && Y3 == 0)
                                        {
                                            continue;
                                        }
                                        if (x轴绝对值3 > 武器参数.X轴自瞄力度 && X3 != 0)
                                        {
                                            X3 = X3 / x轴绝对值3 * 武器参数.X轴自瞄力度;
                                        }
                                        if (y轴绝对值3 > 武器参数.Y轴自瞄力度 && Y3 != 0)
                                        {
                                            Y3 = Y3 / y轴绝对值3 * 武器参数.Y轴自瞄力度;
                                        }
                                        if (!武器参数.Y轴自瞄开关)
                                        {
                                            Y3 = 0;
                                        }
                                        控制器计算(X3, Y3);
                                        自瞄计时器.Stop();
                                        int num5 = (int)自瞄计时器.Elapsed.TotalMilliseconds;
                                        if (自瞄循环次数 % 50u == 0)
                                        {
                                            this.状态("延迟", "主延迟:" + num5.ToString("D3"));
                                        }
                                        if (武器参数.自瞄响应 - 1 > num5)
                                        {
                                            帧率锁(武器参数.自瞄响应 - 1 - num5);
                                        }
                                        计时 += num5;
                                        if (计时 > 自瞄延时)
                                        {
                                            瞄准 = false;
                                            aimPlayer = 0uL;
                                            break;
                                        }

                                        瞄准 = true;
                                        continue;
                                    }
                                    瞄准 = false;
                                    aimPlayer = 0uL;
                                    break;
                                }
                            }
                            瞄准 = false;
                            aimPlayer = 0uL;
                            break;
                        }
                        if (自瞄)
                        {
                            if (武器参数.开镜自瞄)
                            {
                                if (本人.fcameraCacheData.POV.FOV < 75)
                                {
                                    float fov3 = 武器参数.自瞄FOV;
                                    if (武器参数.动态范围 && 本人.fcameraCacheData.POV.FOV != 0f)
                                    {
                                        fov3 = 80f / 本人.fcameraCacheData.POV.FOV * 武器参数.自瞄FOV;
                                    }
                                    float 自瞄距离3 = 武器参数.自瞄距离;
                                    CommonProperty.fov = fov3;
                                    foreach (KeyValuePair<ulong, Actor人物> item50 in dictionary_人物)
                                    {
                                        D3DMATRIX d3DMATRIX_9 = item50.Value.Actor_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX_13 = item50.Value.瞄准_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX8 = method_35(d3DMATRIX_13, d3DMATRIX_9);
                                        item50.Value.vector3_1.x = d3DMATRIX8._41;
                                        item50.Value.vector3_1.y = d3DMATRIX8._42;
                                        item50.Value.vector3_1.z = d3DMATRIX8._43;
                                        item50.Value.瞄准 = 计算透视坐标(item50.Value.vector3_1);
                                        if (item50.Value.Bone == 0L || item50.Value.人物血量 * 10000f + item50.Value.倒地血量 * 10000f == 0f || (!自瞄倒地 && item50.Value.人物血量 * 10000f == 0f && item50.Value.倒地血量 > 0f && item50.Value.倒地血量 < 100.1f) || item50.Value.是否友军 == 1)
                                        {
                                            continue;
                                        }
                                        uint 人物距离3 = item50.Value.距离;
                                        float 人物基于显示器的位置3 = method_40(X分辨率 / 2f, Y分辨率 / 2f, item50.Value.瞄准.x, item50.Value.瞄准.y);
                                        if (武器参数.自瞄优先级 == 0)
                                        {
                                            if (人物距离3 <= 武器参数.自瞄距离 && 人物基于显示器的位置3 < fov3 && item50.Value.是否可视 == 1)
                                            {
                                                aimPlayer = item50.Value.addr;
                                                fov3 = 人物基于显示器的位置3;
                                            }
                                        }
                                        else if (!(人物基于显示器的位置3 > fov3) && 人物距离3 < 自瞄距离3 && item50.Value.是否可视 == 1)
                                        {
                                            aimPlayer = item50.Value.addr;
                                            自瞄距离3 = 人物距离3;
                                        }
                                        if (aimPlayer != 0)
                                        {
                                            EspOverlay.投掷物Clear();
                                            EspOverlay.物资Clear();
                                            EspOverlay.载具Clear();
                                        }
                                    }
                                }
                            }
                            else
                            {
                                float fov3 = 武器参数.自瞄FOV;
                                if (武器参数.动态范围 && 本人.fcameraCacheData.POV.FOV != 0f)
                                {
                                    fov3 = 80f / 本人.fcameraCacheData.POV.FOV * 武器参数.自瞄FOV;
                                }
                                float 自瞄距离3 = 武器参数.自瞄距离;
                                CommonProperty.fov = fov3;
                                foreach (KeyValuePair<ulong, Actor人物> item50 in dictionary_人物)
                                {
                                    D3DMATRIX d3DMATRIX_9 = item50.Value.Actor_Bone.ToMatrixWithScale();
                                    D3DMATRIX d3DMATRIX_13 = item50.Value.瞄准_Bone.ToMatrixWithScale();
                                    D3DMATRIX d3DMATRIX8 = method_35(d3DMATRIX_13, d3DMATRIX_9);
                                    item50.Value.vector3_1.x = d3DMATRIX8._41;
                                    item50.Value.vector3_1.y = d3DMATRIX8._42;
                                    item50.Value.vector3_1.z = d3DMATRIX8._43;
                                    item50.Value.瞄准 = 计算透视坐标(item50.Value.vector3_1);
                                    if (item50.Value.Bone == 0L || item50.Value.人物血量 * 10000f + item50.Value.倒地血量 * 10000f == 0f || (!自瞄倒地 && item50.Value.人物血量 * 10000f == 0f && item50.Value.倒地血量 > 0f && item50.Value.倒地血量 < 100.1f) || item50.Value.是否友军 == 1)
                                    {
                                        continue;
                                    }
                                    uint 人物距离3 = item50.Value.距离;
                                    float 人物基于显示器的位置3 = method_40(X分辨率 / 2f, Y分辨率 / 2f, item50.Value.瞄准.x, item50.Value.瞄准.y);
                                    if (武器参数.自瞄优先级 == 0)
                                    {
                                        if (人物距离3 <= 武器参数.自瞄距离 && 人物基于显示器的位置3 < fov3 && item50.Value.是否可视 == 1)
                                        {
                                            aimPlayer = item50.Value.addr;
                                            fov3 = 人物基于显示器的位置3;
                                        }
                                    }
                                    else if (!(人物基于显示器的位置3 > fov3) && 人物距离3 < 自瞄距离3 && item50.Value.是否可视 == 1)
                                    {
                                        aimPlayer = item50.Value.addr;
                                        自瞄距离3 = 人物距离3;
                                    }
                                    if (aimPlayer != 0)
                                    {
                                        EspOverlay.投掷物Clear();
                                        EspOverlay.物资Clear();
                                        EspOverlay.载具Clear();
                                    }
                                }
                            }

                        }
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && 自瞄)
                        {
                            memGet.Add<FTransform>(dictionary_人物[aimPlayer].视角 + BoneArry);
                            memGet.Add<ulong>(dictionary_人物[aimPlayer].视角 + Bone);
                        }
                        memGet.Finish();
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && 自瞄)
                        {
                            dictionary_人物[aimPlayer].Actor_Bone = memGet.Get<FTransform>(dictionary_人物[aimPlayer].视角 + BoneArry);
                            dictionary_人物[aimPlayer].Bone = memGet.Get<ulong>(dictionary_人物[aimPlayer].视角 + Bone);
                        }
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer))
                        {
                            if (子骨骼自瞄)
                            {
                                memGet.Add<FTransform>(dictionary_人物[aimPlayer].Bone + (ulong)(武器参数.子骨骼 * 48L));
                            }
                            else
                            {
                                if (武器参数.父骨骼 == 0)
                                {
                                    continue;
                                }
                                memGet.Add<FTransform>(dictionary_人物[aimPlayer].Bone + (ulong)(武器参数.父骨骼 * 48L));
                            }
                            memGet.Add<ulong>(dictionary_人物[aimPlayer].addr + VehicleRiderComponent);
                            memGet.Add<ulong>(dictionary_人物[aimPlayer].addr + ActorRootComp);
                        }
                        memGet.Finish();
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && 自瞄)
                        {
                            if (!子骨骼自瞄)
                            {
                                if (武器参数.父骨骼 == 0)
                                {
                                    continue;
                                }
                                dictionary_人物[aimPlayer].瞄准_Bone = memGet.Get<FTransform>(dictionary_人物[aimPlayer].Bone + (ulong)(武器参数.父骨骼 * 48L));
                            }
                            else
                            {
                                dictionary_人物[aimPlayer].瞄准_Bone = memGet.Get<FTransform>(dictionary_人物[aimPlayer].Bone + (ulong)(武器参数.子骨骼 * 48L));
                            }
                            dictionary_人物[aimPlayer].VehicleRiderComponentAddr = memGet.Get<ulong>(dictionary_人物[aimPlayer].addr + VehicleRiderComponent);
                            dictionary_人物[aimPlayer].CharacterMovementAddr = Decrypt_(memGet.Get<ulong>(dictionary_人物[aimPlayer].addr + ActorRootComp));
                        }
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && 自瞄)
                        {
                            memGet.Add<ulong>(dictionary_人物[aimPlayer].VehicleRiderComponentAddr + LastVehiclePawn);
                        }
                        memGet.Finish();
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && 自瞄)
                        {
                            dictionary_人物[aimPlayer].LastVehiclePawnAddr = memGet.Get<ulong>(dictionary_人物[aimPlayer].VehicleRiderComponentAddr + LastVehiclePawn);
                        }
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && 自瞄)
                        {
                            if (dictionary_人物[aimPlayer].LastVehiclePawnAddr != 0)
                            {
                                memGet.Add<Vector3>(dictionary_人物[aimPlayer].LastVehiclePawnAddr + ReplicatedMovement);
                                memGet.Add<Vector3>(dictionary_人物[aimPlayer].LastVehiclePawnAddr + ReplicatedMovement - 40);
                            }
                            else
                            {
                                memGet.Add<Vector3>(dictionary_人物[aimPlayer].CharacterMovementAddr + Veloctity);
                                memGet.Add<Vector3>(dictionary_人物[aimPlayer].CharacterMovementAddr + Veloctity - 40);
                            }
                        }
                        memGet.Finish();
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && 自瞄)
                        {
                            if (dictionary_人物[aimPlayer].LastVehiclePawnAddr != 0)
                            {
                                dictionary_人物[aimPlayer].speed = memGet.Get<Vector3>(dictionary_人物[aimPlayer].LastVehiclePawnAddr + ReplicatedMovement);
                            }
                            else
                            {
                                dictionary_人物[aimPlayer].speed = memGet.Get<Vector3>(dictionary_人物[aimPlayer].CharacterMovementAddr + Veloctity);
                            }
                        }
                        if (aimPlayer != 0 && dictionary_人物.ContainsKey(aimPlayer) && 自瞄)
                        {
                            continue;
                        }
                        if (添加黑名单)
                        {
                            float fov4 = 100f;
                            foreach (KeyValuePair<ulong, Actor人物> item51 in dictionary_人物)
                            {
                                D3DMATRIX d3DMATRIX_10 = item51.Value.Actor_Bone.ToMatrixWithScale();
                                D3DMATRIX d3DMATRIX_14 = item51.Value.瞄准_Bone.ToMatrixWithScale();
                                D3DMATRIX d3DMATRIX9 = method_35(d3DMATRIX_14, d3DMATRIX_10);
                                item51.Value.vector3_1.x = d3DMATRIX9._41;
                                item51.Value.vector3_1.y = d3DMATRIX9._42;
                                item51.Value.vector3_1.z = d3DMATRIX9._43;
                                item51.Value.瞄准 = 计算透视坐标(item51.Value.vector3_1);
                                if (item51.Value.Bone == 0L || item51.Value.人物血量 * 10000f + item51.Value.倒地血量 * 10000f == 0f || (!自瞄倒地 && item51.Value.人物血量 * 10000f == 0f && item51.Value.倒地血量 > 0f && item51.Value.倒地血量 < 100.1f) || item51.Value.是否友军 == 1)
                                {
                                    continue;
                                }
                                uint 人物距离4 = item51.Value.距离;
                                float 人物基于显示器的位置4 = method_40(X分辨率 / 2f, Y分辨率 / 2f, item51.Value.瞄准.x, item51.Value.瞄准.y);
                                //bool flag2 = true;
                                if (人物基于显示器的位置4 < fov4)
                                {
                                    if (CommonProperty.Hash_黑名单.Contains(item51.Value.name))
                                    {
                                        CommonProperty.Hash_黑名单.Remove(item51.Value.name);
                                    }
                                    else
                                    {
                                        CommonProperty.Hash_黑名单.Add(item51.Value.name);
                                    }
                                    fov4 = 人物基于显示器的位置4;
                                }
                            }
                            using StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "\\config\\BlackList.ini");
                            foreach (string item2 in CommonProperty.Hash_黑名单)
                            {
                                streamWriter.WriteLine(item2.Trim());
                            }
                        }
                        瞄准 = false;
                        if (!自瞄 && 本人.fcameraCacheData.POV.FOV != 0f && 本人.WeaponName != "")
                        {
                            if (武器参数.动态范围)
                            {
                                CommonProperty.fov = 80f / 本人.fcameraCacheData.POV.FOV * 武器参数.自瞄FOV;
                            }
                            else
                            {
                                CommonProperty.fov = 武器参数.自瞄FOV;
                            }
                        }
                        else if (本人.WeaponName == "")
                        {
                            CommonProperty.fov = 0f;
                        }

                        if (本人.fcameraCacheData.POV.FOV != 0f)
                        {
                            //CommonProperty.fov2 = 本人.fcameraCacheData.POV.FOV;
                            CommonProperty.fov2 = 80f / 本人.fcameraCacheData.POV.FOV * 80;
                        }

                        //自瞄//

                        ulong 中心有人 = 0;
                        //预瞄点
                        if (CommonProperty.espconfig.EspConfig.提前量 && 屏幕中心是否有人 && 本人.fcameraCacheData.POV.FOV < 75 && 透视 && !自瞄)
                        {

                            float fov3 = CommonProperty.fov2;
                            float 距离 = CommonProperty.espconfig.EspConfig.透视距离;
                            foreach (KeyValuePair<ulong, Actor人物> item in dictionary_人物)
                            {
                                D3DMATRIX d3DMATRIX_9 = item.Value.Actor_Bone.ToMatrixWithScale();
                                D3DMATRIX d3DMATRIX_13 = item.Value.瞄准_Bone.ToMatrixWithScale();
                                D3DMATRIX d3DMATRIX8 = method_35(d3DMATRIX_13, d3DMATRIX_9);
                                item.Value.vector3_1.x = d3DMATRIX8._41;
                                item.Value.vector3_1.y = d3DMATRIX8._42;
                                item.Value.vector3_1.z = d3DMATRIX8._43;
                                item.Value.瞄准 = 计算透视坐标(item.Value.vector3_1);
                                if (item.Value.Bone == 0L || item.Value.人物血量 * 10000f + item.Value.倒地血量 * 10000f == 0f || (!自瞄倒地 && item.Value.人物血量 * 10000f == 0f && item.Value.倒地血量 > 0f && item.Value.倒地血量 < 100.1f) || item.Value.是否友军 == 1)
                                {
                                    continue;
                                }
                                uint 人物距离3 = item.Value.距离;
                                float 人物基于显示器的位置3 = method_40(X分辨率 / 2f, Y分辨率 / 2f, item.Value.瞄准.x, item.Value.瞄准.y);

                                if (人物距离3 <= 距离 && 人物基于显示器的位置3 < fov3 && item.Value.是否可视 == 1)
                                {
                                    中心有人 = item.Value.addr;
                                    fov3 = 人物基于显示器的位置3;

                                }
                            }

                            if (中心有人 != 0 && dictionary_人物.ContainsKey(中心有人))
                            {
                                memGet.Add<FTransform>(dictionary_人物[中心有人].Bone + 15 * 48L);
                                memGet.Add<ulong>(dictionary_人物[中心有人].addr + VehicleRiderComponent);
                                memGet.Add<ulong>(dictionary_人物[中心有人].addr + ActorRootComp);
                                memGet.Finish();
                                dictionary_人物[中心有人].瞄准_Bone = memGet.Get<FTransform>(dictionary_人物[中心有人].Bone + 15 * 48L);
                                dictionary_人物[中心有人].VehicleRiderComponentAddr = memGet.Get<ulong>(dictionary_人物[中心有人].addr + VehicleRiderComponent);
                                dictionary_人物[中心有人].CharacterMovementAddr = Decrypt_(memGet.Get<ulong>(dictionary_人物[中心有人].addr + ActorRootComp));

                                if (dictionary_人物[中心有人].VehicleRiderComponentAddr != 0)
                                {
                                    memGet.Add<ulong>(dictionary_人物[中心有人].VehicleRiderComponentAddr + LastVehiclePawn);

                                    memGet.Finish();

                                    dictionary_人物[中心有人].LastVehiclePawnAddr = memGet.Get<ulong>(dictionary_人物[中心有人].VehicleRiderComponentAddr + LastVehiclePawn);
                                }


                                if (dictionary_人物[中心有人].LastVehiclePawnAddr != 0)
                                {
                                    memGet.Add<Vector3>(dictionary_人物[中心有人].LastVehiclePawnAddr + ReplicatedMovement);
                                    memGet.Add<Vector3>(dictionary_人物[中心有人].LastVehiclePawnAddr + ReplicatedMovement - 40);
                                }
                                else
                                {
                                    memGet.Add<Vector3>(dictionary_人物[中心有人].CharacterMovementAddr + Veloctity);
                                    memGet.Add<Vector3>(dictionary_人物[中心有人].CharacterMovementAddr + Veloctity - 40);
                                }

                                memGet.Finish();

                                if (dictionary_人物[中心有人].LastVehiclePawnAddr != 0)
                                {
                                    dictionary_人物[中心有人].speed = memGet.Get<Vector3>(dictionary_人物[中心有人].LastVehiclePawnAddr + ReplicatedMovement);
                                }
                                else
                                {
                                    dictionary_人物[中心有人].speed = memGet.Get<Vector3>(dictionary_人物[中心有人].CharacterMovementAddr + Veloctity);
                                }


                                if (中心有人 != 0 && dictionary_人物.ContainsKey(中心有人))
                                {
                                    Vector2 vector2_骨骼点2 = default(Vector2);
                                    D3DMATRIX d3DMATRIX_ = dictionary_人物[中心有人].瞄准_Bone.ToMatrixWithScale();
                                    D3DMATRIX d3DMATRIX_15 = dictionary_人物[中心有人].Actor_Bone.ToMatrixWithScale();
                                    D3DMATRIX d3DMATRIX = method_35(d3DMATRIX_, d3DMATRIX_15);
                                    Vector3 vector16 = default(Vector3);
                                    vector16.x = d3DMATRIX._41;
                                    vector16.y = d3DMATRIX._42;
                                    vector16.z = d3DMATRIX._43;
                                    Vector3 骨骼点坐标 = vector16;

                                    memGet.Clear();
                                    memGet.Add<Vector3>(本人.Animasccript + ControlRotationCP, bool_1: true);
                                    memGet.Add<Vector3>(本人.Animasccript + RecoilADSRotationCP, bool_1: true);
                                    memGet.Finish();
                                    本人.ControlRotation = MemRead<Vector3>(本人.Animasccript + ControlRotationCP);
                                    本人.RecoilADSRotation = MemRead<float>(本人.Animasccript + RecoilADSRotationCP);
                                    float float_人物距离2 = 计算距离(相减(本人.fcameraCacheData.POV.Location, 骨骼点坐标)) / 100f;
                                    Vector3 vector3_提前量2 = 预判(骨骼点坐标, float_人物距离2, dictionary_人物[中心有人].speed);

                                    if (WorldToScreen(本人.fcameraCacheData.POV.FOV, 本人.ControlRotation, 本人.RecoilADSRotation, 本人.fcameraCacheData.POV.Location, vector3_提前量2, ref vector2_骨骼点2))
                                    {
                                        CommonProperty.预瞄点.x = vector2_骨骼点2.x;
                                        CommonProperty.预瞄点.y = dictionary_人物[中心有人].头部.y;
                                    }
                                }
                            }
                        }
                        else
                        {
                            中心有人 = 0;
                        }


                        循环次数++;
                        memGet.Clear();
                        网页雷达.地图 = "\"" + 当前地图 + "\"";
                        //读本人信息
                        if (本人.addr == 0)
                        {
                            本人.玩家控制 = Decrypt_(Read<ulong>(Decrypt_(Read<ulong>(Read<ulong>(Decrypt_(Read<ulong>(基准值 + GameInstence)) + LocalPlayer))) + PlayerController));
                            本人.投影相机 = Read<ulong>(本人.玩家控制 + PlayerCameraManager);
                            本人.addr = Decrypt_(Read<ulong>(本人.玩家控制 + AcknowledgedPawn));
                        }
                        if (本人.addr != 0)
                        {
                            if (本人.TeamID == 19831029)
                            {
                                本人.TeamID = MemRead_bool<uint>(本人.addr + TeamNumber, ref bool_) % 100000u;
                                if (!bool_)
                                {
                                    本人.TeamID = 19831029u;
                                }
                            }
                            if (读本人数据计数 > 9 && 本人.name == "")
                            {
                                本人.name = MemRead_Encoding_Unicode_GetString(MemRead<ulong>(本人.addr + this.Playname), 64u);
                                if (本人.name.Contains(" "))
                                {
                                    本人.name = 本人.name.Split(' ')[1].Trim();
                                }
                            }
                            if (本人.视角 == 19831029)
                            {
                                ulong 本人视角 = MemRead_bool<ulong>(本人.addr + this.Mesh, ref bool_);
                                if (!(kyZpsbAxnb(本人视角, 本人.addr) && bool_))
                                {
                                    本人.视角 = 19831029uL;
                                }
                                else
                                {
                                    本人.视角 = 本人视角;
                                }
                            }
                        }
                        else
                        {
                            本人.死亡 = true;
                        }


                        //读全部人物对象
                        memGet.Add<ulong>(对象指针);
                        memGet.Add<uint>(对象指针 + 8);
                        memGet.Finish();
                        ulong actorStartAddr = memGet.Get<ulong>(对象指针);
                        uint actorCount = memGet.Get<uint>(对象指针 + 8);
                        if (actorStartAddr != 0 && actorCount != 0)
                        {
                            角色指针 = actorStartAddr;
                            角色数量 = actorCount;
                        }
                        else
                        {
                            actorStartAddr = 角色指针;
                            actorCount = 角色数量;
                        }
                        if (actorCount == 0 || actorCount > 16384)
                        {
                            continue;
                        }


                        //读gameStateAddr相关信息、遍历所有对象class
                        memGet.Add<ulong>(基准值 + GameState);
                        memGet.Add<Vector3Int>(基准值 + 世界转小地图);
                        if (透视 && MinimapCanvasWidgetAddr != 0L && CommonProperty.espconfig.EspConfig.小地图)
                        {
                            memGet.Add<bool>(MinimapCanvasWidgetAddr + SelectMinimapSizeIndex);
                        }
                        memGet.Add<byte>(本人.玩家控制 + PlayerCameraManager + 392);
                        if (本人.视角 != 0)
                        {
                            memGet.Add<ulong>(本人.视角 + AnimScriptInstance);
                            memGet.Add<Vector3>(本人.视角 + Position);
                            memGet.Add<ulong>(本人.addr + WeaponProcessor);
                        }
                        for (int i = 0; i < actorCount; i++)
                        {
                            memGet.Add<ulong>(actorStartAddr + (ulong)(8 * i));
                        }
                        memGet.Finish();
                        ulong gameStateAddr = Decrypt_(memGet.Get<ulong>(基准值 + GameState));
                        全地图XY = memGet.Get<Vector3Int>(基准值 + 世界转小地图);
                        if (透视 && MinimapCanvasWidgetAddr != 0L && CommonProperty.espconfig.EspConfig.小地图)
                        {
                            小地图放大 = memGet.Get<bool>(MinimapCanvasWidgetAddr + SelectMinimapSizeIndex);
                        }
                        相机 = memGet.Get<byte>(本人.玩家控制 + PlayerCameraManager + 392) % 2u;
                        if (本人.视角 != 0)
                        {
                            ulong 本人Animasccript = memGet.Get<ulong>(本人.视角 + AnimScriptInstance);
                            if (kyZpsbAxnb(本人Animasccript, 本人.addr))
                            {
                                本人.Animasccript = 本人Animasccript;
                            }
                            else if (!debug)
                            {
                            }
                            本人.距离 = memGet.Get<Vector3>(本人.视角 + Position);
                            本人.距离坐标 = 加全地图坐标(本人.距离);
                            ulong 本人WeaponProcessor = memGet.Get<ulong>(本人.addr + WeaponProcessor);
                            if (kyZpsbAxnb(本人WeaponProcessor, 本人.addr))
                            {
                                本人.武器控制 = 本人WeaponProcessor;
                            }
                        }
                        for (int k = 0; k < actorCount; k++)
                        {
                            ulong key = memGet.Get<ulong>(actorStartAddr + (ulong)(8 * k));
                            if (!全部对象.ContainsKey(key))
                            {
                                全部对象[key] = new 全
                                {
                                    addr = key,
                                    @class = 0u,
                                    key = 循环次数
                                };
                            }
                            else
                            {
                                全部对象[key].key = 循环次数;
                            }
                        }
                        //全部对象 全部calss
                        ulongs.Clear();
                        foreach (KeyValuePair<ulong, 全> item in 全部对象)
                        {
                            if (item.Value.key != 循环次数)
                            {
                                ulongs.Add(item.Key);
                            }
                        }
                        foreach (ulong item18 in ulongs)
                        {
                            全部对象.Remove(item18);
                        }
                        if (全部对象 != null && 全部对象.Count != 0)
                        {
                            memGet.初始(flags);
                            foreach (全 value2 in 全部对象.Values)
                            {
                                if (value2.@class == 0)
                                {
                                    memGet.Add<uint>(value2.addr + ObjID);
                                }
                            }
                            if (循环次数 % 150uL == 0L && gameStateAddr != 0)
                            {
                                memGet.Add<Vector3>(gameStateAddr + LerpSafetyZonePosition);
                                memGet.Add<float>(gameStateAddr + LerpSafetyZoneRadius);
                                memGet.Add<Vector3>(gameStateAddr + PoisonGasWarningPosition);
                                memGet.Add<float>(gameStateAddr + PoisonGasWarningRadius);
                                if (轰炸区)
                                {
                                    memGet.Add<Vector3>(gameStateAddr + RedZonePosition);
                                    memGet.Add<float>(gameStateAddr + RedZoneRadius);
                                }
                                memGet.Add<ulong>(gameStateAddr + PlayerArray);
                                memGet.Add<uint>(gameStateAddr + PlayerArray + 8);
                                for (uint TeamIndex = 0u; TeamIndex < PlayerNum; TeamIndex++)
                                {
                                    memGet.Add<ulong>(PlayerArray1 + TeamIndex * 8);
                                }
                            }
                            memGet.Finish();
                            foreach (全 value12 in 全部对象.Values)
                            {
                                if (value12.@class == 0)
                                {
                                    value12.@class = DecryptCIndex(memGet.Get<uint>(value12.addr + ObjID));
                                }
                            }
                            if (循环次数 % 150uL == 0L && gameStateAddr != 0)
                            {
                                毒圈中心 = memGet.Get<Vector3>(gameStateAddr + LerpSafetyZonePosition);
                                毒圈中心.z = memGet.Get<float>(gameStateAddr + LerpSafetyZoneRadius);
                                安全区中心 = memGet.Get<Vector3>(gameStateAddr + PoisonGasWarningPosition);
                                安全区中心.z = memGet.Get<float>(gameStateAddr + PoisonGasWarningRadius);
                                if (轰炸区)
                                {
                                    轰炸区坐标 = memGet.Get<Vector3>(gameStateAddr + RedZonePosition);
                                    轰炸区坐标.z = memGet.Get<float>(gameStateAddr + RedZoneRadius);
                                }
                                PlayerArray1 = memGet.Get<ulong>(gameStateAddr + PlayerArray);
                                PlayerNum = memGet.Get<uint>(gameStateAddr + PlayerArray + 8);
                                int num = 0;
                                for (uint TeamIndex2 = 0u; TeamIndex2 < PlayerNum; TeamIndex2++)
                                {
                                    num++;
                                    ulong addr = memGet.Get<ulong>(PlayerArray1 + TeamIndex2 * 8);
                                    if (addr != 0 && !CommonProperty.玩家列表ss.Contains(addr))
                                    {
                                        CommonProperty.玩家列表s.Add(new 玩家列表
                                        {
                                            addr = addr
                                        });
                                        CommonProperty.玩家列表ss.Add(addr);
                                    }
                                }
                            }
                            memGet.初始(flags_);

                            //分类全部对象
                            foreach (全 value18 in 全部对象.Values)
                            {
                                ulong Addr = value18.addr;
                                uint key2 = value18.@class;
                                if (!ActorClassNameList.ContainsKey(key2))
                                {
                                    string text = MemGetName(key2).Trim();
                                    if (!(text != ""))
                                    {
                                        ActorClassNameList[key2] = "NONE";
                                        continue;
                                    }
                                    ActorClassNameList[key2] = text;
                                }
                                string calssname = ActorClassNameList[key2];
                                if (calssname == "" || calssname == "NONE")
                                {
                                    continue;
                                }
                                if (判断人物(calssname) || 判断人机(calssname))
                                {
                                    if (dictionary_人物.ContainsKey(Addr) && dictionary_人物[Addr].类名 == calssname)
                                    {
                                        dictionary_人物[Addr].key = 循环次数;
                                        continue;
                                    }
                                    dictionary_人物[Addr] = new Actor人物
                                    {
                                        addr = Addr,
                                        类名 = calssname,
                                        人机 = 0,
                                        key = 循环次数
                                    };
                                    if (判断人机(calssname))
                                    {
                                        dictionary_人物[Addr].人机 = 1;
                                    }
                                }
                                else if (判断投掷(calssname))
                                {
                                    if (!dictionary盒子载具.ContainsKey(Addr))
                                    {
                                        dictionary投掷物[Addr] = new Class4
                                        {
                                            种类 = "投掷",
                                            ADDR = Addr,
                                            name = calssname,
                                            key = 循环次数
                                        };
                                    }
                                    else
                                    {
                                        dictionary投掷物[Addr].key = 循环次数;
                                    }
                                }
                                else if (判断载具(calssname) && CommonProperty.战斗模式)
                                {
                                    if (dictionary盒子载具.ContainsKey(Addr))
                                    {
                                        dictionary盒子载具[Addr].key = 循环次数;
                                        continue;
                                    }
                                    dictionary盒子载具[Addr] = new Class4
                                    {
                                        种类 = "载具",
                                        ADDR = Addr,
                                        name = calssname,
                                        key = 循环次数
                                    };
                                }
                                else if (判断盒子(calssname) && CommonProperty.战斗模式)
                                {
                                    if (dictionary盒子载具.ContainsKey(Addr) && !(dictionary盒子载具[Addr].name != calssname))
                                    {
                                        dictionary盒子载具[Addr].key = 循环次数;
                                        continue;
                                    }
                                    dictionary盒子载具[Addr] = new Class4
                                    {
                                        种类 = "盒子",
                                        ADDR = Addr,
                                        name = calssname,
                                        key = 循环次数
                                    };
                                }
                                else
                                {
                                    if (!CommonProperty.战斗模式)
                                    {
                                        continue;
                                    }
                                    if (calssname == "DroppedItemGroup")
                                    {
                                        if (!dictionary物资.ContainsKey(Addr))
                                        {
                                            dictionary物资[Addr] = new 物资
                                            {
                                                key = 循环次数
                                            };
                                        }
                                        else
                                        {
                                            dictionary物资[Addr].key = 循环次数;
                                        }
                                    }
                                    else if (calssname == "DroppedItem")
                                    {
                                        if (!dictionary丢弃的物资.ContainsKey(Addr))
                                        {
                                            dictionary丢弃的物资[Addr] = new GameItems
                                            {
                                                key = 循环次数
                                            };
                                        }
                                        else
                                        {
                                            dictionary丢弃的物资[Addr].key = 循环次数;
                                        }
                                    }
                                }
                            }
                            ulongs.Clear();
                            foreach (KeyValuePair<ulong, 物资> 物资 in dictionary物资)
                            {
                                if (物资.Value.key != 循环次数)
                                {
                                    ulongs.Add(物资.Key);
                                }
                            }
                            foreach (ulong 物资 in ulongs)
                            {
                                dictionary物资.Remove(物资);
                            }
                            ulongs.Clear();
                            foreach (KeyValuePair<ulong, GameItems> 丢弃物资 in dictionary丢弃的物资)
                            {
                                if (丢弃物资.Value.key != 循环次数)
                                {
                                    ulongs.Add(丢弃物资.Key);
                                }
                            }
                            foreach (ulong 丢弃物资 in ulongs)
                            {
                                dictionary丢弃的物资.Remove(丢弃物资);
                            }
                            ulongs.Clear();
                            foreach (KeyValuePair<ulong, Class4> 盒子 in dictionary盒子载具)
                            {
                                if (盒子.Value.key != 循环次数)
                                {
                                    ulongs.Add(盒子.Key);
                                }
                            }
                            foreach (ulong 盒子 in ulongs)
                            {
                                dictionary盒子载具.Remove(盒子);
                            }
                            ulongs.Clear();
                            foreach (KeyValuePair<ulong, Actor人物> 人物 in dictionary_人物)
                            {
                                if (人物.Value.key != 循环次数)
                                {
                                    ulongs.Add(人物.Key);
                                }
                            }
                            foreach (ulong 人物 in ulongs)
                            {
                                dictionary_人物.Remove(人物);
                            }
                            ulongs.Clear();
                            foreach (KeyValuePair<ulong, Class4> 投掷 in dictionary投掷物)
                            {
                                if (投掷.Value.key != 循环次数)
                                {
                                    ulongs.Add(投掷.Key);
                                }
                            }
                            foreach (ulong 投掷 in ulongs)
                            {
                                dictionary投掷物.Remove(投掷);
                            }

                            memGet.Clear();

                            //玩家列表
                            if (循环次数 % 150uL == 0L && gameStateAddr != 0)
                            {
                                foreach (玩家列表 item8 in CommonProperty.玩家列表s)
                                {
                                    if (!item8.死亡)
                                    {
                                        memGet.Add<byte>(item8.addr + bIsSpectator);
                                        if (item8.name == "")
                                        {
                                            memGet.Add<ulong>(item8.addr + PlayerName);
                                        }
                                        if (item8.TeamID == 12345)
                                        {
                                            memGet.Add<uint>(item8.addr + PlayerTeamid);
                                        }
                                        if (item8.等级 == 12345)
                                        {
                                            memGet.Add<uint>(item8.addr + SurvivalLevel - 4);
                                            memGet.Add<uint>(item8.addr + SurvivalLevel);
                                        }
                                        memGet.Add<float>(item8.addr + DamageDealtOnEnemy);
                                    }
                                }
                            }
                            if (本人.武器控制 != 0)
                            {
                                memGet.Add<float>(本人.addr + Health);
                                memGet.Add<float>(本人.addr + HealthDie);
                                memGet.Add<byte>(本人.武器控制 + CurrentWeaponIndex);
                                memGet.Add<ulong>(本人.武器控制 + EquippedWeapons);
                            }
                            if (本人.Animasccript != 0)
                            {
                                memGet.Add<Vector3>(本人.Animasccript + ControlRotationCP);
                                memGet.Add<float>(本人.Animasccript + RecoilADSRotationCP);
                            }
                            //人物基本信息  【血量队伍编号 观战人数 人物方向】
                            foreach (KeyValuePair<ulong, Actor人物> 人物 in dictionary_人物)
                            {
                                if (!人物.Value.存活)
                                {
                                    continue;
                                }
                                if (循环次数 % 20uL == 0L && CommonProperty.espconfig.EspConfig.手持 && 人物.Value.距离 <= CommonProperty.espconfig.EspConfig.手持距离)
                                {
                                    memGet.Add<ulong>(人物.Value.addr + WeaponProcessor);
                                }


                                if (人物.Value.TeamID == 0)
                                {
                                    memGet.Add<uint>(人物.Value.addr + TeamNumber);
                                }


                                memGet.Add<byte>(人物.Value.addr + AActorRole);
                                memGet.Add<uint>(人物.Value.addr + CharacterId);
                                memGet.Add<byte>(人物.Value.addr + Health5);
                                memGet.Add<float>(人物.Value.addr + HealthDie);

                                if (人物.Value.人机 != 0)
                                {
                                    if (人物.Value.use)
                                    {
                                        memGet.Add<Vector3>(人物.Value.addr + 被瞄偏移);
                                        continue;
                                    }
                                    memGet.Add<Vector3>(人物.Value.addr + 被瞄偏移);
                                    memGet.Add<ulong>(人物.Value.addr + this.Mesh);
                                    memGet.Add<ulong>(人物.Value.addr + PlayerState);
                                }
                                else if (!人物.Value.use)
                                {
                                    if (人物.Value.TeamSeq == 0)
                                    {
                                        memGet.Add<uint>(人物.Value.addr + TeamNumber + 8);
                                    }
                                    memGet.Add<uint>(人物.Value.addr + Audience);
                                    memGet.Add<ulong>(人物.Value.addr + this.Mesh);
                                    memGet.Add<ulong>(人物.Value.addr + PlayerState);
                                    memGet.Add<Vector3>(人物.Value.addr + 被瞄偏移);
                                    if (人物.Value.name == "")
                                    {
                                        memGet.Add<ulong>(人物.Value.addr + this.Playname);
                                    }
                                }
                                else
                                {
                                    if (人物.Value.TeamSeq == 0)
                                    {
                                        memGet.Add<uint>(人物.Value.addr + TeamNumber + 8);
                                    }
                                    memGet.Add<uint>(人物.Value.addr + Audience);
                                    memGet.Add<Vector3>(人物.Value.addr + 被瞄偏移);
                                }




                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> 物资 in dictionary物资)
                                {
                                    if (kyZpsbAxnb(物资.Value.ulong_0, 物资.Key) || 物资.Value.距离 > CommonProperty.espconfig.EspConfig.物资距离 || 物资.Value.距离 == 0)
                                    {
                                        memGet.Add<ulong>(物资.Key + DroppedItemGroup);
                                        memGet.Add<uint>(物资.Key + DroppedItemGroup + 8);
                                    }
                                }
                                foreach (KeyValuePair<ulong, GameItems> 丢弃物资 in dictionary丢弃的物资)
                                {
                                    memGet.Add<ulong>(丢弃物资.Key + DroppedItem);
                                }
                                foreach (Class4 盒子 in dictionary盒子载具.Values)
                                {
                                    if (盒子.DroppedItemGroup_2 == 0)
                                    {
                                        memGet.Add<ulong>(盒子.ADDR + DroppedItemGroup);
                                    }
                                }
                            }
                            foreach (Class4 value20 in dictionary投掷物.Values)
                            {
                                if (value20.DroppedItemGroup_2 == 0)
                                {
                                    memGet.Add<ulong>(value20.ADDR + DroppedItemGroup);
                                }
                            }
                            memGet.Finish();
                            if (循环次数 % 150uL == 0L && gameStateAddr != 0)
                            {
                                foreach (玩家列表 item10 in CommonProperty.玩家列表s)
                                {
                                    if (item10.死亡)
                                    {
                                        continue;
                                    }
                                    string 状态 = Convert.ToString(memGet.Get<byte>(item10.addr + bIsSpectator), 2);
                                    if (状态 == "0" || 状态.Length < 3)
                                    {
                                        continue;
                                    }
                                    item10.死亡 = ((状态.Substring(状态.Length - 1, 1) == "1") ? true : false);
                                    item10.人机 = ((状态.Substring(状态.Length - 3, 1) == "1") ? 1 : 0);
                                    if (item10.name == "")
                                    {
                                        item10.name = MemRead_Encoding_Unicode_GetString(memGet.Get<ulong>(item10.addr + PlayerName), 64u);
                                    }
                                    if (item10.TeamID == 12345)
                                    {
                                        item10.TeamID = memGet.Get<uint>(item10.addr + PlayerTeamid);
                                        item10.TeamID %= 100000u;
                                    }
                                    if (item10.name == "#unknown" && item10.TeamID == 0)
                                    {
                                        item10.name = "OB管理员";
                                        item10.等级 = 9999u;
                                        continue;
                                    }
                                    if (item10.等级 == 12345)
                                    {
                                        uint 大等级 = memGet.Get<uint>(item10.addr + SurvivalLevel - 4);
                                        uint 等级 = memGet.Get<uint>(item10.addr + SurvivalLevel);
                                        if (大等级 != 0 && 大等级 <= 6)
                                        {
                                            item10.等级 = (大等级 - 1) * 500 + 等级;
                                        }
                                    }
                                    item10.伤害 = (float)Math.Round(memGet.Get<float>(item10.addr + DamageDealtOnEnemy), 0);
                                }
                                if (!CommonProperty.刷新列表)
                                {
                                    CommonProperty.刷新列表 = true;
                                }
                            }
                            if (本人.武器控制 != 0)
                            {
                                本人.人物血量 = memGet.Get<float>(本人.addr + Health);
                                本人.倒地血量 = memGet.Get<float>(本人.addr + HealthDie);
                                本人.武器类型 = memGet.Get<byte>(本人.武器控制 + CurrentWeaponIndex);
                                ulong 武器基址 = memGet.Get<ulong>(本人.武器控制 + EquippedWeapons);
                                if (武器基址 != 0 && kyZpsbAxnb(武器基址, 本人.addr))
                                {
                                    本人.武器基址 = 武器基址;
                                }
                            }
                            if (本人.Animasccript != 0)
                            {
                                本人.ControlRotation = memGet.Get<Vector3>(本人.Animasccript + ControlRotationCP);
                                本人.RecoilADSRotation = memGet.Get<float>(本人.Animasccript + RecoilADSRotationCP);
                            }
                            foreach (KeyValuePair<ulong, Actor人物> item12 in dictionary_人物)
                            {
                                if (!item12.Value.存活)
                                {
                                    continue;
                                }
                                if (循环次数 % 20uL == 0L && CommonProperty.espconfig.EspConfig.手持 && item12.Value.距离 <= CommonProperty.espconfig.EspConfig.手持距离)
                                {
                                    item12.Value.武器控制 = memGet.Get<ulong>(item12.Value.addr + WeaponProcessor);
                                }


                                if (item12.Value.TeamID == 0)
                                {
                                    item12.Value.TeamID = memGet.Get<uint>(item12.Value.addr + TeamNumber);
                                    item12.Value.TeamID = item12.Value.TeamID % 100000u;
                                    if (item12.Value.TeamID >= 1000000 || item12.Value.TeamID == 0 || item12.Value.TeamID - 100000 == 0)
                                    {
                                        item12.Value.TeamID = 888u;
                                    }
                                }

                                item12.Value.血量加密 = memGet.Get<byte>(item12.Value.addr + AActorRole);
                                item12.Value.血量加密2 = memGet.Get<uint>(item12.Value.addr + CharacterId);
                                item12.Value.血量5 = memGet.Get<byte>(item12.Value.addr + Health5);
                                item12.Value.倒地血量 = memGet.Get<float>(item12.Value.addr + HealthDie);


                                if (item12.Value.人机 != 0)
                                {
                                    if (!item12.Value.存活)
                                    {
                                        continue;
                                    }
                                    if (!item12.Value.use)
                                    {
                                        ulong Mesh = memGet.Get<ulong>(item12.Value.addr + this.Mesh);
                                        if (kyZpsbAxnb(Mesh, item12.Value.addr))
                                        {
                                            item12.Value.视角 = Mesh;
                                        }
                                        item12.Value.人物方向 = memGet.Get<Vector3>(item12.Value.addr + 被瞄偏移);
                                    }
                                    else
                                    {
                                        item12.Value.人物方向 = memGet.Get<Vector3>(item12.Value.addr + 被瞄偏移);
                                    }
                                    continue;
                                }
                                if (item12.Value.use)
                                {
                                    if (item12.Value.TeamSeq == 0)
                                    {
                                        item12.Value.TeamSeq = memGet.Get<uint>(item12.Value.addr + TeamNumber + 8);
                                    }
                                    item12.Value.观战人数 = memGet.Get<uint>(item12.Value.addr + Audience);
                                    item12.Value.人物方向 = memGet.Get<Vector3>(item12.Value.addr + 被瞄偏移);
                                }
                                else
                                {
                                    if (item12.Value.TeamID == 0)
                                    {
                                        item12.Value.TeamSeq = memGet.Get<uint>(item12.Value.addr + TeamNumber + 8);
                                    }
                                    item12.Value.观战人数 = memGet.Get<uint>(item12.Value.addr + Audience);
                                    ulong meshaddr2 = memGet.Get<ulong>(item12.Value.addr + this.Mesh);
                                    if (meshaddr2 != 0 && kyZpsbAxnb(meshaddr2, item12.Value.addr))
                                    {
                                        item12.Value.视角 = meshaddr2;
                                    }
                                    ulong 人物状态 = Decrypt_(memGet.Get<ulong>(item12.Value.addr + PlayerState));
                                    if (人物状态 != 0 && kyZpsbAxnb(人物状态, item12.Value.addr))
                                    {
                                        item12.Value.人物状态 = 人物状态;
                                    }
                                    item12.Value.人物方向 = memGet.Get<Vector3>(item12.Value.addr + 被瞄偏移);
                                    if (item12.Value.name == "")
                                    {
                                        ulong Playname = memGet.Get<ulong>(item12.Value.addr + this.Playname);
                                        if (Playname != 0 && kyZpsbAxnb(Playname, item12.Value.addr))
                                        {
                                            item12.Value.Playname = Playname;
                                        }
                                    }
                                }


                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item32 in dictionary物资)
                                {
                                    if (kyZpsbAxnb(item32.Value.ulong_0, item32.Key) || item32.Value.距离 > CommonProperty.espconfig.EspConfig.物资距离 || item32.Value.距离 == 0)
                                    {
                                        item32.Value.ulong_0 = memGet.Get<ulong>(item32.Key + DroppedItemGroup);
                                        item32.Value.距离 = memGet.Get<uint>(item32.Key + DroppedItemGroup + 8);
                                    }
                                }
                                foreach (KeyValuePair<ulong, GameItems> item33 in dictionary丢弃的物资)
                                {
                                    item33.Value.ulong_0 = Decrypt_(memGet.Get<ulong>(item33.Key + DroppedItem));
                                }
                                foreach (Class4 value21 in dictionary盒子载具.Values)
                                {
                                    if (value21.DroppedItemGroup_2 == 0)
                                    {
                                        ulong ulong_7 = memGet.Get<ulong>(value21.ADDR + DroppedItemGroup);
                                        if (kyZpsbAxnb(ulong_7, value21.ADDR))
                                        {
                                            value21.DroppedItemGroup = ulong_7;
                                        }
                                    }
                                }
                            }
                            foreach (Class4 value22 in dictionary投掷物.Values)
                            {
                                if (value22.DroppedItemGroup_2 == 0)
                                {
                                    ulong ulong_8 = memGet.Get<ulong>(value22.ADDR + DroppedItemGroup);
                                    if (kyZpsbAxnb(ulong_8, value22.ADDR))
                                    {
                                        value22.DroppedItemGroup = ulong_8;
                                    }
                                }
                            }


                            if (!本人.死亡)
                            {
                                if (本人.武器类型 >= 0 && 本人.武器类型 <= 4)
                                {
                                    memGet.Add<ulong>(本人.武器基址 + (ulong)(本人.武器类型 * 8L));
                                }
                                memGet.Add<float>(本人.视角 + Eyes);
                                if (本人.WeaponName == "WeapGrenade_C")
                                {
                                    memGet.Add<float>(本人.WeaponAddr + ElapsedCookingTime);
                                }
                            }
                            else
                            {
                                本人.本人信息();
                            }
                            //人物基本信息  【人物坐标 距离 name 杀敌 等级 是否可视   】
                            foreach (KeyValuePair<ulong, Actor人物> item13 in dictionary_人物)
                            {
                                if (!item13.Value.存活)
                                {
                                    continue;
                                }
                                if (循环次数 % 20uL == 0L && CommonProperty.espconfig.EspConfig.手持 && item13.Value.距离 <= CommonProperty.espconfig.EspConfig.手持距离 && item13.Value.武器控制 != 0)
                                {
                                    memGet.Add<byte>(item13.Value.武器控制 + CurrentWeaponIndex);
                                    memGet.Add<ulong>(item13.Value.武器控制 + EquippedWeapons);
                                }
                                memGet.Add<FTransform>(item13.Value.视角 + BoneArry);
                                memGet.Add<ulong>(item13.Value.视角 + Bone);
                                memGet.Add<Vector3>(item13.Value.视角 + Position);
                                memGet.Add<byte>(item13.Value.视角 + AntiCheatCharacterSyncManager);



                                if (item13.Value.血量加密 == 3 || item13.Value.血量加密2 == 0)
                                {
                                    memGet.Add<float>(item13.Value.addr + Health2);
                                }
                                else
                                {
                                    item13.Value.血量3 = Read<byte>(item13.Value.addr + Health3);
                                    memGet.Add<float>(item13.Value.血量3 + item13.Value.addr + Health4);
                                    if (item13.Value.血量5 > 0)
                                    {
                                        memGet.Add<uint>(item13.Value.addr + Health6);
                                    }
                                }


                                if (item13.Value.人机 != 0)
                                {
                                    continue;
                                }
                                if (!本人.死亡)
                                {
                                    memGet.Add<float>(item13.Value.视角 + Eyes);
                                }
                                if (item13.Value.人物状态 != 0 && 循环次数 % 20uL == 0)
                                {
                                    memGet.Add<uint>(item13.Value.人物状态 + PlayerSatisitc);
                                    if (item13.Value.生存等级 == 0)
                                    {
                                        memGet.Add<uint>(item13.Value.人物状态 + SurvivalLevel - 4);
                                        memGet.Add<uint>(item13.Value.人物状态 + SurvivalLevel);
                                        memGet.Add<byte>(item13.Value.人物状态 + PartnerLevel);
                                    }
                                    if (item13.Value.TeamID == 本人.TeamID)
                                    {
                                        memGet.Add<uint>(item13.Value.人物状态 + MapMarker + 28);
                                        memGet.Add<Vector2>(item13.Value.人物状态 + MapMarker + 32);
                                    }
                                }
                                if ((item13.Value.name == "" || item13.Value.name == "Driver") && item13.Value.Playname != 0)
                                {
                                    memGet.method_3(item13.Value.Playname, 64u);
                                }



                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item34 in dictionary物资)
                                {
                                    if (kyZpsbAxnb(item34.Value.ulong_0, item34.Key) && item34.Value.距离 != 0 && item34.Value.距离 < CommonProperty.espconfig.EspConfig.物资距离)
                                    {
                                        for (uint num15 = 0u; num15 < item34.Value.距离; num15++)
                                        {
                                            memGet.Add<ulong>(item34.Value.ulong_0 - 16 + num15 * 16);
                                        }
                                    }
                                }
                                foreach (KeyValuePair<ulong, GameItems> item35 in dictionary丢弃的物资)
                                {
                                    memGet.Add<ulong>(item35.Value.ulong_0 + 物品一);
                                    memGet.Add<ulong>(item35.Key + DroppedItemGroup);
                                }
                                foreach (Class4 value24 in dictionary盒子载具.Values)
                                {
                                    if (value24.DroppedItemGroup != 0 && value24.DroppedItemGroup_2 == 0)
                                    {
                                        memGet.Add<ulong>(value24.DroppedItemGroup);
                                    }
                                }
                            }
                            foreach (Class4 value23 in dictionary投掷物.Values)
                            {
                                if (value23.DroppedItemGroup != 0 && value23.DroppedItemGroup_2 == 0)
                                {
                                    memGet.Add<ulong>(value23.DroppedItemGroup);
                                }
                            }
                            memGet.Finish();
                            if (!本人.死亡)
                            {
                                if (本人.武器类型 >= 0 && 本人.武器类型 <= 4)
                                {
                                    本人.WeaponAddr = memGet.Get<ulong>(本人.武器基址 + (ulong)(本人.武器类型 * 8L));
                                }
                                else
                                {
                                    本人.WeaponAddr = 0uL;
                                    本人.WeaponTrajectoryDataAddr = 0uL;
                                    本人.武器id = 0u;
                                    本人.WeaponName = "";
                                    本人.InitialSpeed = 0f;
                                }
                                本人.可视 = memGet.Get<float>(本人.视角 + Eyes);
                                if (本人.WeaponName != "WeapGrenade_C")
                                {
                                    CommonProperty.手雷倒计时 = 5f;
                                }
                                else
                                {
                                    手雷倒计时 = memGet.Get<float>(本人.WeaponAddr + ElapsedCookingTime);
                                    CommonProperty.手雷倒计时 = 5f - 手雷倒计时;
                                }
                            }
                            CommonProperty.迷雾人数 = 0;
                            foreach (KeyValuePair<ulong, Actor人物> item11 in dictionary_人物)
                            {
                                if (!item11.Value.存活)
                                {
                                    continue;
                                }
                                if (循环次数 % 20uL == 0L && CommonProperty.espconfig.EspConfig.手持 && item11.Value.距离 <= CommonProperty.espconfig.EspConfig.手持距离)
                                {
                                    item11.Value.byte_b = memGet.Get<byte>(item11.Value.武器控制 + CurrentWeaponIndex);
                                    ulong 武器基质 = memGet.Get<ulong>(item11.Value.武器控制 + EquippedWeapons);
                                    if (武器基质 != 0 && kyZpsbAxnb(武器基质, item11.Value.addr))
                                    {
                                        item11.Value.武器基址 = 武器基质;
                                    }
                                }
                                item11.Value.use = true;
                                item11.Value.Actor_Bone = memGet.Get<FTransform>(item11.Value.视角 + BoneArry);
                                item11.Value.Bone = memGet.Get<ulong>(item11.Value.视角 + Bone);
                                item11.Value.中心坐标.x = item11.Value.Actor_Bone.Translation.x;
                                item11.Value.中心坐标.y = item11.Value.Actor_Bone.Translation.y;
                                item11.Value.中心坐标.z = item11.Value.Actor_Bone.Translation.z;
                                item11.Value.人物雷达坐标 = 加全地图坐标(item11.Value.中心坐标);
                                //判断迷雾
                                item11.Value.迷雾 = memGet.Get<byte>(item11.Value.视角 + AntiCheatCharacterSyncManager) == 4 ? 0 : 1;

                                if (item11.Value.迷雾 == 0)
                                {
                                    CommonProperty.迷雾人数++;
                                }


                                if (item11.Value.血量加密 == 3 || item11.Value.血量加密2 == 0)
                                {
                                    item11.Value.人物血量 = memGet.Get<float>(item11.Value.addr + Health2);
                                }
                                else
                                {
                                    item11.Value.血量4 = memGet.Get<float>(item11.Value.血量3 + item11.Value.addr + Health4);
                                    if (item11.Value.血量5 > 0)
                                    {
                                        byte[] value = BitConverter.GetBytes(item11.Value.血量4);
                                        var en_value = memGet.Get<uint>(item11.Value.addr + Health6);
                                        uint[] v7 = { V1, V2, V3, V4, V5, V6, V7, V8, V9, V10, V11, V12, V13, V14, V15, V16 };
                                        for (uint i = 0; i < 4; i++)
                                        {
                                            uint key_index = (i + en_value) & 0x3f;
                                            uint select_key = v7[key_index / 4];
                                            byte[] a = BitConverter.GetBytes(select_key);
                                            value[i] ^= a[key_index % 4];
                                        }
                                        item11.Value.人物血量 = BitConverter.ToSingle(value, 0);
                                    }
                                    else
                                    {
                                        item11.Value.人物血量 = item11.Value.血量4;
                                    }
                                }


                                if (item11.Value.人物血量 > 100f || float.IsNaN(item11.Value.人物血量))
                                {
                                    item11.Value.人物血量 = 100f;
                                }
                                if (item11.Value.倒地血量 > 100f || float.IsNaN(item11.Value.倒地血量))
                                {
                                    item11.Value.倒地血量 = 100f;
                                }
                                if (item11.Value.人物血量 < 0f)
                                {
                                    item11.Value.人物血量 = 0f;
                                }
                                if (item11.Value.倒地血量 < 0f)
                                {
                                    item11.Value.倒地血量 = 0f;
                                }



                                if (!本人.死亡)
                                {
                                    uint 距离 = 计算距离(相减(本人.距离坐标, item11.Value.人物雷达坐标)) / 100u;
                                    if (距离 < 10000)
                                    {
                                        item11.Value.距离 = 距离;
                                    }
                                }
                                else
                                {
                                    item11.Value.距离 = 0u;
                                }
                                if (item11.Value.人机 != 0)
                                {
                                    if (item11.Value.人机 == 1)
                                    {
                                        item11.Value.是否可视 = 1;
                                        if (item11.Value.视角 == 0)
                                        {
                                            item11.Value.use = false;
                                        }
                                    }
                                    continue;
                                }
                                if (本人.死亡)
                                {
                                    item11.Value.距离 = 0u;
                                    item11.Value.是否可视 = 1;
                                }
                                else
                                {
                                    item11.Value.人物位面 = memGet.Get<float>(item11.Value.视角 + Eyes);
                                    item11.Value.是否可视 = ((item11.Value.人物位面 >= 本人.可视) ? 1 : 0);
                                }
                                if (item11.Value.人物状态 != 0 && 循环次数 % 20uL == 0)
                                {
                                    if (item11.Value.生存等级 == 0)
                                    {
                                        uint 生存等级 = memGet.Get<uint>(item11.Value.人物状态 + SurvivalLevel);
                                        if (生存等级 > 500)
                                        {
                                            item11.Value.use = false;
                                        }
                                        else
                                        {
                                            item11.Value.生存等级 = 生存等级;
                                        }
                                        uint num16 = memGet.Get<uint>(item11.Value.人物状态 + SurvivalLevel - 4);
                                        if (num16 != 0 && num16 <= 6)
                                        {
                                            item11.Value.生存大等级 = num16;
                                            uint num28 = item11.Value.生存等级 + (item11.Value.生存大等级 - 1) * 500;
                                            if (num28 < 5000)
                                            {
                                                item11.Value.等级 = num28;
                                            }
                                            else
                                            {
                                                item11.Value.等级 = item11.Value.生存等级;
                                            }
                                        }
                                        else
                                        {
                                            item11.Value.use = false;
                                        }
                                        byte 合作者等级 = memGet.Get<byte>(item11.Value.人物状态 + PartnerLevel);
                                        if (合作者等级 > 5)
                                        {
                                            item11.Value.use = false;
                                        }
                                        else
                                        {
                                            item11.Value.合作者 = 合作者等级;
                                        }
                                    }
                                    uint 人物杀敌 = memGet.Get<uint>(item11.Value.人物状态 + PlayerSatisitc);
                                    if (人物杀敌 > 100)
                                    {
                                        item11.Value.use = false;
                                    }
                                    else
                                    {
                                        item11.Value.人物杀敌 = 人物杀敌;
                                    }
                                    if (item11.Value.TeamID == 本人.TeamID)
                                    {
                                        item11.Value.标点 = memGet.Get<uint>(item11.Value.人物状态 + MapMarker + 28);
                                        if (item11.Value.标点 == 1)
                                        {
                                            item11.Value.队友标点坐标 = memGet.Get<Vector2>(item11.Value.人物状态 + MapMarker + 32);
                                        }
                                        else
                                        {
                                            item11.Value.队友标点坐标 = default(Vector2);
                                        }
                                    }
                                }
                                if ((item11.Value.name == "" || item11.Value.name == "Driver") && item11.Value.Playname != 0)
                                {
                                    item11.Value.name = NAME(vmm.MemRead(pid, item11.Value.Playname, 64u));
                                    if (item11.Value.name.Contains(" ") && item11.Value.name.StartsWith("["))
                                    {
                                        item11.Value.name = item11.Value.name.Split(' ')[1];
                                    }
                                    item11.Value.ulong_4 = 0uL;
                                }
                                if (item11.Value.name == "" || item11.Value.name == "Driver")
                                {
                                    if (计算距离(相减(item11.Value.距离坐标, item11.Value.人物雷达坐标)) / 100u == 0)
                                    {
                                        if (item11.Value.name == "Driver")
                                        {
                                            Actor人物 value30 = item11.Value;
                                            value30.ulong_4++;
                                            if (item11.Value.ulong_4 > 1000)
                                            {
                                                item11.Value.name = "";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        item11.Value.距离坐标 = 加全地图坐标(memGet.Get<Vector3>(item11.Value.视角 + Position));
                                        item11.Value.name = "Driver";
                                        item11.Value.ulong_4 = 0uL;
                                    }
                                }
                                if (item11.Value.人物状态 == 0L || item11.Value.视角 == 0L || item11.Value.name == "")
                                {
                                    item11.Value.use = false;
                                }





                                if (item11.Value.name == 本人.name && 本人.name != "")
                                {
                                    if (本人.addr != item11.Value.addr)
                                    {
                                        本人.本人信息();
                                        本人.addr = item11.Value.addr;
                                    }
                                    本人.人物血量 = item11.Value.人物血量;
                                    本人.倒地血量 = item11.Value.倒地血量;
                                    本人.本人观战数量 = item11.Value.观战人数;
                                    CommonProperty.本人观战人数 = 本人.本人观战数量;
                                    if (Math.Ceiling(本人.人物血量 + 本人.倒地血量) == 0.0)
                                    {
                                        本人.死亡 = true;
                                    }
                                    else
                                    {
                                        本人.死亡 = false;
                                    }
                                    item11.Value.Isself = 1u;
                                }
                            }
                            foreach (KeyValuePair<ulong, Actor人物> item9 in dictionary_人物)
                            {
                                if (item9.Value.人机 == 0)
                                {
                                    if (item9.Value.name != "" && (CommonProperty.HashSet_白名单.Contains(item9.Value.name) || CommonProperty.Hash_队友.Contains(item9.Value.name)) && !CommonProperty.hashSet_友军.Contains(item9.Value.TeamID))
                                    {
                                        CommonProperty.hashSet_友军.Add(item9.Value.TeamID);
                                    }
                                    if (!CommonProperty.hashSet_友军.Contains(item9.Value.TeamID) && item9.Value.TeamID != 本人.TeamID)
                                    {
                                        item9.Value.是否友军 = 0u;
                                    }
                                    else
                                    {
                                        item9.Value.是否友军 = 1u;
                                    }
                                    if (item9.Value.是否友军 == 1 && item9.Value.name != "" && item9.Value.name != "Driver")
                                    {
                                        this.状态("临时队友", item9.Value.name);
                                    }
                                    else if (item9.Value.是否友军 != 1 && item9.Value.name != "" && item9.Value.name != "Driver")
                                    {
                                        this.状态("本局玩家", "队伍:" + item9.Value.TeamID + "   |" + item9.Value.name);
                                    }
                                }
                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item37 in dictionary物资)
                                {
                                    if (kyZpsbAxnb(item37.Value.ulong_0, item37.Key) && item37.Value.距离 != 0 && item37.Value.距离 < CommonProperty.espconfig.EspConfig.物资距离)
                                    {
                                        for (uint num17 = 0u; num17 < item37.Value.距离; num17++)
                                        {
                                            ulong num18 = memGet.Get<ulong>(item37.Value.ulong_0 - 16 + num17 * 16);
                                            if (kyZpsbAxnb(num18, item37.Value.ulong_0))
                                            {
                                                if (item37.Value.dictionary_物资.ContainsKey(num18))
                                                {
                                                    item37.Value.dictionary_物资[num18].key = 循环次数;
                                                    continue;
                                                }
                                                item37.Value.dictionary_物资[num18] = new GameItems
                                                {
                                                    ulong_0 = num18,
                                                    key = 循环次数
                                                };
                                            }
                                        }
                                    }
                                    ulongs.Clear();
                                    foreach (KeyValuePair<ulong, GameItems> item38 in item37.Value.dictionary_物资)
                                    {
                                        if (item38.Value.key != 循环次数)
                                        {
                                            ulongs.Add(item38.Key);
                                        }
                                    }
                                    foreach (ulong item39 in ulongs)
                                    {
                                        item37.Value.dictionary_物资.Remove(item39);
                                    }
                                }
                                foreach (KeyValuePair<ulong, GameItems> item40 in dictionary丢弃的物资)
                                {
                                    item40.Value.ulong_4 = memGet.Get<ulong>(item40.Value.ulong_0 + 物品一);
                                    item40.Value.ulong_2 = memGet.Get<ulong>(item40.Key + DroppedItemGroup);
                                }
                                foreach (Class4 value26 in dictionary盒子载具.Values)
                                {
                                    if (value26.DroppedItemGroup != 0 && value26.DroppedItemGroup_2 == 0)
                                    {
                                        ulong ulong_10 = memGet.Get<ulong>(value26.DroppedItemGroup);
                                        if (kyZpsbAxnb(ulong_10, value26.ADDR))
                                        {
                                            value26.DroppedItemGroup_2 = ulong_10;
                                        }
                                    }
                                }
                            }
                            foreach (Class4 value25 in dictionary投掷物.Values)
                            {
                                if (value25.DroppedItemGroup != 0 && value25.DroppedItemGroup_2 == 0)
                                {
                                    ulong ulong_9 = memGet.Get<ulong>(value25.DroppedItemGroup);
                                    if (kyZpsbAxnb(ulong_9, value25.ADDR))
                                    {
                                        value25.DroppedItemGroup_2 = ulong_9;
                                    }
                                }
                            }


                            if (!本人.死亡 && 本人.WeaponAddr != 0)
                            {
                                memGet.Add<ulong>(本人.WeaponAddr + WeaponTrajectoryData);
                                memGet.Add<uint>(本人.WeaponAddr + ObjID);
                            }
                            //人物骨骼点
                            foreach (KeyValuePair<ulong, Actor人物> item7 in dictionary_人物)
                            {
                                if (!item7.Value.存活 || item7.Value.迷雾 == 0)
                                {
                                    continue;
                                }
                                if (透视 && item7.Value.距离 < CommonProperty.espconfig.EspConfig.透视距离)
                                {
                                    memGet.Add<FTransform>(item7.Value.Bone + (ulong)(骨盆 * 48L));
                                    memGet.Add<FTransform>(item7.Value.Bone + (ulong)(头部 * 48L));
                                    if (CommonProperty.espconfig.EspConfig.骨骼)
                                    {
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(颈部 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(胸部 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(左肩 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(右肩 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(左手 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(右手 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(左肘 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(右肘 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(左膝 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(右膝 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(左脚 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(右脚 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(左胯 * 48L));
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(右胯 * 48L));
                                    }
                                }
                                if (循环次数 % 10uL == 0L && CommonProperty.espconfig.EspConfig.手持 && item7.Value.距离 <= CommonProperty.espconfig.EspConfig.手持距离)
                                {
                                    memGet.Add<ulong>(item7.Value.武器基址 + (ulong)(item7.Value.byte_b * 8L));
                                    if (item7.Value.当前武器 != 0)
                                    {
                                        memGet.Add<uint>(item7.Value.当前武器 + ObjID);
                                    }
                                }
                                if (!自瞄)
                                {
                                    continue;
                                }
                                if (!子骨骼自瞄)
                                {
                                    if (武器参数.父骨骼 != 0)
                                    {
                                        memGet.Add<FTransform>(item7.Value.Bone + (ulong)(武器参数.父骨骼 * 48L));
                                    }
                                }
                                else
                                {
                                    memGet.Add<FTransform>(item7.Value.Bone + (ulong)(武器参数.子骨骼 * 48L));
                                }
                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item67 in dictionary物资)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item41 in item67.Value.dictionary_物资)
                                    {
                                        if (item41.Value.name == "")
                                        {
                                            memGet.Add<ulong>(item41.Value.ulong_0 + DroppedItemGroupUItem);
                                        }
                                    }
                                }
                                foreach (GameItems value27 in dictionary丢弃的物资.Values)
                                {
                                    memGet.Add<uint>(value27.ulong_4 + 物品二);
                                    memGet.Add<ulong>(value27.ulong_2);
                                }
                                foreach (Class4 value29 in dictionary盒子载具.Values)
                                {
                                    if (value29.DroppedItemGroup != 0 && value29.DroppedItemGroup_2 != 0)
                                    {
                                        memGet.Add<Vector3>(value29.DroppedItemGroup_2 + Position);
                                    }
                                }
                            }
                            foreach (Class4 value28 in dictionary投掷物.Values)
                            {
                                if (value28.DroppedItemGroup != 0 && value28.DroppedItemGroup_2 != 0)
                                {
                                    memGet.Add<Vector3>(value28.DroppedItemGroup_2 + Position);
                                    memGet.Add<float>(value28.ADDR + TimeTillExplosion);
                                }
                            }
                            memGet.Finish();
                            if (!本人.死亡 && 本人.WeaponAddr != 0)
                            {
                                本人.WeaponTrajectoryDataAddr = memGet.Get<ulong>(本人.WeaponAddr + WeaponTrajectoryData);
                                本人.武器id = DecryptCIndex(memGet.Get<uint>(本人.WeaponAddr + ObjID));
                                if (!ActorClassNameList.ContainsKey(本人.武器id))
                                {
                                    ActorClassNameList[本人.武器id] = MemGetName(本人.武器id);
                                }
                                本人.WeaponName = ActorClassNameList[本人.武器id];
                            }
                            foreach (KeyValuePair<ulong, Actor人物> item6 in dictionary_人物)
                            {
                                if (!item6.Value.存活 || item6.Value.迷雾 == 0)
                                {
                                    continue;
                                }
                                if (透视 && item6.Value.距离 < CommonProperty.espconfig.EspConfig.透视距离)
                                {
                                    item6.Value.头部_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(头部 * 48L));
                                    item6.Value.骨盆_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(骨盆 * 48L));
                                    if (CommonProperty.espconfig.EspConfig.骨骼)
                                    {
                                        item6.Value.颈部_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(颈部 * 48L));
                                        item6.Value.胸部_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(胸部 * 48L));
                                        item6.Value.左手_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(左手 * 48L));
                                        item6.Value.右手_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(右手 * 48L));
                                        item6.Value.左肩_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(左肩 * 48L));
                                        item6.Value.右肩_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(右肩 * 48L));
                                        item6.Value.左肘_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(左肘 * 48L));
                                        item6.Value.右肘_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(右肘 * 48L));
                                        item6.Value.左胯_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(左胯 * 48L));
                                        item6.Value.右胯_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(右胯 * 48L));
                                        item6.Value.左膝_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(左膝 * 48L));
                                        item6.Value.右膝_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(右膝 * 48L));
                                        item6.Value.左脚跟_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(左脚 * 48L));
                                        item6.Value.右脚跟_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(右脚 * 48L));
                                    }
                                }
                                if (循环次数 % 10uL == 0L && CommonProperty.espconfig.EspConfig.手持 && item6.Value.距离 <= CommonProperty.espconfig.EspConfig.手持距离)
                                {
                                    if (item6.Value.byte_b >= 0 && item6.Value.byte_b <= 4)
                                    {
                                        item6.Value.当前武器 = memGet.Get<ulong>(item6.Value.武器基址 + (ulong)(item6.Value.byte_b * 8L));
                                    }
                                    else
                                    {
                                        item6.Value.当前武器 = 0uL;
                                        item6.Value.武器类型 = 99;
                                    }
                                    if (item6.Value.当前武器 != 0)
                                    {
                                        item6.Value.武器id = DecryptCIndex(memGet.Get<uint>(item6.Value.当前武器 + ObjID));
                                        if (!ActorClassNameList.ContainsKey(item6.Value.武器id))
                                        {
                                            ActorClassNameList[item6.Value.武器id] = MemGetName(item6.Value.武器id);
                                        }
                                        item6.Value.武器名称name = ActorClassNameList[item6.Value.武器id];
                                        if (Program.mainForm_0.GunList.ContainsKey(item6.Value.武器名称name))
                                        {
                                            item6.Value.武器名称 = Program.mainForm_0.GunList[item6.Value.武器名称name].ShortName;
                                            item6.Value.武器类型 = Program.mainForm_0.GunList[item6.Value.武器名称name].GunType;
                                        }
                                        else
                                        {
                                            item6.Value.武器名称 = "";
                                            item6.Value.武器类型 = 99;
                                        }
                                    }
                                }
                                if (!自瞄)
                                {
                                    continue;
                                }
                                if (!子骨骼自瞄)
                                {
                                    if (武器参数.父骨骼 != 0)
                                    {
                                        item6.Value.瞄准_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(武器参数.父骨骼 * 48L));
                                    }
                                }
                                else
                                {
                                    item6.Value.瞄准_Bone = memGet.Get<FTransform>(item6.Value.Bone + (ulong)(武器参数.子骨骼 * 48L));
                                }
                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item68 in dictionary物资)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item42 in item68.Value.dictionary_物资)
                                    {
                                        if (item42.Value.name == "")
                                        {
                                            item42.Value.ulong_1 = memGet.Get<ulong>(item42.Value.ulong_0 + DroppedItemGroupUItem);
                                            if (!kyZpsbAxnb(item42.Value.ulong_1, item42.Value.ulong_0))
                                            {
                                                item42.Value.name = "None";
                                            }
                                        }
                                    }
                                }
                                foreach (GameItems value4 in dictionary丢弃的物资.Values)
                                {
                                    value4.uint_0 = memGet.Get<uint>(value4.ulong_4 + 物品二);
                                    value4.ulong_3 = memGet.Get<ulong>(value4.ulong_2);
                                    if (!ActorClassNameList.ContainsKey(value4.uint_0))
                                    {
                                        ActorClassNameList[value4.uint_0] = MemGetName(value4.uint_0);
                                    }
                                    value4.name = ActorClassNameList[value4.uint_0];
                                    if (value4.name == "")
                                    {
                                        value4.name = "None";
                                    }
                                }
                                foreach (Class4 value6 in dictionary盒子载具.Values)
                                {
                                    if (value6.DroppedItemGroup == 0 || value6.DroppedItemGroup_2 == 0)
                                    {
                                        continue;
                                    }
                                    value6.vector3_原坐标 = memGet.Get<Vector3>(value6.DroppedItemGroup_2 + Position);
                                    value6.vector3_雷达坐标 = 加全地图坐标(value6.vector3_原坐标);
                                    if (!本人.死亡)
                                    {
                                        uint num20 = 计算距离(相减(本人.距离坐标, value6.vector3_雷达坐标)) / 100u;
                                        if (num20 < 10000)
                                        {
                                            value6.距离 = num20;
                                        }
                                    }
                                    else
                                    {
                                        value6.距离 = 0u;
                                    }
                                }
                            }
                            foreach (Class4 value5 in dictionary投掷物.Values)
                            {
                                if (value5.DroppedItemGroup == 0 || value5.DroppedItemGroup_2 == 0)
                                {
                                    continue;
                                }
                                value5.时间 = memGet.Get<float>(value5.ADDR + TimeTillExplosion);
                                value5.vector3_原坐标 = memGet.Get<Vector3>(value5.DroppedItemGroup_2 + Position);
                                value5.vector3_雷达坐标 = 加全地图坐标(value5.vector3_原坐标);
                                if (!本人.死亡)
                                {
                                    uint num19 = 计算距离(相减(本人.距离坐标, value5.vector3_雷达坐标)) / 100u;
                                    if (num19 < 10000)
                                    {
                                        value5.距离 = num19;
                                    }
                                }
                                else
                                {
                                    value5.距离 = 0u;
                                }
                            }


                            if (!本人.死亡 && 本人.WeaponAddr != 0 && 本人.WeaponTrajectoryDataAddr != 0)
                            {
                                memGet.Add<float>(本人.WeaponTrajectoryDataAddr + TrajectoryConfig);
                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item69 in dictionary物资)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item44 in item69.Value.dictionary_物资)
                                    {
                                        if (item44.Value.name == "")
                                        {
                                            memGet.Add<ulong>(item44.Value.ulong_1 + 物品一);
                                        }
                                    }
                                }
                            }
                            //大地图状态 透视开启的时候读
                            if (透视)
                            {
                                memGet.Add<int>(MapAddr + Visibility);
                            }
                            memGet.Finish();
                            if (!本人.死亡 && 本人.WeaponAddr != 0 && 本人.WeaponTrajectoryDataAddr != 0)
                            {
                                本人.InitialSpeed = memGet.Get<float>(本人.WeaponTrajectoryDataAddr + TrajectoryConfig);
                                if (本人.InitialSpeed == 0f || float.IsNaN(本人.InitialSpeed))
                                {
                                    本人.InitialSpeed = 800f;
                                }
                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item70 in dictionary物资)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item45 in item70.Value.dictionary_物资)
                                    {
                                        if (item45.Value.name == "")
                                        {
                                            item45.Value.ulong_4 = memGet.Get<ulong>(item45.Value.ulong_1 + 物品一);
                                            if (!kyZpsbAxnb(item45.Value.ulong_4, item45.Value.ulong_0))
                                            {
                                                item45.Value.name = "None";
                                            }
                                        }
                                    }
                                }
                            }
                            //计算骨骼点透视坐标
                            if (透视)
                            {
                                CommonProperty.IsShow = memGet.Get<int>(MapAddr + Visibility) == 4;
                                foreach (Actor人物 value3 in dictionary_人物.Values)
                                {
                                    if (value3.存活 && 透视 && value3.距离 < CommonProperty.espconfig.EspConfig.透视距离 && value3.迷雾 != 0)
                                    {
                                        value3.中心 = 计算透视坐标(value3.中心坐标);
                                        D3DMATRIX d3DMATRIX_16 = value3.骨盆_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX10 = method_35(d3DMATRIX_16, value3.Actor_Bone.ToMatrixWithScale());
                                        value3.vector3_骨盆.x = d3DMATRIX10._41;
                                        value3.vector3_骨盆.y = d3DMATRIX10._42;
                                        value3.vector3_骨盆.z = d3DMATRIX10._43;
                                        value3.骨盆 = 计算透视坐标(value3.vector3_骨盆);
                                        D3DMATRIX d3DMATRIX_17 = value3.头部_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX11 = method_35(d3DMATRIX_17, value3.Actor_Bone.ToMatrixWithScale());
                                        value3.vector3_头部.x = d3DMATRIX11._41;
                                        value3.vector3_头部.y = d3DMATRIX11._42;
                                        value3.vector3_头部.z = d3DMATRIX11._43;
                                        value3.头部 = 计算透视坐标(value3.vector3_头部);
                                        if (CommonProperty.espconfig.EspConfig.骨骼)
                                        {
                                            D3DMATRIX d3DMATRIX_18 = value3.颈部_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX12 = method_35(d3DMATRIX_18, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_颈部.x = d3DMATRIX12._41;
                                            value3.vector3_颈部.y = d3DMATRIX12._42;
                                            value3.vector3_颈部.z = d3DMATRIX12._43;
                                            value3.颈部 = 计算透视坐标(value3.vector3_颈部);
                                            D3DMATRIX d3DMATRIX_21 = value3.胸部_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX15 = method_35(d3DMATRIX_21, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_胸部.x = d3DMATRIX15._41;
                                            value3.vector3_胸部.y = d3DMATRIX15._42;
                                            value3.vector3_胸部.z = d3DMATRIX15._43;
                                            value3.胸部 = 计算透视坐标(value3.vector3_胸部);
                                            D3DMATRIX d3DMATRIX_24 = value3.左肘_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX18 = method_35(d3DMATRIX_24, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_左肘.x = d3DMATRIX18._41;
                                            value3.vector3_左肘.y = d3DMATRIX18._42;
                                            value3.vector3_左肘.z = d3DMATRIX18._43;
                                            value3.左肘 = 计算透视坐标(value3.vector3_左肘);
                                            D3DMATRIX d3DMATRIX_25 = value3.右肘_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX19 = method_35(d3DMATRIX_25, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_右肘.x = d3DMATRIX19._41;
                                            value3.vector3_右肘.y = d3DMATRIX19._42;
                                            value3.vector3_右肘.z = d3DMATRIX19._43;
                                            value3.右肘 = 计算透视坐标(value3.vector3_右肘);
                                            D3DMATRIX d3DMATRIX_26 = value3.左手_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX20 = method_35(d3DMATRIX_26, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_左手.x = d3DMATRIX20._41;
                                            value3.vector3_左手.y = d3DMATRIX20._42;
                                            value3.vector3_左手.z = d3DMATRIX20._43;
                                            value3.左手 = 计算透视坐标(value3.vector3_左手);
                                            D3DMATRIX d3DMATRIX_2 = value3.右手_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX21 = method_35(d3DMATRIX_2, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_右手.x = d3DMATRIX21._41;
                                            value3.vector3_右手.y = d3DMATRIX21._42;
                                            value3.vector3_右手.z = d3DMATRIX21._43;
                                            value3.右手 = 计算透视坐标(value3.vector3_右手);
                                            D3DMATRIX d3DMATRIX_3 = value3.左膝_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX2 = method_35(d3DMATRIX_3, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_左膝.x = d3DMATRIX2._41;
                                            value3.vector3_左膝.y = d3DMATRIX2._42;
                                            value3.vector3_左膝.z = d3DMATRIX2._43;
                                            value3.左膝 = 计算透视坐标(value3.vector3_左膝);
                                            D3DMATRIX d3DMATRIX_4 = value3.右膝_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX3 = method_35(d3DMATRIX_4, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_右膝.x = d3DMATRIX3._41;
                                            value3.vector3_右膝.y = d3DMATRIX3._42;
                                            value3.vector3_右膝.z = d3DMATRIX3._43;
                                            value3.右膝 = 计算透视坐标(value3.vector3_右膝);
                                            D3DMATRIX d3DMATRIX_5 = value3.左脚跟_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX4 = method_35(d3DMATRIX_5, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_左脚跟.x = d3DMATRIX4._41;
                                            value3.vector3_左脚跟.y = d3DMATRIX4._42;
                                            value3.vector3_左脚跟.z = d3DMATRIX4._43;
                                            value3.左脚跟 = 计算透视坐标(value3.vector3_左脚跟);
                                            D3DMATRIX d3DMATRIX_6 = value3.右脚跟_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX5 = method_35(d3DMATRIX_6, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_右脚跟.x = d3DMATRIX5._41;
                                            value3.vector3_右脚跟.y = d3DMATRIX5._42;
                                            value3.vector3_右脚跟.z = d3DMATRIX5._43;
                                            value3.右脚跟 = 计算透视坐标(value3.vector3_右脚跟);
                                            D3DMATRIX d3DMATRIX_19 = value3.左肩_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX13 = method_35(d3DMATRIX_19, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_左肩.x = d3DMATRIX13._41;
                                            value3.vector3_左肩.y = d3DMATRIX13._42;
                                            value3.vector3_左肩.z = d3DMATRIX13._43;
                                            value3.左肩 = 计算透视坐标(value3.vector3_左肩);
                                            D3DMATRIX d3DMATRIX_22 = value3.右肩_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX16 = method_35(d3DMATRIX_22, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_右肩.x = d3DMATRIX16._41;
                                            value3.vector3_右肩.y = d3DMATRIX16._42;
                                            value3.vector3_右肩.z = d3DMATRIX16._43;
                                            value3.右肩 = 计算透视坐标(value3.vector3_右肩);
                                            D3DMATRIX d3DMATRIX_20 = value3.左胯_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX14 = method_35(d3DMATRIX_20, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_左胯.x = d3DMATRIX14._41;
                                            value3.vector3_左胯.y = d3DMATRIX14._42;
                                            value3.vector3_左胯.z = d3DMATRIX14._43;
                                            value3.左胯 = 计算透视坐标(value3.vector3_左胯);
                                            D3DMATRIX d3DMATRIX_23 = value3.右胯_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX17 = method_35(d3DMATRIX_23, value3.Actor_Bone.ToMatrixWithScale());
                                            value3.vector3_右胯.x = d3DMATRIX17._41;
                                            value3.vector3_右胯.y = d3DMATRIX17._42;
                                            value3.vector3_右胯.z = d3DMATRIX17._43;
                                            value3.右胯 = 计算透视坐标(value3.vector3_右胯);
                                        }
                                    }
                                }
                            }
                            if (透视)
                            {
                                List<Actor人物> espData = new List<Actor人物>();
                                List<Actor人物> espData2 = new List<Actor人物>();
                                屏幕中心是否有人 = false;
                                foreach (KeyValuePair<ulong, Actor人物> item5 in dictionary_人物)
                                {
                                    if (item5.Value.存活 && item5.Value.是否友军 == 0 && item5.Value.迷雾 != 0)
                                    {
                                        if (item5.Value.中心.x > X分辨率 / 2 - CommonProperty.fov2 && item5.Value.中心.x < X分辨率 / 2 + CommonProperty.fov2 && item5.Value.中心.y > Y分辨率 / 2 - CommonProperty.fov2 && item5.Value.中心.y < Y分辨率 / 2 + CommonProperty.fov2)
                                        {
                                            //CommonProperty.espconfig.EspConfig.提前量 = true;
                                            屏幕中心是否有人 = true;
                                        }
                                        espData.Add(item5.Value);
                                    }
                                }
                                if (espData.Count > 0)
                                {
                                    concurrentQueue_人物.Enqueue(espData);
                                    EspOverlay.Esp人物Queue.Enqueue(espData);
                                    CommonProperty.EspResetEventSlim.Set();
                                }
                                else
                                {
                                    EspOverlay.人物Clear();
                                }
                            }
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item71 in dictionary物资)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item46 in item71.Value.dictionary_物资)
                                    {
                                        if (item46.Value.name == "")
                                        {
                                            memGet.Add<uint>(item46.Value.ulong_4 + 物品二);
                                        }
                                    }
                                }
                            }
                            memGet.Finish();
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item72 in dictionary物资)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item47 in item72.Value.dictionary_物资)
                                    {
                                        if (item47.Value.name == "")
                                        {
                                            item47.Value.uint_0 = memGet.Get<uint>(item47.Value.ulong_4 + 物品二);
                                            if (!ActorClassNameList.ContainsKey(item47.Value.uint_0))
                                            {
                                                ActorClassNameList[item47.Value.uint_0] = MemGetName(item47.Value.uint_0);
                                            }
                                            item47.Value.name = ActorClassNameList[item47.Value.uint_0];
                                            if (item47.Value.name == "")
                                            {
                                                item47.Value.name = "None";
                                            }
                                        }
                                    }
                                }
                            }
                            bool flag = false;
                            if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                            {
                                foreach (KeyValuePair<ulong, 物资> item73 in dictionary物资)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item53 in item73.Value.dictionary_物资)
                                    {
                                        if (item53.Value.name != "None" && item53.Value.vector3_0.x == 0f && item53.Value.vector3_0.y == 0f && item53.Value.vector3_0.z == 0f)
                                        {
                                            flag = true;
                                            memGet.Add<Vector3>(item53.Value.ulong_0 + Position);
                                        }
                                    }
                                }
                                foreach (KeyValuePair<ulong, GameItems> item54 in dictionary丢弃的物资)
                                {
                                    if (item54.Value.name != "None" && item54.Value.vector3_0.x == 0f && item54.Value.vector3_0.y == 0f && item54.Value.vector3_0.z == 0f)
                                    {
                                        flag = true;
                                        memGet.Add<Vector3>(item54.Value.ulong_3 + Position);
                                    }
                                }
                                memGet.Finish();
                                if (!flag)
                                {
                                    foreach (KeyValuePair<ulong, 物资> item74 in dictionary物资)
                                    {
                                        foreach (GameItems value7 in item74.Value.dictionary_物资.Values)
                                        {
                                            if (!本人.死亡)
                                            {
                                                uint num21 = 计算距离(相减(本人.距离坐标, value7.vector3_1)) / 100u;
                                                if (num21 < 10000)
                                                {
                                                    value7.距离 = num21;
                                                }
                                            }
                                            else
                                            {
                                                value7.距离 = 0u;
                                            }
                                        }
                                    }
                                    foreach (GameItems value8 in dictionary丢弃的物资.Values)
                                    {
                                        if (!本人.死亡)
                                        {
                                            uint num22 = 计算距离(相减(本人.距离坐标, value8.vector3_1)) / 100u;
                                            if (num22 < 10000)
                                            {
                                                value8.距离 = num22;
                                            }
                                        }
                                        else
                                        {
                                            value8.距离 = 0u;
                                        }
                                    }
                                }
                                else
                                {
                                    Vector3Int vector3Int = MemRead<Vector3Int>(基准值 + 世界转小地图);
                                    if (vector3Int.x != 全地图XY.x || vector3Int.y != 全地图XY.y || vector3Int.z != 全地图XY.z)
                                    {
                                        flag = true;
                                        continue;
                                    }
                                    foreach (KeyValuePair<ulong, 物资> item75 in dictionary物资)
                                    {
                                        foreach (GameItems value9 in item75.Value.dictionary_物资.Values)
                                        {
                                            if (!(value9.name != "None") || value9.vector3_0.x != 0f || value9.vector3_0.y != 0f || value9.vector3_0.z != 0f)
                                            {
                                                continue;
                                            }
                                            value9.vector3_0 = memGet.Get<Vector3>(value9.ulong_0 + Position);
                                            value9.vector3_1 = 加全地图坐标(value9.vector3_0);
                                            if (!本人.死亡)
                                            {
                                                uint num23 = 计算距离(相减(本人.距离坐标, value9.vector3_1)) / 100u;
                                                if (num23 < 10000)
                                                {
                                                    value9.距离 = num23;
                                                }
                                            }
                                            else
                                            {
                                                value9.距离 = 0u;
                                            }
                                        }
                                    }
                                    foreach (GameItems value10 in dictionary丢弃的物资.Values)
                                    {
                                        if (!(value10.name != "None") || value10.vector3_0.x != 0f || value10.vector3_0.y != 0f || value10.vector3_0.z != 0f)
                                        {
                                            continue;
                                        }
                                        value10.vector3_0 = memGet.Get<Vector3>(value10.ulong_3 + Position);
                                        value10.vector3_1 = 加全地图坐标(value10.vector3_0);
                                        if (!本人.死亡)
                                        {
                                            uint num24 = 计算距离(相减(本人.距离坐标, value10.vector3_1)) / 100u;
                                            if (num24 < 10000)
                                            {
                                                value10.距离 = num24;
                                            }
                                        }
                                        else
                                        {
                                            value10.距离 = 0u;
                                        }
                                    }
                                }
                            }


                            //透视玩家列表数据收集
                            if (循环次数 % 150uL == 0)
                            {
                                List<玩家列表> espData3 = new List<玩家列表>();
                                foreach (玩家列表 item4 in CommonProperty.玩家列表s)
                                {
                                    if (!item4.死亡 || item4.TeamID != 12345 || !(item4.name == ""))
                                    {
                                        espData3.Add(item4);
                                    }
                                }
                                if (espData3.Count > 0)
                                {
                                    EspOverlay.Esp玩家列表.Enqueue(espData3);
                                    CommonProperty.EspResetEventSlim.Set();
                                }
                            }
                            //人物存活
                            foreach (KeyValuePair<ulong, Actor人物> item3 in dictionary_人物)
                            {
                                if (item3.Value.存活 && Math.Ceiling(item3.Value.人物血量 + item3.Value.倒地血量) == 0.0)
                                {
                                    item3.Value.存活 = false;
                                }
                            }




                            //雷达数据
                            strings_人物.Clear();
                            strings_人物标点.Clear();
                            网页雷达.玩家 = "";
                            网页雷达.标记 = "";
                            foreach (Actor人物 value in dictionary_人物.Values)
                            {
                                if (!value.存活 || value.迷雾 == 0)
                                {
                                    continue;
                                }
                                if (value.人机 == 0)
                                {
                                    if (!(value.KD != "") && !(value.段位 != "") && CommonProperty.玩家列表s.Count > 0)
                                    {
                                        foreach (玩家列表 item in CommonProperty.玩家列表s)
                                        {
                                            if (item.name == value.name)
                                            {
                                                value.KD = item.KD;
                                                value.段位 = item.段位;
                                            }
                                        }
                                    }
                                    Vector3 人物坐标 = value.人物雷达坐标;
                                    uint Teamid = value.TeamID;
                                    Vector3 人物方向 = value.人物方向;
                                    if (本人.死亡)
                                    {
                                        value.被瞄准 = 0;
                                        value.高度 = "";
                                    }
                                    else
                                    {
                                        if ((本人.距离坐标.z - value.人物雷达坐标.z) / 100f > 2f)
                                        {
                                            value.高度 = "▼";
                                        }
                                        else if ((本人.距离坐标.z - value.人物雷达坐标.z) / 100f < -2f)
                                        {
                                            value.高度 = "▲";
                                        }
                                        else
                                        {
                                            value.高度 = "";
                                        }
                                        if (!(人物方向.x < -3600f) && !(人物方向.x > 3600f) && !(人物方向.y < -3600f) && 人物方向.y <= 3600f)
                                        {
                                            Vector3 vector17 = method_31(人物坐标, 本人.距离坐标);
                                            Vector3 vector18 = 判断是否在视角(人物方向);
                                            int num25 = (int)Math.Abs(vector17.x - vector18.y);
                                            int num26 = (int)Math.Abs(vector17.y - vector18.x);
                                            if (num25 <= 3 && num26 <= 3)
                                            {
                                                value.被瞄准 = 1;
                                            }
                                            else
                                            {
                                                value.被瞄准 = 0;
                                            }
                                        }
                                        else
                                        {
                                            value.被瞄准 = 0;
                                        }
                                    }
                                    string 玩家信息s = "";
                                    if (玩家信息)
                                    {
                                        if (游戏ID)
                                        {
                                            玩家信息s += value.name;
                                        }
                                        if (ShowAudience)
                                        {
                                            玩家信息s += ((玩家信息s == "") ? ("V:" + value.观战人数) : ("/V:" + value.观战人数));
                                        }
                                        if (ShowKillNum)
                                        {
                                            玩家信息s += ((玩家信息s == "") ? ("K:" + value.人物杀敌) : ("/K:" + value.人物杀敌));
                                        }
                                        if (ShowKD)
                                        {
                                            玩家信息s += ((!(玩家信息s == "")) ? ("/KD:" + value.KD) : ("KD:" + value.KD));
                                            string text7 = ((!(玩家信息s == "")) ? ("/KD:" + value.KD) : ("KD:" + value.KD));
                                        }
                                        if (ShowDamageAvg)
                                        {
                                            玩家信息s += ((玩家信息s == "") ? ("D:" + value.场伤) : ("/D:" + value.场伤));
                                        }
                                        if (ShowRank)
                                        {
                                            玩家信息s += ((!(玩家信息s == "")) ? ("/" + value.段位) : value.段位);
                                        }
                                        if (ShowSurvivalLevel)
                                        {
                                            uint num27 = value.生存等级 + (value.生存大等级 - 1) * 500;
                                            if (num27 < 5000)
                                            {
                                                value.等级 = num27;
                                                玩家信息s += ((!(玩家信息s == "")) ? ("/S:" + num27) : ("S:" + num27));
                                            }
                                        }
                                        if (ShowDistance || 玩家信息s == "")
                                        {
                                            玩家信息s += ((!(玩家信息s == "")) ? ("/" + value.距离 + "M") : value.距离.ToString());
                                        }
                                    }
                                    if (value.段位 == "大师")
                                    {
                                        CommonProperty.Hash_黑名单.Add(value.name);
                                    }
                                    if (CommonProperty.Hash_黑名单.Contains(value.name))
                                    {
                                        CommonProperty.Hash_黑名单.Add(value.name);
                                        value.人物杀敌 = 99u;
                                    }
                                    try
                                    {
                                        string item30 = string.Format("[{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},\"{15}\",\"{16}\",\"{17}\"]", Convert.ToInt64(Math.Ceiling(人物坐标.x)), Convert.ToInt64(Math.Ceiling(人物坐标.y)), value.距离, (Teamid >= 100000) ? (Teamid - 100000) : Teamid, Convert.ToInt64(Math.Ceiling(value.人物血量)), Convert.ToInt64(Math.Ceiling(value.倒地血量)), value.人物杀敌, value.观战人数, Convert.ToInt64(Math.Ceiling(value.人物方向.y)), value.是否友军, value.人机, (value.合作者 != 0) ? 1 : 0, (value.name == "") ? 1 : 0, value.Isself, value.被瞄准, value.高度, value.name, 玩家信息s);
                                        if (人物坐标.x > 0f && 人物坐标.y > 0f && 人物坐标.x < 1000000f && 人物坐标.y < 1000000f)
                                        {
                                            strings_人物.Add(item30);
                                        }
                                        if (value.是否友军 == 1 && value.队友标点坐标.x > 0f && value.队友标点坐标.y > 0f && value.队友标点坐标.x < 1000000f && value.队友标点坐标.y < 1000000f)
                                        {
                                            item30 = $"[{value.TeamSeq + 1},{value.队友标点坐标.x},{value.队友标点坐标.y}]";
                                            strings_人物标点.Add(item30);
                                        }
                                    }
                                    catch
                                    {
                                    }
                                }
                                else
                                {
                                    if (!value.存活)
                                    {
                                        continue;
                                    }
                                    string text8 = "";
                                    if (本人.死亡)
                                    {
                                        value.高度 = "";
                                    }
                                    else if ((本人.距离坐标.z - value.人物雷达坐标.z) / 100f > 2f)
                                    {
                                        value.高度 = "▼";
                                    }
                                    else if ((本人.距离坐标.z - value.人物雷达坐标.z) / 100f < -2f)
                                    {
                                        value.高度 = "▲";
                                    }
                                    else
                                    {
                                        value.高度 = "";
                                    }
                                    Vector3 vector3_人物雷达坐标 = value.人物雷达坐标;
                                    uint num29 = value.TeamID;
                                    try
                                    {
                                        string item36 = string.Format("[{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},\"{15}\",\"{16}\",\"{17}\"]", Convert.ToInt64(Math.Ceiling(vector3_人物雷达坐标.x)), Convert.ToInt64(Math.Ceiling(vector3_人物雷达坐标.y)), value.距离, (num29 >= 100000) ? (num29 - 100000) : num29, Convert.ToInt64(Math.Ceiling(value.人物血量)), Convert.ToInt64(Math.Ceiling(value.倒地血量)), 0, 0, Convert.ToInt64(Math.Ceiling(value.人物方向.y)), value.是否友军, 1, 0, 0, 0, value.被瞄准, value.高度, "BOT", text8);
                                        if (vector3_人物雷达坐标.x > 0f && vector3_人物雷达坐标.y > 0f && vector3_人物雷达坐标.x < 1000000f && vector3_人物雷达坐标.y < 1000000f)
                                        {
                                            strings_人物.Add(item36);
                                        }
                                    }
                                    catch
                                    {
                                    }
                                }
                            }
                            if (循环次数 % 50uL == 0)
                            {
                                strings_物资.Clear();
                                网页雷达.物资 = "";
                                strings_载具.Clear();
                                strings_盒子.Clear();
                                网页雷达.载具 = "";
                                网页雷达.盒子 = "";
                            }

                            if (CommonProperty.战斗模式 && 雷达物资 && 循环次数 % 50uL == 0)
                            {

                                foreach (KeyValuePair<ulong, 物资> item76 in dictionary物资)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item55 in item76.Value.dictionary_物资)
                                    {
                                        if (dictionary_物资.ContainsKey(item55.Value.name))
                                        {
                                            if (!判断物资(item55.Value.name) || !(item55.Value.vector3_1.x > 0f) || !(item55.Value.vector3_1.y > 0f))
                                            {
                                                continue;
                                            }
                                            string text9 = "0";
                                            string text10 = "●";
                                            if (!本人.死亡)
                                            {
                                                if ((本人.距离坐标.z - item55.Value.vector3_1.z) / 100f > 2f)
                                                {
                                                    text10 = "▼";
                                                }
                                                else if ((本人.距离坐标.z - item55.Value.vector3_1.z) / 100f < -2f)
                                                {
                                                    text10 = "▲";
                                                }
                                            }
                                            switch (dictionary_物资[item55.Value.name].group)
                                            {
                                                default:
                                                    if (物资0)
                                                    {
                                                        text9 = "0";
                                                        string item64 = $"[\"{text10}{dictionary_物资[item55.Value.name].shortName}\",{item55.Value.vector3_1.x},{item55.Value.vector3_1.y},\"{text9}\"]";
                                                        strings_物资.Add(item64);
                                                    }
                                                    break;
                                                case 1:
                                                    if (物资1)
                                                    {
                                                        text9 = "1";
                                                        string item52 = $"[\"{text10}{dictionary_物资[item55.Value.name].shortName}\",{item55.Value.vector3_1.x},{item55.Value.vector3_1.y},\"{text9}\"]";
                                                        strings_物资.Add(item52);
                                                    }
                                                    break;
                                                case 2:
                                                    if (物资2)
                                                    {
                                                        text9 = "2";
                                                        string item59 = $"[\"{text10}{dictionary_物资[item55.Value.name].shortName}\",{item55.Value.vector3_1.x},{item55.Value.vector3_1.y},\"{text9}\"]";
                                                        strings_物资.Add(item59);
                                                    }
                                                    break;
                                                case 3:
                                                    if (物资3)
                                                    {
                                                        text9 = "3";
                                                        string item43 = $"[\"{text10}{dictionary_物资[item55.Value.name].shortName}\",{item55.Value.vector3_1.x},{item55.Value.vector3_1.y},\"{text9}\"]";
                                                        strings_物资.Add(item43);
                                                    }
                                                    break;
                                            }
                                        }
                                        else if (item55.Value.name.Trim() != "None" && !item55.Value.name.Contains("/"))
                                        {
                                            dictionary_5[item55.Value.uint_0] = new KeyValuePair<string, string>("物资透视", item55.Value.name);
                                        }
                                    }
                                }
                                foreach (KeyValuePair<ulong, GameItems> item56 in dictionary丢弃的物资)
                                {
                                    if (!dictionary_物资.ContainsKey(item56.Value.name))
                                    {
                                        if (item56.Value.name.Trim() != "None" && !item56.Value.name.Contains("/"))
                                        {
                                            dictionary_5[item56.Value.uint_0] = new KeyValuePair<string, string>("丢弃物资", item56.Value.name);
                                        }
                                    }
                                    else
                                    {
                                        if (!判断物资(item56.Value.name) || !(item56.Value.vector3_1.x > 0f) || !(item56.Value.vector3_1.y > 0f))
                                        {
                                            continue;
                                        }
                                        string text11 = "0";
                                        string text12 = "●";
                                        if (!本人.死亡)
                                        {
                                            if ((本人.距离坐标.z - item56.Value.vector3_1.z) / 100f > 2f)
                                            {
                                                text12 = "▼";
                                            }
                                            else if ((本人.距离坐标.z - item56.Value.vector3_1.z) / 100f < -2f)
                                            {
                                                text12 = "▲";
                                            }
                                        }
                                        switch (dictionary_物资[item56.Value.name].group)
                                        {
                                            default:
                                                if (物资0)
                                                {
                                                    text11 = "0";
                                                    string item16 = $"[\"{text12}{dictionary_物资[item56.Value.name].shortName}\",{item56.Value.vector3_1.x},{item56.Value.vector3_1.y},\"{text11}\"]";
                                                    strings_物资.Add(item16);
                                                }
                                                break;
                                            case 1:
                                                if (物资1)
                                                {
                                                    text11 = "1";
                                                    string item14 = $"[\"{text12}{dictionary_物资[item56.Value.name].shortName}\",{item56.Value.vector3_1.x},{item56.Value.vector3_1.y},\"{text11}\"]";
                                                    strings_物资.Add(item14);
                                                }
                                                break;
                                            case 2:
                                                if (物资2)
                                                {
                                                    text11 = "2";
                                                    string item15 = $"[\"{text12}{dictionary_物资[item56.Value.name].shortName}\",{item56.Value.vector3_1.x},{item56.Value.vector3_1.y},\"{text11}\"]";
                                                    strings_物资.Add(item15);
                                                }
                                                break;
                                            case 3:
                                                if (物资3)
                                                {
                                                    text11 = "3";
                                                    string item65 = $"[\"{text12}{dictionary_物资[item56.Value.name].shortName}\",{item56.Value.vector3_1.x},{item56.Value.vector3_1.y},\"{text11}\"]";
                                                    strings_物资.Add(item65);
                                                }
                                                break;
                                        }
                                    }
                                }
                            }
                            if (CommonProperty.战斗模式 && 循环次数 % 50uL == 0)
                            {

                                foreach (Class4 value11 in dictionary盒子载具.Values)
                                {
                                    string text13 = "●";
                                    if (!本人.死亡)
                                    {
                                        if ((本人.距离坐标.z - value11.vector3_雷达坐标.z) / 100f > 2f)
                                        {
                                            text13 = "▼";
                                        }
                                        else if ((本人.距离坐标.z - value11.vector3_雷达坐标.z) / 100f < -2f)
                                        {
                                            text13 = "▲";
                                        }
                                    }
                                    string 种类 = value11.种类;
                                    string text14 = 种类;
                                    if (!(text14 == "盒子"))
                                    {
                                        if (text14 == "载具")
                                        {
                                            string text3 = $"[\"{text13}{dictionary_载具[value11.name].shortName}\",{value11.vector3_雷达坐标.x},{value11.vector3_雷达坐标.y}]";
                                            if (!text3.Contains("\"NaN\"") && value11.vector3_雷达坐标.x > 0f && value11.vector3_雷达坐标.y > 0f && 雷达载具)
                                            {
                                                strings_载具.Add(text3);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        string text2 = string.Format("[\"{0}\",{1},{2}]", (value11.name.Trim() == "DeathDropItemPackage_C") ? "0" : "1", value11.vector3_雷达坐标.x, value11.vector3_雷达坐标.y);
                                        if (!text2.Contains("\"NaN\"") && value11.vector3_雷达坐标.x > 0f && value11.vector3_雷达坐标.y > 0f)
                                        {
                                            strings_盒子.Add(text2);
                                        }
                                    }
                                }
                            }
                            if (透视)
                            {
                                List<GameItems> gameItemsList = new List<GameItems>();
                                List<Class4> vehiclesList_载具 = new List<Class4>();
                                if (CommonProperty.战斗模式 && !本人.死亡)
                                {
                                    foreach (Class4 value14 in dictionary盒子载具.Values)
                                    {
                                        string text6 = value14.种类;
                                        if ((CommonProperty.espconfig.EspConfig.透视载具 || CommonProperty.espconfig.EspConfig.大地图载具) && text6 == "载具" && 1 < value14.距离 && value14.距离 < CommonProperty.espconfig.EspConfig.载具距离)
                                        {
                                            Vector2 透视坐标3 = 计算透视坐标(value14.vector3_原坐标);
                                            value14.透视坐标 = 透视坐标3;
                                            value14.ShortName = dictionary_载具[value14.name].shortName;
                                            if (CommonProperty.IsShow)
                                            {
                                                float MapSizeFactored2 = MapSize / WorldMapZoomFactor;
                                                Vector3 vector19 = default(Vector3);
                                                vector19.x = MapSize * (1f + WorldMapPosition.x);
                                                vector19.y = MapSize * (1f + WorldMapPosition.y);
                                                vector19.z = 0f;
                                                Vector3 WorldCenterLocation2 = vector19;
                                                Vector3 RadarPos2 = 相减(value14.vector3_雷达坐标, WorldCenterLocation2);
                                                float x2 = X分辨率 / 2 + RadarPos2.x / MapSizeFactored2 * (Y分辨率 / 2);
                                                float y2 = Y分辨率 / 2 + RadarPos2.y / MapSizeFactored2 * (Y分辨率 / 2);
                                                if (x2 > 0f && y2 > 0f && x2 < X分辨率 && y2 < Y分辨率)
                                                {
                                                    value14.vector3_大地图.x = x2;
                                                    value14.vector3_大地图.y = y2;
                                                }
                                                else
                                                {
                                                    value14.vector3_大地图.x = 0f;
                                                    value14.vector3_大地图.y = 0f;
                                                }
                                            }
                                            else
                                            {
                                                value14.vector3_大地图.x = 0f;
                                                value14.vector3_大地图.y = 0f;
                                            }
                                            vehiclesList_载具.Add(value14);
                                        }
                                        if (!(text6 == "盒子") || 1 >= value14.距离 || (!(value14.name == "Carapackage_RedBox_C") && !(value14.name == "Carapackage_FlareGun_C") && !(value14.name == "DeathDropItemPackage_C")))
                                        {
                                            continue;
                                        }
                                        Vector2 透视坐标2 = 计算透视坐标(value14.vector3_原坐标);
                                        value14.透视坐标 = 透视坐标2;
                                        if (value14.name == "DeathDropItemPackage_C" && value14.距离 > 50)
                                        {
                                            continue;
                                        }
                                        if (CommonProperty.IsShow)
                                        {
                                            float MapSizeFactored = MapSize / WorldMapZoomFactor;
                                            Vector3 vector19 = default(Vector3);
                                            vector19.x = MapSize * (1f + WorldMapPosition.x);
                                            vector19.y = MapSize * (1f + WorldMapPosition.y);
                                            vector19.z = 0f;
                                            Vector3 WorldCenterLocation = vector19;
                                            Vector3 RadarPos = 相减(value14.vector3_雷达坐标, WorldCenterLocation);
                                            float x = X分辨率 / 2 + RadarPos.x / MapSizeFactored * (Y分辨率 / 2);
                                            float y = Y分辨率 / 2 + RadarPos.y / MapSizeFactored * (Y分辨率 / 2);
                                            if (x > 0f && y > 0f && x < X分辨率 && y < Y分辨率)
                                            {
                                                value14.vector3_大地图.x = x;
                                                value14.vector3_大地图.y = y;
                                            }
                                            else
                                            {
                                                value14.vector3_大地图.x = 0f;
                                                value14.vector3_大地图.y = 0f;
                                            }
                                        }
                                        else
                                        {
                                            value14.vector3_大地图.x = 0f;
                                            value14.vector3_大地图.y = 0f;
                                        }
                                        vehiclesList_载具.Add(value14);
                                    }
                                    if (vehiclesList_载具.Count > 0)
                                    {
                                        EspOverlay.Esp载具Queue.Enqueue(vehiclesList_载具);
                                        CommonProperty.EspResetEventSlim.Set();
                                    }
                                    else
                                    {
                                        EspOverlay.载具Clear();
                                    }
                                    if (CommonProperty.espconfig.EspConfig.透视物资)
                                    {
                                        foreach (物资 value15 in dictionary物资.Values)
                                        {
                                            foreach (GameItems value16 in value15.dictionary_物资.Values)
                                            {
                                                if (value16.距离 >= CommonProperty.espconfig.EspConfig.物资距离 || value16.距离 == 0 || !dictionary_物资.ContainsKey(value16.name) || !dictionary_物资[value16.name].showItem)
                                                {
                                                    continue;
                                                }
                                                Vector2 vector透视坐标 = 计算透视坐标(value16.vector3_0);
                                                if (!(vector透视坐标.x < 0f) && !(vector透视坐标.y < 0f) && !(vector透视坐标.x > X分辨率) && !(vector透视坐标.y > Y分辨率))
                                                {
                                                    value16.透视坐标 = vector透视坐标;
                                                    if (物资0 && dictionary_物资[value16.name].group == 0)
                                                    {
                                                        value16.group = 0;
                                                        value16.ShortName = dictionary_物资[value16.name].shortName;
                                                        gameItemsList.Add(value16);
                                                    }
                                                    if (物资1 && dictionary_物资[value16.name].group == 1)
                                                    {
                                                        value16.group = 1;
                                                        value16.ShortName = dictionary_物资[value16.name].shortName;
                                                        gameItemsList.Add(value16);
                                                    }
                                                    if (物资2 && dictionary_物资[value16.name].group == 2)
                                                    {
                                                        value16.group = 2;
                                                        value16.ShortName = dictionary_物资[value16.name].shortName;
                                                        gameItemsList.Add(value16);
                                                    }
                                                    if (物资3 && dictionary_物资[value16.name].group == 3)
                                                    {
                                                        value16.group = 3;
                                                        value16.ShortName = dictionary_物资[value16.name].shortName;
                                                        gameItemsList.Add(value16);
                                                    }
                                                }
                                            }
                                        }
                                        foreach (GameItems value17 in dictionary丢弃的物资.Values)
                                        {
                                            if (value17.距离 >= CommonProperty.espconfig.EspConfig.物资距离 || value17.距离 == 0 || !dictionary_物资.ContainsKey(value17.name) || !dictionary_物资[value17.name].showItem)
                                            {
                                                continue;
                                            }
                                            Vector2 vector15 = 计算透视坐标(value17.vector3_0);
                                            if (!(vector15.x < 0f) && !(vector15.y < 0f) && !(vector15.x > X分辨率) && !(vector15.y > Y分辨率))
                                            {
                                                value17.透视坐标 = vector15;
                                                if (物资0 && dictionary_物资[value17.name].group == 0)
                                                {
                                                    value17.group = 0;
                                                    value17.ShortName = dictionary_物资[value17.name].shortName;
                                                    gameItemsList.Add(value17);
                                                }
                                                if (物资1 && dictionary_物资[value17.name].group == 1)
                                                {
                                                    value17.group = 1;
                                                    value17.ShortName = dictionary_物资[value17.name].shortName;
                                                    gameItemsList.Add(value17);
                                                }
                                                if (物资2 && dictionary_物资[value17.name].group == 2)
                                                {
                                                    value17.group = 2;
                                                    value17.ShortName = dictionary_物资[value17.name].shortName;
                                                    gameItemsList.Add(value17);
                                                }
                                                if (物资3 && dictionary_物资[value17.name].group == 3)
                                                {
                                                    value17.group = 3;
                                                    value17.ShortName = dictionary_物资[value17.name].shortName;
                                                    gameItemsList.Add(value17);
                                                }
                                            }
                                        }
                                    }
                                    if (gameItemsList.Count > 0)
                                    {
                                        EspOverlay.Esp物资Queue.Enqueue(gameItemsList);
                                        CommonProperty.EspResetEventSlim.Set();
                                    }
                                    else
                                    {
                                        EspOverlay.物资Clear();
                                    }
                                }
                                else
                                {
                                    EspOverlay.物资Clear();
                                    EspOverlay.载具Clear();
                                }
                                List<Class4> vehiclesList_投掷物 = new List<Class4>();
                                foreach (Class4 value13 in dictionary投掷物.Values)
                                {
                                    string text5 = value13.种类;
                                    if (text5 == "投掷" && value13.距离 < 100 && value13.时间 > 0f)
                                    {
                                        Vector2 透视坐标 = 计算透视坐标(value13.vector3_原坐标);
                                        value13.透视坐标 = 透视坐标;
                                        value13.ShortName = dictionary_投掷物[value13.name].shortName;
                                        vehiclesList_投掷物.Add(value13);
                                    }
                                }
                                if (vehiclesList_投掷物.Count > 0)
                                {
                                    EspOverlay.ESP投掷物.Enqueue(vehiclesList_投掷物);
                                    CommonProperty.EspResetEventSlim.Set();
                                }
                                else
                                {
                                    EspOverlay.投掷物Clear();
                                }
                            }
                            strings_雷达信息.Clear();
                            网页雷达.玩家信息 = "";
                            switch (int_0)
                            {
                                case 1:
                                    int_0 = 0;
                                    strings_雷达信息.Add("[\"zoom\",\"U\"]");
                                    break;
                                default:
                                    int_0 = 0;
                                    strings_雷达信息.Add("[\"zoom\",\"K\"]");
                                    break;
                                case -1:
                                    int_0 = 0;
                                    strings_雷达信息.Add("[\"zoom\",\"D\"]");
                                    break;
                            }
                            if (玩家信息)
                            {
                                strings_雷达信息.Add("[\"showplayinfo\",\"T\"]");
                            }
                            else
                            {
                                strings_雷达信息.Add("[\"showplayinfo\",\"F\"]");
                            }
                            strings_雷达信息.Add("[\"FontSize\",\"" + 14 + "\"]");
                            string text4 = $"[{(物资0 ? 1 : 0)},{(物资1 ? 1 : 0)},{(物资2 ? 1 : 0)},{(物资3 ? 1 : 0)},{((!CommonProperty.战斗模式) ? 1 : 0)},{9}]";
                            strings_雷达信息.Add("[\"INFO\"," + text4 + "]");
                            网页雷达.毒圈 = $"[{Math.Ceiling(毒圈中心.x)},{Math.Ceiling(毒圈中心.y)},{Math.Ceiling(毒圈中心.z)}],[{Math.Ceiling(安全区中心.x)},{Math.Ceiling(安全区中心.y)},{Math.Ceiling(安全区中心.z)}],[{Math.Ceiling(轰炸区坐标.x)},{Math.Ceiling(轰炸区坐标.y)},{Math.Ceiling(轰炸区坐标.z)}],[{0},{0},{0}]";
                            StringBuilder stringBuilder = new StringBuilder();
                            if (循环次数 % 50uL == 0)
                            {
                                stringBuilder.Clear();
                                foreach (string item57 in strings_物资)
                                {
                                    if (!item57.Contains("\"NaN\""))
                                    {
                                        stringBuilder.Append(item57);
                                        stringBuilder.Append(",");
                                    }
                                }
                                网页雷达.物资 = stringBuilder.ToString().TrimEnd(',');
                                stringBuilder.Clear();
                                foreach (string item60 in strings_载具)
                                {
                                    if (!item60.Contains("\"NaN\""))
                                    {
                                        stringBuilder.Append(item60);
                                        stringBuilder.Append(",");
                                    }
                                }
                                网页雷达.载具 = stringBuilder.ToString().TrimEnd(',');
                                stringBuilder.Clear();
                                foreach (string item61 in strings_盒子)
                                {
                                    if (!item61.Contains("\"NaN\""))
                                    {
                                        stringBuilder.Append(item61);
                                        stringBuilder.Append(",");
                                    }
                                }
                                网页雷达.盒子 = stringBuilder.ToString().TrimEnd(',');
                            }
                            stringBuilder.Clear();
                            foreach (string item58 in strings_人物)
                            {
                                if (!item58.Contains("\"NaN\""))
                                {
                                    stringBuilder.Append(item58);
                                    stringBuilder.Append(",");
                                }
                            }
                            网页雷达.玩家 = stringBuilder.ToString().TrimEnd(',');
                            stringBuilder.Clear();
                            foreach (string item62 in strings_人物标点)
                            {
                                if (!item62.Contains("\"NaN\""))
                                {
                                    stringBuilder.Append(item62);
                                    stringBuilder.Append(",");
                                }
                            }
                            网页雷达.标记 = stringBuilder.ToString().TrimEnd(',');
                            stringBuilder.Clear();
                            foreach (string item63 in strings_雷达信息)
                            {
                                if (!item63.Contains("\"NaN\""))
                                {
                                    stringBuilder.Append(item63);
                                    stringBuilder.Append(",");
                                }
                            }
                            网页雷达.玩家信息 = stringBuilder.ToString().TrimEnd(',');
                            stringBuilder.Clear();
                            WebServer = WebServer.ToLower();
                            if (!WebServer.StartsWith("http://"))
                            {
                                WebServer = "http://" + WebServer.ToLower();
                            }
                            if (!WebServer.EndsWith("/"))
                            {
                                WebServer = WebServer.ToLower() + "/";
                            }

                            雷达url = WebServer + "?" + username + "&addr=" + MqttServer + "&id=";

                            this.状态("网页", 雷达url);



                            //线程计时
                            主线程计时器.Stop();
                            int 主线程延迟 = (int)主线程计时器.Elapsed.TotalMilliseconds;
                            延迟_主线程 += 主线程延迟;
                            string 雷达数据 = 网页雷达.雷达数据();
                            线程延迟 += 主线程延迟;
                            线程延迟2 += 主线程延迟;
                            if (线程延迟 >= 30)
                            {
                                concurrentQueue_网页雷达.Enqueue(雷达数据);
                                autoResetEvent_1.Set();
                                while (线程延迟 >= 30)
                                {
                                    线程延迟 -= 30;
                                }
                            }
                            if (循环次数 == 800)
                            {
                                MapAddr = 0uL;
                                MinimapCanvasWidgetAddr = 0uL;
                                MapGrid = 0uL;
                                Slot1 = 0uL;
                                循环次数 = 1001uL;
                                ActorClassNameList.Clear();
                                dictionary_人物.Clear();
                                dictionary盒子载具.Clear();
                                dictionary物资.Clear();
                                dictionary丢弃的物资.Clear();
                                全部对象.Clear();
                                EspOverlay.投掷物Clear();
                                EspOverlay.物资Clear();
                                EspOverlay.载具Clear();
                                EspOverlay.人物Clear();
                                EspOverlay.人物Clear1();
                            }
                            if (循环次数 % 1000uL == 0)
                            {
                                ActorClassNameList.Clear();
                                dictionary_人物.Clear();
                                if (循环次数 % 3000uL == 0)
                                {
                                    dictionary盒子载具.Clear();
                                    全部对象.Clear();
                                }
                            }
                            if (线程延迟2 > 8000)
                            {
                                dictionary物资.Clear();
                                dictionary丢弃的物资.Clear();
                                线程延迟2 = 0;
                            }
                            if (循环次数 % 50uL == 0)
                            {
                                if (CommonProperty.espconfig.EspConfig.小地图 || CommonProperty.espconfig.EspConfig.大地图)
                                {
                                    小地图雷达();
                                }
                                this.状态("延迟", "主延迟:" + (延迟_主线程 / 50).ToString("D3"));
                                延迟_主线程 = 0;
                            }
                            if (CommonProperty.espconfig.EspConfig.大地图 && CommonProperty.IsShow)
                            {
                                大地图雷达();
                            }
                        }
                        else
                        {
                            基准值 = Decrypt_(MemRead<ulong>(GameNULL + Uworld));
                            对象指针 = Decrypt_(MemRead<ulong>(Decrypt_(MemRead<ulong>(基准值 + Leve)) + Actor));
                        }
                    }
                    continue;
                }
                按键();
                初始化数据();
                网页雷达.地图 = "\"Range_Main\"";
                this.状态("地图", "等待进入地图", bool_50: false);
                this.状态("延迟", "", bool_50: false);
                this.状态("清理友军黑名单", "");
                concurrentQueue_网页雷达.Enqueue(网页雷达.雷达数据());
                autoResetEvent_1.Set();
                Thread.Sleep(500);
            }
            catch (Exception ex)
            {
                MapAddr = 0uL;
                MinimapCanvasWidgetAddr = 0uL;
                MapGrid = 0uL;
                Slot1 = 0uL;
                读本人数据计数 = 0u;
                地图状态计数 = 0;
                本人 = new 本人();
                ActorClassNameList.Clear();
                dictionary投掷物.Clear();
                dictionary_人物.Clear();
                dictionary物资.Clear();
                dictionary盒子载具.Clear();
                全部对象.Clear();
                this.状态("地图", "未检测到游戏", bool_50: false);
                this.状态("延迟", "", bool_50: false);
                this.状态("清理友军黑名单", "");
                if (透视)
                {
                    EspOverlay.投掷物Clear();
                    EspOverlay.物资Clear();
                    EspOverlay.载具Clear();
                    EspOverlay.人物Clear();
                    EspOverlay.人物Clear1();
                    CommonProperty.fov = 0f;
                    CommonProperty.本人观战人数 = 0u;
                    CommonProperty.菜单 = true;
                }
                CommonProperty.hashSet_友军.Clear();
                CommonProperty.HashSet_白名单.Clear();
                CommonProperty.玩家列表s = new List<玩家列表>();
                CommonProperty.玩家列表ss = new List<ulong>();
                if (!CommonProperty.刷新列表)
                {
                    CommonProperty.刷新列表 = true;
                }
                网页雷达.雷达初始化数据();
                网页雷达.地图 = "\"Range_Main\"";
                concurrentQueue_网页雷达.Enqueue(网页雷达.雷达数据());
                autoResetEvent_1.Set();
                ThreadRunning = false;
                CommonProperty.GameStartSlim.Set();
                string str = ex.StackTrace;
                Write2("异常：  " + str.Substring(str.LastIndexOf("\\") + 1, str.Length - str.LastIndexOf("\\") - 1) + "--------" + ex.Message, CommonProperty.path);
                break;
            }
        }
    }

    public void 小地图雷达()
    {
        ulong MyHUDAddr = MemRead<ulong>(本人.玩家控制 + MyHUD);
        //ulong BlockInputWidgetList1 = MemRead<ulong>(MyHUDAddr + BlockInputWidgetList);
        //uint BlockInputWidgetListcount = MemRead<uint>(MyHUDAddr + BlockInputWidgetList + 8);
        //for (uint i = 0; i < BlockInputWidgetListcount; i++)
        //{
        //    ulong Widget = MemRead<ulong>(BlockInputWidgetList1 + i * 8);
        //    uint ID = DecryptCIndex(MemRead<uint>(Widget + ObjID));
        //    string text = MemGetName(ID);
        //    if (text.Trim() == "MinimapOriginalType_C")
        //    {
        //        MinimapCanvasWidgetAddr = Widget;
        //    }
        //    if (text.Trim() == "NewWorldMapWidget_BP_C")
        //    {
        //        MapAddr = Widget;
        //        MapGrid = Read<ulong>(Widget + MapGrids);
        //    }
        //    if (text.Trim() == "UI_TrainingWorldMapWidget_C")
        //    {
        //        MapAddr = Widget;
        //        MapGrid = Read<ulong>(Widget + TrainingMapGrid);
        //    }
        //    if (MinimapCanvasWidgetAddr != 0 && MapAddr != 0 && MapGrid != 0)
        //    {
        //        break;
        //    }
        //}

        ulong WidgetStateMapAddr = MemRead<ulong>(MyHUDAddr + WidgetStateMap);
        for (ulong num4 = 0uL; num4 < 1000; num4++)
        {
            Struct0 @struct = Read<Struct0>(WidgetStateMapAddr + num4 * 8);
            uint num5 = DecryptCIndex(Read<uint>(@struct.Widget + ObjID));
            uint num6 = DecryptCIndex(Read<uint>(@struct.ulong_0 + ObjID));
            if (num5 == num6)
            {
                string text = MemGetName(num5);
                if (text.Trim() == "MinimapOriginalType_C")
                {
                    MinimapCanvasWidgetAddr = @struct.Widget;
                }
                if (text.Trim() == "NewWorldMapWidget_BP_C")
                {
                    MapAddr = @struct.Widget;
                    MapGrid = Read<ulong>(@struct.Widget + MapGrids);
                }
                if (text.Trim() == "UI_TrainingWorldMapWidget_C")
                {
                    MapAddr = @struct.Widget;
                    MapGrid = Read<ulong>(@struct.Widget + TrainingMapGrid);
                }
                if (MinimapCanvasWidgetAddr != 0 && MapAddr != 0 && MapGrid != 0)
                {
                    break;
                }
            }
        }
    }

    public void 大地图雷达()
    {
        if (MapAddr != 0L && MapGrid != 0)
        {
            if (Slot1 != 0)
            {
                FMargin Offsetss = MemRead<FMargin>(Slot1 + LayoutData + Offsets);
                WorldMapZoomFactor = Offsetss.Right / 1080f;
                Vector2 Alignment1 = MemRead<Vector2>(Slot1 + LayoutData + Alignment);
                WorldMapPosition.x = (Offsetss.Right * (Alignment1.x - 0.5f) - Offsetss.Left) / 1080f / WorldMapZoomFactor * 2f;
                WorldMapPosition.y = (Offsetss.Bottom * (Alignment1.y - 0.5f) - Offsetss.Top) / 1080f / WorldMapZoomFactor * 2f;
            }
            else
            {
                Slot1 = MemRead<ulong>(MapGrid + Slot);
            }
        }
    }

    public float 解密血量(ulong addr)
    {
        读写 memGet = new 读写(pid, vmm);


        memGet.Add<byte>(addr + AActorRole);
        memGet.Add<uint>(addr + CharacterId);
        memGet.Finish();
        if (memGet.Get<byte>(addr + AActorRole) == 3 || memGet.Get<uint>(addr + CharacterId) == 0)
        {
            memGet.Add<float>(addr + Health2);
            memGet.Finish();
            return memGet.Get<float>(addr + Health2);
        }

        var v2 = Read<byte>(addr + Health3);
        memGet.Add<float>(v2 + addr + Health4);
        memGet.Add<byte>(addr + Health5);
        memGet.Finish();
        var v3 = memGet.Get<float>(v2 + addr + Health4);
        if (memGet.Get<byte>(addr + Health5) > 0)
        {
            byte[] value = BitConverter.GetBytes(v3);
            var en_value = Read<uint>(addr + Health6);
            uint[] v7 = { V1, V2, V3, V4, V5, V6, V7, V8, V9, V10, V11, V12, V13, V14, V15, V16 };
            for (uint i = 0; i < 4; i++)
            {
                uint key_index = (i + en_value) & 0x3f;
                uint select_key = v7[key_index / 4];
                byte[] a = BitConverter.GetBytes(select_key);
                value[i] ^= a[key_index % 4];
            }
            v3 = BitConverter.ToSingle(value, 0);
        }
        return v3;

    }

    public void setMap()
    {
        if (当前地图 == "Tiger_Main" || 当前地图 == "Desert_Main" || 当前地图 == "Kiki_Main" || 当前地图 == "DihorOtok_Main" || 当前地图 == "Neon_Main" || 当前地图 == "Erangel_Main")
        {
            MapSize = 408000f;
        }
        else if (当前地图 == "Range_Main" || 当前地图 == "Summerland_Main")
        {
            MapSize = 101175f;
        }
        else if (当前地图 == "Baltic_Main")
        {
            MapSize = 1276704f / (float)Math.PI;
        }
        else if (当前地图 == "Heaven_Main")
        {
            MapSize = 51420f;
        }
        else if (当前地图 == "Savage_Main")
        {
            MapSize = 202387.5f;
        }
        else if (当前地图 == "Chimera_Main")
        {
            MapSize = 153000f;
        }
    }

    static Game()
    {
        vmm = Program.mainForm_0.vmm;
        dictionary_物资 = new Dictionary<string, 物资info>();
        RolByType = new Dictionary<Type, object>();
        vector2_0 = new Vector2
        {
            x = 1920f,
            y = 1080f
        };
        vector2_1 = new Vector2
        {
            x = 1887f,
            y = 1054f
        };
        float_0 = 261f;
        float_1 = 461f;
        vector2_2 = new Vector2
        {
            x = vector2_1.x / vector2_0.x,
            y = vector2_1.y / vector2_0.y
        };
        vector2_3 = new Vector2
        {
            x = float_0 / vector2_0.x,
            y = float_0 / vector2_0.y
        };
        vector2_4 = new Vector2
        {
            x = vector2_2.x - vector2_3.x,
            y = vector2_2.y - vector2_3.y
        };
        vector2_5 = new Vector2
        {
            x = float_1 / vector2_0.x,
            y = float_1 / vector2_0.y
        };
        vector2_6 = new Vector2
        {
            x = vector2_2.x - vector2_5.x,
            y = vector2_2.y - vector2_5.y
        };
    }

    public void StopAll()
    {
        if (vmm != null)
        {
            Vmm.CloseAll();
        }
        ThreadRunning = false;
    }

    public void Write2(string Logstring, string newPath)
    {
        string now_date = DateTime.Now.ToString("yyyyMMdd");
        string path = newPath + "\\" + now_date + ".txt";
        if (!File.Exists(path))
        {
            FileStream stream = File.Create(path);
            stream.Close();
            stream.Dispose();
        }
        using StreamWriter writer = new StreamWriter(path, append: true);
        writer.WriteLine(Logstring);
        writer.Close();
    }
}
