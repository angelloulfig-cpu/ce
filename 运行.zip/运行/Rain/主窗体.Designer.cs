﻿using System.ComponentModel;

namespace Rain
{
    partial class Rains
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            timer1 = new System.Windows.Forms.Timer(components);
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel_MapName = new ToolStripStatusLabel();
            UnxXuvxlhp = new ToolStripStatusLabel();
            toolStripStatusLabel_自瞄状态 = new ToolStripStatusLabel();
            mqtt状态 = new ToolStripStatusLabel();
            玩家 = new TabPage();
            aloneButton1 = new ReaLTaiizor.Controls.AloneButton();
            aloneButton2 = new ReaLTaiizor.Controls.AloneButton();
            dungeonLabel16 = new ReaLTaiizor.Controls.DungeonLabel();
            textBox_TeamAdd = new TextBox();
            checkBox_单排 = new ReaLTaiizor.Controls.AirCheckBox();
            radioButton_KDFPP = new ReaLTaiizor.Controls.SkyRadioButton();
            radioButton_KDTPP = new ReaLTaiizor.Controls.SkyRadioButton();
            物资 = new TabPage();
            poisonDataGridView3 = new ReaLTaiizor.Controls.PoisonDataGridView();
            物资名称 = new DataGridViewTextBoxColumn();
            分组 = new DataGridViewComboBoxColumn();
            显示 = new DataGridViewButtonColumn();
            自瞄 = new TabPage();
            groupBox3 = new ReaLTaiizor.Controls.GroupBox();
            checkBox开镜自瞄 = new ReaLTaiizor.Controls.AirCheckBox();
            自瞄延时 = new NumericUpDown();
            numericUpDown_Recoil = new NumericUpDown();
            numericUpDown_AimRange = new NumericUpDown();
            numericUpDown_AimDistince = new NumericUpDown();
            numericUpDown_AimDelay = new NumericUpDown();
            numericUpDown_AimSmooth = new NumericUpDown();
            numericUpDown_AimY = new NumericUpDown();
            numericUpDown_AimX = new NumericUpDown();
            checkBox跳过击杀 = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox动态FOV = new ReaLTaiizor.Controls.AirCheckBox();
            comboBox_热键_自瞄配置2 = new ReaLTaiizor.Controls.AloneComboBox();
            dungeonLabel14 = new ReaLTaiizor.Controls.DungeonLabel();
            aloneButton6 = new ReaLTaiizor.Controls.AloneButton();
            radioButton_AimUseDistince = new ReaLTaiizor.Controls.AirRadioButton();
            radioButton_AimUseRange = new ReaLTaiizor.Controls.AirRadioButton();
            crownLabel14 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel13 = new ReaLTaiizor.Controls.CrownLabel();
            comboBox_AimKey2 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_AimLock = new ReaLTaiizor.Controls.AloneComboBox();
            crownLabel6 = new ReaLTaiizor.Controls.CrownLabel();
            comboBox_AimAt = new ReaLTaiizor.Controls.AloneComboBox();
            crownLabel12 = new ReaLTaiizor.Controls.CrownLabel();
            comboBox_LockGrobbyKey = new ReaLTaiizor.Controls.AloneComboBox();
            crownLabel11 = new ReaLTaiizor.Controls.CrownLabel();
            comboBox_LockKey = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_AimKey1 = new ReaLTaiizor.Controls.AloneComboBox();
            crownLabel5 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel4 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel9 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel10 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel3 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel7 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel2 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel8 = new ReaLTaiizor.Controls.CrownLabel();
            crownLabel1 = new ReaLTaiizor.Controls.CrownLabel();
            枪类型 = new TabControl();
            tabPage7 = new TabPage();
            tabPage8 = new TabPage();
            tabPage9 = new TabPage();
            tabPage10 = new TabPage();
            tabPage11 = new TabPage();
            groupBox1 = new ReaLTaiizor.Controls.GroupBox();
            aloneButton3 = new ReaLTaiizor.Controls.AloneButton();
            MVPNETTXT = new ReaLTaiizor.Controls.DungeonTextBox();
            comboBox_COM = new ReaLTaiizor.Controls.AloneComboBox();
            关闭自瞄 = new ReaLTaiizor.Controls.SkyRadioButton();
            radioButton_易键鼠 = new ReaLTaiizor.Controls.SkyRadioButton();
            radioButton_CtrlBlack = new ReaLTaiizor.Controls.SkyRadioButton();
            radioButton_魔盒 = new ReaLTaiizor.Controls.SkyRadioButton();
            radioButton_MVPNET = new ReaLTaiizor.Controls.SkyRadioButton();
            radioButton_CtrlKmbox = new ReaLTaiizor.Controls.SkyRadioButton();
            配置 = new TabPage();
            OPENURL = new ReaLTaiizor.Controls.AloneButton();
            COPYURL = new ReaLTaiizor.Controls.AloneButton();
            checkBox_ShowVehicles = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_PlayerInfo = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_物资 = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_itemgroup3 = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_itemgroup2 = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_itemgroup1 = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_itemgroup0 = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_Rank = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_DamageAvg = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_KD = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_Audience = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_SurvivalLevel = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_KillNum = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_Distance = new ReaLTaiizor.Controls.AirCheckBox();
            checkBox_ShowName = new ReaLTaiizor.Controls.AirCheckBox();
            保存参数按钮 = new ReaLTaiizor.Controls.AloneButton();
            button_Start = new ReaLTaiizor.Controls.AloneButton();
            dungeonLabel5 = new ReaLTaiizor.Controls.DungeonLabel();
            checkBox_ESPEnable = new ReaLTaiizor.Controls.CyberSwitch();
            dungeonLabel2 = new ReaLTaiizor.Controls.DungeonLabel();
            textBox_ScreenX = new ReaLTaiizor.Controls.MoonTextBox();
            textBox_ScreenY = new ReaLTaiizor.Controls.MoonTextBox();
            groupBox2 = new ReaLTaiizor.Controls.GroupBox();
            comboBox_热键_显示物资组3 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_热键_显示物资组2 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_热键_显示物资组1 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_热键_显示物资组0 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_热键_玩家信息 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_热键_雷达缩小 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_热键_雷达放大 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_热键_加黑名单 = new ReaLTaiizor.Controls.AloneComboBox();
            comboBox_热键_透视开关 = new ReaLTaiizor.Controls.AloneComboBox();
            战斗模式 = new ReaLTaiizor.Controls.AloneComboBox();
            dungeonLabel13 = new ReaLTaiizor.Controls.DungeonLabel();
            comboBox_热键_数据刷新 = new ReaLTaiizor.Controls.AloneComboBox();
            dungeonLabel6 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel12 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel4 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel3 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel11 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel7 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel15 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel8 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel10 = new ReaLTaiizor.Controls.DungeonLabel();
            dungeonLabel9 = new ReaLTaiizor.Controls.DungeonLabel();
            comboBox_WebServer = new ComboBox();
            dungeonLabel1 = new ReaLTaiizor.Controls.DungeonLabel();
            网页服务器1 = new ReaLTaiizor.Controls.DungeonLabel();
            comboBox_MqttServer = new ComboBox();
            主菜单 = new ReaLTaiizor.Controls.AirTabPage();
            crownContextMenuStrip1 = new ReaLTaiizor.Controls.CrownContextMenuStrip();
            button_LoadAllGuns = new Button();
            label11 = new Label();
            textBox_Aim400 = new TextBox();
            radioButton_DMR = new RadioButton();
            label10 = new Label();
            textBox_Aim100 = new TextBox();
            label7 = new Label();
            textBox_Aim999 = new TextBox();
            radioButton_SR = new RadioButton();
            radioButton_GunTypeOthers = new RadioButton();
            label_GunRaise = new Label();
            label8 = new Label();
            label13 = new Label();
            textBox_Aim350 = new TextBox();
            radioButton_SG = new RadioButton();
            label17 = new Label();
            textBox_Aim150 = new TextBox();
            textBox_Aim450 = new TextBox();
            textBox_Aim600 = new TextBox();
            radioButton_AR = new RadioButton();
            label14 = new Label();
            button_SaveGun = new Button();
            textBox_Aim550 = new TextBox();
            textBox_Aim300 = new TextBox();
            textBox_Aim50 = new TextBox();
            label15 = new Label();
            textBox_Aim250 = new TextBox();
            comboBox_Gun = new ComboBox();
            label12 = new Label();
            textBox_Aim200 = new TextBox();
            label9 = new Label();
            textBox_AimRaise = new TextBox();
            checkBox_GunAdvMode = new CheckBox();
            label4 = new Label();
            textBox_Aim500 = new TextBox();
            textBox_GunShortName = new TextBox();
            label5 = new Label();
            label3 = new Label();
            textBox_URL = new TextBox();
            statusStrip1.SuspendLayout();
            玩家.SuspendLayout();
            物资.SuspendLayout();
            ((ISupportInitialize)poisonDataGridView3).BeginInit();
            自瞄.SuspendLayout();
            groupBox3.SuspendLayout();
            ((ISupportInitialize)自瞄延时).BeginInit();
            ((ISupportInitialize)numericUpDown_Recoil).BeginInit();
            ((ISupportInitialize)numericUpDown_AimRange).BeginInit();
            ((ISupportInitialize)numericUpDown_AimDistince).BeginInit();
            ((ISupportInitialize)numericUpDown_AimDelay).BeginInit();
            ((ISupportInitialize)numericUpDown_AimSmooth).BeginInit();
            ((ISupportInitialize)numericUpDown_AimY).BeginInit();
            ((ISupportInitialize)numericUpDown_AimX).BeginInit();
            枪类型.SuspendLayout();
            groupBox1.SuspendLayout();
            配置.SuspendLayout();
            groupBox2.SuspendLayout();
            主菜单.SuspendLayout();
            SuspendLayout();
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 300000;
            timer1.Tick += timer1_Tick;
            // 
            // statusStrip1
            // 
            statusStrip1.BackColor = Color.WhiteSmoke;
            statusStrip1.Dock = DockStyle.None;
            statusStrip1.ImageScalingSize = new Size(24, 24);
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel_MapName, UnxXuvxlhp, toolStripStatusLabel_自瞄状态, mqtt状态 });
            statusStrip1.Location = new Point(2, 478);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Padding = new Padding(1, 0, 16, 0);
            statusStrip1.Size = new Size(63, 22);
            statusStrip1.SizingGrip = false;
            statusStrip1.TabIndex = 2;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_MapName
            // 
            toolStripStatusLabel_MapName.ForeColor = Color.Green;
            toolStripStatusLabel_MapName.Name = "toolStripStatusLabel_MapName";
            toolStripStatusLabel_MapName.Size = new Size(44, 17);
            toolStripStatusLabel_MapName.Text = "未启动";
            // 
            // UnxXuvxlhp
            // 
            UnxXuvxlhp.Name = "UnxXuvxlhp";
            UnxXuvxlhp.Size = new Size(0, 17);
            // 
            // toolStripStatusLabel_自瞄状态
            // 
            toolStripStatusLabel_自瞄状态.Name = "toolStripStatusLabel_自瞄状态";
            toolStripStatusLabel_自瞄状态.Size = new Size(0, 17);
            // 
            // mqtt状态
            // 
            mqtt状态.Name = "mqtt状态";
            mqtt状态.Size = new Size(0, 17);
            // 
            // 玩家
            // 
            玩家.BackColor = Color.Transparent;
            玩家.Controls.Add(aloneButton1);
            玩家.Controls.Add(aloneButton2);
            玩家.Controls.Add(dungeonLabel16);
            玩家.Controls.Add(textBox_TeamAdd);
            玩家.Controls.Add(checkBox_单排);
            玩家.Controls.Add(radioButton_KDFPP);
            玩家.Controls.Add(radioButton_KDTPP);
            玩家.Font = new Font("Microsoft YaHei UI", 9F);
            玩家.Location = new Point(64, 4);
            玩家.Name = "玩家";
            玩家.Padding = new Padding(3);
            玩家.Size = new Size(516, 404);
            玩家.TabIndex = 2;
            玩家.Text = "玩家";
            // 
            // aloneButton1
            // 
            aloneButton1.EnabledCalc = true;
            aloneButton1.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            aloneButton1.ForeColor = Color.ForestGreen;
            aloneButton1.Location = new Point(20, 87);
            aloneButton1.Name = "aloneButton1";
            aloneButton1.Size = new Size(114, 64);
            aloneButton1.TabIndex = 142;
            aloneButton1.Text = "打开玩家列表";
            aloneButton1.Click += aloneButton1_Click;
            // 
            // aloneButton2
            // 
            aloneButton2.EnabledCalc = true;
            aloneButton2.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            aloneButton2.ForeColor = Color.ForestGreen;
            aloneButton2.Location = new Point(188, 48);
            aloneButton2.Name = "aloneButton2";
            aloneButton2.Size = new Size(85, 22);
            aloneButton2.TabIndex = 141;
            aloneButton2.Text = "添加白名单";
            aloneButton2.Click += aloneButton2_Click;
            // 
            // dungeonLabel16
            // 
            dungeonLabel16.AutoSize = true;
            dungeonLabel16.BackColor = Color.Transparent;
            dungeonLabel16.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel16.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel16.Location = new Point(20, 48);
            dungeonLabel16.Name = "dungeonLabel16";
            dungeonLabel16.Size = new Size(68, 19);
            dungeonLabel16.TabIndex = 128;
            dungeonLabel16.Text = "多排队伍:";
            // 
            // textBox_TeamAdd
            // 
            textBox_TeamAdd.Location = new Point(95, 47);
            textBox_TeamAdd.Margin = new Padding(4);
            textBox_TeamAdd.Name = "textBox_TeamAdd";
            textBox_TeamAdd.Size = new Size(86, 23);
            textBox_TeamAdd.TabIndex = 127;
            // 
            // checkBox_单排
            // 
            checkBox_单排.Checked = false;
            checkBox_单排.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_单排.Font = new Font("微软雅黑", 10.5F);
            checkBox_单排.Image = null;
            checkBox_单排.Location = new Point(133, 18);
            checkBox_单排.Name = "checkBox_单排";
            checkBox_单排.NoRounding = false;
            checkBox_单排.Size = new Size(66, 17);
            checkBox_单排.TabIndex = 126;
            checkBox_单排.Text = "单排";
            checkBox_单排.Transparent = false;
            checkBox_单排.CheckedChanged += checkBox_单排_CheckedChanged;
            // 
            // radioButton_KDFPP
            // 
            radioButton_KDFPP.BackColor = Color.Transparent;
            radioButton_KDFPP.Checked = false;
            radioButton_KDFPP.CheckedColorA = Color.FromArgb(27, 94, 137);
            radioButton_KDFPP.CheckedColorB = Color.FromArgb(150, 118, 177, 211);
            radioButton_KDFPP.EllipseBackColorA = Color.FromArgb(245, 245, 245);
            radioButton_KDFPP.EllipseBackColorB = Color.FromArgb(231, 231, 231);
            radioButton_KDFPP.EllipseBorderColorA = Color.FromArgb(168, 168, 168);
            radioButton_KDFPP.EllipseBorderColorB = Color.FromArgb(252, 252, 252);
            radioButton_KDFPP.Font = new Font("Verdana", 9F, FontStyle.Bold);
            radioButton_KDFPP.ForeColor = Color.FromArgb(27, 94, 137);
            radioButton_KDFPP.Location = new Point(79, 18);
            radioButton_KDFPP.Name = "radioButton_KDFPP";
            radioButton_KDFPP.Size = new Size(55, 14);
            radioButton_KDFPP.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            radioButton_KDFPP.TabIndex = 17;
            radioButton_KDFPP.Text = "FPP";
            radioButton_KDFPP.CheckedChanged += radioButton_KDFPP_CheckedChanged;
            // 
            // radioButton_KDTPP
            // 
            radioButton_KDTPP.BackColor = Color.Transparent;
            radioButton_KDTPP.Checked = false;
            radioButton_KDTPP.CheckedColorA = Color.FromArgb(27, 94, 137);
            radioButton_KDTPP.CheckedColorB = Color.FromArgb(150, 118, 177, 211);
            radioButton_KDTPP.EllipseBackColorA = Color.FromArgb(245, 245, 245);
            radioButton_KDTPP.EllipseBackColorB = Color.FromArgb(231, 231, 231);
            radioButton_KDTPP.EllipseBorderColorA = Color.FromArgb(168, 168, 168);
            radioButton_KDTPP.EllipseBorderColorB = Color.FromArgb(252, 252, 252);
            radioButton_KDTPP.Font = new Font("Verdana", 9F, FontStyle.Bold);
            radioButton_KDTPP.ForeColor = Color.FromArgb(27, 94, 137);
            radioButton_KDTPP.Location = new Point(20, 18);
            radioButton_KDTPP.Name = "radioButton_KDTPP";
            radioButton_KDTPP.Size = new Size(53, 14);
            radioButton_KDTPP.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            radioButton_KDTPP.TabIndex = 16;
            radioButton_KDTPP.Text = "TPP";
            radioButton_KDTPP.CheckedChanged += radioButton_KDTPP_CheckedChanged;
            // 
            // 物资
            // 
            物资.BackColor = Color.Transparent;
            物资.Controls.Add(poisonDataGridView3);
            物资.Location = new Point(64, 4);
            物资.Name = "物资";
            物资.Size = new Size(516, 404);
            物资.TabIndex = 3;
            物资.Text = "物资";
            // 
            // poisonDataGridView3
            // 
            poisonDataGridView3.AllowUserToAddRows = false;
            poisonDataGridView3.AllowUserToDeleteRows = false;
            poisonDataGridView3.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            poisonDataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            poisonDataGridView3.BackgroundColor = Color.White;
            poisonDataGridView3.BorderStyle = BorderStyle.None;
            poisonDataGridView3.CellBorderStyle = DataGridViewCellBorderStyle.None;
            poisonDataGridView3.ClipboardCopyMode = DataGridViewClipboardCopyMode.Disable;
            poisonDataGridView3.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.White;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.Green;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            poisonDataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            poisonDataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            poisonDataGridView3.Columns.AddRange(new DataGridViewColumn[] { 物资名称, 分组, 显示 });
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.BottomLeft;
            dataGridViewCellStyle4.BackColor = Color.White;
            dataGridViewCellStyle4.Font = new Font("Tahoma", 9.75F);
            dataGridViewCellStyle4.ForeColor = Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = Color.Green;
            dataGridViewCellStyle4.SelectionForeColor = Color.White;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            poisonDataGridView3.DefaultCellStyle = dataGridViewCellStyle4;
            poisonDataGridView3.Dock = DockStyle.Fill;
            poisonDataGridView3.EnableHeadersVisualStyles = false;
            poisonDataGridView3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            poisonDataGridView3.GridColor = Color.FromArgb(192, 255, 192);
            poisonDataGridView3.Location = new Point(0, 0);
            poisonDataGridView3.MaximumSize = new Size(5000, 440);
            poisonDataGridView3.MinimumSize = new Size(343, 410);
            poisonDataGridView3.MultiSelect = false;
            poisonDataGridView3.Name = "poisonDataGridView3";
            poisonDataGridView3.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.BottomLeft;
            dataGridViewCellStyle5.BackColor = Color.White;
            dataGridViewCellStyle5.Font = new Font("Tahoma", 9.75F);
            dataGridViewCellStyle5.ForeColor = Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = Color.Green;
            dataGridViewCellStyle5.SelectionForeColor = Color.White;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            poisonDataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            poisonDataGridView3.RowHeadersVisible = false;
            poisonDataGridView3.RowHeadersWidth = 50;
            poisonDataGridView3.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.ForeColor = Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = Color.Green;
            dataGridViewCellStyle6.SelectionForeColor = Color.White;
            poisonDataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle6;
            poisonDataGridView3.RowTemplate.Height = 25;
            poisonDataGridView3.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            poisonDataGridView3.Size = new Size(516, 410);
            poisonDataGridView3.TabIndex = 4;
            poisonDataGridView3.CellContentClick += poisonDataGridView物资开关_CellContentClick;
            // 
            // 物资名称
            // 
            物资名称.DataPropertyName = "物资名称";
            dataGridViewCellStyle3.BackColor = Color.White;
            物资名称.DefaultCellStyle = dataGridViewCellStyle3;
            物资名称.FillWeight = 200F;
            物资名称.HeaderText = "物资名称";
            物资名称.MinimumWidth = 8;
            物资名称.Name = "物资名称";
            物资名称.Width = 300;
            // 
            // 分组
            // 
            分组.DataPropertyName = "分组";
            分组.FillWeight = 60F;
            分组.HeaderText = "分组";
            分组.Items.AddRange(new object[] { "A", "B", "C", "D" });
            分组.MinimumWidth = 8;
            分组.Name = "分组";
            分组.SortMode = DataGridViewColumnSortMode.Automatic;
            分组.Width = 80;
            // 
            // 显示
            // 
            显示.DataPropertyName = "显示";
            显示.FillWeight = 80F;
            显示.HeaderText = "显示";
            显示.MinimumWidth = 8;
            显示.Name = "显示";
            显示.Resizable = DataGridViewTriState.False;
            显示.SortMode = DataGridViewColumnSortMode.Automatic;
            显示.Text = "显示";
            显示.Width = 90;
            // 
            // 自瞄
            // 
            自瞄.BackColor = Color.Transparent;
            自瞄.Controls.Add(groupBox3);
            自瞄.Controls.Add(groupBox1);
            自瞄.Location = new Point(64, 4);
            自瞄.Name = "自瞄";
            自瞄.Padding = new Padding(3);
            自瞄.Size = new Size(516, 404);
            自瞄.TabIndex = 1;
            自瞄.Text = "自瞄";
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.Transparent;
            groupBox3.BackGColor = Color.WhiteSmoke;
            groupBox3.BaseColor = Color.Transparent;
            groupBox3.BorderColorG = Color.FromArgb(0, 64, 0);
            groupBox3.BorderColorH = Color.FromArgb(182, 180, 186);
            groupBox3.Controls.Add(checkBox开镜自瞄);
            groupBox3.Controls.Add(自瞄延时);
            groupBox3.Controls.Add(numericUpDown_Recoil);
            groupBox3.Controls.Add(numericUpDown_AimRange);
            groupBox3.Controls.Add(numericUpDown_AimDistince);
            groupBox3.Controls.Add(numericUpDown_AimDelay);
            groupBox3.Controls.Add(numericUpDown_AimSmooth);
            groupBox3.Controls.Add(numericUpDown_AimY);
            groupBox3.Controls.Add(numericUpDown_AimX);
            groupBox3.Controls.Add(checkBox跳过击杀);
            groupBox3.Controls.Add(checkBox动态FOV);
            groupBox3.Controls.Add(comboBox_热键_自瞄配置2);
            groupBox3.Controls.Add(dungeonLabel14);
            groupBox3.Controls.Add(aloneButton6);
            groupBox3.Controls.Add(radioButton_AimUseDistince);
            groupBox3.Controls.Add(radioButton_AimUseRange);
            groupBox3.Controls.Add(crownLabel14);
            groupBox3.Controls.Add(crownLabel13);
            groupBox3.Controls.Add(comboBox_AimKey2);
            groupBox3.Controls.Add(comboBox_AimLock);
            groupBox3.Controls.Add(crownLabel6);
            groupBox3.Controls.Add(comboBox_AimAt);
            groupBox3.Controls.Add(crownLabel12);
            groupBox3.Controls.Add(comboBox_LockGrobbyKey);
            groupBox3.Controls.Add(crownLabel11);
            groupBox3.Controls.Add(comboBox_LockKey);
            groupBox3.Controls.Add(comboBox_AimKey1);
            groupBox3.Controls.Add(crownLabel5);
            groupBox3.Controls.Add(crownLabel4);
            groupBox3.Controls.Add(crownLabel9);
            groupBox3.Controls.Add(crownLabel10);
            groupBox3.Controls.Add(crownLabel3);
            groupBox3.Controls.Add(crownLabel7);
            groupBox3.Controls.Add(crownLabel2);
            groupBox3.Controls.Add(crownLabel8);
            groupBox3.Controls.Add(crownLabel1);
            groupBox3.Controls.Add(枪类型);
            groupBox3.Font = new Font("Tahoma", 9F);
            groupBox3.ForeColor = Color.Black;
            groupBox3.HeaderColor = Color.DarkGray;
            groupBox3.Location = new Point(6, 97);
            groupBox3.MinimumSize = new Size(136, 50);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(5, 28, 5, 5);
            groupBox3.Size = new Size(504, 301);
            groupBox3.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            groupBox3.TabIndex = 15;
            groupBox3.Text = "参数配置";
            // 
            // checkBox开镜自瞄
            // 
            checkBox开镜自瞄.Checked = false;
            checkBox开镜自瞄.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox开镜自瞄.Font = new Font("微软雅黑", 10.5F);
            checkBox开镜自瞄.Image = null;
            checkBox开镜自瞄.Location = new Point(308, 221);
            checkBox开镜自瞄.Name = "checkBox开镜自瞄";
            checkBox开镜自瞄.NoRounding = false;
            checkBox开镜自瞄.Size = new Size(83, 17);
            checkBox开镜自瞄.TabIndex = 302;
            checkBox开镜自瞄.Text = "开镜自瞄";
            checkBox开镜自瞄.Transparent = false;
            checkBox开镜自瞄.CheckedChanged += checkBox开镜自瞄_CheckedChanged;
            // 
            // 自瞄延时
            // 
            自瞄延时.Increment = new decimal(new int[] { 100, 0, 0, 0 });
            自瞄延时.Location = new Point(218, 260);
            自瞄延时.Margin = new Padding(5, 6, 5, 6);
            自瞄延时.Maximum = new decimal(new int[] { 3000, 0, 0, 0 });
            自瞄延时.Name = "自瞄延时";
            自瞄延时.Size = new Size(58, 22);
            自瞄延时.TabIndex = 301;
            自瞄延时.Value = new decimal(new int[] { 100, 0, 0, 0 });
            // 
            // numericUpDown_Recoil
            // 
            numericUpDown_Recoil.Location = new Point(218, 226);
            numericUpDown_Recoil.Margin = new Padding(5, 6, 5, 6);
            numericUpDown_Recoil.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            numericUpDown_Recoil.Name = "numericUpDown_Recoil";
            numericUpDown_Recoil.Size = new Size(58, 22);
            numericUpDown_Recoil.TabIndex = 300;
            // 
            // numericUpDown_AimRange
            // 
            numericUpDown_AimRange.Increment = new decimal(new int[] { 5, 0, 0, 0 });
            numericUpDown_AimRange.Location = new Point(218, 192);
            numericUpDown_AimRange.Margin = new Padding(5, 6, 5, 6);
            numericUpDown_AimRange.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numericUpDown_AimRange.Minimum = new decimal(new int[] { 5, 0, 0, 0 });
            numericUpDown_AimRange.Name = "numericUpDown_AimRange";
            numericUpDown_AimRange.Size = new Size(58, 22);
            numericUpDown_AimRange.TabIndex = 299;
            numericUpDown_AimRange.Value = new decimal(new int[] { 60, 0, 0, 0 });
            // 
            // numericUpDown_AimDistince
            // 
            numericUpDown_AimDistince.Increment = new decimal(new int[] { 50, 0, 0, 0 });
            numericUpDown_AimDistince.Location = new Point(218, 159);
            numericUpDown_AimDistince.Margin = new Padding(5, 6, 5, 6);
            numericUpDown_AimDistince.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numericUpDown_AimDistince.Minimum = new decimal(new int[] { 50, 0, 0, 0 });
            numericUpDown_AimDistince.Name = "numericUpDown_AimDistince";
            numericUpDown_AimDistince.Size = new Size(58, 22);
            numericUpDown_AimDistince.TabIndex = 298;
            numericUpDown_AimDistince.Value = new decimal(new int[] { 600, 0, 0, 0 });
            // 
            // numericUpDown_AimDelay
            // 
            numericUpDown_AimDelay.Location = new Point(90, 260);
            numericUpDown_AimDelay.Margin = new Padding(5, 6, 5, 6);
            numericUpDown_AimDelay.Maximum = new decimal(new int[] { 30, 0, 0, 0 });
            numericUpDown_AimDelay.Minimum = new decimal(new int[] { 4, 0, 0, 0 });
            numericUpDown_AimDelay.Name = "numericUpDown_AimDelay";
            numericUpDown_AimDelay.Size = new Size(59, 22);
            numericUpDown_AimDelay.TabIndex = 297;
            numericUpDown_AimDelay.Value = new decimal(new int[] { 25, 0, 0, 0 });
            // 
            // numericUpDown_AimSmooth
            // 
            numericUpDown_AimSmooth.Location = new Point(90, 226);
            numericUpDown_AimSmooth.Margin = new Padding(5, 6, 5, 6);
            numericUpDown_AimSmooth.Maximum = new decimal(new int[] { 5, 0, 0, 0 });
            numericUpDown_AimSmooth.Name = "numericUpDown_AimSmooth";
            numericUpDown_AimSmooth.Size = new Size(59, 22);
            numericUpDown_AimSmooth.TabIndex = 296;
            numericUpDown_AimSmooth.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // numericUpDown_AimY
            // 
            numericUpDown_AimY.Location = new Point(90, 192);
            numericUpDown_AimY.Margin = new Padding(5, 6, 5, 6);
            numericUpDown_AimY.Maximum = new decimal(new int[] { 120, 0, 0, 0 });
            numericUpDown_AimY.Name = "numericUpDown_AimY";
            numericUpDown_AimY.Size = new Size(59, 22);
            numericUpDown_AimY.TabIndex = 295;
            numericUpDown_AimY.Value = new decimal(new int[] { 100, 0, 0, 0 });
            // 
            // numericUpDown_AimX
            // 
            numericUpDown_AimX.Location = new Point(90, 159);
            numericUpDown_AimX.Margin = new Padding(5, 6, 5, 6);
            numericUpDown_AimX.Maximum = new decimal(new int[] { 120, 0, 0, 0 });
            numericUpDown_AimX.Name = "numericUpDown_AimX";
            numericUpDown_AimX.Size = new Size(59, 22);
            numericUpDown_AimX.TabIndex = 294;
            numericUpDown_AimX.Value = new decimal(new int[] { 100, 0, 0, 0 });
            // 
            // checkBox跳过击杀
            // 
            checkBox跳过击杀.Checked = false;
            checkBox跳过击杀.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox跳过击杀.Font = new Font("微软雅黑", 10.5F);
            checkBox跳过击杀.Image = null;
            checkBox跳过击杀.Location = new Point(308, 192);
            checkBox跳过击杀.Name = "checkBox跳过击杀";
            checkBox跳过击杀.NoRounding = false;
            checkBox跳过击杀.Size = new Size(83, 17);
            checkBox跳过击杀.TabIndex = 287;
            checkBox跳过击杀.Text = "击杀切换";
            checkBox跳过击杀.Transparent = false;
            checkBox跳过击杀.CheckedChanged += checkBox跳过击杀_CheckedChanged;
            // 
            // checkBox动态FOV
            // 
            checkBox动态FOV.Checked = false;
            checkBox动态FOV.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox动态FOV.Font = new Font("微软雅黑", 10.5F);
            checkBox动态FOV.Image = null;
            checkBox动态FOV.Location = new Point(308, 164);
            checkBox动态FOV.Name = "checkBox动态FOV";
            checkBox动态FOV.NoRounding = false;
            checkBox动态FOV.Size = new Size(83, 17);
            checkBox动态FOV.TabIndex = 288;
            checkBox动态FOV.Text = "动态范围";
            checkBox动态FOV.Transparent = false;
            checkBox动态FOV.CheckedChanged += checkBox动态FOV_CheckedChanged;
            // 
            // comboBox_热键_自瞄配置2
            // 
            comboBox_热键_自瞄配置2.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_自瞄配置2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_自瞄配置2.EnabledCalc = true;
            comboBox_热键_自瞄配置2.FormattingEnabled = true;
            comboBox_热键_自瞄配置2.ItemHeight = 20;
            comboBox_热键_自瞄配置2.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_自瞄配置2.Location = new Point(406, 33);
            comboBox_热键_自瞄配置2.Name = "comboBox_热键_自瞄配置2";
            comboBox_热键_自瞄配置2.Size = new Size(83, 26);
            comboBox_热键_自瞄配置2.TabIndex = 293;
            comboBox_热键_自瞄配置2.SelectedIndexChanged += comboBox_热键_自瞄配置2_SelectedIndexChanged;
            // 
            // dungeonLabel14
            // 
            dungeonLabel14.AutoSize = true;
            dungeonLabel14.BackColor = Color.Transparent;
            dungeonLabel14.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel14.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel14.Location = new Point(325, 35);
            dungeonLabel14.Name = "dungeonLabel14";
            dungeonLabel14.Size = new Size(76, 19);
            dungeonLabel14.TabIndex = 292;
            dungeonLabel14.Text = "第2套参数:";
            // 
            // aloneButton6
            // 
            aloneButton6.EnabledCalc = true;
            aloneButton6.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            aloneButton6.ForeColor = Color.ForestGreen;
            aloneButton6.Location = new Point(308, 252);
            aloneButton6.Name = "aloneButton6";
            aloneButton6.Size = new Size(165, 41);
            aloneButton6.TabIndex = 291;
            aloneButton6.Text = "保存参数";
            aloneButton6.Click += aloneButton6_Click;
            // 
            // radioButton_AimUseDistince
            // 
            radioButton_AimUseDistince.Checked = false;
            radioButton_AimUseDistince.Customization = "PDw8/+3t7f/m5ub/p6en/2RkZP8=";
            radioButton_AimUseDistince.Field = 16;
            radioButton_AimUseDistince.Font = new Font("Segoe UI", 9F);
            radioButton_AimUseDistince.Image = null;
            radioButton_AimUseDistince.Location = new Point(399, 192);
            radioButton_AimUseDistince.Name = "radioButton_AimUseDistince";
            radioButton_AimUseDistince.NoRounding = false;
            radioButton_AimUseDistince.Size = new Size(81, 16);
            radioButton_AimUseDistince.TabIndex = 290;
            radioButton_AimUseDistince.Text = "优先距离";
            radioButton_AimUseDistince.Transparent = false;
            // 
            // radioButton_AimUseRange
            // 
            radioButton_AimUseRange.Checked = false;
            radioButton_AimUseRange.Customization = "PDw8/+3t7f/m5ub/p6en/2RkZP8=";
            radioButton_AimUseRange.Field = 16;
            radioButton_AimUseRange.Font = new Font("Segoe UI", 9F);
            radioButton_AimUseRange.Image = null;
            radioButton_AimUseRange.Location = new Point(399, 165);
            radioButton_AimUseRange.Name = "radioButton_AimUseRange";
            radioButton_AimUseRange.NoRounding = false;
            radioButton_AimUseRange.Size = new Size(81, 16);
            radioButton_AimUseRange.TabIndex = 289;
            radioButton_AimUseRange.Text = "优先范围";
            radioButton_AimUseRange.Transparent = false;
            // 
            // crownLabel14
            // 
            crownLabel14.AutoSize = true;
            crownLabel14.Font = new Font("Tahoma", 9F);
            crownLabel14.ForeColor = Color.Black;
            crownLabel14.Location = new Point(169, 262);
            crownLabel14.Name = "crownLabel14";
            crownLabel14.Size = new Size(31, 14);
            crownLabel14.TabIndex = 285;
            crownLabel14.Text = "延时";
            crownLabel14.TextAlign = ContentAlignment.TopCenter;
            // 
            // crownLabel13
            // 
            crownLabel13.AutoSize = true;
            crownLabel13.Font = new Font("Tahoma", 9F);
            crownLabel13.ForeColor = Color.Black;
            crownLabel13.Location = new Point(169, 228);
            crownLabel13.Name = "crownLabel13";
            crownLabel13.Size = new Size(31, 14);
            crownLabel13.TabIndex = 283;
            crownLabel13.Text = "修正";
            // 
            // comboBox_AimKey2
            // 
            comboBox_AimKey2.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_AimKey2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_AimKey2.EnabledCalc = true;
            comboBox_AimKey2.FormattingEnabled = true;
            comboBox_AimKey2.ItemHeight = 20;
            comboBox_AimKey2.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_AimKey2.Location = new Point(239, 78);
            comboBox_AimKey2.Name = "comboBox_AimKey2";
            comboBox_AimKey2.Size = new Size(91, 26);
            comboBox_AimKey2.TabIndex = 268;
            // 
            // comboBox_AimLock
            // 
            comboBox_AimLock.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_AimLock.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_AimLock.EnabledCalc = true;
            comboBox_AimLock.FormattingEnabled = true;
            comboBox_AimLock.ItemHeight = 20;
            comboBox_AimLock.Items.AddRange(new object[] { "头部", "颈部", "胸口", "无", "" });
            comboBox_AimLock.Location = new Point(388, 113);
            comboBox_AimLock.Name = "comboBox_AimLock";
            comboBox_AimLock.Size = new Size(68, 26);
            comboBox_AimLock.TabIndex = 267;
            // 
            // crownLabel6
            // 
            crownLabel6.AutoSize = true;
            crownLabel6.Font = new Font("Tahoma", 9F);
            crownLabel6.ForeColor = Color.FromArgb(192, 64, 0);
            crownLabel6.Location = new Point(339, 116);
            crownLabel6.Name = "crownLabel6";
            crownLabel6.Size = new Size(43, 14);
            crownLabel6.TabIndex = 266;
            crownLabel6.Text = "子骨骼";
            // 
            // comboBox_AimAt
            // 
            comboBox_AimAt.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_AimAt.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_AimAt.EnabledCalc = true;
            comboBox_AimAt.FormattingEnabled = true;
            comboBox_AimAt.ItemHeight = 20;
            comboBox_AimAt.Items.AddRange(new object[] { "头部", "颈部", "胸口", "无", "随机" });
            comboBox_AimAt.Location = new Point(388, 77);
            comboBox_AimAt.Name = "comboBox_AimAt";
            comboBox_AimAt.Size = new Size(68, 26);
            comboBox_AimAt.TabIndex = 265;
            // 
            // crownLabel12
            // 
            crownLabel12.AutoSize = true;
            crownLabel12.Font = new Font("Tahoma", 9F);
            crownLabel12.ForeColor = Color.Black;
            crownLabel12.Location = new Point(169, 194);
            crownLabel12.Name = "crownLabel12";
            crownLabel12.Size = new Size(31, 14);
            crownLabel12.TabIndex = 273;
            crownLabel12.Text = "范围";
            // 
            // comboBox_LockGrobbyKey
            // 
            comboBox_LockGrobbyKey.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_LockGrobbyKey.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_LockGrobbyKey.EnabledCalc = true;
            comboBox_LockGrobbyKey.FormattingEnabled = true;
            comboBox_LockGrobbyKey.ItemHeight = 20;
            comboBox_LockGrobbyKey.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_LockGrobbyKey.Location = new Point(86, 110);
            comboBox_LockGrobbyKey.Name = "comboBox_LockGrobbyKey";
            comboBox_LockGrobbyKey.Size = new Size(91, 26);
            comboBox_LockGrobbyKey.TabIndex = 263;
            // 
            // crownLabel11
            // 
            crownLabel11.AutoSize = true;
            crownLabel11.Font = new Font("Tahoma", 9F);
            crownLabel11.ForeColor = Color.Black;
            crownLabel11.Location = new Point(169, 161);
            crownLabel11.Name = "crownLabel11";
            crownLabel11.Size = new Size(31, 14);
            crownLabel11.TabIndex = 272;
            crownLabel11.Text = "距离";
            // 
            // comboBox_LockKey
            // 
            comboBox_LockKey.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_LockKey.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_LockKey.EnabledCalc = true;
            comboBox_LockKey.FormattingEnabled = true;
            comboBox_LockKey.ItemHeight = 20;
            comboBox_LockKey.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_LockKey.Location = new Point(240, 112);
            comboBox_LockKey.Name = "comboBox_LockKey";
            comboBox_LockKey.Size = new Size(91, 26);
            comboBox_LockKey.TabIndex = 262;
            // 
            // comboBox_AimKey1
            // 
            comboBox_AimKey1.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_AimKey1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_AimKey1.EnabledCalc = true;
            comboBox_AimKey1.FormattingEnabled = true;
            comboBox_AimKey1.ItemHeight = 20;
            comboBox_AimKey1.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_AimKey1.Location = new Point(86, 78);
            comboBox_AimKey1.Name = "comboBox_AimKey1";
            comboBox_AimKey1.Size = new Size(91, 26);
            comboBox_AimKey1.TabIndex = 261;
            // 
            // crownLabel5
            // 
            crownLabel5.AutoSize = true;
            crownLabel5.Font = new Font("Tahoma", 9F);
            crownLabel5.ForeColor = Color.Green;
            crownLabel5.Location = new Point(339, 82);
            crownLabel5.Name = "crownLabel5";
            crownLabel5.Size = new Size(43, 14);
            crownLabel5.TabIndex = 260;
            crownLabel5.Text = "父骨骼";
            // 
            // crownLabel4
            // 
            crownLabel4.AutoSize = true;
            crownLabel4.Font = new Font("Tahoma", 9F);
            crownLabel4.ForeColor = Color.LightSeaGreen;
            crownLabel4.Location = new Point(29, 115);
            crownLabel4.Name = "crownLabel4";
            crownLabel4.Size = new Size(55, 14);
            crownLabel4.TabIndex = 259;
            crownLabel4.Text = "自瞄倒地";
            // 
            // crownLabel9
            // 
            crownLabel9.AutoSize = true;
            crownLabel9.Font = new Font("Tahoma", 9F);
            crownLabel9.ForeColor = Color.Black;
            crownLabel9.Location = new Point(36, 228);
            crownLabel9.Name = "crownLabel9";
            crownLabel9.Size = new Size(31, 14);
            crownLabel9.TabIndex = 270;
            crownLabel9.Text = "平滑";
            // 
            // crownLabel10
            // 
            crownLabel10.AutoSize = true;
            crownLabel10.Font = new Font("Tahoma", 9F);
            crownLabel10.ForeColor = Color.Black;
            crownLabel10.Location = new Point(36, 262);
            crownLabel10.Name = "crownLabel10";
            crownLabel10.Size = new Size(31, 14);
            crownLabel10.TabIndex = 271;
            crownLabel10.Text = "响应";
            // 
            // crownLabel3
            // 
            crownLabel3.AutoSize = true;
            crownLabel3.Font = new Font("Tahoma", 9F);
            crownLabel3.ForeColor = Color.FromArgb(192, 64, 0);
            crownLabel3.Location = new Point(183, 115);
            crownLabel3.Name = "crownLabel3";
            crownLabel3.Size = new Size(51, 14);
            crownLabel3.TabIndex = 258;
            crownLabel3.Text = "子按键A";
            // 
            // crownLabel7
            // 
            crownLabel7.AutoSize = true;
            crownLabel7.Font = new Font("Tahoma", 9F);
            crownLabel7.ForeColor = Color.Black;
            crownLabel7.Location = new Point(45, 161);
            crownLabel7.Name = "crownLabel7";
            crownLabel7.Size = new Size(14, 14);
            crownLabel7.TabIndex = 268;
            crownLabel7.Text = "X";
            // 
            // crownLabel2
            // 
            crownLabel2.AutoSize = true;
            crownLabel2.Font = new Font("Tahoma", 9F);
            crownLabel2.ForeColor = Color.Green;
            crownLabel2.Location = new Point(183, 81);
            crownLabel2.Name = "crownLabel2";
            crownLabel2.Size = new Size(50, 14);
            crownLabel2.TabIndex = 257;
            crownLabel2.Text = "父按键B";
            // 
            // crownLabel8
            // 
            crownLabel8.AutoSize = true;
            crownLabel8.Font = new Font("Tahoma", 9F);
            crownLabel8.ForeColor = Color.Black;
            crownLabel8.Location = new Point(44, 194);
            crownLabel8.Name = "crownLabel8";
            crownLabel8.Size = new Size(15, 14);
            crownLabel8.TabIndex = 269;
            crownLabel8.Text = "Y";
            // 
            // crownLabel1
            // 
            crownLabel1.AutoSize = true;
            crownLabel1.Font = new Font("Tahoma", 9F);
            crownLabel1.ForeColor = Color.Green;
            crownLabel1.Location = new Point(29, 81);
            crownLabel1.Name = "crownLabel1";
            crownLabel1.Size = new Size(51, 14);
            crownLabel1.TabIndex = 256;
            crownLabel1.Text = "父按键A";
            // 
            // 枪类型
            // 
            枪类型.Controls.Add(tabPage7);
            枪类型.Controls.Add(tabPage8);
            枪类型.Controls.Add(tabPage9);
            枪类型.Controls.Add(tabPage10);
            枪类型.Controls.Add(tabPage11);
            枪类型.Font = new Font("Tahoma", 12F);
            枪类型.Location = new Point(31, 32);
            枪类型.Margin = new Padding(4);
            枪类型.Name = "枪类型";
            枪类型.SelectedIndex = 0;
            枪类型.Size = new Size(286, 22);
            枪类型.TabIndex = 255;
            枪类型.SelectedIndexChanged += 主菜单_SelectedIndexChanged;
            // 
            // tabPage7
            // 
            tabPage7.Location = new Point(4, 28);
            tabPage7.Margin = new Padding(4);
            tabPage7.Name = "tabPage7";
            tabPage7.Size = new Size(278, 0);
            tabPage7.TabIndex = 0;
            tabPage7.Text = "步枪";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabPage8
            // 
            tabPage8.Location = new Point(4, 28);
            tabPage8.Margin = new Padding(4);
            tabPage8.Name = "tabPage8";
            tabPage8.Size = new Size(278, 0);
            tabPage8.TabIndex = 1;
            tabPage8.Text = "连狙";
            tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            tabPage9.Location = new Point(4, 28);
            tabPage9.Margin = new Padding(4);
            tabPage9.Name = "tabPage9";
            tabPage9.Size = new Size(278, 0);
            tabPage9.TabIndex = 2;
            tabPage9.Text = "栓狙";
            tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabPage10
            // 
            tabPage10.Location = new Point(4, 28);
            tabPage10.Margin = new Padding(4);
            tabPage10.Name = "tabPage10";
            tabPage10.Size = new Size(278, 0);
            tabPage10.TabIndex = 3;
            tabPage10.Text = "散弹";
            tabPage10.UseVisualStyleBackColor = true;
            // 
            // tabPage11
            // 
            tabPage11.Location = new Point(4, 28);
            tabPage11.Margin = new Padding(4);
            tabPage11.Name = "tabPage11";
            tabPage11.Size = new Size(278, 0);
            tabPage11.TabIndex = 4;
            tabPage11.Text = "其它";
            tabPage11.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.BackGColor = Color.WhiteSmoke;
            groupBox1.BaseColor = Color.Transparent;
            groupBox1.BorderColorG = Color.FromArgb(0, 64, 0);
            groupBox1.BorderColorH = Color.FromArgb(182, 180, 186);
            groupBox1.Controls.Add(aloneButton3);
            groupBox1.Controls.Add(MVPNETTXT);
            groupBox1.Controls.Add(comboBox_COM);
            groupBox1.Controls.Add(关闭自瞄);
            groupBox1.Controls.Add(radioButton_易键鼠);
            groupBox1.Controls.Add(radioButton_CtrlBlack);
            groupBox1.Controls.Add(radioButton_魔盒);
            groupBox1.Controls.Add(radioButton_MVPNET);
            groupBox1.Controls.Add(radioButton_CtrlKmbox);
            groupBox1.Font = new Font("Tahoma", 9F);
            groupBox1.ForeColor = Color.BlanchedAlmond;
            groupBox1.HeaderColor = Color.Green;
            groupBox1.Location = new Point(6, 6);
            groupBox1.MinimumSize = new Size(136, 50);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(5, 28, 5, 5);
            groupBox1.Size = new Size(504, 85);
            groupBox1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            groupBox1.TabIndex = 14;
            groupBox1.Text = "控制器";
            // 
            // aloneButton3
            // 
            aloneButton3.EnabledCalc = true;
            aloneButton3.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            aloneButton3.ForeColor = Color.ForestGreen;
            aloneButton3.Location = new Point(387, 51);
            aloneButton3.Name = "aloneButton3";
            aloneButton3.Size = new Size(69, 25);
            aloneButton3.TabIndex = 125;
            aloneButton3.Text = "连接";
            aloneButton3.Click += 连接控制器;
            // 
            // MVPNETTXT
            // 
            MVPNETTXT.BackColor = Color.Transparent;
            MVPNETTXT.BorderColor = Color.FromArgb(180, 180, 180);
            MVPNETTXT.EdgeColor = Color.White;
            MVPNETTXT.Font = new Font("Tahoma", 11F);
            MVPNETTXT.ForeColor = Color.DimGray;
            MVPNETTXT.Location = new Point(33, 50);
            MVPNETTXT.MaxLength = 32767;
            MVPNETTXT.Multiline = false;
            MVPNETTXT.Name = "MVPNETTXT";
            MVPNETTXT.ReadOnly = false;
            MVPNETTXT.Size = new Size(169, 28);
            MVPNETTXT.TabIndex = 15;
            MVPNETTXT.TextAlignment = HorizontalAlignment.Left;
            MVPNETTXT.UseSystemPasswordChar = false;
            // 
            // comboBox_COM
            // 
            comboBox_COM.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_COM.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_COM.EnabledCalc = true;
            comboBox_COM.FormattingEnabled = true;
            comboBox_COM.ItemHeight = 20;
            comboBox_COM.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_COM.Location = new Point(287, 50);
            comboBox_COM.Name = "comboBox_COM";
            comboBox_COM.Size = new Size(84, 26);
            comboBox_COM.TabIndex = 22;
            // 
            // 关闭自瞄
            // 
            关闭自瞄.BackColor = Color.Transparent;
            关闭自瞄.Checked = false;
            关闭自瞄.CheckedColorA = Color.FromArgb(27, 94, 137);
            关闭自瞄.CheckedColorB = Color.FromArgb(150, 118, 177, 211);
            关闭自瞄.EllipseBackColorA = Color.FromArgb(245, 245, 245);
            关闭自瞄.EllipseBackColorB = Color.FromArgb(231, 231, 231);
            关闭自瞄.EllipseBorderColorA = Color.FromArgb(168, 168, 168);
            关闭自瞄.EllipseBorderColorB = Color.FromArgb(252, 252, 252);
            关闭自瞄.Font = new Font("Verdana", 9F, FontStyle.Bold);
            关闭自瞄.ForeColor = Color.FromArgb(27, 94, 137);
            关闭自瞄.Location = new Point(212, 56);
            关闭自瞄.Name = "关闭自瞄";
            关闭自瞄.Size = new Size(84, 14);
            关闭自瞄.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            关闭自瞄.TabIndex = 19;
            关闭自瞄.Text = "关闭";
            关闭自瞄.CheckedChanged += radioButton关闭自瞄_CheckedChanged;
            // 
            // radioButton_易键鼠
            // 
            radioButton_易键鼠.BackColor = Color.Transparent;
            radioButton_易键鼠.Checked = false;
            radioButton_易键鼠.CheckedColorA = Color.FromArgb(27, 94, 137);
            radioButton_易键鼠.CheckedColorB = Color.FromArgb(150, 118, 177, 211);
            radioButton_易键鼠.EllipseBackColorA = Color.FromArgb(245, 245, 245);
            radioButton_易键鼠.EllipseBackColorB = Color.FromArgb(231, 231, 231);
            radioButton_易键鼠.EllipseBorderColorA = Color.FromArgb(168, 168, 168);
            radioButton_易键鼠.EllipseBorderColorB = Color.FromArgb(252, 252, 252);
            radioButton_易键鼠.Font = new Font("Verdana", 9F, FontStyle.Bold);
            radioButton_易键鼠.ForeColor = Color.FromArgb(27, 94, 137);
            radioButton_易键鼠.Location = new Point(387, 27);
            radioButton_易键鼠.Name = "radioButton_易键鼠";
            radioButton_易键鼠.Size = new Size(84, 14);
            radioButton_易键鼠.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            radioButton_易键鼠.TabIndex = 17;
            radioButton_易键鼠.Text = "飞易来";
            radioButton_易键鼠.CheckedChanged += 易键鼠_CheckedChanged;
            // 
            // radioButton_CtrlBlack
            // 
            radioButton_CtrlBlack.BackColor = Color.Transparent;
            radioButton_CtrlBlack.Checked = false;
            radioButton_CtrlBlack.CheckedColorA = Color.FromArgb(27, 94, 137);
            radioButton_CtrlBlack.CheckedColorB = Color.FromArgb(150, 118, 177, 211);
            radioButton_CtrlBlack.EllipseBackColorA = Color.FromArgb(245, 245, 245);
            radioButton_CtrlBlack.EllipseBackColorB = Color.FromArgb(231, 231, 231);
            radioButton_CtrlBlack.EllipseBorderColorA = Color.FromArgb(168, 168, 168);
            radioButton_CtrlBlack.EllipseBorderColorB = Color.FromArgb(252, 252, 252);
            radioButton_CtrlBlack.Font = new Font("Verdana", 9F, FontStyle.Bold);
            radioButton_CtrlBlack.ForeColor = Color.FromArgb(27, 94, 137);
            radioButton_CtrlBlack.Location = new Point(287, 27);
            radioButton_CtrlBlack.Name = "radioButton_CtrlBlack";
            radioButton_CtrlBlack.Size = new Size(84, 14);
            radioButton_CtrlBlack.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            radioButton_CtrlBlack.TabIndex = 18;
            radioButton_CtrlBlack.Text = "黑色双头";
            radioButton_CtrlBlack.CheckedChanged += LUERKER控制器_CheckedChanged;
            // 
            // radioButton_魔盒
            // 
            radioButton_魔盒.BackColor = Color.Transparent;
            radioButton_魔盒.Checked = false;
            radioButton_魔盒.CheckedColorA = Color.FromArgb(27, 94, 137);
            radioButton_魔盒.CheckedColorB = Color.FromArgb(150, 118, 177, 211);
            radioButton_魔盒.EllipseBackColorA = Color.FromArgb(245, 245, 245);
            radioButton_魔盒.EllipseBackColorB = Color.FromArgb(231, 231, 231);
            radioButton_魔盒.EllipseBorderColorA = Color.FromArgb(168, 168, 168);
            radioButton_魔盒.EllipseBorderColorB = Color.FromArgb(252, 252, 252);
            radioButton_魔盒.Font = new Font("Verdana", 9F, FontStyle.Bold);
            radioButton_魔盒.ForeColor = Color.FromArgb(27, 94, 137);
            radioButton_魔盒.Location = new Point(212, 27);
            radioButton_魔盒.Name = "radioButton_魔盒";
            radioButton_魔盒.Size = new Size(81, 14);
            radioButton_魔盒.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            radioButton_魔盒.TabIndex = 17;
            radioButton_魔盒.Text = "魔盒";
            radioButton_魔盒.CheckedChanged += radioButton_魔盒_CheckedChanged;
            // 
            // radioButton_MVPNET
            // 
            radioButton_MVPNET.BackColor = Color.Transparent;
            radioButton_MVPNET.Checked = false;
            radioButton_MVPNET.CheckedColorA = Color.FromArgb(27, 94, 137);
            radioButton_MVPNET.CheckedColorB = Color.FromArgb(150, 118, 177, 211);
            radioButton_MVPNET.EllipseBackColorA = Color.FromArgb(245, 245, 245);
            radioButton_MVPNET.EllipseBackColorB = Color.FromArgb(231, 231, 231);
            radioButton_MVPNET.EllipseBorderColorA = Color.FromArgb(168, 168, 168);
            radioButton_MVPNET.EllipseBorderColorB = Color.FromArgb(252, 252, 252);
            radioButton_MVPNET.Font = new Font("Verdana", 9F, FontStyle.Bold);
            radioButton_MVPNET.ForeColor = Color.FromArgb(27, 94, 137);
            radioButton_MVPNET.Location = new Point(127, 27);
            radioButton_MVPNET.Name = "radioButton_MVPNET";
            radioButton_MVPNET.Size = new Size(85, 14);
            radioButton_MVPNET.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            radioButton_MVPNET.TabIndex = 16;
            radioButton_MVPNET.Text = "KMNET";
            radioButton_MVPNET.CheckedChanged += KMNET_CheckedChanged;
            // 
            // radioButton_CtrlKmbox
            // 
            radioButton_CtrlKmbox.BackColor = Color.Transparent;
            radioButton_CtrlKmbox.Checked = false;
            radioButton_CtrlKmbox.CheckedColorA = Color.FromArgb(27, 94, 137);
            radioButton_CtrlKmbox.CheckedColorB = Color.FromArgb(150, 118, 177, 211);
            radioButton_CtrlKmbox.EllipseBackColorA = Color.FromArgb(245, 245, 245);
            radioButton_CtrlKmbox.EllipseBackColorB = Color.FromArgb(231, 231, 231);
            radioButton_CtrlKmbox.EllipseBorderColorA = Color.FromArgb(168, 168, 168);
            radioButton_CtrlKmbox.EllipseBorderColorB = Color.FromArgb(252, 252, 252);
            radioButton_CtrlKmbox.Font = new Font("Verdana", 9F, FontStyle.Bold);
            radioButton_CtrlKmbox.ForeColor = Color.FromArgb(27, 94, 137);
            radioButton_CtrlKmbox.Location = new Point(33, 27);
            radioButton_CtrlKmbox.Name = "radioButton_CtrlKmbox";
            radioButton_CtrlKmbox.Size = new Size(88, 14);
            radioButton_CtrlKmbox.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            radioButton_CtrlKmbox.TabIndex = 15;
            radioButton_CtrlKmbox.Text = "KMBOX";
            radioButton_CtrlKmbox.CheckedChanged += KMBOX_CheckedChanged;
            // 
            // 配置
            // 
            配置.BackColor = Color.Transparent;
            配置.Controls.Add(OPENURL);
            配置.Controls.Add(COPYURL);
            配置.Controls.Add(checkBox_ShowVehicles);
            配置.Controls.Add(checkBox_PlayerInfo);
            配置.Controls.Add(checkBox_物资);
            配置.Controls.Add(checkBox_itemgroup3);
            配置.Controls.Add(checkBox_itemgroup2);
            配置.Controls.Add(checkBox_itemgroup1);
            配置.Controls.Add(checkBox_itemgroup0);
            配置.Controls.Add(checkBox_Rank);
            配置.Controls.Add(checkBox_DamageAvg);
            配置.Controls.Add(checkBox_KD);
            配置.Controls.Add(checkBox_Audience);
            配置.Controls.Add(checkBox_SurvivalLevel);
            配置.Controls.Add(checkBox_KillNum);
            配置.Controls.Add(checkBox_Distance);
            配置.Controls.Add(checkBox_ShowName);
            配置.Controls.Add(保存参数按钮);
            配置.Controls.Add(button_Start);
            配置.Controls.Add(dungeonLabel5);
            配置.Controls.Add(checkBox_ESPEnable);
            配置.Controls.Add(dungeonLabel2);
            配置.Controls.Add(textBox_ScreenX);
            配置.Controls.Add(textBox_ScreenY);
            配置.Controls.Add(groupBox2);
            配置.Controls.Add(comboBox_WebServer);
            配置.Controls.Add(dungeonLabel1);
            配置.Controls.Add(网页服务器1);
            配置.Controls.Add(comboBox_MqttServer);
            配置.Location = new Point(64, 4);
            配置.Name = "配置";
            配置.Size = new Size(516, 404);
            配置.TabIndex = 4;
            配置.Text = "配置";
            // 
            // OPENURL
            // 
            OPENURL.EnabledCalc = true;
            OPENURL.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            OPENURL.ForeColor = Color.ForestGreen;
            OPENURL.Location = new Point(273, 370);
            OPENURL.Name = "OPENURL";
            OPENURL.Size = new Size(77, 22);
            OPENURL.TabIndex = 141;
            OPENURL.Text = "OPEN";
            OPENURL.Click += 打开雷达URL;
            // 
            // COPYURL
            // 
            COPYURL.EnabledCalc = true;
            COPYURL.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            COPYURL.ForeColor = Color.ForestGreen;
            COPYURL.Location = new Point(273, 342);
            COPYURL.Name = "COPYURL";
            COPYURL.Size = new Size(77, 22);
            COPYURL.TabIndex = 140;
            COPYURL.Text = "COPY";
            COPYURL.Click += 复制雷达URL;
            // 
            // checkBox_ShowVehicles
            // 
            checkBox_ShowVehicles.BackColor = Color.DarkGray;
            checkBox_ShowVehicles.Checked = false;
            checkBox_ShowVehicles.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_ShowVehicles.Font = new Font("微软雅黑", 10.5F);
            checkBox_ShowVehicles.Image = null;
            checkBox_ShowVehicles.Location = new Point(449, 152);
            checkBox_ShowVehicles.Name = "checkBox_ShowVehicles";
            checkBox_ShowVehicles.NoRounding = false;
            checkBox_ShowVehicles.Size = new Size(59, 17);
            checkBox_ShowVehicles.TabIndex = 139;
            checkBox_ShowVehicles.Text = "载具";
            checkBox_ShowVehicles.Transparent = false;
            checkBox_ShowVehicles.CheckedChanged += airCheckBox16_CheckedChanged;
            // 
            // checkBox_PlayerInfo
            // 
            checkBox_PlayerInfo.BackColor = Color.DarkGray;
            checkBox_PlayerInfo.Checked = false;
            checkBox_PlayerInfo.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_PlayerInfo.Font = new Font("微软雅黑", 10.5F);
            checkBox_PlayerInfo.Image = null;
            checkBox_PlayerInfo.Location = new Point(273, 189);
            checkBox_PlayerInfo.Name = "checkBox_PlayerInfo";
            checkBox_PlayerInfo.NoRounding = false;
            checkBox_PlayerInfo.RightToLeft = RightToLeft.No;
            checkBox_PlayerInfo.Size = new Size(117, 17);
            checkBox_PlayerInfo.TabIndex = 138;
            checkBox_PlayerInfo.Text = "雷达人物信息";
            checkBox_PlayerInfo.Transparent = false;
            checkBox_PlayerInfo.CheckedChanged += checkBox_PlayerInfo_CheckedChanged;
            // 
            // checkBox_物资
            // 
            checkBox_物资.BackColor = Color.DarkGray;
            checkBox_物资.Checked = false;
            checkBox_物资.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_物资.Font = new Font("微软雅黑", 10.5F);
            checkBox_物资.Image = null;
            checkBox_物资.Location = new Point(384, 152);
            checkBox_物资.Name = "checkBox_物资";
            checkBox_物资.NoRounding = false;
            checkBox_物资.Size = new Size(59, 17);
            checkBox_物资.TabIndex = 137;
            checkBox_物资.Text = "物资";
            checkBox_物资.Transparent = false;
            checkBox_物资.CheckedChanged += airCheckBox14_CheckedChanged;
            // 
            // checkBox_itemgroup3
            // 
            checkBox_itemgroup3.Checked = false;
            checkBox_itemgroup3.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_itemgroup3.Font = new Font("微软雅黑", 10.5F);
            checkBox_itemgroup3.Image = null;
            checkBox_itemgroup3.Location = new Point(413, 286);
            checkBox_itemgroup3.Name = "checkBox_itemgroup3";
            checkBox_itemgroup3.NoRounding = false;
            checkBox_itemgroup3.Size = new Size(83, 17);
            checkBox_itemgroup3.TabIndex = 136;
            checkBox_itemgroup3.Text = "D组物资";
            checkBox_itemgroup3.Transparent = false;
            checkBox_itemgroup3.CheckedChanged += checkBox_itemgroup3_CheckedChanged;
            // 
            // checkBox_itemgroup2
            // 
            checkBox_itemgroup2.Checked = false;
            checkBox_itemgroup2.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_itemgroup2.Font = new Font("微软雅黑", 10.5F);
            checkBox_itemgroup2.Image = null;
            checkBox_itemgroup2.Location = new Point(413, 254);
            checkBox_itemgroup2.Name = "checkBox_itemgroup2";
            checkBox_itemgroup2.NoRounding = false;
            checkBox_itemgroup2.Size = new Size(83, 17);
            checkBox_itemgroup2.TabIndex = 135;
            checkBox_itemgroup2.Text = "C组物资";
            checkBox_itemgroup2.Transparent = false;
            checkBox_itemgroup2.CheckedChanged += checkBox_itemgroup2_CheckedChanged;
            // 
            // checkBox_itemgroup1
            // 
            checkBox_itemgroup1.Checked = false;
            checkBox_itemgroup1.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_itemgroup1.Font = new Font("微软雅黑", 10.5F);
            checkBox_itemgroup1.Image = null;
            checkBox_itemgroup1.Location = new Point(413, 222);
            checkBox_itemgroup1.Name = "checkBox_itemgroup1";
            checkBox_itemgroup1.NoRounding = false;
            checkBox_itemgroup1.Size = new Size(83, 17);
            checkBox_itemgroup1.TabIndex = 134;
            checkBox_itemgroup1.Text = "B组物资";
            checkBox_itemgroup1.Transparent = false;
            checkBox_itemgroup1.CheckedChanged += checkBox_itemgroup1_CheckedChanged;
            // 
            // checkBox_itemgroup0
            // 
            checkBox_itemgroup0.Checked = false;
            checkBox_itemgroup0.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_itemgroup0.Font = new Font("微软雅黑", 10.5F);
            checkBox_itemgroup0.Image = null;
            checkBox_itemgroup0.Location = new Point(413, 189);
            checkBox_itemgroup0.Name = "checkBox_itemgroup0";
            checkBox_itemgroup0.NoRounding = false;
            checkBox_itemgroup0.Size = new Size(83, 17);
            checkBox_itemgroup0.TabIndex = 133;
            checkBox_itemgroup0.Text = "A组物资";
            checkBox_itemgroup0.Transparent = false;
            checkBox_itemgroup0.CheckedChanged += checkBox_itemgroup0_CheckedChanged;
            // 
            // checkBox_Rank
            // 
            checkBox_Rank.Checked = false;
            checkBox_Rank.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_Rank.Font = new Font("微软雅黑", 10.5F);
            checkBox_Rank.Image = null;
            checkBox_Rank.Location = new Point(339, 319);
            checkBox_Rank.Name = "checkBox_Rank";
            checkBox_Rank.NoRounding = false;
            checkBox_Rank.Size = new Size(72, 17);
            checkBox_Rank.TabIndex = 132;
            checkBox_Rank.Text = "段位";
            checkBox_Rank.Transparent = false;
            checkBox_Rank.CheckedChanged += checkBox_Rank_CheckedChanged;
            // 
            // checkBox_DamageAvg
            // 
            checkBox_DamageAvg.Checked = false;
            checkBox_DamageAvg.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_DamageAvg.Font = new Font("微软雅黑", 10.5F);
            checkBox_DamageAvg.Image = null;
            checkBox_DamageAvg.Location = new Point(339, 287);
            checkBox_DamageAvg.Name = "checkBox_DamageAvg";
            checkBox_DamageAvg.NoRounding = false;
            checkBox_DamageAvg.Size = new Size(72, 17);
            checkBox_DamageAvg.TabIndex = 131;
            checkBox_DamageAvg.Text = "场伤";
            checkBox_DamageAvg.Transparent = false;
            checkBox_DamageAvg.CheckedChanged += checkBox_DamageAvg_CheckedChanged;
            // 
            // checkBox_KD
            // 
            checkBox_KD.Checked = false;
            checkBox_KD.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_KD.Font = new Font("微软雅黑", 10.5F);
            checkBox_KD.Image = null;
            checkBox_KD.Location = new Point(339, 255);
            checkBox_KD.Name = "checkBox_KD";
            checkBox_KD.NoRounding = false;
            checkBox_KD.Size = new Size(72, 17);
            checkBox_KD.TabIndex = 130;
            checkBox_KD.Text = "KD";
            checkBox_KD.Transparent = false;
            checkBox_KD.CheckedChanged += checkBox_KD_CheckedChanged;
            // 
            // checkBox_Audience
            // 
            checkBox_Audience.Checked = false;
            checkBox_Audience.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_Audience.Font = new Font("微软雅黑", 10.5F);
            checkBox_Audience.Image = null;
            checkBox_Audience.Location = new Point(339, 222);
            checkBox_Audience.Name = "checkBox_Audience";
            checkBox_Audience.NoRounding = false;
            checkBox_Audience.Size = new Size(72, 17);
            checkBox_Audience.TabIndex = 129;
            checkBox_Audience.Text = "观战";
            checkBox_Audience.Transparent = false;
            checkBox_Audience.CheckedChanged += checkBox_Audience_CheckedChanged;
            // 
            // checkBox_SurvivalLevel
            // 
            checkBox_SurvivalLevel.Checked = false;
            checkBox_SurvivalLevel.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_SurvivalLevel.Font = new Font("微软雅黑", 10.5F);
            checkBox_SurvivalLevel.Image = null;
            checkBox_SurvivalLevel.Location = new Point(273, 287);
            checkBox_SurvivalLevel.Name = "checkBox_SurvivalLevel";
            checkBox_SurvivalLevel.NoRounding = false;
            checkBox_SurvivalLevel.Size = new Size(66, 17);
            checkBox_SurvivalLevel.TabIndex = 128;
            checkBox_SurvivalLevel.Text = "等级";
            checkBox_SurvivalLevel.Transparent = false;
            checkBox_SurvivalLevel.CheckedChanged += checkBox_SurvivalLevel_CheckedChanged;
            // 
            // checkBox_KillNum
            // 
            checkBox_KillNum.Checked = false;
            checkBox_KillNum.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_KillNum.Font = new Font("微软雅黑", 10.5F);
            checkBox_KillNum.Image = null;
            checkBox_KillNum.Location = new Point(273, 319);
            checkBox_KillNum.Name = "checkBox_KillNum";
            checkBox_KillNum.NoRounding = false;
            checkBox_KillNum.Size = new Size(66, 17);
            checkBox_KillNum.TabIndex = 127;
            checkBox_KillNum.Text = "击杀";
            checkBox_KillNum.Transparent = false;
            checkBox_KillNum.CheckedChanged += checkBox_KillNum_CheckedChanged;
            // 
            // checkBox_Distance
            // 
            checkBox_Distance.Checked = false;
            checkBox_Distance.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_Distance.Font = new Font("微软雅黑", 10.5F);
            checkBox_Distance.Image = null;
            checkBox_Distance.Location = new Point(273, 255);
            checkBox_Distance.Name = "checkBox_Distance";
            checkBox_Distance.NoRounding = false;
            checkBox_Distance.Size = new Size(66, 17);
            checkBox_Distance.TabIndex = 126;
            checkBox_Distance.Text = "距离";
            checkBox_Distance.Transparent = false;
            checkBox_Distance.CheckedChanged += checkBox_Distance_CheckedChanged;
            // 
            // checkBox_ShowName
            // 
            checkBox_ShowName.Checked = false;
            checkBox_ShowName.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8=";
            checkBox_ShowName.Font = new Font("微软雅黑", 10.5F);
            checkBox_ShowName.Image = null;
            checkBox_ShowName.Location = new Point(273, 222);
            checkBox_ShowName.Name = "checkBox_ShowName";
            checkBox_ShowName.NoRounding = false;
            checkBox_ShowName.Size = new Size(66, 17);
            checkBox_ShowName.TabIndex = 125;
            checkBox_ShowName.Text = "名字";
            checkBox_ShowName.Transparent = false;
            checkBox_ShowName.CheckedChanged += checkBox_ShowName_CheckedChanged;
            // 
            // 保存参数按钮
            // 
            保存参数按钮.EnabledCalc = true;
            保存参数按钮.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            保存参数按钮.ForeColor = Color.ForestGreen;
            保存参数按钮.Location = new Point(418, 312);
            保存参数按钮.Name = "保存参数按钮";
            保存参数按钮.Size = new Size(76, 31);
            保存参数按钮.TabIndex = 124;
            保存参数按钮.Text = "保存参数";
            保存参数按钮.Click += 保存参数_Click;
            // 
            // button_Start
            // 
            button_Start.EnabledCalc = true;
            button_Start.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            button_Start.ForeColor = Color.ForestGreen;
            button_Start.Location = new Point(356, 349);
            button_Start.Name = "button_Start";
            button_Start.Size = new Size(140, 45);
            button_Start.TabIndex = 123;
            button_Start.Text = "RAIN RUN";
            button_Start.Click += button_Start_Click;
            // 
            // dungeonLabel5
            // 
            dungeonLabel5.AutoSize = true;
            dungeonLabel5.BackColor = Color.Transparent;
            dungeonLabel5.Font = new Font("Segoe UI", 11F);
            dungeonLabel5.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel5.Location = new Point(273, 149);
            dungeonLabel5.Name = "dungeonLabel5";
            dungeonLabel5.Size = new Size(44, 20);
            dungeonLabel5.TabIndex = 122;
            dungeonLabel5.Text = "透视:";
            // 
            // checkBox_ESPEnable
            // 
            checkBox_ESPEnable.Alpha = 50;
            checkBox_ESPEnable.BackColor = Color.Transparent;
            checkBox_ESPEnable.Background = true;
            checkBox_ESPEnable.Background_WidthPen = 2F;
            checkBox_ESPEnable.BackgroundPen = true;
            checkBox_ESPEnable.Checked = false;
            checkBox_ESPEnable.ColorBackground = Color.WhiteSmoke;
            checkBox_ESPEnable.ColorBackground_1 = Color.Lime;
            checkBox_ESPEnable.ColorBackground_2 = Color.Lime;
            checkBox_ESPEnable.ColorBackground_Pen = Color.DarkGreen;
            checkBox_ESPEnable.ColorBackground_Value_1 = Color.Lime;
            checkBox_ESPEnable.ColorBackground_Value_2 = Color.Lime;
            checkBox_ESPEnable.ColorLighting = Color.Lime;
            checkBox_ESPEnable.ColorPen_1 = Color.Lime;
            checkBox_ESPEnable.ColorPen_2 = Color.Lime;
            checkBox_ESPEnable.ColorValue = Color.Lime;
            checkBox_ESPEnable.CyberSwitchStyle = ReaLTaiizor.Enum.Cyber.StateStyle.Custom;
            checkBox_ESPEnable.Font = new Font("Arial", 11F);
            checkBox_ESPEnable.ForeColor = Color.FromArgb(245, 245, 245);
            checkBox_ESPEnable.Lighting = false;
            checkBox_ESPEnable.LinearGradient_Background = false;
            checkBox_ESPEnable.LinearGradient_Value = false;
            checkBox_ESPEnable.LinearGradientPen = false;
            checkBox_ESPEnable.Location = new Point(326, 146);
            checkBox_ESPEnable.Name = "checkBox_ESPEnable";
            checkBox_ESPEnable.PenWidth = 10;
            checkBox_ESPEnable.RGB = false;
            checkBox_ESPEnable.Rounding = true;
            checkBox_ESPEnable.RoundingInt = 90;
            checkBox_ESPEnable.Size = new Size(46, 28);
            checkBox_ESPEnable.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            checkBox_ESPEnable.TabIndex = 121;
            checkBox_ESPEnable.Tag = "Cyber";
            checkBox_ESPEnable.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            checkBox_ESPEnable.Timer_RGB = 300;
            checkBox_ESPEnable.CheckedChanged += checkBox_ESPEnable_CheckedChanged;
            // 
            // dungeonLabel2
            // 
            dungeonLabel2.AutoSize = true;
            dungeonLabel2.BackColor = Color.Transparent;
            dungeonLabel2.Font = new Font("Segoe UI", 11F);
            dungeonLabel2.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel2.Location = new Point(273, 32);
            dungeonLabel2.Name = "dungeonLabel2";
            dungeonLabel2.Size = new Size(60, 20);
            dungeonLabel2.TabIndex = 11;
            dungeonLabel2.Text = "分辨率:";
            // 
            // textBox_ScreenX
            // 
            textBox_ScreenX.BackColor = Color.FromArgb(235, 235, 235);
            textBox_ScreenX.BorderColor = Color.LightGray;
            textBox_ScreenX.BorderStyle = BorderStyle.FixedSingle;
            textBox_ScreenX.Font = new Font("Microsoft Sans Serif", 8F);
            textBox_ScreenX.ForeColor = Color.Gray;
            textBox_ScreenX.Location = new Point(339, 31);
            textBox_ScreenX.Name = "textBox_ScreenX";
            textBox_ScreenX.Size = new Size(73, 20);
            textBox_ScreenX.TabIndex = 9;
            textBox_ScreenX.Text = "1920";
            textBox_ScreenX.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox_ScreenY
            // 
            textBox_ScreenY.BackColor = Color.FromArgb(235, 235, 235);
            textBox_ScreenY.BorderColor = Color.LightGray;
            textBox_ScreenY.BorderStyle = BorderStyle.FixedSingle;
            textBox_ScreenY.Font = new Font("Microsoft Sans Serif", 8F);
            textBox_ScreenY.ForeColor = Color.Gray;
            textBox_ScreenY.Location = new Point(418, 31);
            textBox_ScreenY.Name = "textBox_ScreenY";
            textBox_ScreenY.Size = new Size(73, 20);
            textBox_ScreenY.TabIndex = 10;
            textBox_ScreenY.Text = "1080";
            textBox_ScreenY.TextAlign = HorizontalAlignment.Center;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Transparent;
            groupBox2.BackGColor = Color.WhiteSmoke;
            groupBox2.BaseColor = Color.Transparent;
            groupBox2.BorderColorG = Color.FromArgb(0, 64, 0);
            groupBox2.BorderColorH = Color.FromArgb(182, 180, 186);
            groupBox2.Controls.Add(comboBox_热键_显示物资组3);
            groupBox2.Controls.Add(comboBox_热键_显示物资组2);
            groupBox2.Controls.Add(comboBox_热键_显示物资组1);
            groupBox2.Controls.Add(comboBox_热键_显示物资组0);
            groupBox2.Controls.Add(comboBox_热键_玩家信息);
            groupBox2.Controls.Add(comboBox_热键_雷达缩小);
            groupBox2.Controls.Add(comboBox_热键_雷达放大);
            groupBox2.Controls.Add(comboBox_热键_加黑名单);
            groupBox2.Controls.Add(comboBox_热键_透视开关);
            groupBox2.Controls.Add(战斗模式);
            groupBox2.Controls.Add(dungeonLabel13);
            groupBox2.Controls.Add(comboBox_热键_数据刷新);
            groupBox2.Controls.Add(dungeonLabel6);
            groupBox2.Controls.Add(dungeonLabel12);
            groupBox2.Controls.Add(dungeonLabel4);
            groupBox2.Controls.Add(dungeonLabel3);
            groupBox2.Controls.Add(dungeonLabel11);
            groupBox2.Controls.Add(dungeonLabel7);
            groupBox2.Controls.Add(dungeonLabel15);
            groupBox2.Controls.Add(dungeonLabel8);
            groupBox2.Controls.Add(dungeonLabel10);
            groupBox2.Controls.Add(dungeonLabel9);
            groupBox2.Font = new Font("Tahoma", 9F);
            groupBox2.ForeColor = Color.BlanchedAlmond;
            groupBox2.HeaderColor = Color.Green;
            groupBox2.Location = new Point(15, 8);
            groupBox2.MinimumSize = new Size(136, 50);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(5, 28, 5, 5);
            groupBox2.Size = new Size(242, 386);
            groupBox2.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            groupBox2.TabIndex = 13;
            groupBox2.Text = "快捷键";
            // 
            // comboBox_热键_显示物资组3
            // 
            comboBox_热键_显示物资组3.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_显示物资组3.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_显示物资组3.EnabledCalc = true;
            comboBox_热键_显示物资组3.FormattingEnabled = true;
            comboBox_热键_显示物资组3.ItemHeight = 20;
            comboBox_热键_显示物资组3.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_显示物资组3.Location = new Point(103, 350);
            comboBox_热键_显示物资组3.Name = "comboBox_热键_显示物资组3";
            comboBox_热键_显示物资组3.Size = new Size(114, 26);
            comboBox_热键_显示物资组3.TabIndex = 31;
            comboBox_热键_显示物资组3.SelectedIndexChanged += comboBox_热键_D组物资_SelectedIndexChanged;
            // 
            // comboBox_热键_显示物资组2
            // 
            comboBox_热键_显示物资组2.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_显示物资组2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_显示物资组2.EnabledCalc = true;
            comboBox_热键_显示物资组2.FormattingEnabled = true;
            comboBox_热键_显示物资组2.ItemHeight = 20;
            comboBox_热键_显示物资组2.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_显示物资组2.Location = new Point(103, 318);
            comboBox_热键_显示物资组2.Name = "comboBox_热键_显示物资组2";
            comboBox_热键_显示物资组2.Size = new Size(114, 26);
            comboBox_热键_显示物资组2.TabIndex = 30;
            comboBox_热键_显示物资组2.SelectedIndexChanged += comboBox_热键_C组物资_SelectedIndexChanged;
            // 
            // comboBox_热键_显示物资组1
            // 
            comboBox_热键_显示物资组1.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_显示物资组1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_显示物资组1.EnabledCalc = true;
            comboBox_热键_显示物资组1.FormattingEnabled = true;
            comboBox_热键_显示物资组1.ItemHeight = 20;
            comboBox_热键_显示物资组1.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_显示物资组1.Location = new Point(103, 287);
            comboBox_热键_显示物资组1.Name = "comboBox_热键_显示物资组1";
            comboBox_热键_显示物资组1.Size = new Size(114, 26);
            comboBox_热键_显示物资组1.TabIndex = 29;
            comboBox_热键_显示物资组1.SelectedIndexChanged += comboBox_热键_B组物资_SelectedIndexChanged;
            // 
            // comboBox_热键_显示物资组0
            // 
            comboBox_热键_显示物资组0.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_显示物资组0.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_显示物资组0.EnabledCalc = true;
            comboBox_热键_显示物资组0.FormattingEnabled = true;
            comboBox_热键_显示物资组0.ItemHeight = 20;
            comboBox_热键_显示物资组0.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_显示物资组0.Location = new Point(103, 256);
            comboBox_热键_显示物资组0.Name = "comboBox_热键_显示物资组0";
            comboBox_热键_显示物资组0.Size = new Size(114, 26);
            comboBox_热键_显示物资组0.TabIndex = 28;
            comboBox_热键_显示物资组0.SelectedIndexChanged += comboBox_热键_A组物资_SelectedIndexChanged;
            // 
            // comboBox_热键_玩家信息
            // 
            comboBox_热键_玩家信息.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_玩家信息.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_玩家信息.EnabledCalc = true;
            comboBox_热键_玩家信息.FormattingEnabled = true;
            comboBox_热键_玩家信息.ItemHeight = 20;
            comboBox_热键_玩家信息.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_玩家信息.Location = new Point(103, 223);
            comboBox_热键_玩家信息.Name = "comboBox_热键_玩家信息";
            comboBox_热键_玩家信息.Size = new Size(114, 26);
            comboBox_热键_玩家信息.TabIndex = 27;
            comboBox_热键_玩家信息.SelectedIndexChanged += comboBox_热键_玩家信息_SelectedIndexChanged;
            // 
            // comboBox_热键_雷达缩小
            // 
            comboBox_热键_雷达缩小.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_雷达缩小.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_雷达缩小.EnabledCalc = true;
            comboBox_热键_雷达缩小.FormattingEnabled = true;
            comboBox_热键_雷达缩小.ItemHeight = 20;
            comboBox_热键_雷达缩小.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_雷达缩小.Location = new Point(103, 192);
            comboBox_热键_雷达缩小.Name = "comboBox_热键_雷达缩小";
            comboBox_热键_雷达缩小.Size = new Size(114, 26);
            comboBox_热键_雷达缩小.TabIndex = 26;
            comboBox_热键_雷达缩小.SelectedIndexChanged += comboBox_热键_雷达缩小_SelectedIndexChanged;
            // 
            // comboBox_热键_雷达放大
            // 
            comboBox_热键_雷达放大.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_雷达放大.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_雷达放大.EnabledCalc = true;
            comboBox_热键_雷达放大.FormattingEnabled = true;
            comboBox_热键_雷达放大.ItemHeight = 20;
            comboBox_热键_雷达放大.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_雷达放大.Location = new Point(103, 161);
            comboBox_热键_雷达放大.Name = "comboBox_热键_雷达放大";
            comboBox_热键_雷达放大.Size = new Size(114, 26);
            comboBox_热键_雷达放大.TabIndex = 25;
            comboBox_热键_雷达放大.SelectedIndexChanged += comboBox_热键_雷达放大_SelectedIndexChanged;
            // 
            // comboBox_热键_加黑名单
            // 
            comboBox_热键_加黑名单.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_加黑名单.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_加黑名单.EnabledCalc = true;
            comboBox_热键_加黑名单.FormattingEnabled = true;
            comboBox_热键_加黑名单.ItemHeight = 20;
            comboBox_热键_加黑名单.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_加黑名单.Location = new Point(103, 129);
            comboBox_热键_加黑名单.Name = "comboBox_热键_加黑名单";
            comboBox_热键_加黑名单.Size = new Size(114, 26);
            comboBox_热键_加黑名单.TabIndex = 24;
            comboBox_热键_加黑名单.SelectedIndexChanged += comboBox_热键_加黑名单_SelectedIndexChanged;
            // 
            // comboBox_热键_透视开关
            // 
            comboBox_热键_透视开关.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_透视开关.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_透视开关.EnabledCalc = true;
            comboBox_热键_透视开关.FormattingEnabled = true;
            comboBox_热键_透视开关.ItemHeight = 20;
            comboBox_热键_透视开关.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_透视开关.Location = new Point(103, 97);
            comboBox_热键_透视开关.Name = "comboBox_热键_透视开关";
            comboBox_热键_透视开关.Size = new Size(114, 26);
            comboBox_热键_透视开关.TabIndex = 23;
            comboBox_热键_透视开关.SelectedIndexChanged += comboBox_热键_透视开关_SelectedIndexChanged;
            // 
            // 战斗模式
            // 
            战斗模式.DrawMode = DrawMode.OwnerDrawFixed;
            战斗模式.DropDownStyle = ComboBoxStyle.DropDownList;
            战斗模式.EnabledCalc = true;
            战斗模式.FormattingEnabled = true;
            战斗模式.ItemHeight = 20;
            战斗模式.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            战斗模式.Location = new Point(103, 65);
            战斗模式.Name = "战斗模式";
            战斗模式.Size = new Size(114, 26);
            战斗模式.TabIndex = 22;
            战斗模式.SelectedIndexChanged += comboBox_热键_战斗模式_SelectedIndexChanged;
            // 
            // dungeonLabel13
            // 
            dungeonLabel13.AutoSize = true;
            dungeonLabel13.BackColor = Color.Transparent;
            dungeonLabel13.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel13.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel13.Location = new Point(19, 351);
            dungeonLabel13.Name = "dungeonLabel13";
            dungeonLabel13.Size = new Size(68, 19);
            dungeonLabel13.TabIndex = 20;
            dungeonLabel13.Text = "D 组物资:";
            // 
            // comboBox_热键_数据刷新
            // 
            comboBox_热键_数据刷新.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox_热键_数据刷新.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_热键_数据刷新.EnabledCalc = true;
            comboBox_热键_数据刷新.FormattingEnabled = true;
            comboBox_热键_数据刷新.ItemHeight = 20;
            comboBox_热键_数据刷新.Items.AddRange(new object[] { "无", "左键", "右键", "CANCEL", "中键", "侧键_左下", "侧键_左上", "[7]", "BACK", "TAB", "[10]", "[11]", "CLEAR", "RETURN", "[14]", "[15]", "SHIFT", "Ctrl", "AIT_L", "PAUSE", "Capslock", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "ESC", "[28]", "[29]", "[30]", "[31]", "SPACE", "PgUp", "PgDn", "END", "HOME", "LEFT", "UP", "RIGHT", "DOWN", "SELECT", "PRINT", "EXECUTE", "PS", "Ins", "Del", "HELP", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "[58]", "[59]", "[60]", "[61]", "[62]", "[63]", "[64]", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWIN", "RWIN", "APPS", "[94]", "SLEEP", "NUM0", "NUM1", "NUM2", "NUM3", "NUM4", "NUM5", "NUM6", "NUM7", "NUM8", "NUM9", "*", "+", "|", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "[136]", "[137]", "[138]", "[139]", "[140]", "[141]", "[142]", "[143]", "NUMLOCK", "SCROLL", "[146]", "[147]", "[148]", "[149]", "[150]", "[151]", "[152]", "[153]", "[154]", "[155]", "[156]", "[157]", "[158]", "[159]", "LSHIFT", "RSHIFT", "LCtrl", "RCtrl", "LMENU", "RMENU", "[166]", "[167]", "[168]", "[169]", "[170]", "[171]", "[172]", "[173]", "[174]", "[175]", "[176]", "[177]", "[178]", "[179]", "[180]", "[181]", "[182]", "[183]", "[184]", "[185]", "[186]", "[187]", "[188]", "[189]", "[190]", "[191]", "[192]", "[193]", "[194]", "[195]", "[196]", "[197]", "[198]", "[199]", "[200]" });
            comboBox_热键_数据刷新.Location = new Point(103, 33);
            comboBox_热键_数据刷新.Name = "comboBox_热键_数据刷新";
            comboBox_热键_数据刷新.Size = new Size(114, 26);
            comboBox_热键_数据刷新.TabIndex = 21;
            comboBox_热键_数据刷新.SelectedIndexChanged += aloneComboBox1_SelectedIndexChanged;
            // 
            // dungeonLabel6
            // 
            dungeonLabel6.AutoSize = true;
            dungeonLabel6.BackColor = Color.Transparent;
            dungeonLabel6.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel6.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel6.Location = new Point(18, 65);
            dungeonLabel6.Name = "dungeonLabel6";
            dungeonLabel6.Size = new Size(68, 19);
            dungeonLabel6.TabIndex = 8;
            dungeonLabel6.Text = "战斗模式:";
            // 
            // dungeonLabel12
            // 
            dungeonLabel12.AutoSize = true;
            dungeonLabel12.BackColor = Color.Transparent;
            dungeonLabel12.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel12.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel12.Location = new Point(19, 321);
            dungeonLabel12.Name = "dungeonLabel12";
            dungeonLabel12.Size = new Size(67, 19);
            dungeonLabel12.TabIndex = 19;
            dungeonLabel12.Text = "C 组物资:";
            // 
            // dungeonLabel4
            // 
            dungeonLabel4.AutoSize = true;
            dungeonLabel4.BackColor = Color.Transparent;
            dungeonLabel4.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel4.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel4.Location = new Point(18, 97);
            dungeonLabel4.Name = "dungeonLabel4";
            dungeonLabel4.Size = new Size(68, 19);
            dungeonLabel4.TabIndex = 7;
            dungeonLabel4.Text = "透视开关:";
            // 
            // dungeonLabel3
            // 
            dungeonLabel3.AutoSize = true;
            dungeonLabel3.BackColor = Color.Transparent;
            dungeonLabel3.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel3.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel3.Location = new Point(19, 36);
            dungeonLabel3.Name = "dungeonLabel3";
            dungeonLabel3.Size = new Size(68, 19);
            dungeonLabel3.TabIndex = 6;
            dungeonLabel3.Text = "数据刷新:";
            // 
            // dungeonLabel11
            // 
            dungeonLabel11.AutoSize = true;
            dungeonLabel11.BackColor = Color.Transparent;
            dungeonLabel11.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel11.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel11.Location = new Point(20, 289);
            dungeonLabel11.Name = "dungeonLabel11";
            dungeonLabel11.Size = new Size(66, 19);
            dungeonLabel11.TabIndex = 18;
            dungeonLabel11.Text = "B 组物资:";
            // 
            // dungeonLabel7
            // 
            dungeonLabel7.AutoSize = true;
            dungeonLabel7.BackColor = Color.Transparent;
            dungeonLabel7.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel7.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel7.Location = new Point(18, 130);
            dungeonLabel7.Name = "dungeonLabel7";
            dungeonLabel7.Size = new Size(68, 19);
            dungeonLabel7.TabIndex = 9;
            dungeonLabel7.Text = "加黑名单:";
            // 
            // dungeonLabel15
            // 
            dungeonLabel15.AutoSize = true;
            dungeonLabel15.BackColor = Color.Transparent;
            dungeonLabel15.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel15.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel15.Location = new Point(19, 260);
            dungeonLabel15.Name = "dungeonLabel15";
            dungeonLabel15.Size = new Size(67, 19);
            dungeonLabel15.TabIndex = 17;
            dungeonLabel15.Text = "A 组物资:";
            // 
            // dungeonLabel8
            // 
            dungeonLabel8.AutoSize = true;
            dungeonLabel8.BackColor = Color.Transparent;
            dungeonLabel8.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel8.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel8.Location = new Point(18, 164);
            dungeonLabel8.Name = "dungeonLabel8";
            dungeonLabel8.Size = new Size(68, 19);
            dungeonLabel8.TabIndex = 10;
            dungeonLabel8.Text = "雷达放大:";
            // 
            // dungeonLabel10
            // 
            dungeonLabel10.AutoSize = true;
            dungeonLabel10.BackColor = Color.Transparent;
            dungeonLabel10.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel10.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel10.Location = new Point(18, 227);
            dungeonLabel10.Name = "dungeonLabel10";
            dungeonLabel10.Size = new Size(68, 19);
            dungeonLabel10.TabIndex = 12;
            dungeonLabel10.Text = "玩家信息:";
            // 
            // dungeonLabel9
            // 
            dungeonLabel9.AutoSize = true;
            dungeonLabel9.BackColor = Color.Transparent;
            dungeonLabel9.Font = new Font("Segoe UI", 10.5F);
            dungeonLabel9.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel9.Location = new Point(18, 197);
            dungeonLabel9.Name = "dungeonLabel9";
            dungeonLabel9.Size = new Size(68, 19);
            dungeonLabel9.TabIndex = 11;
            dungeonLabel9.Text = "雷达缩小:";
            // 
            // comboBox_WebServer
            // 
            comboBox_WebServer.FormattingEnabled = true;
            comboBox_WebServer.Location = new Point(339, 69);
            comboBox_WebServer.Name = "comboBox_WebServer";
            comboBox_WebServer.Size = new Size(152, 28);
            comboBox_WebServer.TabIndex = 8;
            comboBox_WebServer.SelectedIndexChanged += comboBox_WebServer_SelectedIndexChanged;
            // 
            // dungeonLabel1
            // 
            dungeonLabel1.AutoSize = true;
            dungeonLabel1.BackColor = Color.Transparent;
            dungeonLabel1.Font = new Font("Segoe UI", 11F);
            dungeonLabel1.ForeColor = Color.FromArgb(76, 76, 77);
            dungeonLabel1.Location = new Point(273, 110);
            dungeonLabel1.Name = "dungeonLabel1";
            dungeonLabel1.Size = new Size(44, 20);
            dungeonLabel1.TabIndex = 6;
            dungeonLabel1.Text = "共享:";
            // 
            // 网页服务器1
            // 
            网页服务器1.AutoSize = true;
            网页服务器1.BackColor = Color.Transparent;
            网页服务器1.Font = new Font("Segoe UI", 11F);
            网页服务器1.ForeColor = Color.FromArgb(76, 76, 77);
            网页服务器1.Location = new Point(273, 72);
            网页服务器1.Name = "网页服务器1";
            网页服务器1.Size = new Size(44, 20);
            网页服务器1.TabIndex = 5;
            网页服务器1.Text = "网页:";
            // 
            // comboBox_MqttServer
            // 
            comboBox_MqttServer.FormattingEnabled = true;
            comboBox_MqttServer.Location = new Point(339, 107);
            comboBox_MqttServer.Name = "comboBox_MqttServer";
            comboBox_MqttServer.Size = new Size(152, 28);
            comboBox_MqttServer.TabIndex = 7;
            comboBox_MqttServer.SelectedIndexChanged += comboBox_MqttServer_SelectedIndexChanged;
            // 
            // 主菜单
            // 
            主菜单.Alignment = TabAlignment.Left;
            主菜单.BaseColor = Color.WhiteSmoke;
            主菜单.Controls.Add(配置);
            主菜单.Controls.Add(自瞄);
            主菜单.Controls.Add(物资);
            主菜单.Controls.Add(玩家);
            主菜单.Font = new Font("Microsoft YaHei UI", 10.5F);
            主菜单.ItemSize = new Size(70, 60);
            主菜单.Location = new Point(1, 66);
            主菜单.Margin = new Padding(0);
            主菜单.MaximumSize = new Size(584, 412);
            主菜单.MinimumSize = new Size(584, 412);
            主菜单.Multiline = true;
            主菜单.Name = "主菜单";
            主菜单.NormalTextColor = Color.Black;
            主菜单.SelectedIndex = 0;
            主菜单.SelectedTabBackColor = Color.Transparent;
            主菜单.SelectedTextColor = Color.Black;
            主菜单.ShowOuterBorders = false;
            主菜单.Size = new Size(584, 412);
            主菜单.SizeMode = TabSizeMode.Fixed;
            主菜单.SquareColor = Color.DarkSeaGreen;
            主菜单.TabCursor = Cursors.Hand;
            主菜单.TabIndex = 0;
            主菜单.SelectedIndexChanged += 主菜单_SelectedIndexChanged;
            // 
            // crownContextMenuStrip1
            // 
            crownContextMenuStrip1.BackColor = Color.FromArgb(60, 63, 65);
            crownContextMenuStrip1.ForeColor = Color.FromArgb(220, 220, 220);
            crownContextMenuStrip1.ImageScalingSize = new Size(24, 24);
            crownContextMenuStrip1.Name = "crownContextMenuStrip1";
            crownContextMenuStrip1.Size = new Size(61, 4);
            // 
            // button_LoadAllGuns
            // 
            button_LoadAllGuns.Font = new Font("Microsoft YaHei UI", 9F);
            button_LoadAllGuns.Location = new Point(63, 629);
            button_LoadAllGuns.Margin = new Padding(4);
            button_LoadAllGuns.Name = "button_LoadAllGuns";
            button_LoadAllGuns.Size = new Size(88, 33);
            button_LoadAllGuns.TabIndex = 292;
            button_LoadAllGuns.Text = "加载";
            button_LoadAllGuns.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft YaHei UI", 9F);
            label11.Location = new Point(315, 736);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(58, 17);
            label11.TabIndex = 274;
            label11.Text = "300-350:";
            label11.Visible = false;
            // 
            // textBox_Aim400
            // 
            textBox_Aim400.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim400.Location = new Point(385, 745);
            textBox_Aim400.Margin = new Padding(4);
            textBox_Aim400.Name = "textBox_Aim400";
            textBox_Aim400.Size = new Size(40, 23);
            textBox_Aim400.TabIndex = 277;
            textBox_Aim400.Text = "1.29";
            textBox_Aim400.Visible = false;
            // 
            // radioButton_DMR
            // 
            radioButton_DMR.AutoSize = true;
            radioButton_DMR.Font = new Font("Microsoft YaHei UI", 9F);
            radioButton_DMR.Location = new Point(63, 725);
            radioButton_DMR.Margin = new Padding(4);
            radioButton_DMR.Name = "radioButton_DMR";
            radioButton_DMR.Size = new Size(87, 21);
            radioButton_DMR.TabIndex = 289;
            radioButton_DMR.TabStop = true;
            radioButton_DMR.Text = "连狙[DMR]";
            radioButton_DMR.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft YaHei UI", 9F);
            label10.Location = new Point(315, 770);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(58, 17);
            label10.TabIndex = 276;
            label10.Text = "350-400:";
            label10.Visible = false;
            // 
            // textBox_Aim100
            // 
            textBox_Aim100.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim100.Location = new Point(269, 738);
            textBox_Aim100.Margin = new Padding(4);
            textBox_Aim100.Name = "textBox_Aim100";
            textBox_Aim100.Size = new Size(40, 23);
            textBox_Aim100.TabIndex = 265;
            textBox_Aim100.Text = "1.72";
            textBox_Aim100.Visible = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft YaHei UI", 9F);
            label7.Location = new Point(199, 831);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(58, 17);
            label7.TabIndex = 268;
            label7.Text = "150-200:";
            label7.Visible = false;
            // 
            // textBox_Aim999
            // 
            textBox_Aim999.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim999.Location = new Point(505, 714);
            textBox_Aim999.Margin = new Padding(4);
            textBox_Aim999.Name = "textBox_Aim999";
            textBox_Aim999.Size = new Size(40, 23);
            textBox_Aim999.TabIndex = 287;
            textBox_Aim999.Text = "1.6";
            textBox_Aim999.Visible = false;
            // 
            // radioButton_SR
            // 
            radioButton_SR.AutoSize = true;
            radioButton_SR.Font = new Font("Microsoft YaHei UI", 9F);
            radioButton_SR.Location = new Point(63, 695);
            radioButton_SR.Margin = new Padding(4);
            radioButton_SR.Name = "radioButton_SR";
            radioButton_SR.Size = new Size(74, 21);
            radioButton_SR.TabIndex = 288;
            radioButton_SR.TabStop = true;
            radioButton_SR.Text = "步枪[AR]";
            radioButton_SR.UseVisualStyleBackColor = true;
            // 
            // radioButton_GunTypeOthers
            // 
            radioButton_GunTypeOthers.AutoSize = true;
            radioButton_GunTypeOthers.Font = new Font("Microsoft YaHei UI", 9F);
            radioButton_GunTypeOthers.Location = new Point(63, 812);
            radioButton_GunTypeOthers.Margin = new Padding(4);
            radioButton_GunTypeOthers.Name = "radioButton_GunTypeOthers";
            radioButton_GunTypeOthers.Size = new Size(65, 21);
            radioButton_GunTypeOthers.TabIndex = 291;
            radioButton_GunTypeOthers.TabStop = true;
            radioButton_GunTypeOthers.Text = "Others";
            radioButton_GunTypeOthers.UseVisualStyleBackColor = true;
            // 
            // label_GunRaise
            // 
            label_GunRaise.AutoSize = true;
            label_GunRaise.Font = new Font("Microsoft YaHei UI", 9F);
            label_GunRaise.Location = new Point(199, 698);
            label_GunRaise.Margin = new Padding(4, 0, 4, 0);
            label_GunRaise.Name = "label_GunRaise";
            label_GunRaise.Size = new Size(42, 17);
            label_GunRaise.TabIndex = 260;
            label_GunRaise.Text = "Raise:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft YaHei UI", 9F);
            label8.Location = new Point(199, 866);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(58, 17);
            label8.TabIndex = 270;
            label8.Text = "200-250:";
            label8.Visible = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft YaHei UI", 9F);
            label13.Location = new Point(315, 804);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(58, 17);
            label13.TabIndex = 278;
            label13.Text = "400-450:";
            label13.Visible = false;
            // 
            // textBox_Aim350
            // 
            textBox_Aim350.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim350.Location = new Point(385, 711);
            textBox_Aim350.Margin = new Padding(4);
            textBox_Aim350.Name = "textBox_Aim350";
            textBox_Aim350.Size = new Size(40, 23);
            textBox_Aim350.TabIndex = 275;
            textBox_Aim350.Text = "1.28";
            textBox_Aim350.Visible = false;
            // 
            // radioButton_SG
            // 
            radioButton_SG.AutoSize = true;
            radioButton_SG.Font = new Font("Microsoft YaHei UI", 9F);
            radioButton_SG.Location = new Point(63, 783);
            radioButton_SG.Margin = new Padding(4);
            radioButton_SG.Name = "radioButton_SG";
            radioButton_SG.Size = new Size(86, 21);
            radioButton_SG.TabIndex = 293;
            radioButton_SG.TabStop = true;
            radioButton_SG.Text = "散弹枪[SG]";
            radioButton_SG.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Microsoft YaHei UI", 9F);
            label17.Location = new Point(435, 739);
            label17.Margin = new Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new Size(58, 17);
            label17.TabIndex = 286;
            label17.Text = "600-999:";
            label17.Visible = false;
            // 
            // textBox_Aim150
            // 
            textBox_Aim150.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim150.Location = new Point(269, 772);
            textBox_Aim150.Margin = new Padding(4);
            textBox_Aim150.Name = "textBox_Aim150";
            textBox_Aim150.Size = new Size(40, 23);
            textBox_Aim150.TabIndex = 267;
            textBox_Aim150.Text = "1.23";
            textBox_Aim150.Visible = false;
            // 
            // textBox_Aim450
            // 
            textBox_Aim450.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim450.Location = new Point(385, 779);
            textBox_Aim450.Margin = new Padding(4);
            textBox_Aim450.Name = "textBox_Aim450";
            textBox_Aim450.Size = new Size(40, 23);
            textBox_Aim450.TabIndex = 279;
            textBox_Aim450.Text = "1.33";
            textBox_Aim450.Visible = false;
            // 
            // textBox_Aim600
            // 
            textBox_Aim600.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim600.Location = new Point(505, 679);
            textBox_Aim600.Margin = new Padding(4);
            textBox_Aim600.Name = "textBox_Aim600";
            textBox_Aim600.Size = new Size(40, 23);
            textBox_Aim600.TabIndex = 285;
            textBox_Aim600.Text = "1.5";
            textBox_Aim600.Visible = false;
            // 
            // radioButton_AR
            // 
            radioButton_AR.AutoSize = true;
            radioButton_AR.Font = new Font("Microsoft YaHei UI", 9F);
            radioButton_AR.Location = new Point(63, 754);
            radioButton_AR.Margin = new Padding(4);
            radioButton_AR.Name = "radioButton_AR";
            radioButton_AR.Size = new Size(73, 21);
            radioButton_AR.TabIndex = 290;
            radioButton_AR.TabStop = true;
            radioButton_AR.Text = "栓狙[SR]";
            radioButton_AR.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft YaHei UI", 9F);
            label14.Location = new Point(435, 705);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(58, 17);
            label14.TabIndex = 284;
            label14.Text = "550-600:";
            label14.Visible = false;
            // 
            // button_SaveGun
            // 
            button_SaveGun.Font = new Font("Microsoft YaHei UI", 9F);
            button_SaveGun.Location = new Point(482, 836);
            button_SaveGun.Margin = new Padding(4);
            button_SaveGun.Name = "button_SaveGun";
            button_SaveGun.Size = new Size(88, 33);
            button_SaveGun.TabIndex = 259;
            button_SaveGun.Text = "Save Gun";
            button_SaveGun.UseVisualStyleBackColor = true;
            // 
            // textBox_Aim550
            // 
            textBox_Aim550.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim550.Location = new Point(385, 844);
            textBox_Aim550.Margin = new Padding(4);
            textBox_Aim550.Name = "textBox_Aim550";
            textBox_Aim550.Size = new Size(40, 23);
            textBox_Aim550.TabIndex = 283;
            textBox_Aim550.Text = "1.45";
            textBox_Aim550.Visible = false;
            // 
            // textBox_Aim300
            // 
            textBox_Aim300.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim300.Location = new Point(385, 677);
            textBox_Aim300.Margin = new Padding(4);
            textBox_Aim300.Name = "textBox_Aim300";
            textBox_Aim300.Size = new Size(40, 23);
            textBox_Aim300.TabIndex = 273;
            textBox_Aim300.Text = "1.27";
            textBox_Aim300.Visible = false;
            // 
            // textBox_Aim50
            // 
            textBox_Aim50.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim50.Location = new Point(269, 704);
            textBox_Aim50.Margin = new Padding(4);
            textBox_Aim50.Name = "textBox_Aim50";
            textBox_Aim50.Size = new Size(40, 23);
            textBox_Aim50.TabIndex = 263;
            textBox_Aim50.Text = "1.8";
            textBox_Aim50.Visible = false;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Microsoft YaHei UI", 9F);
            label15.Location = new Point(315, 870);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(58, 17);
            label15.TabIndex = 282;
            label15.Text = "500-550:";
            label15.Visible = false;
            // 
            // textBox_Aim250
            // 
            textBox_Aim250.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim250.Location = new Point(269, 841);
            textBox_Aim250.Margin = new Padding(4);
            textBox_Aim250.Name = "textBox_Aim250";
            textBox_Aim250.Size = new Size(40, 23);
            textBox_Aim250.TabIndex = 271;
            textBox_Aim250.Text = "1.26";
            textBox_Aim250.Visible = false;
            // 
            // comboBox_Gun
            // 
            comboBox_Gun.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Gun.FormattingEnabled = true;
            comboBox_Gun.Location = new Point(159, 632);
            comboBox_Gun.Margin = new Padding(4);
            comboBox_Gun.Name = "comboBox_Gun";
            comboBox_Gun.Size = new Size(205, 25);
            comboBox_Gun.TabIndex = 258;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft YaHei UI", 9F);
            label12.Location = new Point(315, 838);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(58, 17);
            label12.TabIndex = 280;
            label12.Text = "450-500:";
            label12.Visible = false;
            // 
            // textBox_Aim200
            // 
            textBox_Aim200.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim200.Location = new Point(269, 806);
            textBox_Aim200.Margin = new Padding(4);
            textBox_Aim200.Name = "textBox_Aim200";
            textBox_Aim200.Size = new Size(40, 23);
            textBox_Aim200.TabIndex = 269;
            textBox_Aim200.Text = "1.25";
            textBox_Aim200.Visible = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft YaHei UI", 9F);
            label9.Location = new Point(315, 702);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(58, 17);
            label9.TabIndex = 272;
            label9.Text = "250-300:";
            label9.Visible = false;
            // 
            // textBox_AimRaise
            // 
            textBox_AimRaise.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_AimRaise.Location = new Point(269, 673);
            textBox_AimRaise.Margin = new Padding(4);
            textBox_AimRaise.Name = "textBox_AimRaise";
            textBox_AimRaise.Size = new Size(40, 23);
            textBox_AimRaise.TabIndex = 261;
            textBox_AimRaise.Text = "0.4";
            // 
            // checkBox_GunAdvMode
            // 
            checkBox_GunAdvMode.AutoSize = true;
            checkBox_GunAdvMode.Font = new Font("Microsoft YaHei UI", 9F);
            checkBox_GunAdvMode.Location = new Point(379, 655);
            checkBox_GunAdvMode.Margin = new Padding(4);
            checkBox_GunAdvMode.Name = "checkBox_GunAdvMode";
            checkBox_GunAdvMode.Size = new Size(36, 21);
            checkBox_GunAdvMode.TabIndex = 294;
            checkBox_GunAdvMode.Text = "G";
            checkBox_GunAdvMode.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft YaHei UI", 9F);
            label4.Location = new Point(199, 763);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(58, 17);
            label4.TabIndex = 264;
            label4.Text = "050-100:";
            label4.Visible = false;
            // 
            // textBox_Aim500
            // 
            textBox_Aim500.Font = new Font("Microsoft YaHei UI", 9F);
            textBox_Aim500.Location = new Point(385, 813);
            textBox_Aim500.Margin = new Padding(4);
            textBox_Aim500.Name = "textBox_Aim500";
            textBox_Aim500.Size = new Size(40, 23);
            textBox_Aim500.TabIndex = 281;
            textBox_Aim500.Text = "1.38";
            textBox_Aim500.Visible = false;
            // 
            // textBox_GunShortName
            // 
            textBox_GunShortName.Location = new Point(64, 820);
            textBox_GunShortName.Margin = new Padding(4);
            textBox_GunShortName.Name = "textBox_GunShortName";
            textBox_GunShortName.Size = new Size(116, 23);
            textBox_GunShortName.TabIndex = 295;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft YaHei UI", 9F);
            label5.Location = new Point(199, 797);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(58, 17);
            label5.TabIndex = 266;
            label5.Text = "100-150:";
            label5.Visible = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft YaHei UI", 9F);
            label3.Location = new Point(199, 729);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(58, 17);
            label3.TabIndex = 262;
            label3.Text = "000-050:";
            label3.Visible = false;
            // 
            // textBox_URL
            // 
            textBox_URL.BackColor = Color.WhiteSmoke;
            textBox_URL.BorderStyle = BorderStyle.FixedSingle;
            textBox_URL.Enabled = false;
            textBox_URL.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            textBox_URL.Location = new Point(65, 595);
            textBox_URL.Margin = new Padding(4);
            textBox_URL.Name = "textBox_URL";
            textBox_URL.ReadOnly = true;
            textBox_URL.Size = new Size(348, 26);
            textBox_URL.TabIndex = 296;
            // 
            // Rains
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(589, 503);
            Controls.Add(textBox_URL);
            Controls.Add(button_LoadAllGuns);
            Controls.Add(label11);
            Controls.Add(textBox_Aim400);
            Controls.Add(radioButton_DMR);
            Controls.Add(label10);
            Controls.Add(textBox_Aim100);
            Controls.Add(label7);
            Controls.Add(textBox_Aim999);
            Controls.Add(radioButton_SR);
            Controls.Add(radioButton_GunTypeOthers);
            Controls.Add(label_GunRaise);
            Controls.Add(label8);
            Controls.Add(label13);
            Controls.Add(textBox_Aim350);
            Controls.Add(radioButton_SG);
            Controls.Add(label17);
            Controls.Add(textBox_Aim150);
            Controls.Add(textBox_Aim450);
            Controls.Add(textBox_Aim600);
            Controls.Add(radioButton_AR);
            Controls.Add(label14);
            Controls.Add(button_SaveGun);
            Controls.Add(textBox_Aim550);
            Controls.Add(textBox_Aim300);
            Controls.Add(textBox_Aim50);
            Controls.Add(label15);
            Controls.Add(textBox_Aim250);
            Controls.Add(comboBox_Gun);
            Controls.Add(label12);
            Controls.Add(textBox_Aim200);
            Controls.Add(label9);
            Controls.Add(textBox_AimRaise);
            Controls.Add(checkBox_GunAdvMode);
            Controls.Add(label4);
            Controls.Add(textBox_Aim500);
            Controls.Add(textBox_GunShortName);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(statusStrip1);
            Controls.Add(主菜单);
            MaximumSize = new Size(589, 503);
            MinimumSize = new Size(589, 503);
            Name = "Rains";
            Opacity = 0.9D;
            Padding = new Padding(2, 45, 3, 3);
            Text = "RAIN";
            FormClosing += Rains_FormClosing;
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            玩家.ResumeLayout(false);
            玩家.PerformLayout();
            物资.ResumeLayout(false);
            ((ISupportInitialize)poisonDataGridView3).EndInit();
            自瞄.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((ISupportInitialize)自瞄延时).EndInit();
            ((ISupportInitialize)numericUpDown_Recoil).EndInit();
            ((ISupportInitialize)numericUpDown_AimRange).EndInit();
            ((ISupportInitialize)numericUpDown_AimDistince).EndInit();
            ((ISupportInitialize)numericUpDown_AimDelay).EndInit();
            ((ISupportInitialize)numericUpDown_AimSmooth).EndInit();
            ((ISupportInitialize)numericUpDown_AimY).EndInit();
            ((ISupportInitialize)numericUpDown_AimX).EndInit();
            枪类型.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            配置.ResumeLayout(false);
            配置.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            主菜单.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel_MapName;
        private ToolStripStatusLabel UnxXuvxlhp;
        private ToolStripStatusLabel toolStripStatusLabel_自瞄状态;
        private ToolStripStatusLabel mqtt状态;
        private TabPage 玩家;
        private TabPage 物资;
        private TabPage 自瞄;
        private TabPage 配置;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_ShowVehicles;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_PlayerInfo;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_物资;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_itemgroup3;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_itemgroup2;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_itemgroup1;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_itemgroup0;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_Rank;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_DamageAvg;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_KD;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_Audience;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_SurvivalLevel;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_KillNum;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_Distance;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_ShowName;
        private ReaLTaiizor.Controls.AloneButton 保存参数按钮;
        private ReaLTaiizor.Controls.AloneButton button_Start;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel5;
        private ReaLTaiizor.Controls.CyberSwitch checkBox_ESPEnable;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel2;
        private ReaLTaiizor.Controls.MoonTextBox textBox_ScreenX;
        private ReaLTaiizor.Controls.MoonTextBox textBox_ScreenY;
        private ReaLTaiizor.Controls.GroupBox groupBox2;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_显示物资组3;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_显示物资组2;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_显示物资组1;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_显示物资组0;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_玩家信息;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_雷达缩小;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_雷达放大;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_加黑名单;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_透视开关;
        private ReaLTaiizor.Controls.AloneComboBox 战斗模式;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel13;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_数据刷新;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel6;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel12;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel4;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel3;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel11;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel7;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel15;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel8;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel10;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel9;
        private ComboBox comboBox_WebServer;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel1;
        private ReaLTaiizor.Controls.DungeonLabel 网页服务器1;
        private ComboBox comboBox_MqttServer;
        private ReaLTaiizor.Controls.AirTabPage 主菜单;
        private ReaLTaiizor.Controls.SkyRadioButton radioButton_CtrlKmbox;
        private ReaLTaiizor.Controls.GroupBox groupBox1;
        private ReaLTaiizor.Controls.SkyRadioButton radioButton_易键鼠;
        private ReaLTaiizor.Controls.SkyRadioButton radioButton_CtrlBlack;
        private ReaLTaiizor.Controls.SkyRadioButton radioButton_魔盒;
        private ReaLTaiizor.Controls.SkyRadioButton radioButton_MVPNET;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_COM;
        private ReaLTaiizor.Controls.SkyRadioButton 关闭自瞄;
        private ReaLTaiizor.Controls.DungeonTextBox MVPNETTXT;
        private ReaLTaiizor.Controls.CrownContextMenuStrip crownContextMenuStrip1;
        private ReaLTaiizor.Controls.AloneButton aloneButton3;
        private ReaLTaiizor.Controls.GroupBox groupBox3;
        private TabControl 枪类型;
        private TabPage tabPage7;
        private TabPage tabPage8;
        private TabPage tabPage9;
        private TabPage tabPage10;
        private TabPage tabPage11;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_AimLock;
        private ReaLTaiizor.Controls.CrownLabel crownLabel6;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_AimAt;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_LockGrobbyKey;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_LockKey;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_AimKey1;
        private ReaLTaiizor.Controls.CrownLabel crownLabel5;
        private ReaLTaiizor.Controls.CrownLabel crownLabel4;
        private ReaLTaiizor.Controls.CrownLabel crownLabel3;
        private ReaLTaiizor.Controls.CrownLabel crownLabel2;
        private ReaLTaiizor.Controls.CrownLabel crownLabel1;
        private ReaLTaiizor.Controls.AloneButton OPENURL;
        private ReaLTaiizor.Controls.AloneButton COPYURL;
        private NumericUpDown numericUpDown_AimDistince;
        private Label label_AimDistince;
        private NumericUpDown numericUpDown_AimDelay;
        private NumericUpDown numericUpDown_AimRange;
        private Label label_AimDelay;
        private Label label_AimRange;
        private Label label_AimSmooth;
        private NumericUpDown numericUpDown_AimSmooth;
        private ReaLTaiizor.Controls.CrownLabel crownLabel12;
        private ReaLTaiizor.Controls.CrownLabel crownLabel11;
        private ReaLTaiizor.Controls.CrownLabel crownLabel10;
        private ReaLTaiizor.Controls.CrownLabel crownLabel9;
        private ReaLTaiizor.Controls.CrownLabel crownLabel8;
        private ReaLTaiizor.Controls.CrownLabel crownLabel7;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_AimKey2;
        private ReaLTaiizor.Controls.CrownLabel crownLabel13;
        private NumericUpDown 自瞄延时;
        private ReaLTaiizor.Controls.CrownLabel crownLabel14;
        private ReaLTaiizor.Controls.AirRadioButton radioButton_AimUseDistince;
        private ReaLTaiizor.Controls.AirRadioButton radioButton_AimUseRange;
        private ReaLTaiizor.Controls.AirCheckBox checkBox动态FOV;
        private ReaLTaiizor.Controls.AirCheckBox checkBox跳过击杀;
        private ReaLTaiizor.Controls.AloneButton aloneButton6;
        private ReaLTaiizor.Controls.AloneComboBox comboBox_热键_自瞄配置2;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel14;
        internal ReaLTaiizor.Controls.PoisonDataGridView poisonDataGridView3;
        private ReaLTaiizor.Controls.SkyRadioButton radioButton_KDFPP;
        private ReaLTaiizor.Controls.SkyRadioButton radioButton_KDTPP;
        private ReaLTaiizor.Controls.AirCheckBox checkBox_单排;
        private Button button_LoadAllGuns;
        private Label label11;
        private TextBox textBox_Aim400;
        private RadioButton radioButton_DMR;
        private Label label10;
        private TextBox textBox_Aim100;
        private Label label7;
        private TextBox textBox_Aim999;
        private RadioButton radioButton_SR;
        private RadioButton radioButton_GunTypeOthers;
        private Label label_GunRaise;
        private Label label8;
        private Label label13;
        private TextBox textBox_Aim350;
        private RadioButton radioButton_SG;
        private Label label17;
        private TextBox textBox_Aim150;
        private TextBox textBox_Aim450;
        private TextBox textBox_Aim600;
        private RadioButton radioButton_AR;
        private Label label14;
        private Button button_SaveGun;
        private TextBox textBox_Aim550;
        private TextBox textBox_Aim300;
        private TextBox textBox_Aim50;
        private Label label15;
        private TextBox textBox_Aim250;
        private ComboBox comboBox_Gun;
        private Label label12;
        private TextBox textBox_Aim200;
        private Label label9;
        private TextBox textBox_AimRaise;
        private CheckBox checkBox_GunAdvMode;
        private Label label4;
        private TextBox textBox_Aim500;
        private TextBox textBox_GunShortName;
        private Label label5;
        private Label label3;
        private TextBox textBox_URL;
        private NumericUpDown numericUpDown_AimY;
        private NumericUpDown numericUpDown_AimX;
        private NumericUpDown numericUpDown_Recoil;
        private ReaLTaiizor.Controls.AloneButton aloneButton2;
        private ReaLTaiizor.Controls.DungeonLabel dungeonLabel16;
        private TextBox textBox_TeamAdd;
        private DataGridViewTextBoxColumn 物资名称;
        private DataGridViewComboBoxColumn 分组;
        private DataGridViewButtonColumn 显示;
        private ReaLTaiizor.Controls.AloneButton aloneButton1;
        private System.Windows.Forms.Timer timer1;
        private ReaLTaiizor.Controls.AirCheckBox checkBox开镜自瞄;
    }
}