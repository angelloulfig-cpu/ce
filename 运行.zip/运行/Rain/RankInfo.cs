namespace GameHelper.Struct
{
    public class RankInfo
    {

        public string rank { get; set; }
        public float kd { get; set; }

        public int avg { get; set; }


        public RankInfo()
        {
            rank = "";
            kd = 0;
            avg = 0;
        }

    }

    public class RankAPI
    {
        public float kd { get; set; }

        public int avg { get; set; }

        public int rank { get; set; }

        public long expire_time { get; set; }

        public string GetRankName(int rank)
        {
            if (rank == 0)
            {
                return "";
            }
            if (rank >= 2000m && rank < 2100m)
            {
                return "黄金5";
            }
            if (rank >= 2100m && rank < 2200m)
            {
                return "黄金4";
            }
            if (rank >= 2200m && rank < 2300m)
            {
                return "黄金3";
            }
            if (rank >= 2300m && rank < 2400m)
            {
                return "黄金2";
            }
            if (rank >= 2400m && rank < 2500m)
            {
                return "黄金1";
            }
            if (rank >= 2500m && rank < 2600m)
            {
                return "白金5";
            }
            if (rank >= 2600m && rank < 2700m)
            {
                return "白金4";
            }
            if (rank >= 2700m && rank < 2800m)
            {
                return "白金3";
            }
            if (rank >= 2800m && rank < 2900m)
            {
                return "白金2";
            }
            if (rank >= 2900m && rank < 3000m)
            {
                return "白金1";
            }
            if (rank >= 3000m && rank < 3100m)
            {
                return "钻石5";
            }
            if (rank >= 3100m && rank < 3200m)
            {
                return "钻石4";
            }
            if (rank >= 3200m && rank < 3300m)
            {
                return "钻石3";
            }
            if (rank >= 3300m && rank < 3400m)
            {
                return "钻石2";
            }
            if (rank >= 3400m && rank < 3500m)
            {
                return "钻石1";
            }
            if (rank >= 3500m)
            {
                return "大师";
            }
            return "菜狗";
        }

    }


}