﻿using BsPhpLoginUser;
using PGE.Common;
using RAIN;
using ReaLTaiizor.Forms;
using System.Diagnostics;
using System.Net;
using System.Reflection;

namespace PUBG
{
    [Obfuscation(Feature = "virtualization", Exclude = false)]
    public partial class 验证窗口 : MaterialForm
    {
        public string Version;//本程序版本号。
        public static BsPhp1 BSPHP;//网络验证类
        string name = "";
        string pasword = "";
        public static string webUri = ""; // Web 服务器地址

        CodeDescription codeDescription;
        public 验证窗口()
        {
            webUri = "xn--5suo68eupl.com";
            BSPHP = new BsPhp1();//实例化
            string 网络状态 = BSPHP.AppEn_Internet();
            int j1 = 0;
            while (网络状态 == "")
            {
                j1++;
                BSPHP = new BsPhp1();//实例化
                网络状态 = BSPHP.AppEn_Internet();
                if (j1 > 5)
                {
                    break;
                }
            }
            int j2 = 0;
            while (网络状态 == "")
            {
                j2++;
                webUri = "nmbombombom.xyz";
                BSPHP = new BsPhp1();//实例化
                网络状态 = BSPHP.AppEn_Internet();
                if (j1 > 3)
                {
                    break;
                }
            }
            if (网络状态 != "")
            {
                InitializeComponent();
            }
            else
            {
                MessageBox.Show("启动失败请检测网络!");
                QUIT();
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            //本地保存的账号密码
            var username = 写入读取配置文件.读取配置文件("login", "UserName", "");
            var pwd = 写入读取配置文件.读取配置文件("login", "Pwd", "");
            smallTextBox3.Text = username;
            smallTextBox2.Text = pwd;
            this.name = smallTextBox3.Text;
            this.pasword = smallTextBox2.Text;
            ////////////////////////

            if (name == "" || pasword == "")
            {
                MessageBox.Show("登陆状态错误请重试!");
                QUIT();
            }
            else
            {
                int 计数器 = 0;
                int 计数器1 = 0;
                int 计数器2 = 0;
                string srt;
                srt = BSPHP.AppEn_LogIn(name, pasword, "");
                //string 验证信息 = BSPHP.AppEn_GetVerification();
                while (srt == "")
                {
                    srt = BSPHP.AppEn_LogIn(name, pasword, "");
                    //验证信息 = BSPHP.AppEn_GetVerification();
                    计数器1++;
                    if (计数器1 > 10)
                    {
                        MessageBox.Show("登录信息丢失,请检查网络后重试!");
                        QUIT();
                    }
                }

                if (srt.Contains("1011"))
                {
                    写入读取配置文件.写入配置文件("login", "UserName", name);
                    写入读取配置文件.写入配置文件("login", "Pwd", pasword);
                    CommonProperty.username = name;
                    CommonProperty.到期时间 = srt.Split("|")[4];

                    string offset = BSPHP.RemoteVariable("3338c230a86ba2cb17d2c668ce32fdd8", "1");
                    while (offset == "")
                    {
                        计数器2++;
                        offset = BSPHP.RemoteVariable("3338c230a86ba2cb17d2c668ce32fdd8", "1");
                        if (计数器2 > 10)
                        {
                            MessageBox.Show("核心数据一获取失败,请重新启动!");
                            QUIT();
                        }
                    }
                    CommonProperty.jiemi = offset;


                    string 服务器 = BSPHP.RemoteVariable("6afbb6337ac0599d1c057b7c891bf3f8", "1");
                    while (服务器 == "")
                    {
                        计数器++;
                        服务器 = BSPHP.RemoteVariable("6afbb6337ac0599d1c057b7c891bf3f8", "1");
                        if (计数器 > 10)
                        {
                            MessageBox.Show("核心数据二获取失败,请重新启动!!");
                            QUIT();
                        }
                    }
                    CommonProperty.WebServer = 服务器.Split("##")[0];
                    CommonProperty.NOMqttserver = 服务器.Split("##")[1];
                    CommonProperty.Gnames加 = 服务器.Split("##")[2];

                    if (CommonProperty.到期时间.Length == 19 && CommonProperty.jiemi != "" && CommonProperty.WebServer != "" && CommonProperty.NOMqttserver != "")
                    {
                        base.DialogResult = DialogResult.OK;
                    }
                    else
                    {
                        MessageBox.Show("登陆状态错误请重试!");
                        QUIT();
                    }
                }
                else
                {
                    if (srt == "")
                    {
                        srt = "登录信息丢失,请检查网络后重试!";
                    }
                    MessageBox.Show(srt);
                    QUIT();
                }
            }
        }

        private void QUIT()
        {
            string environmentVariable = Environment.GetEnvironmentVariable("SystemRoot");
            using (Process process = new Process())
            {
                ProcessStartInfo startInfo = new ProcessStartInfo(environmentVariable + "\\System32\\taskkill.exe", "/f /im Rain.exe ");
                process.StartInfo = startInfo;
                process.StartInfo.UseShellExecute = true;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
                process.WaitForExit();
            }
        }
    }
}