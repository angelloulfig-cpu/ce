﻿namespace RAIN
{
    public class GunInfo
    {
        public string Name = "";

        public string ShortName = "";

        public int GunType = 4;

        public float Raise = 0.4f;

        public float Gun50 = 1.8f;

        public float Gun100 = 1.72f;

        public float Gun150 = 1.23f;

        public float Gun200 = 1.25f;

        public float Gun250 = 1.26f;

        public float Gun300 = 1.27f;

        public float Gun350 = 1.28f;

        public float Gun400 = 1.29f;

        public float Gun450 = 1.33f;

        public float Gun500 = 1.38f;

        public float Gun550 = 1.45f;

        public float Gun600 = 1.5f;

        public float Gun999 = 1.6f;
    }
}
