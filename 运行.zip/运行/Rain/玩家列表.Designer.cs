﻿namespace Rain
{
    partial class 人物列表窗口
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            dataGridView_用户列表 = new DataGridView();
            TeamIDColumn = new DataGridViewTextBoxColumn();
            NameColumn = new DataGridViewTextBoxColumn();
            生存等级Column = new DataGridViewTextBoxColumn();
            KDAColumn = new DataGridViewTextBoxColumn();
            RankColumn = new DataGridViewTextBoxColumn();
            本场伤害 = new DataGridViewTextBoxColumn();
            状态 = new DataGridViewTextBoxColumn();
            类型 = new DataGridViewTextBoxColumn();
            BlackColumn = new DataGridViewButtonColumn();
            timer2 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)dataGridView_用户列表).BeginInit();
            SuspendLayout();
            // 
            // dataGridView_用户列表
            // 
            dataGridView_用户列表.AllowUserToAddRows = false;
            dataGridView_用户列表.AllowUserToResizeColumns = false;
            dataGridView_用户列表.AllowUserToResizeRows = false;
            dataGridView_用户列表.BackgroundColor = Color.WhiteSmoke;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("宋体", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView_用户列表.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView_用户列表.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_用户列表.Columns.AddRange(new DataGridViewColumn[] { TeamIDColumn, NameColumn, 生存等级Column, KDAColumn, RankColumn, 本场伤害, 状态, 类型, BlackColumn });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("宋体", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridView_用户列表.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView_用户列表.GridColor = Color.Gainsboro;
            dataGridView_用户列表.Location = new Point(0, 24);
            dataGridView_用户列表.Name = "dataGridView_用户列表";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("宋体", 9F);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataGridView_用户列表.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGridView_用户列表.RowHeadersVisible = false;
            dataGridView_用户列表.RowHeadersWidth = 62;
            dataGridView_用户列表.RowTemplate.Height = 25;
            dataGridView_用户列表.ScrollBars = ScrollBars.Vertical;
            dataGridView_用户列表.Size = new Size(605, 381);
            dataGridView_用户列表.TabIndex = 5;
            dataGridView_用户列表.CellContentClick += dataGridView_用户列表_CellContentClick;
            dataGridView_用户列表.CellPainting += dataGridView_用户列表_CellPainting;
            dataGridView_用户列表.Scroll += dataGridView_用户列表_Scroll;
            dataGridView_用户列表.Sorted += dataGridView_用户列表_Sorted;
            // 
            // TeamIDColumn
            // 
            TeamIDColumn.FillWeight = 40F;
            TeamIDColumn.HeaderText = "Team";
            TeamIDColumn.MinimumWidth = 8;
            TeamIDColumn.Name = "TeamIDColumn";
            TeamIDColumn.ReadOnly = true;
            TeamIDColumn.Width = 50;
            // 
            // NameColumn
            // 
            NameColumn.FillWeight = 150F;
            NameColumn.HeaderText = "Name";
            NameColumn.MinimumWidth = 8;
            NameColumn.Name = "NameColumn";
            NameColumn.Width = 165;
            // 
            // 生存等级Column
            // 
            生存等级Column.FillWeight = 55F;
            生存等级Column.HeaderText = "等级";
            生存等级Column.MinimumWidth = 8;
            生存等级Column.Name = "生存等级Column";
            生存等级Column.Width = 52;
            // 
            // KDAColumn
            // 
            KDAColumn.FillWeight = 50F;
            KDAColumn.HeaderText = "KD";
            KDAColumn.MinimumWidth = 8;
            KDAColumn.Name = "KDAColumn";
            KDAColumn.Width = 50;
            // 
            // RankColumn
            // 
            RankColumn.FillWeight = 60F;
            RankColumn.HeaderText = "段位";
            RankColumn.MinimumWidth = 8;
            RankColumn.Name = "RankColumn";
            RankColumn.Width = 52;
            // 
            // 本场伤害
            // 
            本场伤害.HeaderText = "伤害";
            本场伤害.MinimumWidth = 8;
            本场伤害.Name = "本场伤害";
            本场伤害.Width = 52;
            // 
            // 状态
            // 
            状态.HeaderText = "状态";
            状态.MinimumWidth = 8;
            状态.Name = "状态";
            状态.Width = 53;
            // 
            // 类型
            // 
            类型.FillWeight = 55F;
            类型.HeaderText = "类型";
            类型.MinimumWidth = 8;
            类型.Name = "类型";
            类型.ToolTipText = "类型";
            类型.Width = 52;
            // 
            // BlackColumn
            // 
            BlackColumn.FillWeight = 55F;
            BlackColumn.HeaderText = "操作";
            BlackColumn.MinimumWidth = 8;
            BlackColumn.Name = "BlackColumn";
            BlackColumn.Text = "Revise";
            BlackColumn.ToolTipText = "操作";
            BlackColumn.UseColumnTextForButtonValue = true;
            BlackColumn.Width = 52;
            // 
            // timer2
            // 
            timer2.Enabled = true;
            timer2.Interval = 8000;
            timer2.Tick += timer2_Tick;
            // 
            // 人物列表窗口
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(607, 404);
            Controls.Add(dataGridView_用户列表);
            FormStyle = ReaLTaiizor.Enum.Material.FormStyles.ActionBar_None;
            MaximumSize = new Size(607, 404);
            MinimumSize = new Size(607, 404);
            Name = "人物列表窗口";
            Opacity = 0.7D;
            Padding = new Padding(3, 24, 3, 3);
            Text = "人物列表窗口";
            ((System.ComponentModel.ISupportInitialize)dataGridView_用户列表).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView_用户列表;
        private DataGridViewTextBoxColumn TeamIDColumn;
        private DataGridViewTextBoxColumn NameColumn;
        private DataGridViewTextBoxColumn 生存等级Column;
        private DataGridViewTextBoxColumn KDAColumn;
        private DataGridViewTextBoxColumn RankColumn;
        private DataGridViewTextBoxColumn 本场伤害;
        private DataGridViewTextBoxColumn 状态;
        private DataGridViewTextBoxColumn 类型;
        private DataGridViewButtonColumn BlackColumn;
    }
}