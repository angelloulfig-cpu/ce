﻿using PGE;

internal class 本人
{
    public ulong addr;

    public ulong 玩家控制;

    public ulong 投影相机;

    public ulong Animasccript;

    public ulong 视角 = 19831029uL;

    public ulong 状态 = 19831029uL;

    public ulong 武器控制;

    public ulong 武器基址;

    public byte 武器类型 = byte.MaxValue;

    public ulong WeaponAddr;

    public ulong WeaponTrajectoryDataAddr;

    public uint 武器id;

    public string WeaponName = "";

    public float InitialSpeed;

    public uint TeamID = 19831029u;

    public float 人物血量;

    public float 倒地血量;

    public bool 死亡 = true;

    public float 可视;

    public string name = "";

    public uint 本人观战数量;

    public ulong ulong_10;

    public Vector3 距离;

    public Vector3 距离坐标;

    public Vector3 ControlRotation;

    public float RecoilADSRotation;

    public FCameraCacheData fcameraCacheData;

    public void 本人信息()
    {
        addr = 0uL;
        视角 = 19831029uL;
        状态 = 19831029uL;
        武器控制 = 0uL;
        武器基址 = 0uL;
        武器类型 = byte.MaxValue;
        WeaponAddr = 0uL;
        WeaponTrajectoryDataAddr = 0uL;
        武器id = 0u;
        WeaponName = "";
        InitialSpeed = 0f;
        距离坐标 = default(Vector3);
        人物血量 = 0f;
        倒地血量 = 0f;
    }
}
