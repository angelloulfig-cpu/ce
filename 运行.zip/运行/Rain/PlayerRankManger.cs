using Newtonsoft.Json;
using PGE.Common;
using System.Net;
using System.Text.RegularExpressions;


namespace TestNet
{
    public class PlayerRankManger
    {
        private string localFile;

        private string localFileContext = "";

        private string season = "pc-2018-28";

        public static string mod = "tpp";

        public static string 单排 = "4";

        private HttpClient client;

        private Dictionary<string, RankAPI> playerCacheList;

        private bool seasonStatus;

        private bool opggStatus;

        private HashSet<string> readList;

        private RankAPI Empty;

        public PlayerRankManger()
        {
            //checkHost();
            localFile = CommonProperty.path + "rankInfo.json";
            if (File.Exists(localFile))
            {
                try
                {
                    localFileContext = File.ReadAllText(localFile);
                    playerCacheList = JsonConvert.DeserializeObject<Dictionary<string, RankAPI>>(localFileContext);
                    if (playerCacheList == null)
                    {
                        playerCacheList = new Dictionary<string, RankAPI>();
                    }
                }
                catch
                {
                    playerCacheList = new Dictionary<string, RankAPI>();
                }
            }
            else
            {
                playerCacheList = new Dictionary<string, RankAPI>();
            }
            client = new HttpClient(new HttpClientHandler() { UseCookies = true })
            {
                Timeout = new TimeSpan(0, 0, 5, 0, 0)
            };
            string ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36";
            client.DefaultRequestHeaders.Add("Connection", "Keep-Alive");
            client.DefaultRequestHeaders.Add("Keep-Alive", "timeout=300");
            client.DefaultRequestHeaders.UserAgent.ParseAdd(ua);
            Empty = new RankAPI();
            readList = new HashSet<string>();
            checkStatus();
        }

        public static long GetTimeStamp()
        {
            var ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalMilliseconds);
        }

        public void pull(string playerName)
        {
            try
            {
                if (!opggStatus)
                {
                    return;
                }
                if (string.IsNullOrWhiteSpace(playerName))
                {
                    return;
                }
                if (readList.Contains(playerName))
                {
                    return;
                }
                if (playerCacheList.ContainsKey(playerName))
                {
                    if (playerCacheList[playerName].expire_time > GetTimeStamp())
                    {
                        return;
                    }
                }
                if (!playerCacheList.ContainsKey(playerName))
                {
                    playerCacheList.Add(playerName, new RankAPI());
                }
                readList.Add(playerName);
                if (opggStatus)
                {
                    opggAdd(playerName);
                }
            }
            catch (Exception)
            {

            }

        }

        public RankAPI get(string playerName)
        {
            if (string.IsNullOrWhiteSpace(playerName))
            {
                return Empty;
            }
            if (playerCacheList.ContainsKey(playerName) && playerCacheList[playerName].expire_time > GetTimeStamp())
            {
                return playerCacheList[playerName];
            }
            return Empty;
        }

        private async void checkStatus()
        {
            try
            {
                string ret = await client.GetStringAsync("https://pubg.op.gg/template/6f6c43a6604d0a2c205698fbc835b075zh_CN/template?path=main.favoritesPlayerError");
                opggStatus = !string.IsNullOrEmpty(ret);
            }
            catch
            {
                opggStatus = false;
            }
        }

        //private void checkHost()
        //{
        //    try
        //    {
        //        string hostsPath = @"C:\Windows\System32\drivers\etc\hosts"; // Windows系统下的hosts文件路径
        //        string lineToAppend = CommonProperty.段位ip+"    pubg.op.gg";
        //        if (File.Exists(hostsPath) && !File.ReadAllText(hostsPath).Contains(lineToAppend))
        //        {
        //            File.AppendAllText(hostsPath, $"{Environment.NewLine}{lineToAppend}");
        //        }
        //    }
        //    catch
        //    {
        //    }
        //}


        private void opggAdd(string playerName)
        {
            if (!opggStatus)
            {
                return;
            }
            Task.Run(async () =>
            {

                if (!playerCacheList.ContainsKey(playerName))
                {
                    return;
                }
                var playerCache = playerCacheList[playerName];
                try
                {
                    if (string.IsNullOrEmpty(playerCache.oid))
                    {
                        var ret = await client.GetAsync("https://pubg.op.gg/user/" + playerName);
                        if (ret.StatusCode != HttpStatusCode.OK)
                        {
                            return;
                        }
                        var r = await ret.Content.ReadAsStringAsync();
                        Match match = Regex.Match(r, "data-user_id=\"[a-zA-Z0-9]+");
                        if (match.Success)
                        {
                            playerCache.oid = match.Value.Replace("data-user_id=\"", "");
                        }
                        if (!seasonStatus)
                        {
                            match = Regex.Match(r, "data-status=\"[a-zA-Z0-9-]+");
                            if (match.Success)
                            {
                                season = match.Value.Replace("data-status=\"", "");
                                seasonStatus = true;
                            }
                        }
                    }
                    if (string.IsNullOrEmpty(playerCache.oid))
                    {
                        return;
                    }
                    // 刷新内存缓存
                    HttpContent content = new StringContent("{\"_method\":\"PATCH\",\"type\":\"matches\"}");
                    content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
                    await client.PostAsync("https://pubg.op.gg/api/users/" + playerCache.oid + "/renew", content);
                    var info = await client.GetAsync("https://pubg.op.gg/api/users/" + playerCache.oid + "/ranked-stats?season=" + season + "&queue_size=" + 单排 + "&mode=competitive-" + mod);
                    if (info.StatusCode == HttpStatusCode.OK)
                    {
                        var text = await info.Content.ReadAsStringAsync();
                        OpggApi rankApi = JsonConvert.DeserializeObject<OpggApi>(text);
                        playerCache.rank = rankApi.stats.rank_points;
                        playerCache.kd = (float)Math.Round(rankApi.stats.kills_sum / rankApi.stats.deaths_sum, 1);
                        playerCache.avg = (int)rankApi.stats.damage_dealt_avg;
                        playerCache.expire_time = GetTimeStamp() + 21600000;
                    }
                    else
                    {
                        if (playerCache.rank > 0)
                        {
                            playerCache.expire_time = GetTimeStamp() + 21600000;
                        }
                    }
                    save();
                }
                catch (Exception) { }
            });
        }

        private void save()
        {
            try
            {
                string newJson = JsonConvert.SerializeObject(playerCacheList);
                if (newJson != localFileContext)
                {
                    File.WriteAllText(localFile, newJson);
                }
            }
            catch (Exception) { }
        }
    }

    public class RankAPI
    {
        public float kd { get; set; }

        public int avg { get; set; }

        public int rank { get; set; }

        public long expire_time { get; set; }

        public string oid { get; set; }

        public string lid { get; set; }


        public string GetRankName()
        {
            if (rank == 0)
            {
                return "";
            }
            if (rank >= 2000m && rank < 2100m)
            {
                return "黄金5";
            }
            if (rank >= 2100m && rank < 2200m)
            {
                return "黄金4";
            }
            if (rank >= 2200m && rank < 2300m)
            {
                return "黄金3";
            }
            if (rank >= 2300m && rank < 2400m)
            {
                return "黄金2";
            }
            if (rank >= 2400m && rank < 2500m)
            {
                return "黄金1";
            }
            if (rank >= 2500m && rank < 2600m)
            {
                return "白金5";
            }
            if (rank >= 2600m && rank < 2700m)
            {
                return "白金4";
            }
            if (rank >= 2700m && rank < 2800m)
            {
                return "白金3";
            }
            if (rank >= 2800m && rank < 2900m)
            {
                return "白金2";
            }
            if (rank >= 2900m && rank < 3000m)
            {
                return "白金1";
            }
            if (rank >= 3000m && rank < 3100m)
            {
                return "钻石5";
            }
            if (rank >= 3100m && rank < 3200m)
            {
                return "钻石4";
            }
            if (rank >= 3200m && rank < 3300m)
            {
                return "钻石3";
            }
            if (rank >= 3300m && rank < 3400m)
            {
                return "钻石2";
            }
            if (rank >= 3400m && rank < 3500m)
            {
                return "钻石1";
            }
            if (rank >= 3500m)
            {
                return "大师";
            }
            return "菜狗";
        }

    }
    public class OpggApi
    {
        public OpggStats stats { get; set; }
    }
    public class OpggStats
    {
        // 段位
        public int rank_points { get; set; }

        // 击杀
        public float kills_sum { get; set; }

        // 死亡
        public float deaths_sum { get; set; }

        // 场均伤害
        public float damage_dealt_avg { get; set; }
    }

    public class LookApi
    {
        public Dictionary<string, LookStats> stats { get; set; }
    }

    public class LookStats
    {
        // 段位
        public int currentRankPoint { get; set; }

        // 击杀
        public float kills { get; set; }

        // 死亡
        public float deaths { get; set; }

        // 伤害
        public float damageDealt { get; set; }

        // 场次
        public int roundsPlayed { get; set; }
    }
}
