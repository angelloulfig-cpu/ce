﻿internal class 自瞄数据
{
    public string string_0 = "";

    public string 武器名称 = "";

    public int 枪type = 4;

    public string 抢类型 = "其它";

    public int 自瞄按键1 = 1;

    public int 自瞄按键2 = 2;

    public int 父骨骼 = 2;

    public int 自瞄子按键 = 113;

    public int 子骨骼 = 2;

    public int 自瞄倒地按键 = 115;

    public int 自瞄响应 = 30;

    public int 自瞄距离 = 600;

    public int 自瞄FOV = 60;

    public int 自瞄平滑 = 1;

    public int 自瞄修正;

    public int 自瞄压枪;

    public int X轴自瞄力度 = 100;

    public bool Y轴自瞄开关 = true;

    public int Y轴自瞄力度 = 100;

    public bool 自瞄随机开关;

    public int 自瞄随机值 = 100;

    public int 自瞄优先级;

    public bool 动态范围 = true;

    public bool 跳过击杀 = true;

    public bool 开镜自瞄 = true;

    public float 初速度 = 0.4f;

    public float Gun50 = 1.8f;

    public float Gun100 = 1.72f;

    public float Gun150 = 1.23f;

    public float Gun200 = 1.25f;

    public float Gun250 = 1.26f;

    public float Gun300 = 1.27f;

    public float Gun350 = 1.28f;

    public float Gun400 = 1.29f;

    public float Gun450 = 1.33f;

    public float Gun500 = 1.38f;

    public float Gun550 = 1.45f;

    public float Gun600 = 1.5f;

    public float Gun999 = 1.6f;
}
