﻿namespace RAIN
{
    public class 载具info
    {
        public string shortName = "";

        public bool showItem;

        public int group;
    }
}
