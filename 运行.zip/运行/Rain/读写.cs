﻿using System.Runtime.InteropServices;
using vmmsharp;

internal class 读写
{
    private Vmm vmm_0;

    private uint uint_0;

    private uint uint_1 = Vmm.FLAG_NOCACHE | Vmm.FLAG_NOPAGING | Vmm.FLAG_NOCACHEPUT | Vmm.FLAG_ZEROPAD_ON_FAIL | Vmm.FLAG_NOPAGING_IO;

    private bool bool_0;

    private HashSet<ulong> hashSet_0 = new HashSet<ulong>();

    private Dictionary<ulong, bool> GyxUhishrN = new Dictionary<ulong, bool>();

    private HashSet<ulong> hashSet_1 = new HashSet<ulong>();

    private Dictionary<ulong, 读写1> dictionary_0 = new Dictionary<ulong, 读写1>();

    private Dictionary<ulong, MEM_SCATTER> dictionary_1 = new Dictionary<ulong, MEM_SCATTER>();

    public Dictionary<ulong, byte[]> dictionary_2 = new Dictionary<ulong, byte[]>();

    public int Finish()
    {
        hashSet_1.Clear();
        foreach (KeyValuePair<ulong, bool> item in GyxUhishrN)
        {
            if (!item.Value)
            {
                hashSet_1.Add(item.Key);
            }
        }
        foreach (ulong item2 in hashSet_1)
        {
            GyxUhishrN[item2] = true;
        }
        try
        {
            MEM_SCATTER[] array = MemReadScatter(hashSet_1.ToArray());
            for (int i = 0; i < array.Length; i++)
            {
                MEM_SCATTER value = array[i];
                dictionary_1[value.qwA] = value;
            }
            foreach (ulong item3 in hashSet_0)
            {
                if (!dictionary_2.ContainsKey(item3))
                {
                    byte[] array2 = new byte[dictionary_0[item3].uint_0];
                    if (dictionary_0[item3].ulongs_0[1] - dictionary_0[item3].UyhpMogdQl < dictionary_0[item3].uint_0)
                    {
                        uint num = (uint)(dictionary_0[item3].ulongs_0[1] - dictionary_0[item3].UyhpMogdQl);
                        uint count = dictionary_0[item3].uint_0 - num;
                        Buffer.BlockCopy(dictionary_1[dictionary_0[item3].ulongs_0[0]].pb, (int)(4096 - num), array2, 0, (int)num);
                        Buffer.BlockCopy(dictionary_1[dictionary_0[item3].ulongs_0[1]].pb, 0, array2, (int)num, (int)count);
                    }
                    else
                    {
                        Buffer.BlockCopy(dictionary_1[dictionary_0[item3].ulongs_0[0]].pb, (int)(dictionary_0[item3].UyhpMogdQl - dictionary_0[item3].ulongs_0[0]), array2, 0, (int)dictionary_0[item3].uint_0);
                    }
                    dictionary_2[item3] = array2;
                }
            }
        }
        catch (Exception)
        {
            bool_0 = false;
        }
        bool_0 = true;
        return hashSet_1.Count();
    }

    public void Add<T>(ulong uyhpMogdQl, bool bool_1 = false)
    {
        if (bool_1)
        {
            hashSet_0.Remove(uyhpMogdQl);
            dictionary_0.Remove(uyhpMogdQl);
        }
        uint num = (uint)Marshal.SizeOf(typeof(T));
        if (hashSet_0.Contains(uyhpMogdQl) || num > 4096)
        {
            return;
        }
        hashSet_0.Add(uyhpMogdQl);
        ulong num2 = uyhpMogdQl & 0xFFFFFFFFFFFFF000uL;
        ulong num3 = (uyhpMogdQl + num) & 0xFFFFFFFFFFFFF000uL;
        if (num2 == num3)
        {
            (new ulong[1])[0] = num2;
            读写1 @class = new 读写1();
            @class.UyhpMogdQl = uyhpMogdQl;
            @class.uint_0 = num;
            @class.ulongs_0[0] = num2;
            if (!GyxUhishrN.ContainsKey(num2) || bool_1)
            {
                GyxUhishrN[num2] = false;
            }
            dictionary_0[uyhpMogdQl] = @class;
            return;
        }
        ulong[] array = new ulong[2] { num2, num3 };
        读写1 class2 = new 读写1();
        class2.UyhpMogdQl = uyhpMogdQl;
        class2.uint_0 = num;
        class2.ulongs_0[0] = num2;
        class2.ulongs_0[1] = num3;
        if (!GyxUhishrN.ContainsKey(num2) || bool_1)
        {
            GyxUhishrN[num2] = false;
        }
        if (!GyxUhishrN.ContainsKey(num3) || bool_1)
        {
            GyxUhishrN[num3] = false;
        }
        dictionary_0[uyhpMogdQl] = class2;
    }

    public T Get<T>(ulong ulong_0)
    {
        if (!bool_0)
        {
            return default(T);
        }
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            Marshal.Copy(dictionary_2[ulong_0], 0, intPtr, num);
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    public void method_3(ulong uyhpMogdQl, uint uint_0)
    {
        bool_0 = false;
        if (hashSet_0.Contains(uyhpMogdQl) || uint_0 > 4096)
        {
            return;
        }
        hashSet_0.Add(uyhpMogdQl);
        ulong num = uyhpMogdQl & 0xFFFFFFFFFFFFF000uL;
        ulong num2 = (uyhpMogdQl + uint_0) & 0xFFFFFFFFFFFFF000uL;
        if (num == num2)
        {
            (new ulong[1])[0] = num;
            读写1 @class = new 读写1();
            @class.UyhpMogdQl = uyhpMogdQl;
            @class.uint_0 = uint_0;
            @class.ulongs_0[0] = num;
            if (!GyxUhishrN.ContainsKey(num))
            {
                GyxUhishrN[num] = false;
            }
            dictionary_0[uyhpMogdQl] = @class;
            return;
        }
        ulong[] array = new ulong[2] { num, num2 };
        读写1 class2 = new 读写1();
        class2.UyhpMogdQl = uyhpMogdQl;
        class2.uint_0 = uint_0;
        class2.ulongs_0[0] = num;
        class2.ulongs_0[1] = num2;
        if (!GyxUhishrN.ContainsKey(num))
        {
            GyxUhishrN[num] = false;
        }
        if (!GyxUhishrN.ContainsKey(num2))
        {
            GyxUhishrN[num2] = false;
        }
        dictionary_0[uyhpMogdQl] = class2;
    }

    public void Clear()
    {
        bool_0 = false;
        hashSet_0.Clear();
        GyxUhishrN.Clear();
        dictionary_0.Clear();
        dictionary_1.Clear();
        dictionary_2.Clear();
        uint_1 = Vmm.FLAG_NOCACHE | Vmm.FLAG_NOPAGING | Vmm.FLAG_NOCACHEPUT | Vmm.FLAG_ZEROPAD_ON_FAIL | Vmm.FLAG_NOPAGING_IO;
    }

    public 读写(uint uint_0, Vmm vmm_0)
    {
        this.uint_0 = uint_0;
        this.vmm_0 = vmm_0;
    }

    public void 初始(uint uint_1)
    {
        this.uint_1 = uint_1;
    }

    private MEM_SCATTER[] MemReadScatter(params ulong[] qwA)
    {
        return vmm_0.MemReadScatter(uint_0, uint_1, qwA);
    }
}
