﻿internal struct TArraya
{
    public UInt64 data;

    public int count;
}
