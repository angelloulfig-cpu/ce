﻿internal class 全
{
    public ulong addr;

    public uint @class;

    public ulong key;
}
