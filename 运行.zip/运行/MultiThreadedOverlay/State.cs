﻿namespace MultiThreadedOverlay
{
    public class State
    {
        public readonly EspOverlay EspOverlay = new EspOverlay();
        //public bool ShowClickableMenu = false;
        //public bool ShowOverlaySample1 = false;
        //public bool ShowImGuiDemo = false;
        //public int[] resizeHelper = new int[4] { 0, 0, 1920, 1080 };
        //public int Seconds = 1;
        //public int CurrentDisplay = 0;
        //public bool IsRunning = true;
        //public bool Visible;

        public bool ShowClickableMenu = true;
        public bool ShowOverlaySample1 = true;
        public bool ShowImGuiDemo = false;
        public int[] resizeHelper = new int[4] { 0, 0, 2560, 1440 };
        public int Seconds = 5;
        public int CurrentDisplay = 0;
        public bool IsRunning = true;
        public bool Visible;



        public int LogicTickDelayInMilliseconds = 10;
        public float LogicalDelta = 0;
        public bool RequestLogicThreadSleep = false;
        public int SleepInSeconds = 1;


        public float ReappearTimeRemaining = 0;

        public bool LogicThreadCloseOverlay = false;
    }
}