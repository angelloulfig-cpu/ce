﻿using FB_pubgesp;
using MultiThreadedOverlay;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PGaides;
using PGaides.Properties;
using pgauth;
using PGE;
using PGE.Common;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.IO.Compression;
using System.IO.Ports;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Exceptions;
using vmmsharp;
using System.Drawing.Drawing2D;
using SharpGen.Runtime;


internal class Class11
{
    private pg_pubgdata value;
    private double 全_地图比例;
    private float MapSize = 0;
    private bool IsShow;
    private int 全_地图状态 = 0;
    private Vector2 WorldMapPosition;
    private float WorldMapZoomFactor;
    private ulong 地图判断;

    public static VmmScatter TS;
    public static VmmScatter HS;


    private uint uint_0 = Vmm.FLAG_NOCACHE | Vmm.FLAG_NOPAGING | Vmm.FLAG_NOCACHEPUT | Vmm.FLAG_ZEROPAD_ON_FAIL | Vmm.FLAG_NOPAGING_IO;

    private uint flags = Vmm.FLAG_NOPAGING | Vmm.FLAG_ZEROPAD_ON_FAIL | Vmm.FLAG_NOPAGING_IO;

    private string string_0 = "";

    private uint uint_2;

    private string string_1 = "";

    private string 当前地图 = "";

    //private Vmm vmm = Program.mainForm_0.vmm;

    public static Vmm vmm;

    private string username = "";

    public static uint pid;

    private ulong ulong_0;

    private ulong ulong_1;

    private ulong ulong_2;

    private ulong MapAddr;

    private ulong MinimapCanvasWidgetAddr;

    private bool 透视小地图 = true;

    private ulong MapGrid;

    private int 帧率 = 240;

    private int int_0;

    private bool 自瞄兼容模式;

    private Vector3Int 全地图XY;

    private byte ammoData;

    private float 手雷倒计时;

    private float 透视手雷倒计时;

    private int num116;

    private int 头部 = 15;

    private int 颈部 = 5;

    private int 胸部 = 4;

    private int 左肩 = 88;

    private int 右肩 = 115;

    private int 左肘 = 89;

    private int 右肘 = 116;

    private int 左手 = 90;

    private int 右手 = 117;

    private int 骨盆 = 1;

    private int 左胯 = 172;

    private int 右胯 = 178;

    private int 左膝 = 173;

    private int 右膝 = 179;

    private int 左脚 = 174;

    private int 右脚 = 180;

    private ulong 瞄准地址;

    private bool 瞄准;

    private int 自瞄帧率;


    private Class7 class7_0 = new Class7();

    private HashSet<string> hashSet_地图 = new HashSet<string>();

    private HashSet<string> hashSet_物资 = new HashSet<string>();

    private Dictionary<string, 投掷info> dictionary_投掷物 = new Dictionary<string, 投掷info>();

    private Dictionary<string, 载具info> dictionary_载具 = new Dictionary<string, 载具info>();

    private HashSet<string> hashSet_人物 = new HashSet<string>();

    private HashSet<string> hashSet_人机 = new HashSet<string>();

    private HashSet<string> hashSet_盒子 = new HashSet<string>();

    private HashSet<string> hashSet_载具 = new HashSet<string>();

    private HashSet<string> hashSet_投掷物 = new HashSet<string>();

    private HashSet<string> hashSet_雷达信息 = new HashSet<string>();

    private ConcurrentQueue<string> concurrentQueue_雷达信息 = new ConcurrentQueue<string>();

    private static Dictionary<string, 物资info> dictionary_物资;

    private AutoResetEvent autoResetEvent_雷达信息 = new AutoResetEvent(false);

    private static Dictionary<string, PlayerInfo> dictionary_3;

    private ConcurrentQueue<string> concurrentQueue_1 = new ConcurrentQueue<string>();

    private AutoResetEvent autoResetEvent_1 = new AutoResetEvent(false);

    private ConcurrentQueue<List<Actor人物>> concurrentQueue_人物 = new ConcurrentQueue<List<Actor人物>>();

    private ConcurrentQueue<List<Class4>> concurrentQueue_地图资源 = new ConcurrentQueue<List<Class4>>();

    private List<ulong> ulongs_盒子 = new List<ulong>();

    private Dictionary<ulong, Actor人物> dictionary_人物 = new Dictionary<ulong, Actor人物>();

    private Dictionary<uint, KeyValuePair<string, string>> dictionary_5 = new Dictionary<uint, KeyValuePair<string, string>>();

    private Dictionary<ulong, Class4> dictionary地图资源 = new Dictionary<ulong, Class4>();

    private Dictionary<ulong, Class4> dictionary投掷物 = new Dictionary<ulong, Class4>();

    private List<Class4> dictionary投掷物2 = new List<Class4>();


    private Dictionary<ulong, Class5> dictionary物资 = new Dictionary<ulong, Class5>();

    private Dictionary<ulong, GameItems> dictionary丢弃的物资 = new Dictionary<ulong, GameItems>();

    private Dictionary<ulong, Class3> dictionary_全 = new Dictionary<ulong, Class3>();

    private Dictionary<int, int> dictionary_骨骼点 = new Dictionary<int, int>();

    private List<string> strings_人物 = new List<string>();

    private List<string> strings_物资 = new List<string>();

    private List<string> strings_盒子 = new List<string>();

    private List<string> strings_载具 = new List<string>();

    private List<string> strings_雷达信息 = new List<string>();

    private List<string> strings_人物2 = new List<string>();

    private uint uint_4;

    private Dictionary<uint, string> dictionary_本人 = new Dictionary<uint, string>();

    private bool debug;

    private bool 透视开关;

    private bool 透视;

    private bool 融合器;

    private bool 融合器1;

    private bool 透视投掷物;

    private bool 透视载具;

    private bool 动态FOV;

    private bool 雷达载具;

    private bool 雷达物资;

    private bool 战斗模式物资;

    private bool 物资0;

    private bool 物资1;

    private bool 物资2;

    private bool 物资3;

    private bool 自瞄优先 = true;

    private string string_4 = PGTools.ReadIni("config", "MqttServer", "127.0.0.1");

    private static Vector2 vector2_0;

    private static Vector2 vector2_1;

    private static float float_0;

    private static float float_1;

    private static Vector2 vector2_2;

    private static Vector2 vector2_3;

    private static Vector2 vector2_4;

    private static Vector2 vector2_5;

    private static Vector2 vector2_6;

    private bool 小地图放大;

    private ulong 基准值;

    private int x;

    private int y;

    private int 热键_战斗模式;

    private int 热键_显示物资组0;

    private int 热键_显示物资组1;

    private int 热键_显示物资组2;

    private int 热键_显示物资组3;

    private int 热键_缩小;

    private int 热键_放大;

    private int 热键_自瞄配置2;

    private int 热键_脖子;

    private int 热键_胸部;

    private int 热键_车辆;

    private int 热键_刷新;

    private int 热键_ESP;

    private int 热键_黑名单;

    private int 热键_用户信息;

    private int 热键_显示名字;

    private bool AutoJump;

    private bool bool_16 = true;

    private bool 左键按下;

    private bool 热键战斗模式;

    private bool 热键显示物资组0;

    private bool 热键显示物资组1;

    private bool 热键显示物资组2;

    private bool 热键显示物资组3;

    private bool 热键缩小;

    private bool 热键放大;

    private bool 自瞄头热键;

    private bool 自瞄脖热键;

    private bool 自瞄胸热键;

    private bool 热键车辆;

    private bool 数据刷新;

    private bool 热键ESP;

    private bool 热键黑名单;

    private bool 热键用户信息;

    private bool 热键显示名字;

    private bool 自瞄;

    private bool 子骨骼自瞄;

    private bool 自瞄倒地;

    private int X分辨率;

    private int Y分辨率;

    private int 自瞄模式;

    private int 控制器类型;

    private string COM端口 = "";

    private string 波动率 = "";

    private SerialPort KM_COM;

    private string MqttServer = "";

    private int EspDelay = 10;

    private int 透视距离;

    private bool 骨骼 = true;

    private int BoneDis = 60;

    private bool 玩家信息;

    private bool 游戏ID;

    private bool ShowAudience;

    private bool ShowKillNum;

    private bool 战斗模式载具;

    private bool 手持;

    private int 手持距离;

    private int 物资距离;

    private bool 轰炸区;

    private bool ShowKD;

    private bool ShowRank;

    private string string_8 = "";

    private bool ShowDamageAvg;

    private bool ShowSurvivalLevel;

    private bool ShowDistance;

    private int 字体大小 = 14;

    private string WebServer = "";

    private Class1 class_本人 = new Class1();

    private string 白名单_队伍 = "";

    private string string_11 = "";

    public HashSet<uint> hashSet_友军 = new HashSet<uint>();

    public HashSet<string> hashSet_白名单 = new HashSet<string>();

    private bool ThreadRunning = true;

    private bool 热键监控;

    private uint winlogonpid;

    private ulong gafAsyncKeyStateAddress;

    private byte[] HsqakkX6Do = new byte[64];

    private int int_25;

    private int int_26;

    private ulong Shield;

    private ulong Uworld;

    private ulong GNames;

    private ulong Leve;

    private ulong GameInstence;

    private ulong LocalPlayer;

    private ulong PlayerController;

    private ulong Actor;

    private ulong AcknowledgedPawn;

    private ulong ObjID;

    private ulong IDD;

    private ulong TeamNumber;

    private ulong Health;

    private ulong HealthDie;

    private ulong Audience;

    private ulong Playname;

    private ulong PlayerState;

    private ulong PlayerSatisitc;

    private ulong Mesh;

    private ulong Position;

    private ulong DroppedItemGroup;

    private ulong DroppedItemGroupUItem;

    private ulong 物品一;

    private ulong 物品二;

    private ulong 世界转小地图;

    private ulong 被瞄偏移;

    private ulong GameState;

    private ulong LerpSafetyZonePosition;

    private ulong LerpSafetyZoneRadius;

    private ulong PoisonGasWarningPosition;

    private ulong PoisonGasWarningRadius;

    private ulong RedZonePosition;

    private ulong RedZoneRadius;

    private bool ROR;

    private uint DecryptOne;

    private int TableOne;

    private int TableTwo;

    private uint DecryptTwo;

    private ulong PlayerCameraManager;

    private ulong CameraPos;

    private ulong CameraRot;

    private ulong CameraFov;

    private ulong Bone;

    private ulong BoneArry;

    private ulong Eyes;

    private ulong WeaponProcessor;

    private ulong EquippedWeapons;

    private ulong CurrentWeaponIndex;

    private ulong WeaponTrajectoryData;

    private ulong TrajectoryConfig;

    private ulong AnimScriptInstance;

    private ulong ControlRotationCP;

    private ulong RecoilADSRotationCP;

    private ulong VehicleRiderComponent;

    private ulong LastVehiclePawn;

    private ulong ActorRootComp;

    private ulong ReplicatedMovement;

    private ulong Veloctity;

    private ulong 背包状态;

    private ulong MapMarker;

    private ulong PartnerLevel;

    private ulong SurvivalLevel;

    private ulong BWasKicked;

    private ulong WidgetStateMap;

    private ulong MyHUD;

    private ulong BlockInputWidgetList;

    private ulong SelectMinimapSizeIndex;

    private ulong DroppedItem;

    private ulong CurrentAmmoData;

    private ulong ElapsedCookingTime;

    private ulong TimeTillExplosion;

    private ulong TrainingMapGrid;

    private ulong Visibility;

    private ulong Slot;

    private ulong Slot1;

    private ulong LayoutData;

    private ulong Offsets;

    private ulong Alignment;



    private Thread thread;
    private Thread thread3;
    private Thread thread4;
    private Thread thread5;

    [DllImport("user32")]
    private static extern int GetCursorPos(out Point lpPoint);

    [DllImport("user32")]
    private static extern int SetCursorPos(int X, int Y);

    [DllImport("user32")]
    private static extern int ShowCursor(int bShow);

    [DllImport("user32.dll")]
    private static extern int GetAsyncKeyState(int vKey);

    [DllImport("PG.dll")]
    private static extern int InitD(byte[] bytes_0);

    [DllImport("PG.dll")]
    private static extern ulong Decrypt(ulong ulong_70, ulong ulong_71);

    [DllImport("PG.dll")]
    private static extern uint ROL1(byte byte_0, int int_29);

    [DllImport("PG.dll")]
    private static extern uint ROL2(ushort ushort_0, int int_29);

    [DllImport("PG.dll")]
    private static extern uint ROL4(uint uint_8, int int_29);

    [DllImport("PG.dll")]
    private static extern uint ROL8(ulong ulong_70, int int_29);

    [DllImport("PG.dll")]
    private static extern uint ROR1(ushort ushort_0, int int_29);

    [DllImport("PG.dll")]
    private static extern uint ROR2(uint uint_8, int int_29);

    [DllImport("PG.dll")]
    private static extern uint ROR4(ulong ulong_70, int int_29);

    [DllImport("PG.dll")]
    private static extern uint ROR8(ulong ulong_70, int int_29);

    [DllImport("PG.dll")]
    private static extern uint AimBot(int int_29, int int_30);

    private string MemGetName(uint uint_8)
    {
        if (ulong_2 == 0L)
        {
            ulong_2 = method_4(Read<ulong>(method_4(Read<ulong>(ulong_0 + GNames))));
            if (ulong_2 == 0L)
            {
                return "";
            }
        }
        return method_2(Read<ulong>(Read<ulong>(ulong_2 + uint_8 / IDD * 8L) + uint_8 % IDD * 8L) + 16L, 64u).Split(default(char))[0].Trim();
    }

    private bool 游戏机按键是否按下(int vKey)
    {
        if ((HsqakkX6Do[vKey * 2 / 8] & (1 << vKey % 4 * 2)) <= 0)
        {
            return false;
        }
        return true;
    }

    private bool 雷达机按键是否按下(int int_29)
    {
        return (GetAsyncKeyState(int_29) & 0x8000) != 0;
    }

    private string method_2(ulong ulong_70, uint uint_8)
    {
        byte[] array = vmm.MemRead(pid, ulong_70, uint_8, flags);
        if (array != null && array.Length == uint_8)
        {
            return Encoding.Default.GetString(array);
        }
        return "";
    }

    private string method_3(ulong ulong_70, uint uint_8)
    {
        byte[] array = vmm.MemRead(pid, ulong_70, uint_8, flags);
        if (array == null || array.Length != uint_8)
        {
            return "";
        }
        return Encoding.Unicode.GetString(array).Split(default(char))[0].Trim();
    }

    private ulong method_4(ulong ulong_70)
    {
        try
        {
            return Decrypt(ulong_70, ulong_1);
        }
        catch
        {
            return 0;
        }
    }

    private uint DecryptCIndex(uint uint_8)
    {
        if (!ROR)
        {
            uint num = ROL4(uint_8 ^ DecryptOne, TableOne);
            return num ^ (num << TableTwo) ^ DecryptTwo;
        }
        uint num2 = ROR4(uint_8 ^ DecryptOne, TableOne);
        return num2 ^ (num2 << TableTwo) ^ DecryptTwo;
    }

    private void 帧率锁(int int_29)
    {
        Stopwatch stopwatch = new Stopwatch();
        stopwatch.Start();
        while ((int)stopwatch.Elapsed.TotalMilliseconds < int_29)
        {
            SpinWait.SpinUntil(() => true, int_29);
        }
    }

    public void 状态3(string string_12, Color color)
    {
        LogType logType = new LogType();
        logType.dt = DateTime.Now;
        logType.msg = "[Radar] -> " + string_12;
        logType.color = color;
        Program.mainForm_0.LogList.Enqueue(logType);
    }

    public void 状态2(string string_12)
    {
        LogType logType = new LogType();
        logType.dt = DateTime.Now;
        logType.msg = "[Radar] -> " + string_12;
        Program.mainForm_0.LogList.Enqueue(logType);
    }

    public void 状态(string string_12, object object_0, bool bool_50 = true)
    {
        Program.mainForm_0.UICHANGE.Enqueue(new KeyValuePair<string, object>(string_12, object_0));
        if (bool_50)
        {
            Program.mainForm_0.are_UICHANGE.Set();
        }
    }

    private void 雷达MQTT()
    {
        string text = string_4;
        状态2("连接到MQTT服务:" + text);
        MqttClient mqttClient = new MqttClient(text);
        string clientId = Guid.NewGuid().ToString();
        try
        {
            mqttClient.Connect(clientId);
        }
        catch (Exception ex)
        {
            MessageBox.Show("服务器异常,请更换服务器!Server have some error,pls change mqtt server" + ex.Message);
        }
        while (ThreadRunning)
        {
            try
            {
                while (true)
                {
                    string result;
                    if (concurrentQueue_1.Count > 0 && concurrentQueue_1.TryDequeue(out result))
                    {
                        if (mqttClient != null && mqttClient.IsConnected)
                        {
                            string s = method_11(result);
                            mqttClient.Publish(username, Encoding.UTF8.GetBytes(s), 0, false);
                        }
                    }
                    else
                    {
                        autoResetEvent_1.WaitOne();
                    }
                    Thread.Sleep(1);
                }
            }
            catch (MqttClientException)
            {
                mqttClient = new MqttClient(text);
                clientId = Guid.NewGuid().ToString();
                mqttClient.Connect(clientId);
            }
            Thread.Sleep(1000);
        }
    }

    private string method_11(string string_12)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(string_12);
        return Convert.ToBase64String(method_12(bytes));
    }

    private byte[] method_12(byte[] bytes_0)
    {
        using (MemoryStream memoryStream = new MemoryStream())
        {
            using (GZipStream gZipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
            {
                gZipStream.Write(bytes_0, 0, bytes_0.Length);
                gZipStream.Close();
            }
            return memoryStream.ToArray();
        }
    }


    private bool 判断人物(string string_12)
    {
        if (hashSet_人物.Contains(string_12))
        {
            return true;
        }
        return false;
    }

    private bool 判断人机(string string_12)
    {
        if (hashSet_人机.Contains(string_12))
        {
            return true;
        }
        return false;
    }

    private bool 判断盒子(string string_12)
    {
        if (!hashSet_盒子.Contains(string_12))
        {
            return false;
        }
        return true;
    }

    private bool 判断载具(string string_12)
    {
        if (!hashSet_载具.Contains(string_12))
        {
            return false;
        }
        return true;
    }

    private bool 判断投掷物(string string_12)
    {
        if (!hashSet_投掷物.Contains(string_12))
        {
            return false;
        }
        return true;
    }

    private bool 判断物资(string string_12)
    {
        if (hashSet_物资.Contains(string_12))
        {
            return true;
        }
        return false;
    }
    private SampleOverlay overlay;
    private void 结束进程()
    {
        if (vmm != null)
        {
            vmm.Close();
        }


        using (Process process = new Process())
        {
            string environmentVariable = Environment.GetEnvironmentVariable("SystemRoot");
            ProcessStartInfo startInfo = new ProcessStartInfo(fileName: environmentVariable + "\\System32\\taskkill.exe", arguments: "/f /im " + AppDomain.CurrentDomain.FriendlyName);
            process.StartInfo = startInfo;
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            process.Start();
            process.WaitForExit();
        }
        if (overlay != null)
        {
            overlay.Close();
            overlay.Dispose();
            overlay = null;
            EspOverlay.Clear();
            EspOverlay.Clear2();
            EspOverlay.Clear3();
        }
    }

    private bool DMATEST()
    {
        if (vmm != null)
        {
            vmm.Close();
        }
        bool flag = false;
        if (File.Exists("mmap.txt"))
        {
            try
            {
                vmm = new Vmm("", "-device", "fpga", "-memmap", "mmap.txt", "-norefresh");
                flag = true;
            }
            catch (Exception)
            {
                状态2(Resources.DMAinitFalse + " -memmap mmap.txt");
            }
            if (flag)
            {
                状态2(Resources.DMAinitTrue);
                return true;
            }
        }
        try
        {
            if (vmm != null)
            {
                vmm.Close();
            }
            vmm = new Vmm("", "-device", "fpga", "-norefresh");
        }
        catch (Exception)
        {
            状态2(Resources.DMAinitFalse + "default");
            return false;
        }
        Vmm.MAP_PHYSMEMENTRY[] array = vmm.Map_GetPhysMem();
        if (array.Length != 0)
        {
            状态2("Create mmap file!");
            using (StreamWriter streamWriter = new StreamWriter("mmap.txt"))
            {
                Vmm.MAP_PHYSMEMENTRY[] array2 = array;
                for (int i = 0; i < array2.Length; i++)
                {
                    Vmm.MAP_PHYSMEMENTRY mAP_PHYSMEMENTRY = array2[i];
                    ulong pa = mAP_PHYSMEMENTRY.pa;
                    string value = string.Format("{0} {1}", pa.ToString("X").ToLower(), (mAP_PHYSMEMENTRY.pa + mAP_PHYSMEMENTRY.cb - 1L).ToString("X").ToLower());
                    streamWriter.WriteLine(value);
                }
            }
            vmm.Close();
            if (File.Exists("mmap.txt"))
            {
                try
                {
                    if (vmm != null)
                    {
                        vmm.Close();
                    }
                    vmm = new Vmm("", "-device", "fpga", "-memmap", "mmap.txt", "-norefresh");
                    flag = true;
                }
                catch (Exception)
                {
                    flag = false;
                    状态2(Resources.DMAinitFalse + " -memmap mmap.txt");
                }
                if (flag)
                {
                    状态2(Resources.DMAinitTrue);
                    return true;
                }
            }
            try
            {
                if (vmm != null)
                {
                    vmm.Close();
                }
                vmm = new Vmm("", "-device", "fpga", "-norefresh");
            }
            catch (Exception)
            {
                状态2(Resources.DMAinitFalse);
                return false;
            }
            return true;
        }
        return true;
    }

    private bool 读取游戏进程()
    {
        uint[] array = vmm.PidList();
        List<uint> list = new List<uint>();
        uint[] array2 = array;
        foreach (uint num in array2)
        {
            if (vmm.ProcessGetInformation(num).szName.Trim().EndsWith("TslGame.exe"))
            {
                list.Add(num);
            }
        }
        foreach (uint item in list)
        {
            Vmm.MAP_VADENTRY[] array3 = vmm.Map_GetVad(item);
            for (int i = 0; i < array3.Length; i++)
            {
                Vmm.MAP_VADENTRY mAP_VADENTRY = array3[i];
                if (!mAP_VADENTRY.wszText.Contains("TslGame.exe"))
                {
                    continue;
                }
                ulong_0 = mAP_VADENTRY.vaStart;
                foreach (uint item2 in list)
                {
                    uint num2 = (pid = item2);
                    if (MemRead<ulong>(ulong_0 + Shield) <= 0L)
                    {
                        pid = 0u;
                        continue;
                    }
                    pid = num2;
                    return true;
                }
            }
        }
        return false;
    }

    private bool kyZpsbAxnb(ulong ulong_70, ulong ulong_71)
    {
        if (ulong_70 != 0L && ulong_71 != 0L)
        {
            return Math.Abs(ulong_70.ToString().Length - ulong_71.ToString().Length) < 5;
        }
        return false;
    }

    private T MemRead<T>(ulong ulong_70)
    {
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            byte[] array = vmm.MemRead(pid, ulong_70, (uint)num, uint_0);
            if (array.Length != num)
            {
                return default(T);
            }
            Marshal.Copy(array, 0, intPtr, num);
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    private T method_23<T>(ulong ulong_70, ref bool bool_50)
    {
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            byte[] array = vmm.MemRead(pid, ulong_70, (uint)num, uint_0);
            if (array.Length != num)
            {
                bool_50 = false;
                return default(T);
            }
            Marshal.Copy(array, 0, intPtr, num);
            bool_50 = true;
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            bool_50 = false;
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    private T method_24<T>(uint uint_8, ulong ulong_70)
    {
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            byte[] array = vmm.MemRead(uint_8, ulong_70, (uint)num, uint_0);
            if (array.Length != num)
            {
                return default(T);
            }
            Marshal.Copy(array, 0, intPtr, num);
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    public static T GetStructure<T>(byte[] bytes)
    {
        var handle = GCHandle.Alloc(bytes, GCHandleType.Pinned);
        var structure = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
        handle.Free();
        return structure;
    }

    public static T Read<T>(ulong qwA)
    {
        uint size = (uint)Marshal.SizeOf(typeof(T));
        var data = vmm.MemRead(pid, qwA, size);
        if (data == null)
        {
            return default(T);
        }
        return GetStructure<T>(data);
    }

    private T method_26<T>(ulong qwa, ref bool bool_50)
    {
        int cb = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(cb);
        try
        {
            byte[] array = vmm.MemRead(pid, qwa, (uint)cb, flags);
            if (array.Length != cb)
            {
                bool_50 = false;
                return default(T);
            }
            bool_50 = true;
            Marshal.Copy(array, 0, intPtr, cb);
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            bool_50 = false;
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    private T method_27<T>(uint uint_8, ulong ulong_70)
    {
        int num = Marshal.SizeOf(typeof(T));
        IntPtr intPtr = Marshal.AllocHGlobal(num);
        try
        {
            byte[] array = vmm.MemRead(uint_8, ulong_70, (uint)num, flags);
            if (array.Length != num)
            {
                return default(T);
            }
            Marshal.Copy(array, 0, intPtr, num);
            return (T)Marshal.PtrToStructure(intPtr, typeof(T));
        }
        catch (Exception)
        {
            return default(T);
        }
        finally
        {
            Marshal.FreeHGlobal(intPtr);
        }
    }

    private string method_28(byte[] bytes_0)
    {
        int num = 0;
        int num2 = 0;
        string result = "";
        byte[] array = new byte[64];
        foreach (byte b in bytes_0)
        {
            if (b < 30 || b > 128)
            {
                num++;
            }
            else
            {
                num = 0;
                array[num2++] = b;
            }
            if (num == 2)
            {
                result = Encoding.Default.GetString(array).Split(default(char))[0];
                break;
            }
        }
        return result;
    }

    private Vector3 相减(Vector3 vector3_0, Vector3 vector3_1)
    {
        Vector3 result = default(Vector3);
        result.x = vector3_0.x - vector3_1.x;
        result.y = vector3_0.y - vector3_1.y;
        result.z = vector3_0.z - vector3_1.z;
        return result;
    }

    private float method_30(Vector3 vector3_0)
    {
        return (float)Math.Sqrt(vector3_0.x * vector3_0.x + vector3_0.y * vector3_0.y + vector3_0.z * vector3_0.z);
    }

    private Vector3 method_31(Vector3 vector3_0, Vector3 vector3_1)
    {
        Vector3 vector = default(Vector3);
        vector.x = 0f;
        vector.y = 0f;
        vector.z = 0f;
        Vector3 result = vector;
        vector = default(Vector3);
        vector.x = 0f;
        vector.y = 0f;
        vector.z = 0f;
        Vector3 vector2 = vector;
        vector2.x = vector3_1.x - vector3_0.x;
        vector2.y = vector3_1.y - vector3_0.y;
        vector2.z = vector3_1.z - vector3_0.z;
        double num = 180.0 / Math.PI;
        result.x = (float)(Math.Atan2(vector2.y, vector2.x) * num);
        result.y = (float)(Math.Atan2(vector2.z, Math.Sqrt(vector2.x * vector2.x + vector2.y * vector2.y)) * num);
        return result;
    }

    private Vector3 method_32(Vector3 vector3_0)
    {
        Vector3 result = vector3_0;
        if (result.x > 180f)
        {
            result.x -= 360f;
        }
        else if (result.x < -180f)
        {
            result.x += 360f;
        }
        if (result.y > 180f)
        {
            result.y -= 360f;
        }
        else if (result.y < -180f)
        {
            result.y += 360f;
        }
        if (result.x < -89f)
        {
            result.x = -89f;
        }
        if (result.x > 89f)
        {
            result.x = 89f;
        }
        while (result.y < 180f)
        {
            result.y += 360f;
        }
        while (result.y > 180f)
        {
            result.y -= 360f;
        }
        result.z = 0f;
        return result;
    }

    private Vector3 相加(Vector3 vector3_0)
    {
        Vector3 result = default(Vector3);
        result.x = (float)Math.Ceiling(vector3_0.x + (float)全地图XY.x);
        result.y = (float)Math.Ceiling(vector3_0.y + (float)全地图XY.y);
        result.z = (float)Math.Ceiling(vector3_0.z + (float)全地图XY.z);
        return result;
    }

    private uint method_34(Vector3 vector3_0)
    {
        return (uint)Math.Sqrt(vector3_0.x * vector3_0.x + vector3_0.y * vector3_0.y + vector3_0.z * vector3_0.z);
    }

    private D3DMATRIX method_35(D3DMATRIX d3DMATRIX_0, D3DMATRIX d3DMATRIX_1)
    {
        D3DMATRIX result = default(D3DMATRIX);
        result._11 = d3DMATRIX_0._11 * d3DMATRIX_1._11 + d3DMATRIX_0._12 * d3DMATRIX_1._21 + d3DMATRIX_0._13 * d3DMATRIX_1._31 + d3DMATRIX_0._14 * d3DMATRIX_1._41;
        result._12 = d3DMATRIX_0._11 * d3DMATRIX_1._12 + d3DMATRIX_0._12 * d3DMATRIX_1._22 + d3DMATRIX_0._13 * d3DMATRIX_1._32 + d3DMATRIX_0._14 * d3DMATRIX_1._42;
        result._13 = d3DMATRIX_0._11 * d3DMATRIX_1._13 + d3DMATRIX_0._12 * d3DMATRIX_1._23 + d3DMATRIX_0._13 * d3DMATRIX_1._33 + d3DMATRIX_0._14 * d3DMATRIX_1._43;
        result._14 = d3DMATRIX_0._11 * d3DMATRIX_1._14 + d3DMATRIX_0._12 * d3DMATRIX_1._24 + d3DMATRIX_0._13 * d3DMATRIX_1._34 + d3DMATRIX_0._14 * d3DMATRIX_1._44;
        result._21 = d3DMATRIX_0._21 * d3DMATRIX_1._11 + d3DMATRIX_0._22 * d3DMATRIX_1._21 + d3DMATRIX_0._23 * d3DMATRIX_1._31 + d3DMATRIX_0._24 * d3DMATRIX_1._41;
        result._22 = d3DMATRIX_0._21 * d3DMATRIX_1._12 + d3DMATRIX_0._22 * d3DMATRIX_1._22 + d3DMATRIX_0._23 * d3DMATRIX_1._32 + d3DMATRIX_0._24 * d3DMATRIX_1._42;
        result._23 = d3DMATRIX_0._21 * d3DMATRIX_1._13 + d3DMATRIX_0._22 * d3DMATRIX_1._23 + d3DMATRIX_0._23 * d3DMATRIX_1._33 + d3DMATRIX_0._24 * d3DMATRIX_1._43;
        result._24 = d3DMATRIX_0._21 * d3DMATRIX_1._14 + d3DMATRIX_0._22 * d3DMATRIX_1._24 + d3DMATRIX_0._23 * d3DMATRIX_1._34 + d3DMATRIX_0._24 * d3DMATRIX_1._44;
        result._31 = d3DMATRIX_0._31 * d3DMATRIX_1._11 + d3DMATRIX_0._32 * d3DMATRIX_1._21 + d3DMATRIX_0._33 * d3DMATRIX_1._31 + d3DMATRIX_0._34 * d3DMATRIX_1._41;
        result._32 = d3DMATRIX_0._31 * d3DMATRIX_1._12 + d3DMATRIX_0._32 * d3DMATRIX_1._22 + d3DMATRIX_0._33 * d3DMATRIX_1._32 + d3DMATRIX_0._34 * d3DMATRIX_1._42;
        result._33 = d3DMATRIX_0._31 * d3DMATRIX_1._13 + d3DMATRIX_0._32 * d3DMATRIX_1._23 + d3DMATRIX_0._33 * d3DMATRIX_1._33 + d3DMATRIX_0._34 * d3DMATRIX_1._43;
        result._34 = d3DMATRIX_0._31 * d3DMATRIX_1._14 + d3DMATRIX_0._32 * d3DMATRIX_1._24 + d3DMATRIX_0._33 * d3DMATRIX_1._34 + d3DMATRIX_0._34 * d3DMATRIX_1._44;
        result._41 = d3DMATRIX_0._41 * d3DMATRIX_1._11 + d3DMATRIX_0._42 * d3DMATRIX_1._21 + d3DMATRIX_0._43 * d3DMATRIX_1._31 + d3DMATRIX_0._44 * d3DMATRIX_1._41;
        result._42 = d3DMATRIX_0._41 * d3DMATRIX_1._12 + d3DMATRIX_0._42 * d3DMATRIX_1._22 + d3DMATRIX_0._43 * d3DMATRIX_1._32 + d3DMATRIX_0._44 * d3DMATRIX_1._42;
        result._43 = d3DMATRIX_0._41 * d3DMATRIX_1._13 + d3DMATRIX_0._42 * d3DMATRIX_1._23 + d3DMATRIX_0._43 * d3DMATRIX_1._33 + d3DMATRIX_0._44 * d3DMATRIX_1._43;
        result._44 = d3DMATRIX_0._41 * d3DMATRIX_1._14 + d3DMATRIX_0._42 * d3DMATRIX_1._24 + d3DMATRIX_0._43 * d3DMATRIX_1._34 + d3DMATRIX_0._44 * d3DMATRIX_1._44;
        return result;
    }

    private bool method_36(float float_2, Vector3 vector3_0, Vector3 vector3_1, Vector3 vector3_2, Vector3 vector3_3, ref Vector2 vector2_7)
    {
        vector3_1.y += (float)(int_25 - int_26) * vector3_1.x / 3f;
        FRotator fRotator = default(FRotator);
        fRotator.Pitch = vector3_0.x + vector3_1.x;
        fRotator.Yaw = vector3_0.y + vector3_1.y;
        fRotator.Roll = vector3_0.z + vector3_1.z;
        FRotator fRotator2 = fRotator;
        D3DMATRIX d3DMATRIX = fRotator2.Matrix();
        Vector3 vector = default(Vector3);
        vector.x = d3DMATRIX._11;
        vector.y = d3DMATRIX._12;
        vector.z = d3DMATRIX._13;
        Vector3 v = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._21;
        vector.y = d3DMATRIX._22;
        vector.z = d3DMATRIX._23;
        Vector3 v2 = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._31;
        vector.y = d3DMATRIX._32;
        vector.z = d3DMATRIX._33;
        Vector3 v3 = vector;
        Vector3 vector2 = 相减(vector3_3, vector3_2);
        vector = default(Vector3);
        vector.x = vector2.Dot(v2);
        vector.y = vector2.Dot(v3);
        vector.z = vector2.Dot(v);
        Vector3 vector3 = vector;
        if (vector3.z < 1f)
        {
            vector3.z = 1f;
        }
        if (vector3.z / 100f < 0f)
        {
            return false;
        }
        vector2_7.x = (float)(960.0 + (double)(vector3.x * 1920f) / 2.0 / (double)(float)Math.Tan((double)float_2 * Math.PI / 360.0) / (double)vector3.z);
        vector2_7.y = (float)(540.0 - (double)(vector3.y * 1920f) / 2.0 / (double)(float)Math.Tan((double)float_2 * Math.PI / 360.0) / (double)vector3.z);
        if (vector2_7.x > 0f && vector2_7.y > 0f && (double)vector2_7.x <= 1920.0 && (double)vector2_7.y <= 1080.0)
        {
            return true;
        }
        return false;
    }

    private bool method_37(float float_2, Vector3 vector3_0, Vector3 vector3_1, Vector3 vector3_2, Vector3 vector3_3, ref Vector2 vector2_7)
    {
        vector3_1.y += (float)(int_25 - int_26) * vector3_1.x / 3f;
        FRotator fRotator = default(FRotator);
        fRotator.Pitch = vector3_0.x + vector3_1.x;
        fRotator.Yaw = vector3_0.y + vector3_1.y;
        fRotator.Roll = vector3_0.z + vector3_1.z;
        FRotator fRotator2 = fRotator;
        D3DMATRIX d3DMATRIX = fRotator2.Matrix();
        Vector3 vector = default(Vector3);
        vector.x = d3DMATRIX._11;
        vector.y = d3DMATRIX._12;
        vector.z = d3DMATRIX._13;
        Vector3 v = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._21;
        vector.y = d3DMATRIX._22;
        vector.z = d3DMATRIX._23;
        Vector3 v2 = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._31;
        vector.y = d3DMATRIX._32;
        vector.z = d3DMATRIX._33;
        Vector3 v3 = vector;
        Vector3 vector2 = 相减(vector3_3, vector3_2);
        vector = default(Vector3);
        vector.x = vector2.Dot(v2);
        vector.y = vector2.Dot(v3);
        vector.z = vector2.Dot(v);
        Vector3 vector3 = vector;
        if (vector3.z < 1f)
        {
            vector3.z = 1f;
        }
        if (vector3.z / 100f < 0f)
        {
            return false;
        }
        vector2_7.x = (float)((double)X分辨率 / 2.0 + (double)(vector3.x * (float)X分辨率) / 2.0 / (double)(float)Math.Tan((double)float_2 * Math.PI / 360.0) / (double)vector3.z);
        vector2_7.y = (float)((double)Y分辨率 / 2.0 - (double)(vector3.y * (float)X分辨率) / 2.0 / (double)(float)Math.Tan((double)float_2 * Math.PI / 360.0) / (double)vector3.z);
        if (vector2_7.x > 0f && vector2_7.y > 0f && (double)vector2_7.x <= (double)(float)X分辨率 / 2.0 * 2.0 && (double)vector2_7.y <= (double)(float)Y分辨率 / 2.0 * 2.0)
        {
            return true;
        }
        return false;
    }


    private bool 计算是否在屏幕(ref Vector2 vector2_7)
    {
        if (vector2_7.x > 0f && vector2_7.y > 0f && (double)vector2_7.x <= (double)(float)X分辨率 / 2.0 * 2.0 && (double)vector2_7.y <= (double)(float)Y分辨率 / 2.0 * 2.0)
        {
            return true;
        }
        return false;
    }


    private Vector2 method_38(Vector3 vector3_0, FCameraCacheData fcameraCacheData_0)
    {
        Vector2 result = default(Vector2);
        D3DMATRIX d3DMATRIX = fcameraCacheData_0.POV.Rotation.Matrix();
        Vector3 vector = default(Vector3);
        vector.x = d3DMATRIX._11;
        vector.y = d3DMATRIX._12;
        vector.z = d3DMATRIX._13;
        Vector3 v = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._21;
        vector.y = d3DMATRIX._22;
        vector.z = d3DMATRIX._23;
        Vector3 v2 = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._31;
        vector.y = d3DMATRIX._32;
        vector.z = d3DMATRIX._33;
        Vector3 v3 = vector;
        Vector3 vector2 = 相减(vector3_0, fcameraCacheData_0.POV.Location);
        vector = default(Vector3);
        vector.x = vector2.Dot(v2);
        vector.y = vector2.Dot(v3);
        vector.z = vector2.Dot(v);
        Vector3 vector3 = vector;
        if (vector3.z < 1f)
        {
            vector3.z = 1f;
        }
        float fOV = fcameraCacheData_0.POV.FOV;
        result.x = (float)((double)((float)X分辨率 / 2f) + (double)vector3.x * ((double)((float)X分辨率 / 2f) / Math.Tan(fOV * (float)Math.PI / 360f)) / (double)vector3.z);
        result.y = (float)((double)((float)Y分辨率 / 2f) - (double)vector3.y * ((double)((float)X分辨率 / 2f) / Math.Tan(fOV * (float)Math.PI / 360f)) / (double)vector3.z);
        return result;
    }

    private Vector2 计算透视坐标(Vector3 vector3_0)
    {
        Vector2 result = default(Vector2);
        D3DMATRIX d3DMATRIX = class_本人.fcameraCacheData_0.POV.Rotation.Matrix();
        Vector3 vector = default(Vector3);
        vector.x = d3DMATRIX._11;
        vector.y = d3DMATRIX._12;
        vector.z = d3DMATRIX._13;
        Vector3 v = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._21;
        vector.y = d3DMATRIX._22;
        vector.z = d3DMATRIX._23;
        Vector3 v2 = vector;
        vector = default(Vector3);
        vector.x = d3DMATRIX._31;
        vector.y = d3DMATRIX._32;
        vector.z = d3DMATRIX._33;
        Vector3 v3 = vector;
        Vector3 vector2 = 相减(vector3_0, class_本人.fcameraCacheData_0.POV.Location);
        vector = default(Vector3);
        vector.x = vector2.Dot(v2);
        vector.y = vector2.Dot(v3);
        vector.z = vector2.Dot(v);
        Vector3 vector3 = vector;
        if (vector3.z < 1f)
        {
            vector3.z = 1f;
        }
        float fOV = class_本人.fcameraCacheData_0.POV.FOV;
        result.x = (float)((double)((float)X分辨率 / 2f) + (double)vector3.x * ((double)((float)X分辨率 / 2f) / Math.Tan(fOV * (float)Math.PI / 360f)) / (double)vector3.z);
        result.y = (float)((double)((float)Y分辨率 / 2f) - (double)vector3.y * ((double)((float)X分辨率 / 2f) / Math.Tan(fOV * (float)Math.PI / 360f)) / (double)vector3.z);
        return result;
    }

    private float method_40(float float_2, float float_3, float float_4, float float_5)
    {
        float_2 -= float_4;
        float_3 -= float_5;
        return (float)Math.Sqrt(float_2 * float_2 + float_3 * float_3);
    }

    private Vector3 计算抬枪量(Vector3 骨骼点坐标, float 距离, Vector3 预判)
    {
        if (class_本人.float_0 == 0f)
        {
            class_本人.float_0 = 800f;
        }
        float num = ((距离 < 50f) ? class7_0.Gun50 : ((距离 < 100f) ? class7_0.Gun100 : ((距离 < 150f) ? class7_0.Gun150 : ((距离 < 200f) ? class7_0.Gun200 : ((距离 < 250f) ? class7_0.Gun250 : ((距离 < 300f) ? class7_0.Gun300 : ((距离 < 350f) ? class7_0.Gun350 : ((距离 < 400f) ? class7_0.Gun400 : ((距离 < 450f) ? class7_0.Gun450 : ((距离 < 500f) ? class7_0.Gun500 : ((距离 < 550f) ? class7_0.Gun550 : ((距离 < 600f) ? class7_0.Gun600 : class7_0.Gun999))))))))))));
        float num2 = 距离 / class_本人.float_0 * num;
        Vector3 result = default(Vector3);
        result.x = 骨骼点坐标.x + 预判.x * num2;
        result.y = 骨骼点坐标.y + 预判.y * num2;
        result.z = 骨骼点坐标.z + 预判.z * num2;
        result.z += 4.9f * (float)Math.Pow(num2, 2.0) * (距离 / 5f) * class7_0.抬枪量;
        return result;
    }

    private Vector3 method_42(Vector3 vector3_0, float float_2, Vector3 vector3_1, float float_3, string string_12)
    {
        float num = ((float_2 < 50f) ? class7_0.Gun50 : ((float_2 < 100f) ? class7_0.Gun100 : ((float_2 < 150f) ? class7_0.Gun150 : ((float_2 < 200f) ? class7_0.Gun200 : ((float_2 < 250f) ? class7_0.Gun250 : ((float_2 < 300f) ? class7_0.Gun300 : ((float_2 < 350f) ? class7_0.Gun350 : ((float_2 < 400f) ? class7_0.Gun400 : ((float_2 < 450f) ? class7_0.Gun450 : ((float_2 < 500f) ? class7_0.Gun500 : ((float_2 < 550f) ? class7_0.Gun550 : ((float_2 < 600f) ? class7_0.Gun600 : class7_0.Gun999))))))))))));
        float num2 = float_2 / float_3 * num;
        Vector3 result = default(Vector3);
        result.x = vector3_0.x + vector3_1.x * num2;
        result.y = vector3_0.y + vector3_1.y * num2;
        result.z = vector3_0.z + vector3_1.z * num2 + 4.9f * (float)Math.Pow(num2, 2.0) * 0.2f * class7_0.抬枪量 * float_2;
        return result;
    }

    private PlayerInfo 获取战绩数据1(string name, bool bool_50 = true)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        PlayerInfo playerInfo = new PlayerInfo();
        string text = "";
        string text2 = "";
        if (!(name == ""))
        {
            string text3 = "";
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create("https://pubg.op.gg/user/" + name + "?hl=zh_CN");
            try
            {
                using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
                {
                    if (httpWebResponse.StatusCode != HttpStatusCode.OK)
                    {
                        if (debug)
                        {
                            状态2(name + " 战绩获取失败(1)! 网络问题");
                        }
                        return playerInfo;
                    }
                    using (Stream stream = httpWebResponse.GetResponseStream())
                    {
                        using (StreamReader streamReader = new StreamReader(stream))
                        {
                            string[] array = streamReader.ReadToEnd().Trim().Replace("\"\n", "\"")
                                .Replace("\"\r", "\"")
                                .Replace("\"\n", "\"")
                                .Split('\r', '\n');
                            foreach (string text4 in array)
                            {
                                if (text4.Contains("data-user_id") || text4.Contains("data-status=\"pc"))
                                {
                                    string[] array2 = text4.Split(' ');
                                    foreach (string text5 in array2)
                                    {
                                        if (text5.Trim().StartsWith("data-user_id") && text3 == "")
                                        {
                                            text3 = text5.Split('"')[1];
                                        }
                                        if (text5.Trim().StartsWith("data-status=\"pc") && string_0 == "")
                                        {
                                            string_0 = text5.Split('"')[1];
                                        }
                                    }
                                }
                                if (!text4.Trim().Contains("recent-matches__stat-value"))
                                {
                                    continue;
                                }
                                string text6 = text4.Trim().Replace(" ", "").Replace("<divclass=", "");
                                if (!text6.Contains("data-damage"))
                                {
                                    if (!text6.Contains("survive-time"))
                                    {
                                        text2 = text6.Split('>', '<')[1];
                                    }
                                }
                                else
                                {
                                    text = text6.Split('>', '<')[1];
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (debug)
                {
                    状态2(name + " 战绩获取失败(2)!" + ex.Message);
                }
                return playerInfo;
            }
            if (!(text3 == ""))
            {
                playerInfo.id = text3;
                playerInfo.name = name;
                try
                {
                    playerInfo.cs = Math.Floor(decimal.Parse(text));
                    playerInfo.KD = Math.Round(decimal.Parse(text2), 1);
                }
                catch
                {
                    if (debug)
                    {
                        状态2("发生异常: D:" + text + " KD:" + text2);
                    }
                    return playerInfo;
                }
                if (bool_50)
                {
                    string text7 = "";
                    try
                    {
                        text7 = "https://pubg.op.gg/api/users/" + text3 + "/renew";
                        httpWebRequest = (HttpWebRequest)WebRequest.Create(text7);
                        httpWebRequest.Method = "POST";
                        httpWebRequest.ContentType = "application/json;charset=UTF-8";
                        string s = "{\"_method\":\"PATCH\",\"type\":\"matches\"}";
                        byte[] bytes = Encoding.UTF8.GetBytes(s);
                        int num = bytes.Length;
                        httpWebRequest.ContentLength = num;
                        using (Stream stream2 = httpWebRequest.GetRequestStream())
                        {
                            stream2.Write(bytes, 0, num);
                            using (HttpWebResponse httpWebResponse2 = (HttpWebResponse)httpWebRequest.GetResponse())
                            {
                                HttpStatusCode statusCode = httpWebResponse2.StatusCode;
                                return playerInfo;
                            }
                        }
                    }
                    catch (Exception ex2)
                    {
                        if (debug)
                        {
                            状态2(name + " 战绩获取失败(3)!" + text7 + " " + ex2.Message);
                        }
                        return playerInfo;
                    }
                }
                return playerInfo;
            }
            return playerInfo;
        }
        return playerInfo;
    }

    private PlayerInfo method_段位(PlayerInfo playerInfo_0, string string_12 = "competitive-tpp")
    {
        HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create("https://pubg.op.gg/api/users/" + playerInfo_0.id + "/ranked-stats?season=" + string_0 + "&queue_size=4&mode=" + string_12);
        try
        {
            using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
            {
                if (httpWebResponse.StatusCode == HttpStatusCode.OK)
                {
                    using (Stream stream = httpWebResponse.GetResponseStream())
                    {
                        using (StreamReader streamReader = new StreamReader(stream))
                        {
                            string text = streamReader.ReadToEnd();
                            if (text == null)
                            {
                                if (debug)
                                {
                                    状态2(playerInfo_0.name + " 战绩获取失败(3)!网络错误!");
                                }
                                return playerInfo_0;
                            }
                            PlayerInfo playerInfo = JsonConvert.DeserializeObject<PlayerInfo>(text);
                            //if (!(playerInfo.stats.kills_sum > 0m))
                            //{
                            //    return playerInfo_0;
                            //}
                            playerInfo_0.stats.kills_sum = playerInfo.stats.kills_sum;
                            playerInfo_0.stats.deaths_sum = playerInfo.stats.deaths_sum;
                            playerInfo_0.stats.damage_dealt_avg = playerInfo.stats.damage_dealt_avg;
                            playerInfo_0.stats.rank_points = playerInfo.stats.rank_points;
                            if (playerInfo_0.stats.rank_points < 2100m)
                            {
                                playerInfo_0.Rank = "菜狗";
                            }
                            if (playerInfo_0.stats.rank_points >= 2000m && playerInfo_0.stats.rank_points < 2100m)
                            {
                                playerInfo_0.Rank = "黄金5";
                            }
                            if (playerInfo_0.stats.rank_points >= 2100m && playerInfo_0.stats.rank_points < 2200m)
                            {
                                playerInfo_0.Rank = "黄金4";
                            }
                            if (playerInfo_0.stats.rank_points >= 2200m && playerInfo_0.stats.rank_points < 2300m)
                            {
                                playerInfo_0.Rank = "黄金3";
                            }
                            if (playerInfo_0.stats.rank_points >= 2300m && playerInfo_0.stats.rank_points < 2400m)
                            {
                                playerInfo_0.Rank = "黄金2";
                            }
                            if (playerInfo_0.stats.rank_points >= 2400m && playerInfo_0.stats.rank_points < 2500m)
                            {
                                playerInfo_0.Rank = "黄金1";
                            }
                            if (playerInfo_0.stats.rank_points >= 2500m && playerInfo_0.stats.rank_points < 2600m)
                            {
                                playerInfo_0.Rank = "白金5";
                            }
                            if (playerInfo_0.stats.rank_points >= 2600m && playerInfo_0.stats.rank_points < 2700m)
                            {
                                playerInfo_0.Rank = "白金4";
                            }
                            if (playerInfo_0.stats.rank_points >= 2700m && playerInfo_0.stats.rank_points < 2800m)
                            {
                                playerInfo_0.Rank = "白金3";
                            }
                            if (playerInfo_0.stats.rank_points >= 2800m && playerInfo_0.stats.rank_points < 2900m)
                            {
                                playerInfo_0.Rank = "白金2";
                            }
                            if (playerInfo_0.stats.rank_points >= 2900m && playerInfo_0.stats.rank_points < 3000m)
                            {
                                playerInfo_0.Rank = "白金1";
                            }
                            if (playerInfo_0.stats.rank_points >= 3000m && playerInfo_0.stats.rank_points < 3100m)
                            {
                                playerInfo_0.Rank = "钻5";
                            }
                            if (playerInfo_0.stats.rank_points >= 3100m && playerInfo_0.stats.rank_points < 3200m)
                            {
                                playerInfo_0.Rank = "钻4";
                            }
                            if (playerInfo_0.stats.rank_points >= 3200m && playerInfo_0.stats.rank_points < 3300m)
                            {
                                playerInfo_0.Rank = "钻3";
                            }
                            if (playerInfo_0.stats.rank_points >= 3300m && playerInfo_0.stats.rank_points < 3400m)
                            {
                                playerInfo_0.Rank = "钻2";
                            }
                            if (playerInfo_0.stats.rank_points >= 3400m && playerInfo_0.stats.rank_points < 3500m)
                            {
                                playerInfo_0.Rank = "钻1";
                            }
                            if (playerInfo_0.stats.rank_points >= 3500m)
                            {
                                playerInfo_0.Rank = "大师";
                            }
                            playerInfo_0.KD = Math.Round(playerInfo.stats.kills_sum / ((playerInfo.stats.deaths_sum == 0m) ? 1m : playerInfo.stats.deaths_sum), 1);
                            playerInfo_0.cs = Math.Floor(playerInfo.stats.damage_dealt_avg);
                            return playerInfo_0;
                        }
                    }
                }
                return playerInfo_0;
            }
        }
        catch
        {
            return playerInfo_0;
        }
    }



    private Vector3 method_45(FB_vector3 fb_vector3_0)
    {
        Vector3 result = default(Vector3);
        result.x = fb_vector3_0.X;
        result.y = fb_vector3_0.Y;
        result.z = fb_vector3_0.Z;
        return result;
    }

    private Vector2 method_46(FB_vector2 fb_vector2_0)
    {
        Vector2 result = default(Vector2);
        result.x = fb_vector2_0.X;
        result.y = fb_vector2_0.Y;
        return result;
    }

    private Vector2 GetFov(Vector2 pos, float angle, float len)
    {
        float rad = (float)(angle * Math.PI / 180);
        return new Vector2
        {
            x = (float)(pos.x + Math.Cos(rad) * len),
            y = (float)(pos.y + Math.Cos(rad) * len)
        };
    }


    private void 融合器透视()
    {
        Stopwatch stopwatch_融合器线程 = new Stopwatch();
        List<Actor人物> 人物 = new List<Actor人物>();
        List<Class4> 地图资源 = new List<Class4>();
        Class9 @class = new Class9(pid, vmm);

        while (ThreadRunning)
        {
            try
            {
                if (透视 && !当前地图.Contains("TslLobby"))
                {
                    stopwatch_融合器线程.Restart();
                    stopwatch_融合器线程.Start();
                    List<Actor人物> result;
                    List<Class4> result2;

                    while (concurrentQueue_人物.TryDequeue(out result))
                    {
                        if (result != null && result.Count > 0)
                        {
                            人物 = result;
                        }
                    }
                    while (concurrentQueue_地图资源.TryDequeue(out result2))
                    {
                        if (result2 != null && result2.Count > 0)
                        {
                            地图资源 = result2;
                        }
                    }
                    if (人物.Count > 0 || 地图资源.Count > 0)
                    {
                        stopwatch_融合器线程.Stop();
                        int 融合器线程 = (int)stopwatch_融合器线程.Elapsed.TotalMilliseconds;
                        if (融合器线程 < 1000 / 帧率 - 2)
                        {
                            帧率锁((1000 / 帧率 - 2) - 融合器线程);
                        }
                        @class.Clear();
                        @class.Add<float>(class_本人.投影相机 + CameraFov);
                        @class.Add<FRotator>(class_本人.投影相机 + CameraRot);
                        @class.Add<Vector3>(class_本人.投影相机 + CameraPos);
                        @class.Finish();
                        class_本人.fcameraCacheData_0.POV.FOV = @class.Get<float>(class_本人.投影相机 + CameraFov);
                        class_本人.fcameraCacheData_0.POV.Rotation = @class.Get<FRotator>(class_本人.投影相机 + CameraRot);
                        class_本人.fcameraCacheData_0.POV.Location = @class.Get<Vector3>(class_本人.投影相机 + CameraPos);
                        if (CommonProperty.pgConfig.EspConfig.大地图 && !自瞄)
                        {
                            @class.Add<int>(class_本人.玩家控制 + 地图判断);
                            @class.Finish();
                            全_地图状态 = @class.Get<int>(class_本人.玩家控制 + 地图判断);
                            if (全_地图状态 == 3)
                            {
                                setMap();
                                大地图();
                            }
                        }
                        if (人物.Count > 0)
                        {
                            if (瞄准)
                            {
                                地图资源.Clear();
                                foreach (Actor人物 item55 in 人物)
                                {
                                    if (item55.活人 && item55.骨盆.x > 0 && item55.骨盆.y > 0 && item55.骨盆.x < X分辨率 && item55.骨盆.y < Y分辨率)
                                    {
                                        TS.Prepare(item55.人物视角 + BoneArry, 50);
                                        TS.Prepare(item55.人物视角 + Bone, 4);
                                    }
                                }
                                TS.Execute();
                                foreach (Actor人物 item66 in 人物)
                                {
                                    if (item66.活人 && item66.骨盆.x > 0 && item66.骨盆.y > 0 && item66.骨盆.x < X分辨率 && item66.骨盆.y < Y分辨率)
                                    {
                                        item66.Actor_Bone = TS.Read<FTransform>(item66.人物视角 + BoneArry);
                                        item66.Bone = TS.Read<ulong>(item66.人物视角 + Bone);
                                    }
                                }
                                TS.Clear(pid, Vmm.FLAG_NOCACHE);

                                foreach (Actor人物 item72 in 人物)
                                {
                                    if (item72.活人 && item72.距离 < CommonProperty.pgConfig.EspConfig.透视距离 && item72.骨盆.x > 0 && item72.骨盆.y > 0 && item72.骨盆.x < X分辨率 && item72.骨盆.y < Y分辨率)
                                    {
                                        TS.Prepare(item72.Bone + (ulong)头部 * 48L, 12);
                                        TS.Prepare(item72.Bone + (ulong)骨盆 * 48L, 12);
                                        if (CommonProperty.pgConfig.EspConfig.骨骼)
                                        {
                                            TS.Prepare(item72.Bone + (ulong)颈部 * 48L, 12);
                                            TS.Prepare(item72.Bone + (ulong)胸部 * 48L, 12);
                                            //TS.Prepare(item72.Bone + (ulong)左肩 * 48L);
                                            //TS.Prepare(item72.Bone + (ulong)右肩 * 48L);
                                            TS.Prepare(item72.Bone + (ulong)左肘 * 48L, 12);
                                            TS.Prepare(item72.Bone + (ulong)右肘 * 48L, 12);
                                            TS.Prepare(item72.Bone + (ulong)左手 * 48L, 12);
                                            TS.Prepare(item72.Bone + (ulong)右手 * 48L, 12);
                                            //TS.Prepare(item72.Bone + (ulong)左胯 * 48L);
                                            //TS.Prepare(item72.Bone + (ulong)右胯 * 48L);
                                            TS.Prepare(item72.Bone + (ulong)左膝 * 48L, 12);
                                            TS.Prepare(item72.Bone + (ulong)右膝 * 48L, 12);
                                            TS.Prepare(item72.Bone + (ulong)左脚 * 48L, 12);
                                            TS.Prepare(item72.Bone + (ulong)右脚 * 48L, 12);
                                        }
                                    }
                                }
                                TS.Execute();
                                foreach (Actor人物 item82 in 人物)
                                {
                                    if (item82.活人 && item82.距离 < CommonProperty.pgConfig.EspConfig.透视距离 && item82.骨盆.x > 0 && item82.骨盆.y > 0 && item82.骨盆.x < X分辨率 && item82.骨盆.y < Y分辨率)
                                    {
                                        item82.头部_Bone = TS.Read<FTransform>(item82.Bone + (ulong)头部 * 48L);
                                        item82.骨盆_Bone = TS.Read<FTransform>(item82.Bone + (ulong)骨盆 * 48L);
                                        if (CommonProperty.pgConfig.EspConfig.骨骼)
                                        {
                                            item82.颈部_Bone = TS.Read<FTransform>(item82.Bone + (ulong)颈部 * 48L);
                                            item82.胸部_Bone = TS.Read<FTransform>(item82.Bone + (ulong)胸部 * 48L);
                                            //item82.左肩_Bone = TS.Read<FTransform>(item82.Bone + (ulong)左肩 * 48L);
                                            //item82.右肩_Bone = TS.Read<FTransform>(item82.Bone + (ulong)右肩 * 48L);
                                            item82.左肘_Bone = TS.Read<FTransform>(item82.Bone + (ulong)左肘 * 48L);
                                            item82.右肘_Bone = TS.Read<FTransform>(item82.Bone + (ulong)右肘 * 48L);
                                            item82.左手_Bone = TS.Read<FTransform>(item82.Bone + (ulong)左手 * 48L);
                                            item82.右手_Bone = TS.Read<FTransform>(item82.Bone + (ulong)右手 * 48L);
                                            //item82.左胯_Bone = TS.Read<FTransform>(item82.Bone + (ulong)左胯 * 48L);
                                            //item82.右胯_Bone = TS.Read<FTransform>(item82.Bone + (ulong)右胯 * 48L);
                                            item82.左膝_Bone = TS.Read<FTransform>(item82.Bone + (ulong)左膝 * 48L);
                                            item82.右膝_Bone = TS.Read<FTransform>(item82.Bone + (ulong)右膝 * 48L);
                                            item82.左脚跟_Bone = TS.Read<FTransform>(item82.Bone + (ulong)左脚 * 48L);
                                            item82.右脚跟_Bone = TS.Read<FTransform>(item82.Bone + (ulong)右脚 * 48L);
                                        }

                                    }
                                }
                                TS.Clear(pid, Vmm.FLAG_NOCACHE);
                                foreach (Actor人物 item9 in 人物)
                                {
                                    if (item9.活人 && 透视 && item9.距离 < CommonProperty.pgConfig.EspConfig.透视距离 && item9.骨盆.x > 0 && item9.骨盆.y > 0 && item9.骨盆.x < X分辨率 && item9.骨盆.y < Y分辨率)
                                    {
                                        D3DMATRIX d3DMATRIX_3 = item9.骨盆_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX2 = method_35(d3DMATRIX_3, item9.Actor_Bone.ToMatrixWithScale());
                                        item9.vector3_骨盆.x = d3DMATRIX2._41;
                                        item9.vector3_骨盆.y = d3DMATRIX2._42;
                                        item9.vector3_骨盆.z = d3DMATRIX2._43;
                                        item9.骨盆 = 计算透视坐标(item9.vector3_骨盆);
                                        D3DMATRIX d3DMATRIX_4 = item9.头部_Bone.ToMatrixWithScale();
                                        D3DMATRIX d3DMATRIX3 = method_35(d3DMATRIX_4, item9.Actor_Bone.ToMatrixWithScale());
                                        item9.vector3_头部.x = d3DMATRIX3._41;
                                        item9.vector3_头部.y = d3DMATRIX3._42;
                                        item9.vector3_头部.z = d3DMATRIX3._43;
                                        item9.头部 = 计算透视坐标(item9.vector3_头部);
                                        if (CommonProperty.pgConfig.EspConfig.骨骼)
                                        {
                                            D3DMATRIX d3DMATRIX_5 = item9.颈部_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX4 = method_35(d3DMATRIX_5, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_颈部.x = d3DMATRIX4._41;
                                            item9.vector3_颈部.y = d3DMATRIX4._42;
                                            item9.vector3_颈部.z = d3DMATRIX4._43;
                                            item9.颈部 = 计算透视坐标(item9.vector3_颈部);
                                            D3DMATRIX d3DMATRIX_6 = item9.胸部_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX5 = method_35(d3DMATRIX_6, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_胸部.x = d3DMATRIX5._41;
                                            item9.vector3_胸部.y = d3DMATRIX5._42;
                                            item9.vector3_胸部.z = d3DMATRIX5._43;
                                            item9.胸部 = 计算透视坐标(item9.vector3_胸部);
                                            D3DMATRIX d3DMATRIX_7 = item9.左肘_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX6 = method_35(d3DMATRIX_7, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_左肘.x = d3DMATRIX6._41;
                                            item9.vector3_左肘.y = d3DMATRIX6._42;
                                            item9.vector3_左肘.z = d3DMATRIX6._43;
                                            item9.左肘 = 计算透视坐标(item9.vector3_左肘);
                                            D3DMATRIX d3DMATRIX_8 = item9.右肘_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX7 = method_35(d3DMATRIX_8, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_右肘.x = d3DMATRIX7._41;
                                            item9.vector3_右肘.y = d3DMATRIX7._42;
                                            item9.vector3_右肘.z = d3DMATRIX7._43;
                                            item9.右肘 = 计算透视坐标(item9.vector3_右肘);
                                            D3DMATRIX d3DMATRIX_9 = item9.左手_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX8 = method_35(d3DMATRIX_9, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_左手.x = d3DMATRIX8._41;
                                            item9.vector3_左手.y = d3DMATRIX8._42;
                                            item9.vector3_左手.z = d3DMATRIX8._43;
                                            item9.左手 = 计算透视坐标(item9.vector3_左手);
                                            D3DMATRIX d3DMATRIX_10 = item9.右手_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX9 = method_35(d3DMATRIX_10, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_右手.x = d3DMATRIX9._41;
                                            item9.vector3_右手.y = d3DMATRIX9._42;
                                            item9.vector3_右手.z = d3DMATRIX9._43;
                                            item9.右手 = 计算透视坐标(item9.vector3_右手);
                                            D3DMATRIX d3DMATRIX_11 = item9.左膝_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX10 = method_35(d3DMATRIX_11, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_左膝.x = d3DMATRIX10._41;
                                            item9.vector3_左膝.y = d3DMATRIX10._42;
                                            item9.vector3_左膝.z = d3DMATRIX10._43;
                                            item9.左膝 = 计算透视坐标(item9.vector3_左膝);
                                            D3DMATRIX d3DMATRIX_12 = item9.右膝_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX11 = method_35(d3DMATRIX_12, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_右膝.x = d3DMATRIX11._41;
                                            item9.vector3_右膝.y = d3DMATRIX11._42;
                                            item9.vector3_右膝.z = d3DMATRIX11._43;
                                            item9.右膝 = 计算透视坐标(item9.vector3_右膝);
                                            D3DMATRIX d3DMATRIX_13 = item9.左脚跟_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX12 = method_35(d3DMATRIX_13, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_左脚跟.x = d3DMATRIX12._41;
                                            item9.vector3_左脚跟.y = d3DMATRIX12._42;
                                            item9.vector3_左脚跟.z = d3DMATRIX12._43;
                                            item9.左脚跟 = 计算透视坐标(item9.vector3_左脚跟);
                                            D3DMATRIX d3DMATRIX_14 = item9.右脚跟_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX13 = method_35(d3DMATRIX_14, item9.Actor_Bone.ToMatrixWithScale());
                                            item9.vector3_右脚跟.x = d3DMATRIX13._41;
                                            item9.vector3_右脚跟.y = d3DMATRIX13._42;
                                            item9.vector3_右脚跟.z = d3DMATRIX13._43;
                                            item9.右脚跟 = 计算透视坐标(item9.vector3_右脚跟);
                                            //D3DMATRIX d3DMATRIX_55 = item9.左肩_Bone.ToMatrixWithScale();
                                            //D3DMATRIX d3DMATRIX44 = method_35(d3DMATRIX_55, item9.Actor_Bone.ToMatrixWithScale());
                                            //item9.vector3_左肩.x = d3DMATRIX44._41;
                                            //item9.vector3_左肩.y = d3DMATRIX44._42;
                                            //item9.vector3_左肩.z = d3DMATRIX44._43;
                                            //item9.左肩 = 计算透视坐标(item9.vector3_左肩);
                                            //D3DMATRIX d3DMATRIX_66 = item9.右肩_Bone.ToMatrixWithScale();
                                            //D3DMATRIX d3DMATRIX55 = method_35(d3DMATRIX_66, item9.Actor_Bone.ToMatrixWithScale());
                                            //item9.vector3_右肩.x = d3DMATRIX55._41;
                                            //item9.vector3_右肩.y = d3DMATRIX55._42;
                                            //item9.vector3_右肩.z = d3DMATRIX55._43;
                                            //item9.右肩 = 计算透视坐标(item9.vector3_右肩);
                                            //D3DMATRIX d3DMATRIX_555 = item9.左胯_Bone.ToMatrixWithScale();
                                            //D3DMATRIX d3DMATRIX444 = method_35(d3DMATRIX_555, item9.Actor_Bone.ToMatrixWithScale());
                                            //item9.vector3_左胯.x = d3DMATRIX444._41;
                                            //item9.vector3_左胯.y = d3DMATRIX444._42;
                                            //item9.vector3_左胯.z = d3DMATRIX444._43;
                                            //item9.左胯 = 计算透视坐标(item9.vector3_左胯);
                                            //D3DMATRIX d3DMATRIX_666 = item9.右胯_Bone.ToMatrixWithScale();
                                            //D3DMATRIX d3DMATRIX555 = method_35(d3DMATRIX_666, item9.Actor_Bone.ToMatrixWithScale());
                                            //item9.vector3_右胯.x = d3DMATRIX555._41;
                                            //item9.vector3_右胯.y = d3DMATRIX555._42;
                                            //item9.vector3_右胯.z = d3DMATRIX555._43;
                                            //item9.右胯 = 计算透视坐标(item9.vector3_右胯);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                foreach (Actor人物 item3 in 人物)
                                {
                                    if (item3.活人 && 透视 && item3.距离 < CommonProperty.pgConfig.EspConfig.透视距离 && item3.骨盆.x > 0 && item3.骨盆.y > 0 && item3.骨盆.x < X分辨率 && item3.骨盆.y < Y分辨率)
                                    {
                                        item3.骨盆 = 计算透视坐标(item3.vector3_骨盆);
                                        item3.头部 = 计算透视坐标(item3.vector3_头部);
                                        if (CommonProperty.pgConfig.EspConfig.骨骼)
                                        {
                                            item3.颈部 = 计算透视坐标(item3.vector3_颈部);
                                            item3.胸部 = 计算透视坐标(item3.vector3_胸部);
                                            item3.左肘 = 计算透视坐标(item3.vector3_左肘);
                                            item3.右肘 = 计算透视坐标(item3.vector3_右肘);
                                            item3.左手 = 计算透视坐标(item3.vector3_左手);
                                            item3.右手 = 计算透视坐标(item3.vector3_右手);
                                            item3.左膝 = 计算透视坐标(item3.vector3_左膝);
                                            item3.右膝 = 计算透视坐标(item3.vector3_右膝);
                                            item3.左脚跟 = 计算透视坐标(item3.vector3_左脚跟);
                                            item3.右脚跟 = 计算透视坐标(item3.vector3_右脚跟);
                                            //item3.左肩 = 计算透视坐标(item3.vector3_左肩);
                                            //item3.右肩 = 计算透视坐标(item3.vector3_右肩);
                                            //item3.左胯 = 计算透视坐标(item3.vector3_左胯);
                                            //item3.右胯 = 计算透视坐标(item3.vector3_右胯);
                                        }
                                    }
                                }
                            }
                            if (!透视)
                            {
                                continue;
                            }
                            float 小地图透视距离 = 200f;
                            if (小地图放大)
                            {
                                小地图透视距离 *= float_1 / float_0;
                            }
                            Vector2 vector = (小地图放大 ? vector2_5 : vector2_3);
                            Vector2 vector2 = ((!小地图放大) ? vector2_4 : vector2_6);
                            Vector3 vector3 = default(Vector3);
                            Vector2 vector4 = default(Vector2);
                            List<Actor人物> espData = new List<Actor人物>();
                            foreach (Actor人物 item4 in 人物)
                            {
                                if (!item4.活人 || item4.是否友军 != 0)
                                {
                                    continue;
                                }
                                if (CommonProperty.pgConfig.EspConfig.小地图 && (float)item4.距离 <= 小地图透视距离 && uint_2 == 0 && !class_本人.bool_0 && MinimapCanvasWidgetAddr != 0L && !自瞄)
                                {
                                    vector3.x = (item4.vector3_距离坐标.x - class_本人.vector3_距离坐标.x) * 0.01f;
                                    vector3.y = (item4.vector3_距离坐标.y - class_本人.vector3_距离坐标.y) * 0.01f;
                                    //vector3.z = (item4.vector3_距离坐标.z - class_本人.vector3_距离坐标.z) * 0.01f;
                                    vector4.x = vector2.x * (float)X分辨率 + (1f + vector3.x / 小地图透视距离) * vector.x / 2f * (float)X分辨率;
                                    vector4.y = vector2.y * (float)Y分辨率 + (1f + vector3.y / 小地图透视距离) * vector.y / 2f * (float)Y分辨率;
                                    //vector4.z = 0f;
                                    item4.vector3_小地图 = vector4;
                                }
                                else
                                {
                                    item4.vector3_小地图.x = 0;
                                    item4.vector3_小地图.y = 0;
                                }
                                if (全_地图状态 == 3 && CommonProperty.pgConfig.EspConfig.大地图 && !自瞄)
                                {
                                    if (IsShow || WorldMapZoomFactor != 0)
                                    {
                                        float MapSizeFactored = MapSize / WorldMapZoomFactor;
                                        Vector3 WorldCenterLocation = new Vector3
                                        {
                                            x = MapSize * (1.0f + WorldMapPosition.x),
                                            y = MapSize * (1.0f + WorldMapPosition.y),
                                            z = 0
                                        };
                                        Vector3 RadarPos = 相减(item4.vector3_距离坐标, WorldCenterLocation);
                                        float x = X分辨率 / 2 + RadarPos.x / MapSizeFactored * (Y分辨率 / 2);
                                        float y = Y分辨率 / 2 + RadarPos.y / MapSizeFactored * (Y分辨率 / 2);
                                        if (x > 0 && y > 0 && x < X分辨率 && y < Y分辨率)
                                        {
                                            item4.vector3_大地图.x = x;
                                            item4.vector3_大地图.y = y;
                                        }
                                        else
                                        {
                                            item4.vector3_大地图.x = 0;
                                            item4.vector3_大地图.y = 0;
                                        }
                                    }
                                }
                                else
                                {
                                    item4.vector3_大地图.x = 0;
                                    item4.vector3_大地图.y = 0;
                                }
                                espData.Add(item4);
                            }
                            if (espData.Count > 0)
                            {
                                EspOverlay.EspQueue.Enqueue(espData);
                                CommonProperty.EspResetEventSlim.Set();
                            }
                            else
                            {
                                EspOverlay.Clear();
                            }
                        }
                        if (地图资源.Count > 0)
                        {
                            List<GameItems> gameItemsList = new List<GameItems>();
                            List<Class4> vehiclesList_载具 = new List<Class4>();
                            if (CommonProperty.战斗模式 && !class_本人.bool_0)
                            {
                                foreach (Class4 value20 in 地图资源)
                                {
                                    string text14 = value20.种类;
                                    if (CommonProperty.pgConfig.EspConfig.大地图 && (CommonProperty.pgConfig.EspConfig.透视载具 || CommonProperty.pgConfig.EspConfig.大地图载具))
                                    {
                                        if (text14 == "载具" && 1 < value20.距离 && value20.距离 < CommonProperty.pgConfig.EspConfig.载具距离)
                                        {
                                            Vector2 透视坐标 = 计算透视坐标(value20.vector3_0);
                                            value20.透视坐标 = 透视坐标;
                                            value20.ShortName = dictionary_载具[value20.name].shortName;

                                            if (全_地图状态 == 3 && CommonProperty.pgConfig.EspConfig.大地图 && !自瞄)
                                            {
                                                if (IsShow || WorldMapZoomFactor != 0)
                                                {
                                                    float MapSizeFactored = MapSize / WorldMapZoomFactor;
                                                    Vector3 WorldCenterLocation = new Vector3
                                                    {
                                                        x = MapSize * (1.0f + WorldMapPosition.x),
                                                        y = MapSize * (1.0f + WorldMapPosition.y),
                                                        z = 0
                                                    };
                                                    Vector3 RadarPos = 相减(value20.vector3_1, WorldCenterLocation);
                                                    float x = X分辨率 / 2 + RadarPos.x / MapSizeFactored * (Y分辨率 / 2);
                                                    float y = Y分辨率 / 2 + RadarPos.y / MapSizeFactored * (Y分辨率 / 2);
                                                    if (x > 0 && y > 0 && x < X分辨率 && y < Y分辨率)
                                                    {
                                                        value20.vector3_大地图.x = x;
                                                        value20.vector3_大地图.y = y;
                                                    }
                                                    else
                                                    {
                                                        value20.vector3_大地图.x = 0;
                                                        value20.vector3_大地图.y = 0;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                value20.vector3_大地图.x = 0;
                                                value20.vector3_大地图.y = 0;
                                            }
                                            vehiclesList_载具.Add(value20);
                                        }
                                    }


                                    if (CommonProperty.pgConfig.EspConfig.大地图)
                                    {
                                        if (text14 == "盒子" && 1 < value20.距离 && (value20.name == "Carapackage_RedBox_C" || value20.name == "Carapackage_FlareGun_C"))
                                        {
                                            Vector2 透视坐标 = 计算透视坐标(value20.vector3_0);
                                            value20.透视坐标 = 透视坐标;
                                            if (全_地图状态 == 3 && CommonProperty.pgConfig.EspConfig.大地图 && !自瞄)
                                            {
                                                if (IsShow || WorldMapZoomFactor != 0)
                                                {
                                                    float MapSizeFactored = MapSize / WorldMapZoomFactor;
                                                    Vector3 WorldCenterLocation = new Vector3
                                                    {
                                                        x = MapSize * (1.0f + WorldMapPosition.x),
                                                        y = MapSize * (1.0f + WorldMapPosition.y),
                                                        z = 0
                                                    };
                                                    Vector3 RadarPos = 相减(value20.vector3_1, WorldCenterLocation);
                                                    float x = X分辨率 / 2 + RadarPos.x / MapSizeFactored * (Y分辨率 / 2);
                                                    float y = Y分辨率 / 2 + RadarPos.y / MapSizeFactored * (Y分辨率 / 2);
                                                    if (x > 0 && y > 0 && x < X分辨率 && y < Y分辨率)
                                                    {
                                                        value20.vector3_大地图.x = x;
                                                        value20.vector3_大地图.y = y;
                                                    }
                                                    else
                                                    {
                                                        value20.vector3_大地图.x = 0;
                                                        value20.vector3_大地图.y = 0;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                value20.vector3_大地图.x = 0;
                                                value20.vector3_大地图.y = 0;
                                            }
                                            vehiclesList_载具.Add(value20);
                                        }
                                    }
                                }
                                if (vehiclesList_载具.Count > 0)
                                {
                                    EspOverlay.EspVehicleQueue.Enqueue(vehiclesList_载具);
                                    //CommonProperty.EspVehicleResetEventSlim.Set();
                                    CommonProperty.EspResetEventSlim.Set();
                                }
                                else
                                {
                                    EspOverlay.Clear2();
                                }

                            }
                        }
                        else
                        {
                            EspOverlay.Clear2();
                        }
                        帧率锁(CommonProperty.pgConfig.EspConfig.帧延迟);
                        continue;
                    }
                    else
                    {
                        帧率锁(1);
                        continue;
                    }
                }
                Thread.Sleep(10);
            }
            catch
            {

            }

        }
    }

    private void 获取各个参数的值()
    {
        玩家信息 = Program.mainForm_0.ShowPlayerInfo;
        游戏ID = Program.mainForm_0.ShowName;
        ShowAudience = Program.mainForm_0.ShowAudience;
        ShowKillNum = Program.mainForm_0.ShowKillNum;
        轰炸区 = Program.mainForm_0.ShowRedZone;
        ShowKD = Program.mainForm_0.ShowKD;
        string_8 = Program.mainForm_0.KDMODE;
        ShowDamageAvg = Program.mainForm_0.ShowDamageAvg;
        ShowSurvivalLevel = Program.mainForm_0.ShowSurvivalLevel;
        ShowDistance = Program.mainForm_0.ShowDistance;
        字体大小 = Program.mainForm_0.FontSize;
        //debug = Program.mainForm_0.DEBUG_MODE;
        debug = false;
        ShowRank = Program.mainForm_0.ShowRank;
        白名单_队伍 = Program.mainForm_0.TeamAdd;
        MqttServer = Program.mainForm_0.MqttServer;
        WebServer = Program.mainForm_0.WebServer;
        //自瞄优先 = Program.mainForm_0.AimFirst;
        自瞄兼容模式 = Program.mainForm_0.自瞄兼容模式;
        if (string_11 != 白名单_队伍 || 白名单_队伍 == "")
        {
            string_11 = 白名单_队伍;
            hashSet_友军.Clear();
            hashSet_白名单.Clear();
            if (白名单_队伍 != "")
            {
                string[] array = 白名单_队伍.Split(',');
                foreach (string text in array)
                {
                    if (text.Trim() != "")
                    {
                        try
                        {
                            hashSet_友军.Add(uint.Parse(text.Trim()));
                        }
                        catch
                        {
                            hashSet_白名单.Add(text.Trim());
                        }
                    }
                }
            }
        }
        自瞄模式 = Program.mainForm_0.ControlMode;
        控制器类型 = Program.mainForm_0.ControlHID;
        COM端口 = Program.mainForm_0.ComPortName;
        波动率 = Program.mainForm_0.ComBaudRate;
        X分辨率 = Program.mainForm_0.ScreenX;
        Y分辨率 = Program.mainForm_0.ScreenY;
        帧率 = Program.mainForm_0.刷新率;
        物资0 = Program.mainForm_0.显示物资组0;
        物资1 = Program.mainForm_0.显示物资组1;
        物资2 = Program.mainForm_0.显示物资组2;
        物资3 = Program.mainForm_0.显示物资组3;
        透视开关 = Program.mainForm_0.ShowESP;
        融合器 = true;
        透视投掷物 = false;
        骨骼 = Program.mainForm_0.ShowBone;
        热键_战斗模式 = Program.mainForm_0.热键_战斗模式;
        热键_显示物资组0 = Program.mainForm_0.热键_显示物资组0;
        热键_显示物资组1 = Program.mainForm_0.热键_显示物资组1;
        热键_显示物资组2 = Program.mainForm_0.热键_显示物资组2;
        热键_显示物资组3 = Program.mainForm_0.热键_显示物资组3;
        热键_缩小 = Program.mainForm_0.热键_缩小;
        热键_放大 = Program.mainForm_0.热键_放大;
        热键_刷新 = Program.mainForm_0.热键_刷新;
        热键_ESP = Program.mainForm_0.热键_ESP;
        热键_用户信息 = Program.mainForm_0.热键_用户信息;
        热键_自瞄配置2 = Program.mainForm_0.热键_自瞄配置2;
        雷达物资 = Program.mainForm_0.bool_00;
        雷达载具 = Program.mainForm_0.bool_0;
        动态FOV = Program.mainForm_0.bool_动态fov;
        CommonProperty.X分辨率 = X分辨率;
        CommonProperty.Y分辨率 = Y分辨率;
        CommonProperty.物资A = 物资0;
        CommonProperty.物资B = 物资1;
        CommonProperty.物资C = 物资2;
        CommonProperty.物资D = 物资3;
        if (X分辨率 == 2560 && Y分辨率 == 1080)
        {
            vector2_0.x = 2560f;
            vector2_0.y = 1080f;
            vector2_1.x = 2529f;
            vector2_1.y = 1054f;
            vector2_2.x = vector2_1.x / vector2_0.x;
            vector2_2.y = vector2_1.y / vector2_0.y;
            vector2_3.x = float_0 / vector2_0.x;
            vector2_3.y = float_0 / vector2_0.y;
            vector2_4.x = vector2_2.x - vector2_3.x;
            vector2_4.y = vector2_2.y - vector2_3.y;
            vector2_5.x = float_1 / vector2_0.x;
            vector2_5.y = float_1 / vector2_0.y;
            vector2_6.x = vector2_2.x - vector2_5.x;
            vector2_6.y = vector2_2.y - vector2_5.y;
        }
    }

    private void 按键()
    {
        Class9 @class = new Class9(pid, vmm);
        自瞄 = false;
        子骨骼自瞄 = false;
        自瞄倒地 = false;
        int_25 = 0;
        int_26 = 0;
        获取各个参数的值();
        左键按下 = false;
        热键战斗模式 = false;
        热键显示物资组0 = false;
        热键显示物资组1 = false;
        热键显示物资组2 = false;
        热键显示物资组3 = false;
        热键缩小 = false;
        热键放大 = false;
        数据刷新 = false;
        热键ESP = false;
        热键用户信息 = false;
        bool flag = false;
        if (热键监控)
        {
            HsqakkX6Do[61] = 0;
            HsqakkX6Do[62] = 0;
            HsqakkX6Do[60] = 0;
            HsqakkX6Do = vmm.MemRead(winlogonpid, gafAsyncKeyStateAddress, 64u, 1u);
            if (HsqakkX6Do.Length != 64)
            {
                状态3("热键读取失败,请关注!", Color.Red);
                return;
            }
            if (HsqakkX6Do[61] == 32 || HsqakkX6Do[62] == 128 || HsqakkX6Do[60] == 130)
            {
                if (游戏机按键是否按下(1) || 雷达机按键是否按下(1))
                {
                    左键按下 = true;
                }
                if (游戏机按键是否按下(热键_战斗模式) || 雷达机按键是否按下(热键_战斗模式))
                {
                    热键战斗模式 = true;
                    flag = true;
                }
                if (游戏机按键是否按下(热键_显示物资组0) || 雷达机按键是否按下(热键_显示物资组0))
                {
                    热键显示物资组0 = true;
                    flag = true;
                }
                if (游戏机按键是否按下(热键_显示物资组1) || 雷达机按键是否按下(热键_显示物资组1))
                {
                    热键显示物资组1 = true;
                    flag = true;
                }
                if (游戏机按键是否按下(热键_显示物资组2) || 雷达机按键是否按下(热键_显示物资组2))
                {
                    热键显示物资组2 = true;
                    flag = true;
                }
                if (游戏机按键是否按下(热键_显示物资组3) || 雷达机按键是否按下(热键_显示物资组3))
                {
                    热键显示物资组3 = true;
                    flag = true;
                }
                if (游戏机按键是否按下(热键_放大) || 雷达机按键是否按下(热键_放大))
                {
                    热键放大 = true;
                }
                if (游戏机按键是否按下(热键_缩小) || 雷达机按键是否按下(热键_缩小))
                {
                    热键缩小 = true;
                }
                if (游戏机按键是否按下(热键_刷新) || 雷达机按键是否按下(热键_刷新))
                {
                    数据刷新 = true;
                    flag = true;
                }
                if (游戏机按键是否按下(热键_ESP) || 雷达机按键是否按下(热键_ESP))
                {
                    热键ESP = true;
                    flag = true;
                }
                if (游戏机按键是否按下(热键_用户信息) || 雷达机按键是否按下(热键_用户信息))
                {
                    热键用户信息 = true;
                    flag = true;
                }
                if (游戏机按键是否按下(36) || 雷达机按键是否按下(36))
                {
                    CommonProperty.caidan = !CommonProperty.caidan;
                    flag = true;
                }
                if (游戏机按键是否按下(热键_自瞄配置2) || 雷达机按键是否按下(热键_自瞄配置2))
                {
                    CommonProperty.pgConfig.EspConfig.自瞄配置2 = !CommonProperty.pgConfig.EspConfig.自瞄配置2;
                    flag = true;

                }
                if (!flag)
                {
                    if (游戏机按键是否按下(69) || 雷达机按键是否按下(69))
                    {
                        int_25 = 1;
                    }
                    if (游戏机按键是否按下(81) || 雷达机按键是否按下(69))
                    {
                        int_26 = 1;
                    }
                    //if (游戏机按键是否按下(热键_黑名单) || 雷达机按键是否按下(69))
                    //{
                    //    热键黑名单 = true;
                    //}
                    //if (游戏机按键是否按下(热键_胸部) || 雷达机按键是否按下(69))
                    //{
                    //    自瞄胸热键 = true;
                    //}
                    //if (游戏机按键是否按下(热键_脖子) || 雷达机按键是否按下(69))
                    //{
                    //    自瞄脖热键 = true;
                    //}
                    if (class_本人.当前武器名称 != "" && class_本人.人物血量 > 0f && 自瞄模式 == 1)
                    {
                        获取自瞄参数和按键(class_本人.当前武器名称);
                        if (!游戏机按键是否按下(class7_0.自瞄按键1) && !游戏机按键是否按下(class7_0.自瞄按键2))
                        {
                            瞄准地址 = 0uL;
                            状态("自瞄状态", "自瞄[AIM]:OFF");
                        }
                        else
                        {
                            @class.Add<byte>(class_本人.当前武器 + CurrentAmmoData);
                            @class.Finish();
                            this.ammoData = @class.Get<byte>(class_本人.当前武器 + CurrentAmmoData);
                            if (this.ammoData > 0)
                            {
                                if (class7_0.父骨骼 != 0)
                                {
                                    自瞄 = true;
                                    string object_ = "自瞄[" + class7_0.武器名称 + "]:ON";
                                    状态("自瞄状态", object_);
                                }
                                else if (游戏机按键是否按下(class7_0.自瞄子按键))
                                {
                                    自瞄 = true;
                                    string object_ = "自瞄[" + class7_0.武器名称 + "]:ON";
                                    状态("自瞄状态", object_);
                                }
                            }
                            else
                            {
                                自瞄 = false;
                            }
                            if (class7_0.武器名称 == "")
                            {
                                class7_0.武器名称 = class7_0.string_0.Replace("Weapon", "").Replace("Weap", "").Replace("_C", "");
                            }
                        }
                        if (游戏机按键是否按下(class7_0.自瞄子按键))
                        {
                            子骨骼自瞄 = true;

                        }
                        if (游戏机按键是否按下(class7_0.自瞄倒地按键))
                        {
                            自瞄倒地 = true;
                        }
                    }
                    else if (class_本人.当前武器名称 != "" && class_本人.人物血量 > 0f && 自瞄模式 == 0)
                    {
                        获取自瞄参数和按键(class_本人.当前武器名称);
                        if (!雷达机按键是否按下(class7_0.自瞄按键1) && !雷达机按键是否按下(class7_0.自瞄按键2))
                        {
                            瞄准地址 = 0uL;
                            状态("自瞄状态", "自瞄[AIM]:OFF");
                        }
                        else
                        {
                            @class.Add<byte>(class_本人.当前武器 + CurrentAmmoData);
                            @class.Finish();
                            this.ammoData = @class.Get<byte>(class_本人.当前武器 + CurrentAmmoData);
                            if (this.ammoData > 0)
                            {
                                if (class7_0.父骨骼 != 0)
                                {
                                    自瞄 = true;
                                    string object_ = "自瞄[" + class7_0.武器名称 + "]:ON";
                                    状态("自瞄状态", object_);
                                }
                                else if (游戏机按键是否按下(class7_0.自瞄子按键))
                                {
                                    自瞄 = true;
                                    string object_ = "自瞄[" + class7_0.武器名称 + "]:ON";
                                    状态("自瞄状态", object_);
                                }
                            }
                            else
                            {
                                自瞄 = false;
                            }
                            if (class7_0.武器名称 == "")
                            {
                                class7_0.武器名称 = class7_0.string_0.Replace("Weapon", "").Replace("Weap", "").Replace("_C", "");
                            }
                        }
                        if (雷达机按键是否按下(class7_0.自瞄子按键))
                        {
                            子骨骼自瞄 = true;
                        }
                        if (雷达机按键是否按下(class7_0.自瞄倒地按键))
                        {
                            自瞄倒地 = true;
                        }
                    }
                    else
                    {
                        class7_0.自瞄FOV = 0;
                        状态("自瞄状态", "自瞄[AIM]:OFF");
                        瞄准地址 = 0uL;
                    }
                }
            }
        }
        if (热键战斗模式)
        {
            CommonProperty.战斗模式 = !CommonProperty.战斗模式;
        }
        if (热键显示物资组0)
        {
            物资0 = !物资0;
            状态("显示物资组0", 物资0.ToString());
        }
        if (热键显示物资组1)
        {
            物资1 = !物资1;
            状态("显示物资组1", 物资1.ToString());
        }
        if (热键显示物资组2)
        {
            物资2 = !物资2;
            状态("显示物资组2", 物资2.ToString());
        }
        if (热键显示物资组3)
        {
            物资3 = !物资3;
            状态("显示物资组3", 物资3.ToString());
        }
        if (热键用户信息)
        {
            玩家信息 = !玩家信息;
            状态("ShowPlayerInfo", 玩家信息.ToString());
        }
        if (热键ESP)
        {
            透视开关 = !透视开关;
            状态("ShowESP", 透视开关.ToString());
        }
        if (热键放大)
        {
            int_0 = 1;
        }
        if (热键缩小)
        {
            int_0 = -1;
        }
        是否透视();
        if (flag)
        {
            Thread.Sleep(200);
        }
    }

    private void 获取自瞄参数和按键(string string_0)
    {
        if (class7_0 == null)
        {
            class7_0 = new Class7();
        }
        if (!CommonProperty.pgConfig.EspConfig.自瞄配置2)
        {
            if (Program.mainForm_0.GunList.ContainsKey(string_0))
            {
                class7_0.string_0 = string_0;
                if (Program.mainForm_0.GunList[string_0].ShortName == "")
                {
                    Program.mainForm_0.GunList[string_0].ShortName = string_0.Replace("Weapon", "").Replace("Weap", "").Replace("_C", "");
                }
                class7_0.武器名称 = Program.mainForm_0.GunList[string_0].ShortName;
                class7_0.枪type = Program.mainForm_0.GunList[string_0].GunType;
                class7_0.抬枪量 = Program.mainForm_0.GunList[string_0].Raise;
                class7_0.Gun50 = Program.mainForm_0.GunList[string_0].Gun50;
                class7_0.Gun100 = Program.mainForm_0.GunList[string_0].Gun100;
                class7_0.Gun150 = Program.mainForm_0.GunList[string_0].Gun150;
                class7_0.Gun200 = Program.mainForm_0.GunList[string_0].Gun200;
                class7_0.Gun250 = Program.mainForm_0.GunList[string_0].Gun250;
                class7_0.Gun300 = Program.mainForm_0.GunList[string_0].Gun300;
                class7_0.Gun350 = Program.mainForm_0.GunList[string_0].Gun350;
                class7_0.Gun400 = Program.mainForm_0.GunList[string_0].Gun400;
                class7_0.Gun450 = Program.mainForm_0.GunList[string_0].Gun450;
                class7_0.Gun500 = Program.mainForm_0.GunList[string_0].Gun500;
                class7_0.Gun550 = Program.mainForm_0.GunList[string_0].Gun550;
                class7_0.Gun600 = Program.mainForm_0.GunList[string_0].Gun600;
                class7_0.Gun999 = Program.mainForm_0.GunList[string_0].Gun999;
            }
            else
            {
                //class7_0 = new Class7();
                //class7_0.name = name;
                class7_0.枪type = 8;
                //class7_0.父骨骼 = dictionary_骨骼点[class7_0.父骨骼];
                //class7_0.子骨骼 = dictionary_骨骼点[class7_0.子骨骼];
            }
            if (!Program.mainForm_0.GunTypeList.ContainsKey(class7_0.枪type))
            {
                Program.mainForm_0.GunTypeList[class7_0.枪type] = new GunType();
            }
            class7_0.抢类型 = Program.mainForm_0.GunTypeList[class7_0.枪type].TypeName;
            class7_0.自瞄按键1 = Program.mainForm_0.GunTypeList[class7_0.枪type].AIMKEY1;
            class7_0.自瞄按键2 = Program.mainForm_0.GunTypeList[class7_0.枪type].AIMKEY2;
            class7_0.自瞄子按键 = Program.mainForm_0.GunTypeList[class7_0.枪type].LOCKKEY;
            class7_0.自瞄倒地按键 = Program.mainForm_0.GunTypeList[class7_0.枪type].倒地KEY;
            class7_0.父骨骼 = dictionary_骨骼点[Program.mainForm_0.GunTypeList[class7_0.枪type].AIM部位];
            class7_0.子骨骼 = dictionary_骨骼点[Program.mainForm_0.GunTypeList[class7_0.枪type].LOCK部位];
            class7_0.自瞄响应 = Program.mainForm_0.GunTypeList[class7_0.枪type].AimDelay;
            class7_0.自瞄距离 = Program.mainForm_0.GunTypeList[class7_0.枪type].AimDistince;
            class7_0.自瞄FOV = Program.mainForm_0.GunTypeList[class7_0.枪type].AimRange;
            class7_0.自瞄平滑 = Program.mainForm_0.GunTypeList[class7_0.枪type].AimSmooth;
            class7_0.自瞄修正 = Program.mainForm_0.GunTypeList[class7_0.枪type].AimAdjust;
            class7_0.自瞄压枪 = Program.mainForm_0.GunTypeList[class7_0.枪type].Recoil;
            class7_0.X轴自瞄力度 = Program.mainForm_0.GunTypeList[class7_0.枪type].MoveX;
            class7_0.Y轴自瞄开关 = Program.mainForm_0.GunTypeList[class7_0.枪type].UseY;
            class7_0.Y轴自瞄力度 = Program.mainForm_0.GunTypeList[class7_0.枪type].MoveY;
            class7_0.自瞄随机开关 = Program.mainForm_0.GunTypeList[class7_0.枪type].AimRandom;
            class7_0.自瞄随机值 = Program.mainForm_0.GunTypeList[class7_0.枪type].RandomValue;
            class7_0.自瞄优先级 = Program.mainForm_0.GunTypeList[class7_0.枪type].Aim优先级;
        }
        else
        {
            if (Program.mainForm_0.GunList.ContainsKey(string_0))
            {
                class7_0.string_0 = string_0;
                if (Program.mainForm_0.GunList[string_0].ShortName == "")
                {
                    Program.mainForm_0.GunList[string_0].ShortName = string_0.Replace("Weapon", "").Replace("Weap", "").Replace("_C", "");
                }
                class7_0.武器名称 = Program.mainForm_0.GunList[string_0].ShortName;
                class7_0.枪type = Program.mainForm_0.GunList[string_0].GunType;
                class7_0.抬枪量 = Program.mainForm_0.GunList[string_0].Raise;
                class7_0.Gun50 = Program.mainForm_0.GunList[string_0].Gun50;
                class7_0.Gun100 = Program.mainForm_0.GunList[string_0].Gun100;
                class7_0.Gun150 = Program.mainForm_0.GunList[string_0].Gun150;
                class7_0.Gun200 = Program.mainForm_0.GunList[string_0].Gun200;
                class7_0.Gun250 = Program.mainForm_0.GunList[string_0].Gun250;
                class7_0.Gun300 = Program.mainForm_0.GunList[string_0].Gun300;
                class7_0.Gun350 = Program.mainForm_0.GunList[string_0].Gun350;
                class7_0.Gun400 = Program.mainForm_0.GunList[string_0].Gun400;
                class7_0.Gun450 = Program.mainForm_0.GunList[string_0].Gun450;
                class7_0.Gun500 = Program.mainForm_0.GunList[string_0].Gun500;
                class7_0.Gun550 = Program.mainForm_0.GunList[string_0].Gun550;
                class7_0.Gun600 = Program.mainForm_0.GunList[string_0].Gun600;
                class7_0.Gun999 = Program.mainForm_0.GunList[string_0].Gun999;
            }
            else
            {
                //class7_0 = new Class7();
                //class7_0.name = name;
                class7_0.枪type = 8;
                //class7_0.父骨骼 = dictionary_骨骼点[class7_0.父骨骼];
                //class7_0.子骨骼 = dictionary_骨骼点[class7_0.子骨骼];
            }
            if (!Program.mainForm_0.GunTypeList2.ContainsKey(class7_0.枪type))
            {
                Program.mainForm_0.GunTypeList2[class7_0.枪type] = new GunType();
            }
            class7_0.抢类型 = Program.mainForm_0.GunTypeList2[class7_0.枪type].TypeName;
            class7_0.自瞄按键1 = Program.mainForm_0.GunTypeList2[class7_0.枪type].AIMKEY1;
            class7_0.自瞄按键2 = Program.mainForm_0.GunTypeList2[class7_0.枪type].AIMKEY2;
            class7_0.自瞄子按键 = Program.mainForm_0.GunTypeList2[class7_0.枪type].LOCKKEY;
            class7_0.自瞄倒地按键 = Program.mainForm_0.GunTypeList2[class7_0.枪type].倒地KEY;
            class7_0.父骨骼 = dictionary_骨骼点[Program.mainForm_0.GunTypeList2[class7_0.枪type].AIM部位];
            class7_0.子骨骼 = dictionary_骨骼点[Program.mainForm_0.GunTypeList2[class7_0.枪type].LOCK部位];
            class7_0.自瞄响应 = Program.mainForm_0.GunTypeList2[class7_0.枪type].AimDelay;
            class7_0.自瞄距离 = Program.mainForm_0.GunTypeList2[class7_0.枪type].AimDistince;
            class7_0.自瞄FOV = Program.mainForm_0.GunTypeList2[class7_0.枪type].AimRange;
            class7_0.自瞄平滑 = Program.mainForm_0.GunTypeList2[class7_0.枪type].AimSmooth;
            class7_0.自瞄修正 = Program.mainForm_0.GunTypeList2[class7_0.枪type].AimAdjust;
            class7_0.自瞄压枪 = Program.mainForm_0.GunTypeList2[class7_0.枪type].Recoil;
            class7_0.X轴自瞄力度 = Program.mainForm_0.GunTypeList2[class7_0.枪type].MoveX;
            class7_0.Y轴自瞄开关 = Program.mainForm_0.GunTypeList2[class7_0.枪type].UseY;
            class7_0.Y轴自瞄力度 = Program.mainForm_0.GunTypeList2[class7_0.枪type].MoveY;
            class7_0.自瞄随机开关 = Program.mainForm_0.GunTypeList2[class7_0.枪type].AimRandom;
            class7_0.自瞄随机值 = Program.mainForm_0.GunTypeList2[class7_0.枪type].RandomValue;
            class7_0.自瞄优先级 = Program.mainForm_0.GunTypeList2[class7_0.枪type].Aim优先级;
        }

    }

    private void 是否透视()
    {
        if (透视 == 透视开关)
        {
            return;
        }
        透视 = 透视开关;
    }

    private void 雷达信息()
    {
        while (ThreadRunning)
        {
            try
            {
                string result;
                while (concurrentQueue_雷达信息.Count > 0 && concurrentQueue_雷达信息.TryDequeue(out result) && (ShowKD || ShowDamageAvg || ShowRank || CommonProperty.pgConfig.EspConfig.KD || CommonProperty.pgConfig.EspConfig.段位) && (玩家信息))
                {
                    if (result != "" && !dictionary_3.ContainsKey(result))
                    {
                        PlayerInfo playerInfo = 获取战绩数据1(result);
                        if (playerInfo.name != "")
                        {
                            dictionary_3[result] = playerInfo;
                        }
                    }
                }
                if ((ShowKD || ShowDamageAvg || ShowRank || CommonProperty.pgConfig.EspConfig.KD || CommonProperty.pgConfig.EspConfig.段位) && (玩家信息))
                {
                    foreach (KeyValuePair<string, PlayerInfo> item in dictionary_3)
                    {
                        //if (!(item.Value.FlushDate.AddMinutes(3.0) < DateTime.Now))
                        //{
                        //    continue;
                        //}
                        if (string_8 == "20")
                        {
                            PlayerInfo playerInfo2 = 获取战绩数据1(item.Key, false);
                            item.Value.KD = playerInfo2.KD;
                            item.Value.cs = playerInfo2.cs;
                            item.Value.stats.deaths_sum = playerInfo2.stats.deaths_sum;
                            item.Value.stats.kills_sum = playerInfo2.stats.kills_sum;
                            item.Value.stats.damage_dealt_avg = playerInfo2.stats.damage_dealt_avg;
                            item.Value.FlushDate = DateTime.Now.AddDays(3.0);
                        }
                        else if (!(string_8 == "TPP"))
                        {
                            if (string_8 == "FPP")
                            {
                                PlayerInfo playerInfo3 = method_段位(item.Value, "competitive-fpp");
                                item.Value.KD = playerInfo3.KD;
                                item.Value.cs = playerInfo3.cs;
                                item.Value.stats.deaths_sum = playerInfo3.stats.deaths_sum;
                                item.Value.stats.kills_sum = playerInfo3.stats.kills_sum;
                                item.Value.stats.damage_dealt_avg = playerInfo3.stats.damage_dealt_avg;
                                item.Value.FlushDate = DateTime.Now.AddDays(3.0);
                            }
                        }
                        else
                        {
                            PlayerInfo playerInfo4 = method_段位(item.Value);
                            item.Value.KD = playerInfo4.KD;
                            item.Value.cs = playerInfo4.cs;
                            item.Value.stats.deaths_sum = playerInfo4.stats.deaths_sum;
                            item.Value.stats.kills_sum = playerInfo4.stats.kills_sum;
                            item.Value.stats.damage_dealt_avg = playerInfo4.stats.damage_dealt_avg;
                            item.Value.FlushDate = DateTime.Now.AddDays(3.0);
                        }
                    }
                }
                Thread.Sleep(10);
            }
            catch
            {
            }
            Thread.Sleep(1000);
        }
    }

    private void 计算自瞄值(int 自瞄X, int 自瞄Y, bool bool_50 = false)
    {
        int 平滑 = class7_0.自瞄平滑 + 1;
        int X轴 = 自瞄X;
        int Y轴 = 自瞄Y;
        int int_31 = 1;
        int num1 = 115;
        int num2 = 62;

        if (平滑 == 1)
        {
            if (X轴 != 0)
            {
                X轴 = ((X轴 / 平滑) * 100) / num1;
            }
            if (Y轴 != 0)
            {
                Y轴 = ((Y轴 / 平滑) * 100) / num1;
            }
        }
        else
        {
            if (X轴 != 0)
            {
                X轴 = ((X轴 / 平滑) * 100) / num2;
            }
            if (Y轴 != 0)
            {
                Y轴 = ((Y轴 / 平滑) * 100) / num2;
            }
        }

        if (class7_0.自瞄压枪 != 0 && 游戏机按键是否按下(1))
        {
            Y轴 = Y轴 + class7_0.自瞄压枪;
        }

        if (控制器类型 == 3)
        {
            控制器移动(X轴, Y轴, 1);
            return;
        }
        else
        {
            控制器移动(X轴, Y轴);
            return;
        }
    }

    private void 控制器移动(int int_29, int int_30, int int_31 = 1)
    {
        if (控制器类型 != 0)
        {
            try
            {
                if (!KM_COM.IsOpen)
                {
                    KM_COM.PortName = COM端口;
                    KM_COM.DataBits = 8;
                    KM_COM.StopBits = StopBits.One;
                    KM_COM.Parity = Parity.None;
                    KM_COM.BaudRate = int.Parse(波动率);
                    KM_COM.Open();
                }
            }
            catch
            {
                MessageBox.Show("控制器连接失败!请检查控制器");
                结束进程();
            }
            if (!KM_COM.IsOpen)
            {
                KM_COM.PortName = COM端口;
                KM_COM.DataBits = 8;
                KM_COM.StopBits = StopBits.One;
                KM_COM.Parity = Parity.None;
                KM_COM.BaudRate = int.Parse(波动率);
                KM_COM.Open();
                return;
            }
        }
        switch (控制器类型)
        {
            case 0:
                AimBot(int_29, int_30);
                break;
            case 1:
                {
                    string text2 = "";
                    if (int_29 >= 0 || int_30 <= 0)
                    {
                        if (int_29 == 0 && int_30 > 0)
                        {
                            text2 = string.Format("[MM2{0}]", Math.Abs(int_30));
                        }
                        else if (int_29 > 0 && int_30 > 0)
                        {
                            text2 = string.Format("[MM8{0},{1}]", Math.Abs(int_29), Math.Abs(int_30));
                        }
                        else if (int_29 > 0 && int_30 < 0)
                        {
                            text2 = string.Format("[MM7{0},{1}]", Math.Abs(int_29), Math.Abs(int_30));
                        }
                        else if (int_29 < 0 && int_30 < 0)
                        {
                            text2 = string.Format("[MM5{0},{1}]", Math.Abs(int_29), Math.Abs(int_30));
                        }
                        else if (int_29 == 0 && int_30 < 0)
                        {
                            text2 = string.Format("[MM1{0}]", Math.Abs(int_30));
                        }
                        else if (int_29 > 0 && int_30 == 0)
                        {
                            text2 = string.Format("[MM4{0}]", Math.Abs(int_29));
                        }
                        else if (int_29 < 0 && int_30 == 0)
                        {
                            text2 = string.Format("[MM3{0}]", Math.Abs(int_29));
                        }
                    }
                    else
                    {
                        text2 = string.Format("[MM6{0},{1}]", Math.Abs(int_29), Math.Abs(int_30));
                    }
                    KM_COM.WriteLine(text2);
                    break;
                }
            case 2:
                {
                    byte[] array = new byte[7] { 87, 171, 2, 0, 0, 0, 0 };
                    if (int_29 > 0)
                    {
                        array[4] = (byte)Math.Abs(int_29);
                    }
                    if (int_29 < 0)
                    {
                        array[4] = (byte)(256 - Math.Abs(int_29));
                    }
                    if (int_30 > 0)
                    {
                        array[5] = (byte)Math.Abs(int_30);
                    }
                    if (int_30 < 0)
                    {
                        array[5] = (byte)(256 - Math.Abs(int_30));
                    }
                    KM_COM.Write(array, 0, 7);
                    break;
                }
            case 3:
                {
                    string text = string.Format("km.move({0},{1},{2})\r\n", int_29, int_30, int_31);
                    KM_COM.WriteLine(text);
                    break;
                }
        }
    }

    private void 小地图雷达()
    {
        ulong MyHUDAddr = MemRead<ulong>(class_本人.玩家控制 + MyHUD);
        ulong WidgetStateMapAddr = MemRead<ulong>(MyHUDAddr + WidgetStateMap);
        int num3 = 0;
        for (ulong num4 = 0uL; num4 < 1000L; num4++)
        {
            num3++;
            Struct0 @struct = Read<Struct0>(WidgetStateMapAddr + num4 * 8L);
            uint num5 = DecryptCIndex(Read<uint>(@struct.ulong_2 + ObjID));
            uint num6 = DecryptCIndex(Read<uint>(@struct.ulong_0 + ObjID));
            if (num5 == num6)
            {
                string text = MemGetName(num5);
                if (text.Trim() == "MinimapOriginalType_C")
                {
                    MinimapCanvasWidgetAddr = @struct.ulong_2;
                }
                if (text.Trim() == "NewWorldMapWidget_BP_C")
                {
                    MapAddr = @struct.ulong_2;
                    MapGrid = Read<ulong>(@struct.ulong_2 + TrainingMapGrid + 0x30);
                }
                if (text.Trim() == "UI_TrainingWorldMapWidget_C")
                {
                    MapAddr = @struct.ulong_2;
                    MapGrid = Read<ulong>(@struct.ulong_2 + TrainingMapGrid);
                }
                if (MinimapCanvasWidgetAddr > 0L && MapAddr > 0 && MapGrid > 0)
                {
                    break;
                }
            }
        }
    }

    public void setMap()
    {
        if (当前地图 == "Tiger_Main" || 当前地图 == "Desert_Main" || 当前地图 == "Kiki_Main" || 当前地图 == "Chimera_Main" || 当前地图 == "DihorOtok_Main") //Desert_Main 沙漠  Tiger_Main  泰格 DihorOtok_Main 雪图
            MapSize = 408000;

        else if (当前地图 == "Range_Main")
            MapSize = 101175;

        else if (当前地图 == "Baltic_Main") // 艾伦格
            MapSize = 406387.5f;

        else if (当前地图 == "Heaven_Main")
            MapSize = 51420;

        else if (当前地图 == "Savage_Main")
            MapSize = 202387.5f;

        //else if (当前地图 == "DihorOtok_Main")
        //    MapSize = 306050;

        else if (当前地图 == "Chimera_Main")
            MapSize = 152950;
    }

    [Obfuscation(Feature = "virtualization", Exclude = false)]
    private bool 登录验证()
    {
        try
        {
            string jiemi = CommonProperty.jiemi;
            //string jiemi = "{\r\nShield:132501544,\r\nUworld:156166056,\r\nGNames:158170480,\r\nLeve:1880,\r\nGameInstence:1888,\r\nLocalPlayer:224,\r\nPlayerController:56,\r\nActor:576,\r\nAcknowledgedPawn:1168,\r\nObjID:12,\r\nIDD:16584,\r\nTeamNumber:7160,\r\nHealth:2184,\r\nHealthDie:3924,\r\nAudience:3688,\r\nPlayname:4256,\r\nPlayerState:1072,\r\nPlayerSatisitc:2472,\r\nMesh:1128,\r\nPosition:624,\r\nDroppedItemGroup:448,\r\nDroppedItemGroup_UItem:1928,\r\n物品一:176,\r\n物品二:584,\r\n世界转小地图:160,\r\n被瞄偏移:5584,\r\nGameState:744,\r\nLerpSafetyZonePosition:1204,\r\nLerpSafetyZoneRadius:1308,\r\nPoisonGasWarningPosition:1400,\r\nPoisonGasWarningRadius:1160,\r\nRedZonePosition:1268,\r\nRedZoneRadius:1200,\r\nROR:false,\r\nDecryptOne:2435047868,\r\nTableOne:3,\r\nTableTwo:16,\r\nDecryptTwo:2674965493,\r\nPlayerCameraManager:1200,\r\nCameraPos:5680,\r\nCameraRot:5728,\r\nCameraFov:5712,\r\nBone:2848,\r\nBoneArry:608,\r\nEyes:1964,\r\nWeaponProcessor:2208,\r\nEquippedWeapons:520,\r\nCurrentWeaponIndex:785,\r\nWeaponTrajectoryData:4104,\r\nTrajectoryConfig:264,\r\nAnimScriptInstance:3264,\r\nControlRotationCP:1908,\r\nRecoilADSRotationCP:2524,\r\nVehicleRiderComponent:7480,\r\nLastVehiclePawn:624,\r\nActorRootComp:1344,\r\nReplicatedMovement:128,\r\nVeloctity:976,\r\n背包状态:156244800,\r\nMapMarker:1564,\r\nPartnerLevel:2558,\r\nSurvivalLevel:3316,\r\nBWasKicked:2761,\r\nWidgetStateMap:1288,\r\nMyHUD:1192,\r\nBlockInputWidgetList:1392,\r\nSelectMinimapSizeIndex:1472,\r\nDroppedItem:1088,\r\nCurrentAmmoData:2576\r\n}";
            {
                offset obj = JsonConvert.DeserializeObject<offset>(jiemi);
                value.Shield = obj.Shield;
                value.Uworld = obj.Uworld;
                value.GNames = obj.GNames;
                value.Leve = obj.Leve;
                value.GameInstence = obj.GameInstence;
                value.LocalPlayer = obj.LocalPlayer;
                value.PlayerController = obj.PlayerController;
                value.Actor = obj.Actor;
                value.AcknowledgedPawn = obj.AcknowledgedPawn;
                value.ObjID = obj.ObjID;
                value.IDD = obj.IDD;
                value.TeamNumber = obj.TeamNumber;
                value.Health = obj.Health;
                value.HealthDie = obj.HealthDie;
                value.Audience = obj.Audience;
                value.Playname = obj.Playname;
                value.PlayerState = obj.PlayerState;
                value.PlayerSatisitc = obj.PlayerSatisitc;
                value.Mesh = obj.Mesh;
                value.Position = obj.Position;
                value.DroppedItemGroup = obj.DroppedItemGroup;
                value.DroppedItemGroupUItem = obj.DroppedItemGroup_UItem;
                value.物品一 = obj.物品一;
                value.物品二 = obj.物品二;
                value.世界转小地图 = obj.世界转小地图;
                value.被瞄偏移 = obj.被瞄偏移;
                value.GameState = obj.GameState;
                value.LerpSafetyZonePosition = obj.LerpSafetyZonePosition;
                value.LerpSafetyZoneRadius = obj.LerpSafetyZoneRadius;
                value.PoisonGasWarningPosition = obj.PoisonGasWarningPosition;
                value.PoisonGasWarningRadius = obj.PoisonGasWarningRadius;
                value.RedZonePosition = obj.RedZonePosition;
                value.RedZoneRadius = obj.RedZoneRadius;
                value.ROR = obj.ROR;
                value.DecryptOne = obj.DecryptOne;
                value.TableOne = obj.TableOne;
                value.TableTwo = obj.TableTwo;
                value.DecryptTwo = obj.DecryptTwo;
                value.PlayerCameraManager = obj.PlayerCameraManager;
                value.CameraPos = obj.CameraPos;
                value.CameraRot = obj.CameraRot;
                value.CameraFov = obj.CameraFov;
                value.Bone = obj.Bone;
                value.BoneArry = obj.BoneArry;
                value.Eyes = obj.Eyes;
                value.WeaponProcessor = obj.WeaponProcessor;
                value.EquippedWeapons = obj.EquippedWeapons;
                value.CurrentWeaponIndex = obj.CurrentWeaponIndex;
                value.WeaponTrajectoryData = obj.WeaponTrajectoryData;
                value.TrajectoryConfig = obj.TrajectoryConfig;
                value.AnimScriptInstance = obj.AnimScriptInstance;
                value.ControlRotationCP = obj.ControlRotationCP;
                value.RecoilADSRotationCP = obj.RecoilADSRotationCP;
                value.VehicleRiderComponent = obj.VehicleRiderComponent;
                value.LastVehiclePawn = obj.LastVehiclePawn;
                value.ActorRootComp = obj.ActorRootComp;
                value.ReplicatedMovement = obj.ReplicatedMovement;
                value.Veloctity = obj.Veloctity;
                value.背包状态 = obj.背包状态;
                value.MapMarker = obj.MapMarker;
                value.PartnerLevel = obj.PartnerLevel;
                value.SurvivalLevel = obj.SurvivalLevel;
                value.BWasKicked = obj.BWasKicked;
                value.WidgetStateMap = obj.WidgetStateMap;
                value.MyHUD = obj.MyHUD;
                value.BlockInputWidgetList = obj.BlockInputWidgetList;
                value.SelectMinimapSizeIndex = obj.SelectMinimapSizeIndex;
                value.DroppedItem = obj.DroppedItem;
                value.CurrentAmmoData = obj.CurrentAmmoData;
                value.ElapsedCookingTime = obj.ElapsedCookingTime;
                value.TimeTillExplosion = obj.TimeTillExplosion;
                value.TrainingMapGrid = obj.TrainingMapGrid;
                value.Visibility = obj.Visibility;
                value.Slot = obj.Slot;
                value.LayoutData = obj.LayoutData;
                value.Offsets = obj.Offsets;
                value.Alignment = obj.Alignment;
                value.地图判断 = obj.地图判断;

                return true;
            }
        }
        catch (Exception ex2)
        {
            MessageBox.Show("正在维护");
            return false;
        }
    }
    [Obfuscation(Feature = "virtualization", Exclude = false)]
    private void 解密(pg_data pg_data_0)
    {
        if (!登录验证()) { 结束进程(); }
        Shield = value.Shield;
        Uworld = value.Uworld;
        GNames = value.GNames;
        Leve = value.Leve;
        GameInstence = value.GameInstence;
        LocalPlayer = value.LocalPlayer;
        PlayerController = value.PlayerController;
        Actor = value.Actor;
        AcknowledgedPawn = value.AcknowledgedPawn;
        ObjID = value.ObjID;
        IDD = value.IDD;
        TeamNumber = value.TeamNumber;
        Health = value.Health;
        HealthDie = value.HealthDie;
        Audience = value.Audience;
        Playname = value.Playname;
        PlayerState = value.PlayerState;
        PlayerSatisitc = value.PlayerSatisitc;
        Mesh = value.Mesh;
        Position = value.Position;
        DroppedItemGroup = value.DroppedItemGroup;
        DroppedItemGroupUItem = value.DroppedItemGroupUItem;
        物品一 = value.物品一;
        物品二 = value.物品二;
        世界转小地图 = value.世界转小地图;
        被瞄偏移 = value.被瞄偏移;
        GameState = value.GameState;
        LerpSafetyZonePosition = value.LerpSafetyZonePosition;
        LerpSafetyZoneRadius = value.LerpSafetyZoneRadius;
        PoisonGasWarningPosition = value.PoisonGasWarningPosition;
        PoisonGasWarningRadius = value.PoisonGasWarningRadius;
        RedZonePosition = value.RedZonePosition;
        RedZoneRadius = value.RedZoneRadius;
        ROR = value.ROR;
        DecryptOne = value.DecryptOne;
        TableOne = value.TableOne;
        TableTwo = value.TableTwo;
        DecryptTwo = value.DecryptTwo;
        PlayerCameraManager = value.PlayerCameraManager;
        CameraPos = value.CameraPos;
        CameraRot = value.CameraRot;
        CameraFov = value.CameraFov;
        Bone = value.Bone;
        BoneArry = value.BoneArry;
        Eyes = value.Eyes;
        WeaponProcessor = value.WeaponProcessor;
        EquippedWeapons = value.EquippedWeapons;
        CurrentWeaponIndex = value.CurrentWeaponIndex;
        WeaponTrajectoryData = value.WeaponTrajectoryData;
        TrajectoryConfig = value.TrajectoryConfig;
        AnimScriptInstance = value.AnimScriptInstance;
        ControlRotationCP = value.ControlRotationCP;
        RecoilADSRotationCP = value.RecoilADSRotationCP;
        VehicleRiderComponent = value.VehicleRiderComponent;
        LastVehiclePawn = value.LastVehiclePawn;
        ActorRootComp = value.ActorRootComp;
        ReplicatedMovement = value.ReplicatedMovement;
        Veloctity = value.Veloctity;
        背包状态 = value.背包状态;
        MapMarker = value.MapMarker;
        PartnerLevel = value.PartnerLevel;
        SurvivalLevel = value.SurvivalLevel;
        BWasKicked = value.BWasKicked;
        WidgetStateMap = value.WidgetStateMap;
        MyHUD = value.MyHUD;
        BlockInputWidgetList = value.BlockInputWidgetList;
        SelectMinimapSizeIndex = value.SelectMinimapSizeIndex;
        DroppedItem = value.DroppedItem;
        CurrentAmmoData = value.CurrentAmmoData;
        ElapsedCookingTime = value.ElapsedCookingTime;
        TimeTillExplosion = value.TimeTillExplosion;
        TrainingMapGrid = value.TrainingMapGrid;
        Visibility = value.Visibility;
        Slot = value.Slot;
        LayoutData = value.LayoutData;
        Offsets = value.Offsets;
        Alignment = value.Alignment;
        地图判断 = value.地图判断;
    }

    public Class11(pg_data PG)
    {
        解密(PG);
        username = CommonProperty.username;
        KM_COM = Program.mainForm_0.KM_COM;
        if (!DMATEST())
        {
            MessageBox.Show(Resources.DMAinitFalse);
            结束进程();
        }
        获取各个参数的值();
        if (!热键监控)
        {
            Vmm.MAP_MODULEENTRY mAP_MODULEENTRY = vmm.Map_GetModuleFromName(4u, "win32ksgd.sys");
            if (mAP_MODULEENTRY.vaBase == 0L)
            {
                状态2("[Win10]使用DMA热键读取,首次初始化![Use DMA to read hot keys,prepare...]");
                if (!vmm.PidGetFromName("winlogon.exe", out winlogonpid))
                {
                    MessageBox.Show("winlogon.exe WinPid Get Failed!Pls reboot Game PC!");
                    结束进程();
                }
                winlogonpid |= 2147483648u;
                ulong vaBase = vmm.Map_GetModuleFromName(winlogonpid, "win32kbase.sys").vaBase;
                Vmm.MAP_EATINFO EatInfo;
                Vmm.MAP_EATENTRY[] array = vmm.Map_GetEAT(winlogonpid, "win32kbase.sys", out EatInfo);
                for (int i = 0; i < array.Length; i++)
                {
                    Vmm.MAP_EATENTRY mAP_EATENTRY = array[i];
                    if (mAP_EATENTRY.wszFunction.Trim() == "gafAsyncKeyState")
                    {
                        gafAsyncKeyStateAddress = mAP_EATENTRY.vaFunction;
                    }
                }
                if (gafAsyncKeyStateAddress == 0L)
                {
                    if (!File.Exists("KeyState.ini"))
                    {
                        MessageBox.Show("热键读取失败,请重启电脑![HotKeys Get Failed!Pls reboot Game PC!]");
                        结束进程();
                    }
                    else
                    {
                        using (StreamReader streamReader = new StreamReader("KeyState.ini"))
                        {
                            gafAsyncKeyStateAddress = vaBase + ulong.Parse(streamReader.ReadLine());
                            状态2("热键使用历史文本读取![Use Pid by file!]");
                        }
                    }
                }
                else
                {
                    using (StreamWriter streamWriter = new StreamWriter("KeyState.ini"))
                    {
                        streamWriter.WriteLine((gafAsyncKeyStateAddress - vaBase).ToString());
                    }
                }
            }
            else
            {
                状态2("[Win11]使用DMA热键读取,首次初始化![Use DMA to read hot keys,prepare...]");
                ulong vaBase2 = mAP_MODULEENTRY.vaBase;
                gafAsyncKeyStateAddress = method_24<ulong>(winlogonpid, method_24<ulong>(winlogonpid, method_24<ulong>(winlogonpid, vaBase2 + 12560L)));
                if (gafAsyncKeyStateAddress == 0L)
                {
                    winlogonpid = 4u;
                    gafAsyncKeyStateAddress = method_24<ulong>(winlogonpid, method_24<ulong>(winlogonpid, method_24<ulong>(winlogonpid, vaBase2 + 12560L)));
                }
                if (gafAsyncKeyStateAddress == 0L)
                {
                    gafAsyncKeyStateAddress = method_24<ulong>(winlogonpid, method_24<ulong>(winlogonpid, method_24<ulong>(winlogonpid, vaBase2 + 12568L)));
                }
                gafAsyncKeyStateAddress += 13968uL;
            }
            HsqakkX6Do = vmm.MemRead(winlogonpid, gafAsyncKeyStateAddress, 64u, 1u);
            if (HsqakkX6Do[61] != 32 && HsqakkX6Do[62] != 128 && HsqakkX6Do[60] != 130)
            {
                状态3("按键信息读取失败!hot keys prepare fail!", Color.Red);
            }
            else
            {
                状态2("按键信息读取成功!hot keys prepare done!");
                热键监控 = true;
            }
        }
        if (!读取游戏进程())
        {
            if (pid != 0)
            {
                //MessageBox.Show("解密失败!可能程序未更新!\r\n[Decryption failed! Perhaps the program has not been updated!]");
            }
            else
            {
                //MessageBox.Show("请先启动游戏!\r\n[Start Game First!]");
            }
            //结束进程();
            CommonProperty.GameStartSlim.Set();
            return;
        }
        dictionary_骨骼点.Add(0, 15);
        dictionary_骨骼点.Add(1, 5);
        dictionary_骨骼点.Add(2, 4);
        dictionary_骨骼点.Add(3, 0);
        ulong_1 = MemRead<ulong>(ulong_0 + Shield);
        if (ulong_1 == 0L)
        {
            //MessageBox.Show("解密失败!可能程序未更新!\r\n[Decryption failed! Perhaps the program has not been updated!]");
            //结束进程();
            CommonProperty.GameStartSlim.Set();
            return;
        }
        byte[] array2 = vmm.MemRead(pid, ulong_1, 512u, uint_0);
        if (array2.Length == 0)
        {
            //MessageBox.Show("解密失败!可能程序未更新!\r\n[Decryption failed! Perhaps the program has not been updated!]");
            //结束进程();
            CommonProperty.GameStartSlim.Set();
            return;
        }
        InitD(array2);
        状态2("初始化解密成功!\r\nInitialization and decryption succeeded!");
        using (StreamReader streamReader2 = new StreamReader("config\\MapList.ini"))
        {
            string text = "";
            while ((text = streamReader2.ReadLine()) != null)
            {
                if (text.Trim() != "")
                {
                    hashSet_地图.Add(text.Trim());
                }
            }
            状态2("地图载入成功!Map List Loaded!");
        }
        using (StreamReader streamReader3 = new StreamReader("config\\PlayerList.ini"))
        {
            string text2 = "";
            while ((text2 = streamReader3.ReadLine()) != null)
            {
                if (text2.Trim() != "")
                {
                    hashSet_人物.Add(text2.Trim());
                }
            }
            状态2("人物载入成功!People List Loaded!");
        }
        using (StreamReader streamReader4 = new StreamReader("config\\droi.ini"))
        {
            string text3 = "";
            while ((text3 = streamReader4.ReadLine()) != null)
            {
                if (text3.Trim() != "")
                {
                    hashSet_人机.Add(text3.Trim());
                }
            }
            状态2("人机载入成功!Bot List Loaded!");
        }
        using (StreamReader streamReader5 = new StreamReader("config\\box.ini"))
        {
            string text4 = "";
            while ((text4 = streamReader5.ReadLine()) != null)
            {
                if (text4.Trim() != "")
                {
                    hashSet_盒子.Add(text4.Trim());
                }
            }
            状态2("盒子载入成功!Box List Loaded!");
        }
        using (StreamReader streamReader6 = new StreamReader("config\\vehiclefilter.json"))
        {
            string value = streamReader6.ReadToEnd();
            dictionary_载具 = JsonConvert.DeserializeObject<Dictionary<string, 载具info>>(value);
            foreach (KeyValuePair<string, 载具info> item in dictionary_载具)
            {
                if (item.Value.showItem && item.Value.shortName != "")
                {
                    hashSet_载具.Add(item.Key.Trim());
                }
            }
            状态2("载具载入成功!Vehicle List Loaded!");
        }
        if (File.Exists("config\\throwablefilter.json"))
        {
            using (StreamReader streamReader7 = new StreamReader("config\\throwablefilter.json"))
            {
                string value2 = streamReader7.ReadToEnd();
                dictionary_投掷物 = JsonConvert.DeserializeObject<Dictionary<string, 投掷info>>(value2);
                foreach (KeyValuePair<string, 投掷info> item2 in dictionary_投掷物)
                {
                    hashSet_投掷物.Add(item2.Key.Trim());
                }
                状态2("投掷载入成功!Vehicle List Loaded!");
            }
        }
        using (StreamReader streamReader8 = new StreamReader("config\\itemfilter.json"))
        {
            string value3 = streamReader8.ReadToEnd();
            dictionary_物资 = JsonConvert.DeserializeObject<Dictionary<string, 物资info>>(value3);
            foreach (KeyValuePair<string, 物资info> item3 in JsonConvert.DeserializeObject<Dictionary<string, 物资info>>(value3))
            {
                dictionary_物资[item3.Key.Replace("Item_", "")] = dictionary_物资[item3.Key];
            }
            foreach (KeyValuePair<string, 物资info> item4 in dictionary_物资)
            {
                if (item4.Value.showItem && item4.Value.shortName != "")
                {
                    hashSet_物资.Add(item4.Key.Trim());
                }
            }
            状态2("物资载入成功!Item List Loaded!");
        }
        按键();
        Thread thread = new Thread(雷达MQTT);
        thread.IsBackground = true;
        thread.Start();
        Thread thread3 = new Thread(Start);
        thread3.IsBackground = true;
        thread3.Start();
        Thread thread4 = new Thread(雷达信息);
        thread4.IsBackground = true;
        thread4.Start();
        Thread thread5 = new Thread(融合器透视);
        thread5.IsBackground = true;
        thread5.Start();
    }

    private void Start()
    {
        Vector3 vector3_ = default(Vector3);
        Vector3 vector = default(Vector3);
        Vector3 vector2 = default(Vector3);
        Stopwatch stopwatch = new Stopwatch();
        Stopwatch stopwatch自瞄 = new Stopwatch();
        Stopwatch stopwatch透视 = new Stopwatch();
        Stopwatch stopwatch帧率 = new Stopwatch();
        Class9 @class = new Class9(pid, vmm);
        Class0 class2 = new Class0();
        uint num = 0u;
        int num2 = 0;
        uint num33 = 0u;
        while (ThreadRunning)
        {
            try
            {
                TS = vmm.Scatter_Initialize(pid, Vmm.FLAG_NOCACHE);
                HS = vmm.Scatter_Initialize(pid, Vmm.FLAG_NOCACHE);
                ulong uword = Read<ulong>(ulong_0 + Uworld);
                if (uword == 0)
                {
                    vmm.ConfigSet(Vmm.OPT_REFRESH_ALL, 1);
                    this.MapAddr = 0uL;
                    this.MinimapCanvasWidgetAddr = 0uL;
                    this.MapGrid = 0uL;
                    this.Slot1 = 0uL;
                    class2.method_1();
                    class2.地图 = "\"Range_Main\"";
                    class_本人 = new Class1();
                    hashSet_友军.Clear();
                    hashSet_白名单.Clear();
                    dictionary_本人.Clear();
                    dictionary投掷物.Clear();
                    dictionary_人物.Clear();
                    dictionary物资.Clear();
                    dictionary地图资源.Clear();
                    dictionary_全.Clear();
                    状态("地图", "等待游戏进程[Lobby]", false);
                    状态("延迟", "[0000]", false);
                    状态("清理友军黑名单", "");
                    concurrentQueue_1.Enqueue(class2.method_0());
                    autoResetEvent_1.Set();
                    if (透视)
                    {
                        CommonProperty.fov = 0;
                        CommonProperty.本人观战人数 = 0;
                        EspOverlay.Clear4();
                        EspOverlay.Clear3();
                        EspOverlay.Clear2();
                        EspOverlay.Clear();
                    }
                    ThreadRunning = false;
                    CommonProperty.GameStartSlim.Set();
                    break;
                }
                this.基准值 = method_4(uword);
                当前地图 = MemGetName(DecryptCIndex(MemRead<uint>(this.基准值 + ObjID)));
                vmm.ConfigSet(Vmm.OPT_REFRESH_ALL, 1);
                //vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                //vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                if (当前地图 == "")
                {
                    num++;
                    Thread.Sleep(100);
                    if (num == 20)
                    {
                        //MessageBox.Show("读取地图失败!可能程序未启动!\r\n[Read map name failed! Perhaps the program has not been started!]");
                        //结束进程();
                        CommonProperty.GameStartSlim.Set();
                        return;
                    }
                    continue;
                }
                num = 0u;
                if (!当前地图.Contains("TslLobby"))
                {
                    if (hashSet_地图.Contains(当前地图))
                    {
                        状态("地图", 当前地图);
                        ulong num3 = 0uL;
                        uint num4 = 0u;
                        class_本人 = new Class1();
                        dictionary_人物.Clear();
                        class_本人.TeamID = 19831029u;
                        ulong 循环次数 = 0uL;
                        int 左下角延迟_主线程 = 0;
                        class2.method_1();
                        dictionary_全.Clear();
                        dictionary_3.Clear();
                        hashSet_雷达信息.Clear();
                        this.MapAddr = 0uL;
                        this.MinimapCanvasWidgetAddr = 0uL;
                        this.MapGrid = 0uL;
                        this.Slot1 = 0uL;
                        //try
                        //{
                        //    if (!KM_COM.IsOpen && 控制器类型 != 0)
                        //    {
                        //        KM_COM.PortName = COM端口;
                        //        KM_COM.DataBits = 8;
                        //        KM_COM.StopBits = StopBits.One;
                        //        KM_COM.Parity = Parity.None;
                        //        KM_COM.BaudRate = int.Parse(波动率);
                        //        KM_COM.Open();
                        //    }
                        //}
                        //catch
                        //{
                        //    MessageBox.Show("控制器打开失败![Control device Open Fail!]");
                        //    结束进程();
                        //}
                        ulong 对象指针 = method_4(MemRead<ulong>(method_4(MemRead<ulong>(this.基准值 + Leve)) + Actor));
                        if (!kyZpsbAxnb(对象指针, this.基准值))
                        {
                            vmm.ConfigSet(Vmm.OPT_REFRESH_ALL, 1);
                            Thread.Sleep(500);
                            continue;
                        }
                        //if (debug)
                        //{
                        //    状态2("对象指针读取失败,读取的值: " + 对象指针 + " 基准值: " + this.基准值);
                        //}
                        while (this.基准值 == method_4(Read<ulong>(ulong_0 + Uworld)))
                        {
                            bool bool_ = false;
                            按键();
                            if (数据刷新)
                            {
                                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                                //vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_SLOW, 1);
                                this.MapAddr = 0uL;
                                this.MinimapCanvasWidgetAddr = 0uL;
                                this.MapGrid = 0uL;
                                this.Slot1 = 0uL;
                                循环次数 = 1500uL;
                                class_本人 = new Class1();
                                dictionary_本人.Clear();
                                dictionary_人物.Clear();
                                dictionary地图资源.Clear();
                                dictionary物资.Clear();
                                dictionary丢弃的物资.Clear();
                                dictionary_全.Clear();
                                EspOverlay.Clear4();
                                EspOverlay.Clear3();
                                EspOverlay.Clear2();
                                EspOverlay.Clear();
                                状态2("数据全量刷新![All Data refreshed!]");
                            }
                            stopwatch.Reset();
                            stopwatch.Start();
                            //if (this.瞄准地址 > 0L)
                            //{
                            //    stopwatch自瞄.Restart();
                            //    stopwatch自瞄.Start();
                            //}
                            if (透视)
                            {
                                stopwatch透视.Restart();
                                stopwatch透视.Start();
                            }
                            瞄准 = false;
                            while (this.瞄准地址 > 0L)
                            {
                                stopwatch自瞄.Restart();
                                stopwatch自瞄.Start();
                                @class.Add<byte>(class_本人.当前武器 + CurrentAmmoData);
                                @class.Finish();
                                this.ammoData = @class.Get<byte>(class_本人.当前武器 + CurrentAmmoData);
                                if (ammoData == 0)
                                {
                                    this.瞄准地址 = 0;
                                    break;
                                }
                                CommonProperty.fov = 0;
                                num33++;
                                按键();
                                if (热键黑名单 && this.瞄准地址 > 0L && dictionary_人物.ContainsKey(this.瞄准地址) && dictionary_人物[this.瞄准地址].是否人机 == 0 && dictionary_人物[this.瞄准地址].name != "")
                                {
                                    Program.mainForm_0.Hash_黑名单.Add(dictionary_人物[this.瞄准地址].name);
                                }
                                @class.Clear();
                                if (dictionary_人物.ContainsKey(this.瞄准地址))
                                {
                                    @class.Add<ulong>(dictionary_人物[this.瞄准地址].addr + Mesh);
                                    @class.Add<ulong>(dictionary_人物[this.瞄准地址].人物视角 + Bone);
                                    @class.Add<ulong>(dictionary_人物[this.瞄准地址].addr + VehicleRiderComponent);
                                    @class.Add<ulong>(dictionary_人物[this.瞄准地址].addr + ActorRootComp);
                                    @class.Add<ulong>(dictionary_人物[this.瞄准地址].ulong_6 + LastVehiclePawn);
                                    @class.Add<Vector3>(dictionary_人物[this.瞄准地址].ulong_8 + ReplicatedMovement);
                                    @class.Add<Vector3>(dictionary_人物[this.瞄准地址].预判 + Veloctity);
                                    @class.Add<float>(dictionary_人物[this.瞄准地址].addr + Health);
                                    @class.Add<float>(dictionary_人物[this.瞄准地址].addr + HealthDie);
                                    @class.Add<ulong>(class_本人.本人视角 + AnimScriptInstance);
                                    @class.Finish();
                                    dictionary_人物[this.瞄准地址].人物血量 = @class.Get<float>(dictionary_人物[this.瞄准地址].addr + Health);
                                    dictionary_人物[this.瞄准地址].倒地血量 = @class.Get<float>(dictionary_人物[this.瞄准地址].addr + HealthDie);
                                    if (dictionary_人物[this.瞄准地址].人物血量 > 100f || float.IsNaN(dictionary_人物[this.瞄准地址].人物血量))
                                    {
                                        dictionary_人物[this.瞄准地址].人物血量 = 100f;
                                    }
                                    if (dictionary_人物[this.瞄准地址].倒地血量 > 100f || float.IsNaN(dictionary_人物[this.瞄准地址].倒地血量))
                                    {
                                        dictionary_人物[this.瞄准地址].倒地血量 = 100f;
                                    }
                                    if (dictionary_人物[this.瞄准地址].人物血量 < 0f)
                                    {
                                        dictionary_人物[this.瞄准地址].人物血量 = 0f;
                                    }
                                    if (dictionary_人物[this.瞄准地址].倒地血量 < 0f)
                                    {
                                        dictionary_人物[this.瞄准地址].倒地血量 = 0f;
                                    }
                                    if (dictionary_人物[this.瞄准地址].人物血量 * 10000f + dictionary_人物[this.瞄准地址].倒地血量 * 10000f != 0f)
                                    {
                                        ulong num8 = @class.Get<ulong>(dictionary_人物[this.瞄准地址].addr + Mesh);
                                        if (num8 > 0L && dictionary_人物[this.瞄准地址].人物视角 == num8)
                                        {
                                            dictionary_人物[this.瞄准地址].人物视角 = num8;
                                            ulong ulong_ = @class.Get<ulong>(class_本人.本人视角 + AnimScriptInstance);
                                            if (kyZpsbAxnb(ulong_, class_本人.本人指针addr))
                                            {
                                                class_本人.Animasccript = ulong_;
                                                class_本人.可视 = MemRead<float>(class_本人.本人视角 + Eyes);
                                                dictionary_人物[this.瞄准地址].人物位面 = MemRead<float>(dictionary_人物[this.瞄准地址].人物视角 + Eyes);
                                                dictionary_人物[this.瞄准地址].是否可视 = ((dictionary_人物[this.瞄准地址].人物位面 >= class_本人.可视) ? 1 : 0);
                                                if (dictionary_人物[this.瞄准地址].是否可视 != 0)
                                                {
                                                    dictionary_人物[this.瞄准地址].Bone = @class.Get<ulong>(dictionary_人物[this.瞄准地址].人物视角 + Bone);
                                                    dictionary_人物[this.瞄准地址].ulong_6 = @class.Get<ulong>(dictionary_人物[this.瞄准地址].addr + VehicleRiderComponent);
                                                    dictionary_人物[this.瞄准地址].预判 = method_4(@class.Get<ulong>(dictionary_人物[this.瞄准地址].addr + ActorRootComp));
                                                    dictionary_人物[this.瞄准地址].ulong_8 = @class.Get<ulong>(dictionary_人物[this.瞄准地址].ulong_6 + LastVehiclePawn);
                                                    if (dictionary_人物[this.瞄准地址].ulong_8 > 0L)
                                                    {
                                                        dictionary_人物[this.瞄准地址].vector3_预判 = @class.Get<Vector3>(dictionary_人物[this.瞄准地址].ulong_8 + ReplicatedMovement);
                                                    }
                                                    else
                                                    {
                                                        dictionary_人物[this.瞄准地址].vector3_预判 = @class.Get<Vector3>(dictionary_人物[this.瞄准地址].预判 + Veloctity);
                                                    }
                                                    if (自瞄倒地 || dictionary_人物[this.瞄准地址].人物血量 * 10000f != 0f)
                                                    {
                                                        uint_2 = (uint)MemRead<byte>(class_本人.玩家控制 + PlayerCameraManager + 392L) % 2u;
                                                        if (uint_2 == 0)
                                                        {
                                                            if (!子骨骼自瞄)
                                                            {
                                                                if (class7_0.父骨骼 == 0)
                                                                {
                                                                    this.瞄准地址 = 0;
                                                                    continue;
                                                                }
                                                                else
                                                                {
                                                                    dictionary_人物[this.瞄准地址].瞄准_Bone = MemRead<FTransform>(dictionary_人物[this.瞄准地址].Bone + (ulong)(class7_0.父骨骼 * 48L));
                                                                }
                                                            }
                                                            else
                                                            {
                                                                dictionary_人物[this.瞄准地址].瞄准_Bone = MemRead<FTransform>(dictionary_人物[this.瞄准地址].Bone + (ulong)(class7_0.子骨骼 * 48L));
                                                            }
                                                            dictionary_人物[this.瞄准地址].Actor_Bone = MemRead<FTransform>(dictionary_人物[this.瞄准地址].人物视角 + BoneArry);
                                                            Vector2 vector2_骨骼点 = default(Vector2);
                                                            D3DMATRIX d3DMATRIX_ = dictionary_人物[this.瞄准地址].瞄准_Bone.ToMatrixWithScale();
                                                            D3DMATRIX d3DMATRIX_2 = dictionary_人物[this.瞄准地址].Actor_Bone.ToMatrixWithScale();
                                                            D3DMATRIX d3DMATRIX = method_35(d3DMATRIX_, d3DMATRIX_2);
                                                            Vector3 vector3 = default(Vector3);
                                                            vector3.x = d3DMATRIX._41;
                                                            vector3.y = d3DMATRIX._42;
                                                            vector3.z = d3DMATRIX._43;
                                                            Vector3 vector骨骼点坐标 = vector3;
                                                            @class.Clear();
                                                            @class.Add<Vector3>(class_本人.Animasccript + ControlRotationCP, true);
                                                            @class.Add<Vector3>(class_本人.Animasccript + RecoilADSRotationCP, true);
                                                            if (!透视)
                                                            {
                                                                @class.Add<float>(class_本人.投影相机 + CameraFov, true);
                                                                @class.Add<Vector3>(class_本人.投影相机 + CameraPos);
                                                                @class.Add<FRotator>(class_本人.投影相机 + CameraRot);
                                                            }
                                                            @class.Finish();
                                                            class_本人.vector3_2 = MemRead<Vector3>(class_本人.Animasccript + ControlRotationCP);
                                                            class_本人.vector3_3 = MemRead<Vector3>(class_本人.Animasccript + RecoilADSRotationCP);
                                                            if (!透视)
                                                            {
                                                                class_本人.fcameraCacheData_0.POV.FOV = @class.Get<float>(class_本人.投影相机 + CameraFov);
                                                                class_本人.fcameraCacheData_0.POV.Location = @class.Get<Vector3>(class_本人.投影相机 + CameraPos);
                                                                class_本人.fcameraCacheData_0.POV.Rotation = @class.Get<FRotator>(class_本人.投影相机 + CameraRot);
                                                            }
                                                            @class.Clear();
                                                            float float_人物距离 = (float)method_34(相减(class_本人.fcameraCacheData_0.POV.Location, vector骨骼点坐标)) / 100f;
                                                            Vector3 vector3_提前量 = 计算抬枪量(vector骨骼点坐标, float_人物距离, dictionary_人物[this.瞄准地址].vector3_预判);
                                                            if (!自瞄兼容模式)
                                                            {
                                                                if (!method_37(class_本人.fcameraCacheData_0.POV.FOV, class_本人.vector3_2, class_本人.vector3_3, class_本人.fcameraCacheData_0.POV.Location, vector3_提前量, ref vector2_骨骼点))
                                                                {
                                                                    continue;
                                                                }
                                                                vector2_1 = vector2_骨骼点;
                                                                int x轴 = (int)Math.Round((double)vector2_骨骼点.x - (double)X分辨率 / 2);
                                                                int Y轴 = (int)Math.Round((double)vector2_骨骼点.y - (double)Y分辨率 / 2);
                                                                if (Y轴 != 0)
                                                                {
                                                                    Y轴 += class7_0.自瞄修正;
                                                                }
                                                                int x轴绝对值 = Math.Abs(x轴);
                                                                int y轴绝对值 = Math.Abs(Y轴);
                                                                if (Math.Abs(x轴) > X分辨率 || Math.Abs(Y轴) > Y分辨率)
                                                                {
                                                                    this.瞄准地址 = 0uL;
                                                                    break;
                                                                }
                                                                if (x轴 == 0 && Y轴 == 0)
                                                                {
                                                                    continue;
                                                                }
                                                                if (x轴绝对值 > class7_0.X轴自瞄力度 && x轴 != 0)
                                                                {
                                                                    x轴 = x轴 / x轴绝对值 * class7_0.X轴自瞄力度;
                                                                }
                                                                if (y轴绝对值 > class7_0.Y轴自瞄力度 && Y轴 != 0)
                                                                {
                                                                    Y轴 = Y轴 / y轴绝对值 * class7_0.Y轴自瞄力度;
                                                                }
                                                                if (!class7_0.Y轴自瞄开关 && Y轴 > 0)
                                                                {
                                                                    Y轴 = 0;
                                                                }
                                                                //int 死区 = 300;
                                                                //int num111 = Math.Abs(x轴);
                                                                //int num122 = Math.Abs(Y轴);
                                                                //int 死区范围 = (int)(死区 / float_人物距离 * (80 / class_本人.fcameraCacheData_0.POV.FOV));
                                                                //if (死区 > 0)
                                                                //{
                                                                //    if (num111 <= 死区范围)
                                                                //    {
                                                                //        x轴 = 0;
                                                                //        //Y轴 = 0;
                                                                //    }
                                                                //    else
                                                                //    {
                                                                //        if(x轴 < 0)
                                                                //        {
                                                                //            x轴 = x轴 + 死区范围;
                                                                //        }
                                                                //        else if (x轴 > 0)
                                                                //        {
                                                                //            x轴 = x轴 - 死区范围;
                                                                //        }
                                                                //    }
                                                                //}
                                                                if (!class7_0.自瞄随机开关 || 子骨骼自瞄)
                                                                {
                                                                    计算自瞄值(x轴, Y轴, 子骨骼自瞄);
                                                                }
                                                                else
                                                                {
                                                                    int 随机数 = new Random().Next(100);
                                                                    if (随机数 >= class7_0.自瞄随机值)
                                                                    {
                                                                        if (debug)
                                                                        {
                                                                            状态2("自瞄随机开启,本次放弃自瞄,随机值: " + class7_0.自瞄随机值 + "> awddddd当前值: " + 随机数);
                                                                        }
                                                                        continue;
                                                                    }
                                                                    计算自瞄值(x轴, Y轴);
                                                                }
                                                                stopwatch自瞄.Stop();
                                                                int num14 = (int)stopwatch自瞄.Elapsed.TotalMilliseconds;
                                                                if (num33 % 50 == 0)
                                                                {
                                                                    状态("延迟", "[" + (num14).ToString("D4") + "]");
                                                                }
                                                                if (class7_0.自瞄响应 - 1 > num14)
                                                                {
                                                                    帧率锁(class7_0.自瞄响应 - 1 - num14);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                if (!method_36(class_本人.fcameraCacheData_0.POV.FOV, class_本人.vector3_2, class_本人.vector3_3, class_本人.fcameraCacheData_0.POV.Location, vector3_提前量, ref vector2_骨骼点))
                                                                {
                                                                    continue;
                                                                }
                                                                int num15 = (int)Math.Round((double)vector2_骨骼点.x - (double)X分辨率 / 2.0);
                                                                int num16 = (int)Math.Round((double)vector2_骨骼点.y - (double)Y分辨率 / 2.0);
                                                                if (num16 != 0)
                                                                {
                                                                    num16 += class7_0.自瞄修正;
                                                                }
                                                                int num17 = Math.Abs(num15);
                                                                int num18 = Math.Abs(num16);
                                                                if (Math.Abs(num15) > (double)X分辨率 || Math.Abs(num16) > (double)Y分辨率)
                                                                {
                                                                    this.瞄准地址 = 0uL;
                                                                    break;
                                                                }
                                                                if (num15 == 0 && num16 == 0)
                                                                {
                                                                    continue;
                                                                }
                                                                if (num17 > class7_0.X轴自瞄力度 && num15 != 0)
                                                                {
                                                                    num15 = num15 / num17 * class7_0.X轴自瞄力度;
                                                                }
                                                                if (num18 > class7_0.Y轴自瞄力度 && num16 != 0)
                                                                {
                                                                    num16 = num16 / num18 * class7_0.Y轴自瞄力度;
                                                                }
                                                                if (!class7_0.Y轴自瞄开关 && num16 > 0)
                                                                {
                                                                    num16 = 0;
                                                                }
                                                                if (class7_0.自瞄随机开关 && !子骨骼自瞄)
                                                                {
                                                                    int num19 = new Random().Next(100);
                                                                    if (num19 >= class7_0.自瞄随机值)
                                                                    {
                                                                        if (debug)
                                                                        {
                                                                            状态2("自瞄随机开启,本次放弃自瞄,随机值: " + class7_0.自瞄随机值 + "> awddddd当前值: " + num19);
                                                                        }
                                                                        continue;
                                                                    }
                                                                    计算自瞄值(num15, num16);
                                                                }
                                                                else
                                                                {
                                                                    计算自瞄值(num15, num16, 子骨骼自瞄);
                                                                }
                                                                stopwatch自瞄.Stop();
                                                                int num20 = (int)stopwatch自瞄.Elapsed.TotalMilliseconds;
                                                                状态("延迟", "[" + (num20).ToString("D4") + "]");
                                                                if (class7_0.自瞄响应 > num20)
                                                                {
                                                                    帧率锁(class7_0.自瞄响应 - num20);
                                                                }
                                                            }
                                                            this.瞄准 = true;
                                                            continue;
                                                        }
                                                        this.瞄准 = false;
                                                        this.瞄准地址 = 0uL;
                                                        break;
                                                    }
                                                    this.瞄准 = false;
                                                    this.瞄准地址 = 0uL;
                                                    break;
                                                }
                                                this.瞄准 = false;
                                                this.瞄准地址 = 0uL;
                                                break;
                                            }
                                            if (debug)
                                            {
                                                状态2("AnimScriptInstance读取失败,读取的值: " + ulong_ + " 基准值: " + class_本人.本人指针addr);
                                            }
                                            this.瞄准 = false;
                                            this.瞄准地址 = 0uL;
                                            break;
                                        }
                                        this.瞄准 = false;
                                        this.瞄准地址 = 0uL;
                                        break;
                                    }
                                    this.瞄准 = false;
                                    this.瞄准地址 = 0uL;
                                    break;
                                }
                                this.瞄准 = false;
                                this.瞄准地址 = 0uL;
                                break;
                            }
                            if (自瞄)
                            {
                                float fov = class7_0.自瞄FOV;
                                if (动态FOV && class_本人.fcameraCacheData_0.POV.FOV != 0)
                                {
                                    fov = (80 / class_本人.fcameraCacheData_0.POV.FOV) * (float)class7_0.自瞄FOV;
                                }
                                float 自瞄距离 = class7_0.自瞄距离;
                                CommonProperty.fov = fov;

                                foreach (KeyValuePair<ulong, Actor人物> item58 in dictionary_人物)
                                {
                                    D3DMATRIX d3DMATRIX_15 = item58.Value.Actor_Bone.ToMatrixWithScale();
                                    D3DMATRIX d3DMATRIX_16 = item58.Value.瞄准_Bone.ToMatrixWithScale();
                                    D3DMATRIX d3DMATRIX14 = method_35(d3DMATRIX_16, d3DMATRIX_15);
                                    item58.Value.vector3_1.x = d3DMATRIX14._41;
                                    item58.Value.vector3_1.y = d3DMATRIX14._42;
                                    item58.Value.vector3_1.z = d3DMATRIX14._43;
                                    item58.Value.瞄准 = 计算透视坐标(item58.Value.vector3_1);
                                    if (item58.Value.Bone == 0L || item58.Value.人物血量 * 10000f + item58.Value.倒地血量 * 10000f == 0f || (!自瞄倒地 && item58.Value.人物血量 * 10000f == 0f && item58.Value.倒地血量 > 0f && item58.Value.倒地血量 < 100.1f) || item58.Value.是否友军 == 1)
                                    {
                                        continue;
                                    }
                                    uint 人物距离 = item58.Value.距离;
                                    float 人物基于显示器的位置 = method_40((float)X分辨率 / 2f, (float)Y分辨率 / 2f, item58.Value.瞄准.x, item58.Value.瞄准.y);
                                    if (class7_0.自瞄优先级 == 0)
                                    {
                                        if (人物距离 <= class7_0.自瞄距离 && 人物基于显示器的位置 < fov && item58.Value.是否可视 == 1)
                                        {
                                            this.瞄准地址 = item58.Value.addr;
                                            fov = 人物基于显示器的位置;
                                        }
                                    }
                                    else if (!(人物基于显示器的位置 > fov) && (float)人物距离 < 自瞄距离 && item58.Value.是否可视 == 1)
                                    {
                                        this.瞄准地址 = item58.Value.addr;
                                        自瞄距离 = 人物距离;
                                    }
                                    if (this.瞄准地址 > 0)
                                    {
                                        EspOverlay.Clear4();
                                        EspOverlay.Clear3();
                                        EspOverlay.Clear2();
                                    }
                                }
                            }
                            if (this.瞄准地址 > 0L && dictionary_人物.ContainsKey(this.瞄准地址) && 自瞄)
                            {
                                TS.Prepare(dictionary_人物[this.瞄准地址].人物视角 + BoneArry, 50);
                                TS.Prepare(dictionary_人物[this.瞄准地址].人物视角 + Bone, 4);
                            }
                            TS.Execute();
                            if (this.瞄准地址 > 0L && dictionary_人物.ContainsKey(this.瞄准地址) && 自瞄)
                            {
                                dictionary_人物[this.瞄准地址].Actor_Bone = TS.Read<FTransform>(dictionary_人物[this.瞄准地址].人物视角 + BoneArry);
                                dictionary_人物[this.瞄准地址].Bone = TS.Read<ulong>(dictionary_人物[this.瞄准地址].人物视角 + Bone);
                            }
                            TS.Clear(pid, Vmm.FLAG_NOCACHE);
                            if (this.瞄准地址 > 0L && dictionary_人物.ContainsKey(this.瞄准地址))
                            {
                                if (子骨骼自瞄)
                                {
                                    TS.Prepare(dictionary_人物[this.瞄准地址].Bone + (ulong)(class7_0.子骨骼 * 48L), 50);
                                }
                                else
                                {
                                    if (class7_0.父骨骼 == 0)
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        TS.Prepare(dictionary_人物[this.瞄准地址].Bone + (ulong)(class7_0.父骨骼 * 48L), 50);
                                    }
                                }
                                TS.Prepare(dictionary_人物[this.瞄准地址].addr + VehicleRiderComponent, 4);
                                TS.Prepare(dictionary_人物[this.瞄准地址].addr + ActorRootComp, 4);

                            }
                            TS.Execute();
                            if (this.瞄准地址 > 0L && dictionary_人物.ContainsKey(this.瞄准地址) && 自瞄)
                            {
                                if (!子骨骼自瞄)
                                {
                                    if (class7_0.父骨骼 == 0)
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        dictionary_人物[this.瞄准地址].瞄准_Bone = TS.Read<FTransform>(dictionary_人物[this.瞄准地址].Bone + (ulong)(class7_0.父骨骼 * 48L));
                                    }
                                }
                                else
                                {
                                    dictionary_人物[this.瞄准地址].瞄准_Bone = TS.Read<FTransform>(dictionary_人物[this.瞄准地址].Bone + (ulong)(class7_0.子骨骼 * 48L));
                                }
                                dictionary_人物[this.瞄准地址].ulong_6 = TS.Read<ulong>(dictionary_人物[this.瞄准地址].addr + VehicleRiderComponent);
                                dictionary_人物[this.瞄准地址].预判 = method_4(TS.Read<ulong>(dictionary_人物[this.瞄准地址].addr + ActorRootComp));
                            }
                            TS.Clear(pid, Vmm.FLAG_NOCACHE);
                            if (this.瞄准地址 > 0L && dictionary_人物.ContainsKey(this.瞄准地址) && 自瞄)
                            {
                                TS.Prepare(dictionary_人物[this.瞄准地址].ulong_6 + LastVehiclePawn, 4);
                            }
                            TS.Execute();
                            if (this.瞄准地址 > 0L && dictionary_人物.ContainsKey(this.瞄准地址) && 自瞄)
                            {
                                dictionary_人物[this.瞄准地址].ulong_8 = TS.Read<ulong>(dictionary_人物[this.瞄准地址].ulong_6 + LastVehiclePawn);
                            }
                            TS.Clear(pid, Vmm.FLAG_NOCACHE);
                            if (this.瞄准地址 > 0L && 自瞄)
                            {
                                if (dictionary_人物[this.瞄准地址].ulong_8 > 0L)
                                {
                                    TS.Prepare(dictionary_人物[this.瞄准地址].ulong_8 + ReplicatedMovement, 12);
                                    TS.Prepare(dictionary_人物[this.瞄准地址].ulong_8 + ReplicatedMovement - 40L, 12);
                                }
                                else
                                {
                                    TS.Prepare(dictionary_人物[this.瞄准地址].预判 + Veloctity, 12);
                                    TS.Prepare(dictionary_人物[this.瞄准地址].预判 + Veloctity - 40L, 12);
                                }
                            }
                            TS.Execute();
                            if (this.瞄准地址 > 0L && 自瞄)
                            {
                                if (dictionary_人物[this.瞄准地址].ulong_8 > 0L)
                                {
                                    dictionary_人物[this.瞄准地址].vector3_预判 = TS.Read<Vector3>(dictionary_人物[this.瞄准地址].ulong_8 + ReplicatedMovement);
                                }
                                else
                                {
                                    dictionary_人物[this.瞄准地址].vector3_预判 = TS.Read<Vector3>(dictionary_人物[this.瞄准地址].预判 + Veloctity);
                                }
                            }
                            TS.Clear(pid, Vmm.FLAG_NOCACHE);
                            if (this.瞄准地址 > 0L)
                            {
                                continue;
                            }
                            瞄准 = false;
                            if (!自瞄 && class_本人.fcameraCacheData_0.POV.FOV != 0)
                            {
                                if (动态FOV)
                                {
                                    CommonProperty.fov = (80 / class_本人.fcameraCacheData_0.POV.FOV) * (float)class7_0.自瞄FOV;
                                }
                                else
                                {
                                    CommonProperty.fov = class7_0.自瞄FOV;
                                }
                            }
                            循环次数++;
                            @class.Clear();
                            stopwatch透视.Stop();
                            int 自瞄帧率 = (int)stopwatch透视.Elapsed.TotalMilliseconds;
                            if (自瞄帧率 < 1000 / 帧率 - 2)
                            {
                                帧率锁((1000 / 帧率 - 2) - 自瞄帧率);
                            }
                            class2.地图 = "\"" + 当前地图 + "\"";
                            if (class_本人.本人指针addr == 0L)
                            {
                                class_本人.玩家控制 = method_4(Read<ulong>(method_4(Read<ulong>(Read<ulong>(method_4(Read<ulong>(this.基准值 + GameInstence)) + LocalPlayer))) + PlayerController));
                                class_本人.投影相机 = Read<ulong>(class_本人.玩家控制 + PlayerCameraManager);
                                class_本人.本人指针addr = method_4(Read<ulong>(class_本人.玩家控制 + AcknowledgedPawn));
                            }
                            if (class_本人.本人指针addr > 0L)
                            {
                                if (class_本人.TeamID == 19831029)
                                {
                                    class_本人.TeamID = method_23<uint>(class_本人.本人指针addr + TeamNumber, ref bool_);
                                    if (!bool_)
                                    {
                                        class_本人.TeamID = 19831029u;
                                    }
                                }
                                if (class_本人.本人name == "")
                                {
                                    class_本人.本人name = method_3(MemRead<ulong>(class_本人.本人指针addr + Playname), 64u);
                                }
                                if (class_本人.本人视角 == 19831029L)
                                {
                                    ulong 本人视角 = method_23<ulong>(class_本人.本人指针addr + Mesh, ref bool_);
                                    if (!(kyZpsbAxnb(本人视角, class_本人.本人指针addr) && bool_))
                                    {
                                        class_本人.本人视角 = 19831029uL;
                                        if (debug)
                                        {
                                            状态2("本人视角读取失败,读取的值: " + 本人视角 + " 基准值: " + class_本人.本人指针addr);
                                        }
                                    }
                                    else
                                    {
                                        class_本人.本人视角 = 本人视角;
                                    }
                                }
                                if (class_本人.本人状态 == 19831029L)
                                {
                                    ulong ulong_3 = method_23<ulong>(class_本人.本人指针addr + PlayerState, ref bool_);
                                    if (bool_)
                                    {
                                        ulong_3 = method_4(ulong_3);
                                        if (!kyZpsbAxnb(ulong_3, class_本人.本人指针addr))
                                        {
                                            class_本人.本人状态 = 19831029uL;
                                            if (debug)
                                            {
                                                状态2("本人状态读取失败,读取的值: " + ulong_3 + " 基准值: " + class_本人.本人指针addr);
                                            }
                                        }
                                        else
                                        {
                                            class_本人.本人状态 = ulong_3;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                class_本人.bool_0 = true;
                            }


                            TS.Clear(pid, Vmm.FLAG_NOCACHE);
                            TS.Prepare(对象指针, 4);
                            TS.Prepare(对象指针 + 8L, 4);
                            TS.Execute();
                            ulong num21 = TS.Read<ulong>(对象指针);
                            uint num22 = TS.Read<uint>(对象指针 + 8L);
                            TS.Clear(pid, Vmm.FLAG_NOCACHE);
                            if (num21 > 0L && num22 != 0)
                            {
                                num3 = num21;
                                num4 = num22;
                            }
                            else
                            {
                                num21 = num3;
                                num22 = num4;
                            }
                            if (num22 == 0 || num22 > 16384)
                            {
                                //vmm.ConfigSet(Vmm.OPT_REFRESH_ALL, 1);
                                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                                vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                                continue;
                            }
                            TS.Prepare(this.基准值 + GameState, 4);
                            TS.Prepare(this.基准值 + 世界转小地图, 12);
                            if (透视 && this.MinimapCanvasWidgetAddr != 0L && CommonProperty.pgConfig.EspConfig.小地图)
                            {
                                TS.Prepare(this.MinimapCanvasWidgetAddr + SelectMinimapSizeIndex, 1);
                            }
                            TS.Prepare(class_本人.玩家控制 + PlayerCameraManager + 392L, 1);
                            if (class_本人.本人视角 > 0L)
                            {
                                TS.Prepare(class_本人.本人视角 + AnimScriptInstance, 4);
                                TS.Prepare(class_本人.本人视角 + Position, 12);
                                TS.Prepare(class_本人.本人指针addr + WeaponProcessor, 4);
                            }
                            for (int i = 0; i < num22; i++)
                            {
                                TS.Prepare(num21 + (ulong)(8 * i), 4);
                            }
                            TS.Execute();
                            ulong num23 = method_4(TS.Read<ulong>(this.基准值 + GameState));
                            全地图XY = TS.Read<Vector3Int>(this.基准值 + 世界转小地图);
                            if (透视 && this.MinimapCanvasWidgetAddr != 0L && CommonProperty.pgConfig.EspConfig.小地图)
                            {
                                小地图放大 = TS.Read<bool>(this.MinimapCanvasWidgetAddr + SelectMinimapSizeIndex);
                            }
                            uint_2 = (uint)TS.Read<byte>(class_本人.玩家控制 + PlayerCameraManager + 392L) % 2u;
                            if (class_本人.本人视角 > 0L)
                            {
                                ulong ulong_4 = TS.Read<ulong>(class_本人.本人视角 + AnimScriptInstance);
                                if (kyZpsbAxnb(ulong_4, class_本人.本人指针addr))
                                {
                                    class_本人.Animasccript = ulong_4;
                                }
                                else if (debug)
                                {
                                    状态2("AnimScriptInstance读取失败,读取的值: " + ulong_4 + " 基准值: " + class_本人.本人指针addr);
                                }
                                class_本人.vector3_0 = TS.Read<Vector3>(class_本人.本人视角 + Position);
                                class_本人.vector3_距离坐标 = 相加(class_本人.vector3_0);
                                ulong ulong_5 = TS.Read<ulong>(class_本人.本人指针addr + WeaponProcessor);
                                if (kyZpsbAxnb(ulong_5, class_本人.本人指针addr))
                                {
                                    class_本人.武器控制 = ulong_5;
                                }
                            }
                            for (int j = 0; j < num22; j++)
                            {
                                ulong key = TS.Read<ulong>(num21 + (ulong)(8 * j));
                                if (!dictionary_全.ContainsKey(key))
                                {
                                    dictionary_全[key] = new Class3
                                    {
                                        ulong_key = key,
                                        uint_0 = 0u,
                                        ulong_1 = 循环次数
                                    };
                                }
                                else
                                {
                                    dictionary_全[key].ulong_1 = 循环次数;
                                    if (dictionary投掷物.ContainsKey(key) && dictionary投掷物[key].种类 == "投掷")
                                    {
                                        dictionary_全[key] = new Class3
                                        {
                                            ulong_key = key,
                                            uint_0 = 0u,
                                            ulong_1 = 循环次数
                                        };
                                    }
                                }
                            }
                            TS.Clear(pid, Vmm.FLAG_NOCACHE);




                            ulongs_盒子.Clear();
                            foreach (KeyValuePair<ulong, Class3> item19 in dictionary_全)
                            {
                                if (item19.Value.ulong_1 != 循环次数)
                                {
                                    ulongs_盒子.Add(item19.Key);
                                }
                            }
                            foreach (ulong item20 in ulongs_盒子)
                            {
                                dictionary_全.Remove(item20);
                            }
                            if (dictionary_全 != null && dictionary_全.Count != 0)
                            {
                                @class.method_5(flags);
                                foreach (Class3 value in dictionary_全.Values)
                                {
                                    if (value.uint_0 == 0)
                                    {
                                        TS.Prepare(value.ulong_key + ObjID, 4);
                                    }
                                }
                                if (循环次数 % 100uL == 0L && num23 > 0L)
                                {
                                    TS.Prepare(num23 + LerpSafetyZonePosition, 4);
                                    TS.Prepare(num23 + LerpSafetyZoneRadius, 4);
                                    TS.Prepare(num23 + PoisonGasWarningPosition, 4);
                                    TS.Prepare(num23 + PoisonGasWarningRadius, 4);
                                    if (轰炸区)
                                    {
                                        TS.Prepare(num23 + RedZonePosition, 4);
                                        TS.Prepare(num23 + RedZoneRadius, 4);
                                    }
                                }
                                TS.Execute();
                                foreach (Class3 value2 in dictionary_全.Values)
                                {
                                    if (value2.uint_0 == 0)
                                    {
                                        value2.uint_0 = DecryptCIndex(TS.Read<uint>(value2.ulong_key + ObjID));
                                    }
                                }
                                if (循环次数 % 100uL == 0L && num23 > 0L)
                                {
                                    vector3_ = TS.Read<Vector3>(num23 + LerpSafetyZonePosition);
                                    vector3_.z = TS.Read<float>(num23 + LerpSafetyZoneRadius);
                                    vector = TS.Read<Vector3>(num23 + PoisonGasWarningPosition);
                                    vector.z = TS.Read<float>(num23 + PoisonGasWarningRadius);
                                    if (轰炸区)
                                    {
                                        vector2 = TS.Read<Vector3>(num23 + RedZonePosition);
                                        vector2.z = TS.Read<float>(num23 + RedZoneRadius);
                                    }
                                }
                                TS.Clear(pid, Vmm.FLAG_NOCACHE);
                                @class.method_5(uint_0);



                                foreach (Class3 value3 in dictionary_全.Values)
                                {
                                    ulong key2 = value3.ulong_key;
                                    uint num24 = value3.uint_0;
                                    if (!dictionary_本人.ContainsKey(num24))
                                    {
                                        string text = MemGetName(num24).Trim();
                                        if (!(text != ""))
                                        {
                                            dictionary_本人[num24] = "None";
                                            continue;
                                        }
                                        dictionary_本人[num24] = text;
                                    }
                                    string text2 = dictionary_本人[num24];
                                    if (text2 == "" || text2 == "None")
                                    {
                                        continue;
                                    }

                                    if (!判断人物(text2))
                                    {
                                        if (!判断人机(text2))
                                        {
                                            if (!判断投掷物(text2))
                                            {
                                                if (CommonProperty.战斗模式)
                                                {
                                                    if (!判断载具(text2) || !CommonProperty.战斗模式)
                                                    {
                                                        if (判断盒子(text2))
                                                        {
                                                            if (dictionary地图资源.ContainsKey(key2) && !(dictionary地图资源[key2].name != text2))
                                                            {
                                                                dictionary地图资源[key2].ulong_3 = 循环次数;
                                                                continue;
                                                            }
                                                            dictionary地图资源[key2] = new Class4
                                                            {
                                                                种类 = "盒子",
                                                                ADDR = key2,
                                                                name = text2,
                                                                ulong_3 = 循环次数
                                                            };
                                                        }
                                                        else if (text2 == "DroppedItemGroup")
                                                        {
                                                            if (dictionary物资.ContainsKey(key2))
                                                            {
                                                                dictionary物资[key2].ulong_1 = 循环次数;
                                                                continue;
                                                            }
                                                            dictionary物资[key2] = new Class5
                                                            {
                                                                ulong_1 = 循环次数
                                                            };
                                                        }
                                                        else if (!(text2 == "DroppedItem"))
                                                        {
                                                            if (!text2.StartsWith("Weap") && text2.EndsWith("_C") && !text2.StartsWith("P_") && !text2.StartsWith("Powerup_") && !text2.EndsWith("Main_C"))
                                                            {
                                                                dictionary_5[num24] = new KeyValuePair<string, string>("主要", text2);
                                                            }
                                                        }
                                                        else if (!dictionary丢弃的物资.ContainsKey(key2))
                                                        {
                                                            dictionary丢弃的物资[key2] = new GameItems
                                                            {
                                                                msUoChmowa = 循环次数
                                                            };
                                                        }
                                                        else
                                                        {
                                                            dictionary丢弃的物资[key2].msUoChmowa = 循环次数;
                                                        }
                                                    }
                                                    else if (dictionary地图资源.ContainsKey(key2))
                                                    {
                                                        dictionary地图资源[key2].ulong_3 = 循环次数;
                                                    }
                                                    else
                                                    {
                                                        dictionary地图资源[key2] = new Class4
                                                        {
                                                            种类 = "载具",
                                                            ADDR = key2,
                                                            name = text2,
                                                            ulong_3 = 循环次数
                                                        };
                                                    }
                                                }
                                            }
                                            else if (dictionary投掷物.ContainsKey(key2))
                                            {
                                                dictionary投掷物[key2].ulong_3 = 循环次数;
                                            }
                                            else
                                            {
                                                dictionary投掷物[key2] = new Class4
                                                {
                                                    种类 = "投掷",
                                                    ADDR = key2,
                                                    name = text2,
                                                    ulong_3 = 循环次数,
                                                };
                                            }

                                        }
                                        else if (dictionary_人物.ContainsKey(key2) && !(dictionary_人物[key2].string_2 != text2))
                                        {
                                            dictionary_人物[key2].ulong_9 = 循环次数;
                                        }
                                        else
                                        {
                                            dictionary_人物[key2] = new Actor人物
                                            {
                                                addr = key2,
                                                string_2 = text2,
                                                是否人机 = 1,
                                                ulong_9 = 循环次数
                                            };
                                        }
                                    }
                                    else if (dictionary_人物.ContainsKey(key2) && !(dictionary_人物[key2].string_2 != text2))
                                    {
                                        dictionary_人物[key2].ulong_9 = 循环次数;
                                    }
                                    else
                                    {
                                        dictionary_人物[key2] = new Actor人物
                                        {
                                            addr = key2,
                                            string_2 = text2,
                                            是否人机 = 0,
                                            ulong_9 = 循环次数
                                        };
                                    }
                                }
                                if (CommonProperty.战斗模式)
                                {
                                    ulongs_盒子.Clear();
                                    foreach (KeyValuePair<ulong, Class5> item21 in dictionary物资)
                                    {
                                        if (item21.Value.ulong_1 != 循环次数)
                                        {
                                            ulongs_盒子.Add(item21.Key);
                                        }
                                    }
                                    foreach (ulong item22 in ulongs_盒子)
                                    {
                                        dictionary物资.Remove(item22);
                                    }
                                    ulongs_盒子.Clear();
                                    foreach (KeyValuePair<ulong, GameItems> item23 in dictionary丢弃的物资)
                                    {
                                        if (item23.Value.msUoChmowa != 循环次数)
                                        {
                                            ulongs_盒子.Add(item23.Key);
                                        }
                                    }
                                    foreach (ulong item24 in ulongs_盒子)
                                    {
                                        dictionary丢弃的物资.Remove(item24);
                                    }
                                    ulongs_盒子.Clear();
                                    foreach (KeyValuePair<ulong, Class4> item25 in dictionary地图资源)
                                    {
                                        if (item25.Value.ulong_3 != 循环次数)
                                        {
                                            ulongs_盒子.Add(item25.Key);
                                        }
                                    }
                                    foreach (ulong item26 in ulongs_盒子)
                                    {
                                        dictionary地图资源.Remove(item26);
                                    }
                                }
                                ulongs_盒子.Clear();
                                foreach (KeyValuePair<ulong, Actor人物> item27 in dictionary_人物)
                                {
                                    if (item27.Value.ulong_9 != 循环次数)
                                    {
                                        ulongs_盒子.Add(item27.Key);
                                    }
                                }
                                foreach (ulong item28 in ulongs_盒子)
                                {
                                    dictionary_人物.Remove(item28);
                                }
                                if (CommonProperty.pgConfig.EspConfig.投掷物)
                                {
                                    ulongs_盒子.Clear();
                                    foreach (KeyValuePair<ulong, Class4> item27 in dictionary投掷物)
                                    {
                                        if (item27.Value.ulong_3 != 循环次数)
                                        {
                                            ulongs_盒子.Add(item27.Key);
                                        }
                                    }
                                    foreach (ulong item28 in ulongs_盒子)
                                    {
                                        dictionary投掷物.Remove(item28);
                                    }
                                }
                                @class.Clear();



                                if (class_本人.武器控制 > 0L)
                                {
                                    TS.Prepare(class_本人.本人指针addr + Health, 4);
                                    TS.Prepare(class_本人.本人指针addr + HealthDie, 4);
                                    TS.Prepare(class_本人.武器控制 + CurrentWeaponIndex, 1);
                                    TS.Prepare(class_本人.武器控制 + EquippedWeapons, 4);
                                }
                                if (class_本人.Animasccript > 0L)
                                {
                                    TS.Prepare(class_本人.Animasccript + ControlRotationCP, 12);
                                    TS.Prepare(class_本人.Animasccript + RecoilADSRotationCP, 12);
                                }
                                foreach (KeyValuePair<ulong, Actor人物> item29 in dictionary_人物)
                                {
                                    if (!item29.Value.活人)
                                    {
                                        continue;
                                    }
                                    if (CommonProperty.pgConfig.EspConfig.手持 && item29.Value.距离 <= CommonProperty.pgConfig.EspConfig.手持距离 && (item29.Value.骨盆.x > 0) && (item29.Value.骨盆.y > 0) && (item29.Value.骨盆.x < X分辨率) && (item29.Value.骨盆.y < Y分辨率))
                                    {
                                        TS.Prepare(item29.Value.addr + WeaponProcessor, 4);
                                    }
                                    if (item29.Value.是否人机 != 0)
                                    {
                                        if (item29.Value.use)
                                        {
                                            TS.Prepare(item29.Value.addr + Health, 4);
                                            TS.Prepare(item29.Value.addr + HealthDie, 4);
                                            TS.Prepare(item29.Value.addr + TeamNumber, 4);
                                            TS.Prepare(item29.Value.addr + 被瞄偏移, 12);
                                        }
                                        else
                                        {
                                            TS.Prepare(item29.Value.addr + Health, 4);
                                            TS.Prepare(item29.Value.addr + HealthDie, 4);
                                            TS.Prepare(item29.Value.addr + TeamNumber, 4);
                                            TS.Prepare(item29.Value.addr + 被瞄偏移, 12);
                                            TS.Prepare(item29.Value.addr + Mesh, 4);
                                            TS.Prepare(item29.Value.addr + PlayerState, 4);
                                        }
                                    }
                                    else if (!item29.Value.use)
                                    {
                                        TS.Prepare(item29.Value.addr + Health, 4);
                                        TS.Prepare(item29.Value.addr + HealthDie, 4);
                                        TS.Prepare(item29.Value.addr + TeamNumber, 4);
                                        TS.Prepare(item29.Value.addr + TeamNumber + 8L, 4);
                                        TS.Prepare(item29.Value.addr + Audience, 4);
                                        TS.Prepare(item29.Value.addr + Mesh, 4);
                                        TS.Prepare(item29.Value.addr + PlayerState, 4);
                                        TS.Prepare(item29.Value.addr + 被瞄偏移, 12);
                                        if (item29.Value.name == "")
                                        {
                                            TS.Prepare(item29.Value.addr + Playname, 4);
                                        }
                                    }
                                    else
                                    {
                                        TS.Prepare(item29.Value.addr + Health, 4);
                                        TS.Prepare(item29.Value.addr + HealthDie, 4);
                                        TS.Prepare(item29.Value.addr + TeamNumber, 4);
                                        TS.Prepare(item29.Value.addr + TeamNumber + 8L, 4);
                                        TS.Prepare(item29.Value.addr + Audience, 4);
                                        TS.Prepare(item29.Value.addr + 被瞄偏移, 12);
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item30 in dictionary物资)
                                    {
                                        if (kyZpsbAxnb(item30.Value.ulong_0, item30.Key) || item30.Value.距离 > CommonProperty.pgConfig.EspConfig.物资距离 || item30.Value.距离 == 0)
                                        {
                                            TS.Prepare(item30.Key + DroppedItemGroup, 4);
                                            TS.Prepare(item30.Key + DroppedItemGroup + 8L, 4);
                                        }
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item31 in dictionary丢弃的物资)
                                    {
                                        TS.Prepare(item31.Key + DroppedItem, 4);
                                    }
                                    foreach (Class4 value4 in dictionary地图资源.Values)
                                    {
                                        if (value4.ulong_2 == 0L)
                                        {
                                            TS.Prepare(value4.ADDR + DroppedItemGroup, 4);
                                        }
                                    }
                                }
                                foreach (Class4 value4 in dictionary投掷物.Values)
                                {
                                    if (value4.ulong_2 == 0L)
                                    {
                                        TS.Prepare(value4.ADDR + DroppedItemGroup, 4);
                                    }
                                }
                                TS.Execute();
                                if (class_本人.武器控制 > 0L)
                                {
                                    class_本人.人物血量 = TS.Read<float>(class_本人.本人指针addr + Health);
                                    class_本人.倒地血量 = TS.Read<float>(class_本人.本人指针addr + HealthDie);
                                    class_本人.byte_b = TS.Read<byte>(class_本人.武器控制 + CurrentWeaponIndex);
                                    ulong 武器基址 = TS.Read<ulong>(class_本人.武器控制 + EquippedWeapons);
                                    if (武器基址 > 0L && kyZpsbAxnb(武器基址, class_本人.本人指针addr))
                                    {
                                        class_本人.武器基址 = 武器基址;
                                    }
                                }
                                if (class_本人.Animasccript > 0L)
                                {
                                    class_本人.vector3_2 = TS.Read<Vector3>(class_本人.Animasccript + ControlRotationCP);
                                    class_本人.vector3_3 = TS.Read<Vector3>(class_本人.Animasccript + RecoilADSRotationCP);
                                }
                                foreach (KeyValuePair<ulong, Actor人物> item32 in dictionary_人物)
                                {
                                    if (!item32.Value.活人)
                                    {
                                        continue;
                                    }
                                    if (CommonProperty.pgConfig.EspConfig.手持 && item32.Value.距离 <= CommonProperty.pgConfig.EspConfig.手持距离 && (item32.Value.骨盆.x > 0) && (item32.Value.骨盆.y > 0) && (item32.Value.骨盆.x < X分辨率) && (item32.Value.骨盆.y < Y分辨率))
                                    {
                                        item32.Value.武器控制 = TS.Read<ulong>(item32.Value.addr + WeaponProcessor);
                                    }
                                    if (item32.Value.是否人机 != 0)
                                    {
                                        if (!item32.Value.活人)
                                        {
                                            continue;
                                        }
                                        if (!item32.Value.use)
                                        {
                                            item32.Value.人物血量 = TS.Read<float>(item32.Value.addr + Health);
                                            item32.Value.倒地血量 = TS.Read<float>(item32.Value.addr + HealthDie);
                                            item32.Value.TeamID = TS.Read<uint>(item32.Value.addr + TeamNumber);
                                            item32.Value.TeamID = ((item32.Value.TeamID >= 100000) ? (item32.Value.TeamID - 100000) : item32.Value.TeamID);
                                            ulong ulong_6 = TS.Read<ulong>(item32.Value.addr + Mesh);
                                            if (kyZpsbAxnb(ulong_6, item32.Value.addr))
                                            {
                                                item32.Value.人物视角 = ulong_6;
                                            }
                                            item32.Value.vector3_方向 = TS.Read<Vector3>(item32.Value.addr + 被瞄偏移);
                                        }
                                        else
                                        {
                                            item32.Value.人物血量 = TS.Read<float>(item32.Value.addr + Health);
                                            item32.Value.倒地血量 = TS.Read<float>(item32.Value.addr + HealthDie);
                                            item32.Value.TeamID = TS.Read<uint>(item32.Value.addr + TeamNumber);
                                            item32.Value.TeamID = ((item32.Value.TeamID >= 100000) ? (item32.Value.TeamID - 100000) : item32.Value.TeamID);
                                            if (item32.Value.TeamID >= 1000000 || item32.Value.TeamID == 0 || item32.Value.TeamID - 100000 == 0)
                                            {
                                                item32.Value.TeamID = 888u;
                                            }
                                            item32.Value.vector3_方向 = TS.Read<Vector3>(item32.Value.addr + 被瞄偏移);
                                        }
                                        if (item32.Value.人物血量 > 100f || float.IsNaN(item32.Value.人物血量))
                                        {
                                            item32.Value.人物血量 = 100f;
                                        }
                                        if (item32.Value.倒地血量 > 100f || float.IsNaN(item32.Value.倒地血量))
                                        {
                                            item32.Value.倒地血量 = 100f;
                                        }
                                        if (item32.Value.人物血量 < 0f)
                                        {
                                            item32.Value.人物血量 = 0f;
                                        }
                                        if (item32.Value.倒地血量 < 0f)
                                        {
                                            item32.Value.倒地血量 = 0f;
                                        }
                                        continue;
                                    }
                                    if (item32.Value.use)
                                    {
                                        item32.Value.人物血量 = TS.Read<float>(item32.Value.addr + Health);
                                        item32.Value.倒地血量 = TS.Read<float>(item32.Value.addr + HealthDie);
                                        item32.Value.TeamID = TS.Read<uint>(item32.Value.addr + TeamNumber);
                                        item32.Value.TeamID = ((item32.Value.TeamID >= 100000) ? (item32.Value.TeamID - 100000) : item32.Value.TeamID);
                                        item32.Value.TeamSeq = TS.Read<uint>(item32.Value.addr + TeamNumber + 8L);
                                        item32.Value.观战人数 = TS.Read<uint>(item32.Value.addr + Audience);
                                        item32.Value.vector3_方向 = TS.Read<Vector3>(item32.Value.addr + 被瞄偏移);
                                    }
                                    else
                                    {
                                        item32.Value.人物血量 = TS.Read<float>(item32.Value.addr + Health);
                                        item32.Value.倒地血量 = TS.Read<float>(item32.Value.addr + HealthDie);
                                        item32.Value.TeamID = TS.Read<uint>(item32.Value.addr + TeamNumber);
                                        item32.Value.TeamID = ((item32.Value.TeamID >= 100000) ? (item32.Value.TeamID - 100000) : item32.Value.TeamID);
                                        item32.Value.TeamSeq = TS.Read<uint>(item32.Value.addr + TeamNumber + 8L);
                                        item32.Value.观战人数 = TS.Read<uint>(item32.Value.addr + Audience);
                                        ulong num26 = TS.Read<ulong>(item32.Value.addr + Mesh);
                                        if (num26 > 0L && kyZpsbAxnb(num26, item32.Value.addr))
                                        {
                                            item32.Value.人物视角 = num26;
                                        }
                                        ulong num27 = method_4(TS.Read<ulong>(item32.Value.addr + PlayerState));
                                        if (num27 > 0L && kyZpsbAxnb(num27, item32.Value.addr))
                                        {
                                            item32.Value.人物状态 = num27;
                                        }
                                        item32.Value.vector3_方向 = TS.Read<Vector3>(item32.Value.addr + 被瞄偏移);
                                        if (item32.Value.name == "")
                                        {
                                            ulong num28 = TS.Read<ulong>(item32.Value.addr + Playname);
                                            if (num28 > 0L && kyZpsbAxnb(num28, item32.Value.addr))
                                            {
                                                item32.Value.Playname = num28;
                                            }
                                        }
                                    }
                                    if (item32.Value.人物血量 > 100f || float.IsNaN(item32.Value.人物血量))
                                    {
                                        item32.Value.人物血量 = 100f;
                                    }
                                    if (item32.Value.倒地血量 > 100f || float.IsNaN(item32.Value.倒地血量))
                                    {
                                        item32.Value.倒地血量 = 100f;
                                    }
                                    if (item32.Value.人物血量 < 0f)
                                    {
                                        item32.Value.人物血量 = 0f;
                                    }
                                    if (item32.Value.倒地血量 < 0f)
                                    {
                                        item32.Value.倒地血量 = 0f;
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item33 in dictionary物资)
                                    {
                                        if (kyZpsbAxnb(item33.Value.ulong_0, item33.Key) || item33.Value.距离 > CommonProperty.pgConfig.EspConfig.物资距离 || item33.Value.距离 == 0)
                                        {
                                            item33.Value.ulong_0 = TS.Read<ulong>(item33.Key + DroppedItemGroup);
                                            item33.Value.距离 = TS.Read<uint>(item33.Key + DroppedItemGroup + 8L);
                                        }
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item34 in dictionary丢弃的物资)
                                    {
                                        item34.Value.ulong_0 = method_4(TS.Read<ulong>(item34.Key + DroppedItem));
                                    }
                                    foreach (Class4 value5 in dictionary地图资源.Values)
                                    {
                                        if (value5.ulong_2 == 0L)
                                        {
                                            ulong ulong_7 = TS.Read<ulong>(value5.ADDR + DroppedItemGroup);
                                            if (kyZpsbAxnb(ulong_7, value5.ADDR))
                                            {
                                                value5.ulong_1 = ulong_7;
                                            }
                                        }
                                    }
                                }
                                foreach (Class4 value5 in dictionary投掷物.Values)
                                {
                                    if (value5.ulong_2 == 0L)
                                    {
                                        ulong ulong_7 = TS.Read<ulong>(value5.ADDR + DroppedItemGroup);
                                        if (kyZpsbAxnb(ulong_7, value5.ADDR))
                                        {
                                            value5.ulong_1 = ulong_7;
                                        }
                                    }
                                }
                                TS.Clear(pid, Vmm.FLAG_NOCACHE);



                                if (!class_本人.bool_0)
                                {
                                    if (class_本人.byte_b >= 0 && class_本人.byte_b <= 4)
                                    {
                                        TS.Prepare(class_本人.武器基址 + (ulong)(class_本人.byte_b * 8L), 4);
                                    }
                                    TS.Prepare(class_本人.本人视角 + Eyes, 4);
                                    TS.Prepare(class_本人.当前武器 + ElapsedCookingTime, 4);
                                    TS.Prepare(class_本人.当前武器 + CurrentAmmoData, 4);
                                }
                                else
                                {
                                    class_本人.本人信息();
                                }
                                foreach (KeyValuePair<ulong, Actor人物> item35 in dictionary_人物)
                                {
                                    if (!item35.Value.活人)
                                    {
                                        continue;
                                    }
                                    if (CommonProperty.pgConfig.EspConfig.手持 && item35.Value.距离 <= CommonProperty.pgConfig.EspConfig.手持距离 && (item35.Value.骨盆.x > 0) && (item35.Value.骨盆.y > 0) && (item35.Value.骨盆.x < X分辨率) && (item35.Value.骨盆.y < Y分辨率))
                                    {
                                        if (item35.Value.武器控制 > 0)
                                        {
                                            TS.Prepare(item35.Value.武器控制 + CurrentWeaponIndex, 1);
                                            TS.Prepare(item35.Value.武器控制 + EquippedWeapons, 4);
                                        }
                                    }

                                    TS.Prepare(item35.Value.人物视角 + BoneArry, 50);
                                    TS.Prepare(item35.Value.人物视角 + Bone, 4);
                                    TS.Prepare(item35.Value.人物视角 + Position, 12);
                                    if (item35.Value.是否人机 != 0)
                                    {
                                        continue;
                                    }

                                    if (!class_本人.bool_0)
                                    {
                                        TS.Prepare(item35.Value.人物视角 + Eyes, 4);
                                    }
                                    if (item35.Value.人物状态 > 0L)
                                    {
                                        TS.Prepare(item35.Value.人物状态 + PlayerSatisitc, 4); //人物杀敌
                                        TS.Prepare(item35.Value.人物状态 + PartnerLevel, 1); //玩家类型
                                        if (item35.Value.生存等级 == 0)
                                        {
                                            TS.Prepare(item35.Value.人物状态 + SurvivalLevel - 4L, 4); // 生存大等级
                                            TS.Prepare(item35.Value.人物状态 + SurvivalLevel, 4); // 生存等级
                                        }
                                        if (item35.Value.TeamID == class_本人.TeamID)
                                        {
                                            TS.Prepare(item35.Value.人物状态 + MapMarker + 28L, 4);
                                            TS.Prepare(item35.Value.人物状态 + MapMarker + 32L, 12);
                                        }
                                    }
                                    if ((item35.Value.name == "" || item35.Value.name == "Driver") && item35.Value.Playname > 0L)
                                    {
                                        @class.method_3(item35.Value.Playname, 64u);
                                    }

                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item36 in dictionary物资)
                                    {
                                        if (kyZpsbAxnb(item36.Value.ulong_0, item36.Key) && item36.Value.距离 != 0 && item36.Value.距离 < CommonProperty.pgConfig.EspConfig.物资距离)
                                        {
                                            for (uint num29 = 0u; num29 < item36.Value.距离; num29++)
                                            {
                                                TS.Prepare(item36.Value.ulong_0 - 16L + num29 * 16, 4);
                                            }
                                        }
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item37 in dictionary丢弃的物资)
                                    {
                                        TS.Prepare(item37.Value.ulong_0 + 物品一, 4);
                                        TS.Prepare(item37.Key + DroppedItemGroup, 4);
                                    }
                                    foreach (Class4 value6 in dictionary地图资源.Values)
                                    {
                                        if (value6.ulong_1 > 0L && value6.ulong_2 == 0L)
                                        {
                                            TS.Prepare(value6.ulong_1, 4);
                                        }
                                    }
                                }
                                foreach (Class4 value6 in dictionary投掷物.Values)
                                {
                                    if (value6.ulong_1 > 0L && value6.ulong_2 == 0L)
                                    {
                                        TS.Prepare(value6.ulong_1, 4);
                                    }
                                }
                                TS.Execute();
                                if (!class_本人.bool_0)
                                {
                                    if (class_本人.byte_b >= 0 && class_本人.byte_b <= 4)
                                    {
                                        class_本人.当前武器 = TS.Read<ulong>(class_本人.武器基址 + (ulong)(class_本人.byte_b * 8L));
                                    }
                                    else
                                    {
                                        class_本人.当前武器 = 0uL;
                                        class_本人.ulong_9 = 0uL;
                                        class_本人.武器id = 0u;
                                        class_本人.当前武器名称 = "";
                                        class_本人.float_0 = 0f;
                                    }
                                    class_本人.可视 = TS.Read<float>(class_本人.本人视角 + Eyes);
                                    this.手雷倒计时 = TS.Read<float>(class_本人.当前武器 + ElapsedCookingTime);
                                    CommonProperty.手雷倒计时 = 5 - 手雷倒计时;
                                    if (class_本人.当前武器名称 != "WeapGrenade_C")
                                    {
                                        CommonProperty.手雷倒计时 = 5;
                                    }
                                }
                                foreach (KeyValuePair<ulong, Actor人物> item38 in dictionary_人物)
                                {
                                    if (!item38.Value.活人)
                                    {
                                        continue;
                                    }
                                    if (CommonProperty.pgConfig.EspConfig.手持 && item38.Value.距离 <= CommonProperty.pgConfig.EspConfig.手持距离 && (item38.Value.骨盆.x > 0) && (item38.Value.骨盆.y > 0) && (item38.Value.骨盆.x < X分辨率) && (item38.Value.骨盆.y < Y分辨率))
                                    {
                                        item38.Value.byte_b = TS.Read<byte>(item38.Value.武器控制 + CurrentWeaponIndex);
                                        ulong 武器基质 = TS.Read<ulong>(item38.Value.武器控制 + EquippedWeapons);
                                        if (武器基质 > 0L && kyZpsbAxnb(武器基质, item38.Value.addr))
                                        {
                                            item38.Value.武器基址 = 武器基质;
                                        }
                                    }
                                    item38.Value.use = true;
                                    item38.Value.Actor_Bone = TS.Read<FTransform>(item38.Value.人物视角 + BoneArry);
                                    item38.Value.Bone = TS.Read<ulong>(item38.Value.人物视角 + Bone);
                                    item38.Value.vector3_距离坐标 = 相加(TS.Read<Vector3>(item38.Value.人物视角 + Position));
                                    if (!class_本人.bool_0)
                                    {
                                        uint num30 = method_34(相减(class_本人.vector3_距离坐标, item38.Value.vector3_距离坐标)) / 100u;
                                        if (num30 < 10000)
                                        {
                                            item38.Value.距离 = num30;
                                        }
                                    }
                                    else
                                    {
                                        item38.Value.距离 = 0u;
                                    }
                                    if (item38.Value.是否人机 != 0)
                                    {
                                        if (item38.Value.是否人机 == 1)
                                        {
                                            item38.Value.是否可视 = 1;
                                            if (item38.Value.人物视角 == 0L)
                                            {
                                                item38.Value.use = false;
                                            }
                                        }
                                        continue;
                                    }
                                    if (class_本人.bool_0)
                                    {
                                        item38.Value.距离 = 0u;
                                        item38.Value.是否可视 = 1;
                                    }
                                    else
                                    {
                                        item38.Value.人物位面 = TS.Read<float>(item38.Value.人物视角 + Eyes);
                                        item38.Value.是否可视 = ((item38.Value.人物位面 >= class_本人.可视) ? 1 : 0);
                                    }
                                    if (item38.Value.人物状态 > 0L)
                                    {
                                        if (item38.Value.生存等级 == 0)
                                        {
                                            uint 生存等级 = TS.Read<uint>(item38.Value.人物状态 + SurvivalLevel);
                                            if (生存等级 > 500)
                                            {
                                                item38.Value.use = false;
                                            }
                                            else
                                            {
                                                item38.Value.生存等级 = 生存等级;
                                                uint num60 = item38.Value.生存等级 + (item38.Value.生存大等级 - 1) * 500;
                                                if (num60 < 5000)
                                                {
                                                    item38.Value.等级 = num60;
                                                }
                                                else
                                                {
                                                    item38.Value.等级 = item38.Value.生存等级;
                                                }
                                            }
                                            uint num32 = TS.Read<uint>(item38.Value.人物状态 + SurvivalLevel - 4L);
                                            if (num32 != 0 && num32 <= 6)
                                            {
                                                item38.Value.生存大等级 = num32;
                                            }
                                            else
                                            {
                                                item38.Value.use = false;
                                            }
                                        }
                                        uint 人物杀敌 = TS.Read<uint>(item38.Value.人物状态 + PlayerSatisitc);
                                        if (人物杀敌 > 100)
                                        {
                                            item38.Value.use = false;
                                        }
                                        else
                                        {
                                            item38.Value.人物杀敌 = 人物杀敌;
                                        }
                                        byte b = TS.Read<byte>(item38.Value.人物状态 + PartnerLevel);
                                        if (b > 5)
                                        {
                                            item38.Value.use = false;
                                        }
                                        else
                                        {
                                            item38.Value.合作者 = b;
                                        }
                                        if (item38.Value.TeamID == class_本人.TeamID)
                                        {
                                            item38.Value.uint_10 = TS.Read<uint>(item38.Value.人物状态 + MapMarker + 28L);
                                            if (item38.Value.uint_10 == 1)
                                            {
                                                item38.Value.vector2_雷达人物坐标 = TS.Read<Vector2>(item38.Value.人物状态 + MapMarker + 32L);
                                            }
                                            else
                                            {
                                                item38.Value.vector2_雷达人物坐标 = default(Vector2);
                                            }
                                        }
                                    }
                                    if ((item38.Value.name == "" || item38.Value.name == "Driver") && item38.Value.Playname > 0L)
                                    {
                                        item38.Value.name = method_28(vmm.MemRead(pid, item38.Value.Playname, 64));
                                        item38.Value.ulong_4 = 0uL;
                                    }
                                    if (item38.Value.name == "" || item38.Value.name == "Driver")
                                    {
                                        if (method_34(相减(item38.Value.vector3_位置, item38.Value.vector3_距离坐标)) / 100u == 0)
                                        {
                                            if (item38.Value.name == "Driver")
                                            {
                                                item38.Value.ulong_4++;
                                                if (item38.Value.ulong_4 > 1000L)
                                                {
                                                    item38.Value.name = "";
                                                }
                                            }
                                        }
                                        else
                                        {
                                            item38.Value.vector3_位置 = 相加(TS.Read<Vector3>(item38.Value.人物视角 + Position));
                                            item38.Value.name = "Driver";
                                            item38.Value.ulong_4 = 0uL;
                                        }
                                    }
                                    if (item38.Value.人物状态 == 0L || item38.Value.人物视角 == 0L || item38.Value.name == "")
                                    {
                                        item38.Value.use = false;
                                    }
                                    if (item38.Value.name == class_本人.本人name && class_本人.本人name != "")
                                    {
                                        if (class_本人.本人指针addr != item38.Value.addr)
                                        {
                                            class_本人.本人信息();
                                            class_本人.本人指针addr = item38.Value.addr;
                                        }
                                        class_本人.人物血量 = item38.Value.人物血量;
                                        class_本人.倒地血量 = item38.Value.倒地血量;
                                        class_本人.本人观战数量 = item38.Value.观战人数;
                                        CommonProperty.本人观战人数 = class_本人.本人观战数量;
                                        if (Math.Ceiling(class_本人.人物血量 + class_本人.倒地血量) == 0.0)
                                        {
                                            class_本人.bool_0 = true;
                                        }
                                        else
                                        {
                                            class_本人.bool_0 = false;
                                        }
                                        item38.Value.uint_9 = 1u;
                                    }
                                }
                                foreach (KeyValuePair<ulong, Actor人物> item39 in dictionary_人物)
                                {
                                    if (item39.Value.是否人机 != 1)
                                    {
                                        if (item39.Value.name != "" && !hashSet_雷达信息.Contains(item39.Value.name) && (玩家信息) && (ShowKD || ShowDamageAvg || ShowRank || CommonProperty.pgConfig.EspConfig.KD || CommonProperty.pgConfig.EspConfig.段位))
                                        {
                                            hashSet_雷达信息.Add(item39.Value.name);
                                            concurrentQueue_雷达信息.Enqueue(item39.Value.name);
                                            autoResetEvent_雷达信息.Set();
                                        }
                                        if (item39.Value.name != "" && (hashSet_白名单.Contains(item39.Value.name) || Program.mainForm_0.Hash_队友.Contains(item39.Value.name)) && !hashSet_友军.Contains(item39.Value.TeamID))
                                        {
                                            hashSet_友军.Add(item39.Value.TeamID);
                                        }
                                        if (!hashSet_友军.Contains(item39.Value.TeamID) && item39.Value.TeamID != class_本人.TeamID)
                                        {
                                            item39.Value.是否友军 = 0u;
                                        }
                                        else
                                        {
                                            item39.Value.是否友军 = 1u;
                                        }
                                        if (item39.Value.是否友军 == 1 && item39.Value.name != "" && item39.Value.name != "Driver")
                                        {
                                            状态("临时队友", item39.Value.name);
                                        }
                                        else if (item39.Value.是否友军 != 1 && item39.Value.name != "" && item39.Value.name != "Driver")
                                        {
                                            状态("本局玩家", item39.Value.name);
                                        }
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item40 in dictionary物资)
                                    {
                                        if (kyZpsbAxnb(item40.Value.ulong_0, item40.Key) && item40.Value.距离 != 0 && item40.Value.距离 < CommonProperty.pgConfig.EspConfig.物资距离)
                                        {
                                            for (uint num34 = 0u; num34 < item40.Value.距离; num34++)
                                            {
                                                ulong num35 = TS.Read<ulong>(item40.Value.ulong_0 - 16L + num34 * 16);
                                                if (kyZpsbAxnb(num35, item40.Value.ulong_0))
                                                {
                                                    if (item40.Value.dictionary_物资.ContainsKey(num35))
                                                    {
                                                        item40.Value.dictionary_物资[num35].msUoChmowa = 循环次数;
                                                        continue;
                                                    }
                                                    item40.Value.dictionary_物资[num35] = new GameItems
                                                    {
                                                        ulong_0 = num35,
                                                        msUoChmowa = 循环次数
                                                    };
                                                }
                                            }
                                        }
                                        ulongs_盒子.Clear();
                                        foreach (KeyValuePair<ulong, GameItems> item41 in item40.Value.dictionary_物资)
                                        {
                                            if (item41.Value.msUoChmowa != 循环次数)
                                            {
                                                ulongs_盒子.Add(item41.Key);
                                            }
                                        }
                                        foreach (ulong item42 in ulongs_盒子)
                                        {
                                            item40.Value.dictionary_物资.Remove(item42);
                                        }
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, GameItems> item43 in dictionary丢弃的物资)
                                    {
                                        item43.Value.ulong_4 = TS.Read<ulong>(item43.Value.ulong_0 + 物品一);
                                        item43.Value.ulong_2 = TS.Read<ulong>(item43.Key + DroppedItemGroup);
                                    }
                                    foreach (Class4 value7 in dictionary地图资源.Values)
                                    {
                                        if (value7.ulong_1 > 0L && value7.ulong_2 == 0L)
                                        {
                                            ulong ulong_8 = TS.Read<ulong>(value7.ulong_1);
                                            if (kyZpsbAxnb(ulong_8, value7.ADDR))
                                            {
                                                value7.ulong_2 = ulong_8;
                                            }
                                        }
                                    }
                                }
                                foreach (Class4 value7 in dictionary投掷物.Values)
                                {
                                    if (value7.ulong_1 > 0L && value7.ulong_2 == 0L)
                                    {
                                        ulong ulong_8 = TS.Read<ulong>(value7.ulong_1);
                                        if (kyZpsbAxnb(ulong_8, value7.ADDR))
                                        {
                                            value7.ulong_2 = ulong_8;
                                        }
                                    }
                                }
                                TS.Clear(pid, Vmm.FLAG_NOCACHE);



                                //foreach (KeyValuePair<ulong, Actor人物> item46 in dictionary_人物)
                                //{
                                //    if (!item46.Value.活人)
                                //    {
                                //        continue;
                                //    }
                                //    if (透视 && item46.Value.距离 < CommonProperty.pgConfig.EspConfig.透视距离)
                                //    {
                                //        TS.Prepare(item46.Value.Bone + (ulong)骨盆 * 48L, 50);
                                //    }
                                //}
                                //TS.Execute();
                                //foreach (KeyValuePair<ulong, Actor人物> item49 in dictionary_人物)
                                //{
                                //    if (!item49.Value.活人)
                                //    {
                                //        continue;
                                //    }
                                //    if (透视 && item49.Value.距离 < CommonProperty.pgConfig.EspConfig.透视距离)
                                //    {
                                //        item49.Value.骨盆_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)骨盆 * 48L);
                                //        D3DMATRIX d3DMATRIX_3 = item49.Value.骨盆_Bone.ToMatrixWithScale();
                                //        D3DMATRIX d3DMATRIX2 = method_35(d3DMATRIX_3, item49.Value.Actor_Bone.ToMatrixWithScale());
                                //        item49.Value.vector3_骨盆.x = d3DMATRIX2._41;
                                //        item49.Value.vector3_骨盆.y = d3DMATRIX2._42;
                                //        item49.Value.vector3_骨盆.z = d3DMATRIX2._43;
                                //        item49.Value.骨盆 = 计算透视坐标(item49.Value.vector3_骨盆);
                                //    }
                                //}
                                //TS.Clear(pid, Vmm.FLAG_NOCACHE);



                                if (!class_本人.bool_0 && class_本人.当前武器 > 0L)
                                {
                                    TS.Prepare(class_本人.当前武器 + WeaponTrajectoryData, 4);
                                    TS.Prepare(class_本人.当前武器 + ObjID, 4);
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item44 in dictionary物资)
                                    {
                                        foreach (KeyValuePair<ulong, GameItems> item45 in item44.Value.dictionary_物资)
                                        {
                                            if (item45.Value.name == "")
                                            {
                                                TS.Prepare(item45.Value.ulong_0 + DroppedItemGroupUItem, 4);
                                            }
                                        }
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (GameItems value8 in dictionary丢弃的物资.Values)
                                    {
                                        TS.Prepare(value8.ulong_4 + 物品二, 4);
                                        TS.Prepare(value8.ulong_2, 4);
                                    }
                                    foreach (Class4 value9 in dictionary地图资源.Values)
                                    {
                                        if (value9.ulong_1 > 0L && value9.ulong_2 > 0L)
                                        {
                                            TS.Prepare(value9.ulong_2 + Position, 12);
                                        }
                                    }
                                }
                                foreach (Class4 value9 in dictionary投掷物.Values)
                                {
                                    if (value9.ulong_1 > 0L && value9.ulong_2 > 0L)
                                    {
                                        TS.Prepare(value9.ulong_2 + Position, 12);
                                        TS.Prepare(value9.ADDR + TimeTillExplosion, 4);
                                    }
                                }
                                if (!dictionary_人物.ContainsKey(this.瞄准地址) || !dictionary_人物[this.瞄准地址].活人 || class_本人.bool_0)
                                {
                                    this.瞄准地址 = 0uL;
                                }
                                foreach (KeyValuePair<ulong, Actor人物> item46 in dictionary_人物)
                                {
                                    if (!item46.Value.活人)
                                    {
                                        continue;
                                    }
                                    if (透视 && item46.Value.距离 < CommonProperty.pgConfig.EspConfig.透视距离)
                                    {
                                        TS.Prepare(item46.Value.Bone + (ulong)骨盆 * 48L, 12);
                                        TS.Prepare(item46.Value.Bone + (ulong)头部 * 48L, 12);
                                        if (CommonProperty.pgConfig.EspConfig.骨骼)
                                        {
                                            TS.Prepare(item46.Value.Bone + (ulong)颈部 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)胸部 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)左手 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)右手 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)左肘 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)右肘 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)左膝 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)右膝 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)左脚 * 48L, 12);
                                            TS.Prepare(item46.Value.Bone + (ulong)右脚 * 48L, 12);
                                        }
                                    }
                                    if (CommonProperty.pgConfig.EspConfig.手持 && item46.Value.距离 <= CommonProperty.pgConfig.EspConfig.手持距离)
                                    {
                                        TS.Prepare(item46.Value.武器基址 + (ulong)(item46.Value.byte_b * 8L), 4);
                                        if (item46.Value.当前武器 > 0)
                                        {
                                            //TS.Prepare(item461.Value.当前武器 + WeaponTrajectoryData);
                                            TS.Prepare(item46.Value.当前武器 + ObjID, 4);
                                        }
                                    }
                                    if (自瞄)
                                    {
                                        if (!子骨骼自瞄)
                                        {
                                            if (class7_0.父骨骼 == 0)
                                            {
                                                continue;
                                            }
                                            TS.Prepare(item46.Value.Bone + (ulong)(class7_0.父骨骼 * 48L), 50);
                                        }
                                        else
                                        {
                                            TS.Prepare(item46.Value.Bone + (ulong)(class7_0.子骨骼 * 48L), 50);
                                        }
                                    }
                                }
                                TS.Execute();
                                if (!class_本人.bool_0 && class_本人.当前武器 > 0L)
                                {
                                    class_本人.ulong_9 = TS.Read<ulong>(class_本人.当前武器 + WeaponTrajectoryData);
                                    class_本人.武器id = DecryptCIndex(TS.Read<uint>(class_本人.当前武器 + ObjID));
                                    if (!dictionary_本人.ContainsKey(class_本人.武器id))
                                    {
                                        dictionary_本人[class_本人.武器id] = MemGetName(class_本人.武器id);
                                    }
                                    class_本人.当前武器名称 = dictionary_本人[class_本人.武器id];
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item47 in dictionary物资)
                                    {
                                        foreach (KeyValuePair<ulong, GameItems> item48 in item47.Value.dictionary_物资)
                                        {
                                            if (item48.Value.name == "")
                                            {
                                                item48.Value.ulong_1 = TS.Read<ulong>(item48.Value.ulong_0 + DroppedItemGroupUItem);
                                                if (!kyZpsbAxnb(item48.Value.ulong_1, item48.Value.ulong_0))
                                                {
                                                    item48.Value.name = "None";
                                                }
                                            }
                                        }
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (GameItems value10 in dictionary丢弃的物资.Values)
                                    {
                                        value10.uint_0 = TS.Read<uint>(value10.ulong_4 + 物品二);
                                        value10.ulong_3 = TS.Read<ulong>(value10.ulong_2);
                                        if (!dictionary_本人.ContainsKey(value10.uint_0))
                                        {
                                            dictionary_本人[value10.uint_0] = MemGetName(value10.uint_0);
                                        }
                                        value10.name = dictionary_本人[value10.uint_0];
                                        if (value10.name == "")
                                        {
                                            value10.name = "None";
                                        }
                                    }
                                    foreach (Class4 value11 in dictionary地图资源.Values)
                                    {
                                        if (value11.ulong_1 <= 0L || value11.ulong_2 <= 0L)
                                        {
                                            continue;
                                        }
                                        value11.vector3_0 = TS.Read<Vector3>(value11.ulong_2 + Position);
                                        value11.vector3_1 = 相加(value11.vector3_0);
                                        if (!class_本人.bool_0)
                                        {
                                            uint num36 = method_34(相减(class_本人.vector3_距离坐标, value11.vector3_1)) / 100u;
                                            if (num36 < 10000)
                                            {
                                                value11.距离 = num36;
                                            }
                                        }
                                        else
                                        {
                                            value11.距离 = 0u;
                                        }
                                    }
                                }
                                foreach (Class4 value11 in dictionary投掷物.Values)
                                {
                                    if (value11.ulong_1 <= 0L || value11.ulong_2 <= 0L)
                                    {
                                        continue;
                                    }
                                    value11.时间 = TS.Read<float>(value11.ADDR + TimeTillExplosion);
                                    value11.vector3_0 = TS.Read<Vector3>(value11.ulong_2 + Position);
                                    value11.vector3_1 = 相加(value11.vector3_0);
                                    if (!class_本人.bool_0)
                                    {
                                        uint num36 = method_34(相减(class_本人.vector3_距离坐标, value11.vector3_1)) / 100u;
                                        if (num36 < 10000)
                                        {
                                            value11.距离 = num36;
                                        }
                                    }
                                    else
                                    {
                                        value11.距离 = 0u;
                                    }
                                }
                                foreach (KeyValuePair<ulong, Actor人物> item49 in dictionary_人物)
                                {
                                    if (!item49.Value.活人)
                                    {
                                        continue;
                                    }
                                    if (透视 && item49.Value.距离 < CommonProperty.pgConfig.EspConfig.透视距离)
                                    {
                                        item49.Value.头部_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)头部 * 48L);
                                        item49.Value.骨盆_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)骨盆 * 48L);
                                        if (CommonProperty.pgConfig.EspConfig.骨骼)
                                        {
                                            item49.Value.颈部_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)颈部 * 48L);
                                            item49.Value.胸部_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)胸部 * 48L);
                                            item49.Value.左手_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)左手 * 48L);
                                            item49.Value.右手_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)右手 * 48L);
                                            //item49.Value.左胯_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)左胯 * 48L);
                                            //item49.Value.右胯_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)右胯 * 48L);
                                            //item49.Value.左肩_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)左肩 * 48L);
                                            //item49.Value.右肩_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)右肩 * 48L);
                                            item49.Value.左肘_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)左肘 * 48L);
                                            item49.Value.右肘_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)右肘 * 48L);
                                            item49.Value.左膝_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)左膝 * 48L);
                                            item49.Value.右膝_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)右膝 * 48L);
                                            item49.Value.左脚跟_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)左脚 * 48L);
                                            item49.Value.右脚跟_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)右脚 * 48L);
                                        }
                                    }
                                    if (CommonProperty.pgConfig.EspConfig.手持 && item49.Value.距离 <= CommonProperty.pgConfig.EspConfig.手持距离)
                                    {
                                        if (item49.Value.byte_b >= 0 && item49.Value.byte_b <= 4)
                                        {
                                            item49.Value.当前武器 = TS.Read<ulong>(item49.Value.武器基址 + (ulong)(item49.Value.byte_b * 8L));
                                        }
                                        else
                                        {
                                            item49.Value.当前武器 = 0ul;
                                            item49.Value.武器类型 = 99;
                                        }

                                        if (item49.Value.当前武器 > 0)
                                        {
                                            item49.Value.武器id = DecryptCIndex(TS.Read<uint>(item49.Value.当前武器 + ObjID));
                                            if (!dictionary_本人.ContainsKey(item49.Value.武器id))
                                            {
                                                dictionary_本人[item49.Value.武器id] = MemGetName(item49.Value.武器id);
                                            }
                                            item49.Value.武器名称name = dictionary_本人[item49.Value.武器id];
                                            if (Program.mainForm_0.GunList.ContainsKey(item49.Value.武器名称name))
                                            {
                                                item49.Value.武器名称 = Program.mainForm_0.GunList[item49.Value.武器名称name].ShortName;
                                                item49.Value.武器类型 = Program.mainForm_0.GunList[item49.Value.武器名称name].GunType;
                                            }
                                            else
                                            {
                                                item49.Value.武器名称 = "";
                                                item49.Value.武器类型 = 99;
                                            }
                                        }
                                    }
                                    if (自瞄)
                                    {
                                        if (!子骨骼自瞄)
                                        {
                                            if (class7_0.父骨骼 == 0)
                                            {
                                                continue;
                                            }
                                            else
                                            {
                                                item49.Value.瞄准_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)(class7_0.父骨骼 * 48L));
                                            }
                                        }
                                        else
                                        {
                                            item49.Value.瞄准_Bone = TS.Read<FTransform>(item49.Value.Bone + (ulong)(class7_0.子骨骼 * 48L));
                                        }
                                    }
                                }
                                TS.Clear(pid, Vmm.FLAG_NOCACHE);





                                if (!class_本人.bool_0 && class_本人.当前武器 > 0L && class_本人.ulong_9 > 0L)
                                {
                                    TS.Prepare(class_本人.ulong_9 + TrajectoryConfig, 4);
                                }
                                TS.Prepare(class_本人.投影相机 + CameraFov, 4);
                                TS.Prepare(class_本人.投影相机 + CameraPos, 12);
                                TS.Prepare(class_本人.投影相机 + CameraRot, 50);
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item50 in dictionary物资)
                                    {
                                        foreach (KeyValuePair<ulong, GameItems> item51 in item50.Value.dictionary_物资)
                                        {
                                            if (item51.Value.name == "")
                                            {
                                                TS.Prepare(item51.Value.ulong_1 + 物品一, 4);
                                            }
                                        }
                                    }
                                }
                                TS.Execute();
                                if (!class_本人.bool_0 && class_本人.当前武器 > 0L && class_本人.ulong_9 > 0L)
                                {
                                    class_本人.float_0 = TS.Read<float>(class_本人.ulong_9 + TrajectoryConfig);
                                    if (class_本人.float_0 == 0f || float.IsNaN(class_本人.float_0))
                                    {
                                        class_本人.float_0 = 800f;
                                    }
                                }
                                class_本人.fcameraCacheData_0.POV.FOV = TS.Read<float>(class_本人.投影相机 + CameraFov);
                                class_本人.fcameraCacheData_0.POV.Location = TS.Read<Vector3>(class_本人.投影相机 + CameraPos);
                                class_本人.fcameraCacheData_0.POV.Rotation = TS.Read<FRotator>(class_本人.投影相机 + CameraRot);
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item52 in dictionary物资)
                                    {
                                        foreach (KeyValuePair<ulong, GameItems> item53 in item52.Value.dictionary_物资)
                                        {
                                            if (item53.Value.name == "")
                                            {
                                                item53.Value.ulong_4 = TS.Read<ulong>(item53.Value.ulong_1 + 物品一);
                                                if (!kyZpsbAxnb(item53.Value.ulong_4, item53.Value.ulong_0))
                                                {
                                                    item53.Value.name = "None";
                                                }
                                            }
                                        }
                                    }
                                }
                                TS.Clear(pid, Vmm.FLAG_NOCACHE);


                                if (透视)
                                {
                                    foreach (Actor人物 value12 in dictionary_人物.Values)
                                    {
                                        if (value12.活人 && 透视 && value12.距离 < CommonProperty.pgConfig.EspConfig.透视距离)
                                        {
                                            D3DMATRIX d3DMATRIX_3 = value12.骨盆_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX2 = method_35(d3DMATRIX_3, value12.Actor_Bone.ToMatrixWithScale());
                                            value12.vector3_骨盆.x = d3DMATRIX2._41;
                                            value12.vector3_骨盆.y = d3DMATRIX2._42;
                                            value12.vector3_骨盆.z = d3DMATRIX2._43;
                                            value12.骨盆 = 计算透视坐标(value12.vector3_骨盆);
                                            D3DMATRIX d3DMATRIX_4 = value12.头部_Bone.ToMatrixWithScale();
                                            D3DMATRIX d3DMATRIX3 = method_35(d3DMATRIX_4, value12.Actor_Bone.ToMatrixWithScale());
                                            value12.vector3_头部.x = d3DMATRIX3._41;
                                            value12.vector3_头部.y = d3DMATRIX3._42;
                                            value12.vector3_头部.z = d3DMATRIX3._43;
                                            value12.头部 = 计算透视坐标(value12.vector3_头部);
                                            if (CommonProperty.pgConfig.EspConfig.骨骼)
                                            {
                                                D3DMATRIX d3DMATRIX_5 = value12.颈部_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX4 = method_35(d3DMATRIX_5, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_颈部.x = d3DMATRIX4._41;
                                                value12.vector3_颈部.y = d3DMATRIX4._42;
                                                value12.vector3_颈部.z = d3DMATRIX4._43;
                                                value12.颈部 = 计算透视坐标(value12.vector3_颈部);
                                                D3DMATRIX d3DMATRIX_6 = value12.胸部_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX5 = method_35(d3DMATRIX_6, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_胸部.x = d3DMATRIX5._41;
                                                value12.vector3_胸部.y = d3DMATRIX5._42;
                                                value12.vector3_胸部.z = d3DMATRIX5._43;
                                                value12.胸部 = 计算透视坐标(value12.vector3_胸部);
                                                D3DMATRIX d3DMATRIX_7 = value12.左肘_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX6 = method_35(d3DMATRIX_7, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_左肘.x = d3DMATRIX6._41;
                                                value12.vector3_左肘.y = d3DMATRIX6._42;
                                                value12.vector3_左肘.z = d3DMATRIX6._43;
                                                value12.左肘 = 计算透视坐标(value12.vector3_左肘);
                                                D3DMATRIX d3DMATRIX_8 = value12.右肘_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX7 = method_35(d3DMATRIX_8, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_右肘.x = d3DMATRIX7._41;
                                                value12.vector3_右肘.y = d3DMATRIX7._42;
                                                value12.vector3_右肘.z = d3DMATRIX7._43;
                                                value12.右肘 = 计算透视坐标(value12.vector3_右肘);
                                                D3DMATRIX d3DMATRIX_9 = value12.左手_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX8 = method_35(d3DMATRIX_9, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_左手.x = d3DMATRIX8._41;
                                                value12.vector3_左手.y = d3DMATRIX8._42;
                                                value12.vector3_左手.z = d3DMATRIX8._43;
                                                value12.左手 = 计算透视坐标(value12.vector3_左手);
                                                D3DMATRIX d3DMATRIX_10 = value12.右手_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX9 = method_35(d3DMATRIX_10, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_右手.x = d3DMATRIX9._41;
                                                value12.vector3_右手.y = d3DMATRIX9._42;
                                                value12.vector3_右手.z = d3DMATRIX9._43;
                                                value12.右手 = 计算透视坐标(value12.vector3_右手);
                                                D3DMATRIX d3DMATRIX_11 = value12.左膝_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX10 = method_35(d3DMATRIX_11, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_左膝.x = d3DMATRIX10._41;
                                                value12.vector3_左膝.y = d3DMATRIX10._42;
                                                value12.vector3_左膝.z = d3DMATRIX10._43;
                                                value12.左膝 = 计算透视坐标(value12.vector3_左膝);
                                                D3DMATRIX d3DMATRIX_12 = value12.右膝_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX11 = method_35(d3DMATRIX_12, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_右膝.x = d3DMATRIX11._41;
                                                value12.vector3_右膝.y = d3DMATRIX11._42;
                                                value12.vector3_右膝.z = d3DMATRIX11._43;
                                                value12.右膝 = 计算透视坐标(value12.vector3_右膝);
                                                D3DMATRIX d3DMATRIX_13 = value12.左脚跟_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX12 = method_35(d3DMATRIX_13, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_左脚跟.x = d3DMATRIX12._41;
                                                value12.vector3_左脚跟.y = d3DMATRIX12._42;
                                                value12.vector3_左脚跟.z = d3DMATRIX12._43;
                                                value12.左脚跟 = 计算透视坐标(value12.vector3_左脚跟);
                                                D3DMATRIX d3DMATRIX_14 = value12.右脚跟_Bone.ToMatrixWithScale();
                                                D3DMATRIX d3DMATRIX13 = method_35(d3DMATRIX_14, value12.Actor_Bone.ToMatrixWithScale());
                                                value12.vector3_右脚跟.x = d3DMATRIX13._41;
                                                value12.vector3_右脚跟.y = d3DMATRIX13._42;
                                                value12.vector3_右脚跟.z = d3DMATRIX13._43;
                                                value12.右脚跟 = 计算透视坐标(value12.vector3_右脚跟);
                                                //D3DMATRIX d3DMATRIX_55 = value12.左肩_Bone.ToMatrixWithScale();
                                                //D3DMATRIX d3DMATRIX44 = method_35(d3DMATRIX_55, value12.Actor_Bone.ToMatrixWithScale());
                                                //value12.vector3_左肩.x = d3DMATRIX44._41;
                                                //value12.vector3_左肩.y = d3DMATRIX44._42;
                                                //value12.vector3_左肩.z = d3DMATRIX44._43;
                                                //value12.左肩 = 计算透视坐标(value12.vector3_左肩);
                                                //D3DMATRIX d3DMATRIX_66 = value12.右肩_Bone.ToMatrixWithScale();
                                                //D3DMATRIX d3DMATRIX55 = method_35(d3DMATRIX_66, value12.Actor_Bone.ToMatrixWithScale());
                                                //value12.vector3_右肩.x = d3DMATRIX55._41;
                                                //value12.vector3_右肩.y = d3DMATRIX55._42;
                                                //value12.vector3_右肩.z = d3DMATRIX55._43;
                                                //value12.右肩 = 计算透视坐标(value12.vector3_右肩);
                                                //D3DMATRIX d3DMATRIX_555 = value12.左胯_Bone.ToMatrixWithScale();
                                                //D3DMATRIX d3DMATRIX444 = method_35(d3DMATRIX_555, value12.Actor_Bone.ToMatrixWithScale());
                                                //value12.vector3_左胯.x = d3DMATRIX444._41;
                                                //value12.vector3_左胯.y = d3DMATRIX444._42;
                                                //value12.vector3_左胯.z = d3DMATRIX444._43;
                                                //value12.左胯 = 计算透视坐标(value12.vector3_左胯);
                                                //D3DMATRIX d3DMATRIX_666 = value12.右胯_Bone.ToMatrixWithScale();
                                                //D3DMATRIX d3DMATRIX555 = method_35(d3DMATRIX_666, value12.Actor_Bone.ToMatrixWithScale());
                                                //value12.vector3_右胯.x = d3DMATRIX555._41;
                                                //value12.vector3_右胯.y = d3DMATRIX555._42;
                                                //value12.vector3_右胯.z = d3DMATRIX555._43;
                                                //value12.右胯 = 计算透视坐标(value12.vector3_右胯);
                                            }
                                        }
                                    }
                                }
                                if (透视)
                                {
                                    List<Actor人物> espData = new List<Actor人物>();
                                    List<Actor人物> espData2 = new List<Actor人物>();
                                    foreach (KeyValuePair<ulong, Actor人物> item44 in dictionary_人物)
                                    {
                                        if (!item44.Value.活人! || item44.Value.是否友军 != 0)
                                        {
                                            continue;
                                        }
                                        Actor人物 item3 = new Actor人物
                                        {
                                            addr = item44.Value.addr,
                                            use = item44.Value.use,
                                            Playname = item44.Value.Playname,
                                            人物视角 = item44.Value.人物视角,
                                            人物状态 = item44.Value.人物状态,
                                            name = item44.Value.name,
                                            ulong_4 = item44.Value.ulong_4,
                                            人物血量 = item44.Value.人物血量,
                                            倒地血量 = item44.Value.倒地血量,
                                            合作者 = item44.Value.合作者,
                                            生存大等级 = item44.Value.生存大等级,
                                            生存等级 = item44.Value.生存等级,
                                            TeamID = item44.Value.TeamID,
                                            TeamSeq = item44.Value.TeamSeq,
                                            人物位面 = item44.Value.人物位面,
                                            人物杀敌 = item44.Value.人物杀敌,
                                            观战人数 = item44.Value.观战人数,
                                            是否人机 = item44.Value.是否人机,
                                            被瞄准 = item44.Value.被瞄准,
                                            距离 = item44.Value.距离,
                                            高度 = item44.Value.高度,
                                            是否可视 = item44.Value.是否可视,
                                            Bone = item44.Value.Bone,
                                            ulong_6 = item44.Value.ulong_6,
                                            预判 = item44.Value.预判,
                                            ulong_8 = item44.Value.ulong_8,
                                            是否友军 = item44.Value.是否友军,
                                            uint_9 = item44.Value.uint_9,
                                            ulong_9 = item44.Value.ulong_9,
                                            当前武器 = item44.Value.当前武器,
                                            string_2 = item44.Value.string_2,
                                            武器名称 = item44.Value.武器名称,
                                            武器类型 = item44.Value.武器类型,
                                            活人 = item44.Value.活人,
                                            武器id = item44.Value.武器id,
                                            IsBlackList = item44.Value.IsBlackList,
                                            uint_10 = item44.Value.uint_10,
                                            vector3_预判 = item44.Value.vector3_预判,
                                            vector2_雷达人物坐标 = item44.Value.vector2_雷达人物坐标,
                                            Actor_Bone = item44.Value.Actor_Bone,
                                            瞄准_Bone = item44.Value.瞄准_Bone,
                                            头部_Bone = item44.Value.头部_Bone,
                                            颈部_Bone = item44.Value.颈部_Bone,
                                            胸部_Bone = item44.Value.胸部_Bone,
                                            //左肩_Bone = item44.Value.左肩_Bone,
                                            //右肩_Bone = item44.Value.右肩_Bone,
                                            //左胯_Bone = item44.Value.左胯_Bone,
                                            //右胯_Bone = item44.Value.右胯_Bone,
                                            左肘_Bone = item44.Value.左肘_Bone,
                                            右肘_Bone = item44.Value.右肘_Bone,
                                            左手_Bone = item44.Value.左手_Bone,
                                            右手_Bone = item44.Value.右手_Bone,
                                            骨盆_Bone = item44.Value.骨盆_Bone,
                                            左膝_Bone = item44.Value.左膝_Bone,
                                            右膝_Bone = item44.Value.右膝_Bone,
                                            左脚跟_Bone = item44.Value.左脚跟_Bone,
                                            右脚跟_Bone = item44.Value.右脚跟_Bone,
                                            瞄准 = item44.Value.瞄准,
                                            头部 = item44.Value.头部,
                                            颈部 = item44.Value.颈部,
                                            胸部 = item44.Value.胸部,
                                            左肘 = item44.Value.左肘,
                                            右肘 = item44.Value.右肘,
                                            左手 = item44.Value.左手,
                                            右手 = item44.Value.右手,
                                            骨盆 = item44.Value.骨盆,
                                            左膝 = item44.Value.左膝,
                                            右膝 = item44.Value.右膝,
                                            左脚跟 = item44.Value.左脚跟,
                                            右脚跟 = item44.Value.右脚跟,
                                            //左肩 = item44.Value.左肩,
                                            //右肩 = item44.Value.右肩,
                                            //左胯 = item44.Value.左胯,
                                            //右胯 = item44.Value.右胯,
                                            vector3_1 = item44.Value.vector3_1,
                                            vector3_头部 = item44.Value.vector3_头部,
                                            vector3_颈部 = item44.Value.vector3_颈部,
                                            vector3_胸部 = item44.Value.vector3_胸部,
                                            vector3_左肘 = item44.Value.vector3_左肘,
                                            vector3_右肘 = item44.Value.vector3_右肘,
                                            vector3_左手 = item44.Value.vector3_左手,
                                            vector3_右手 = item44.Value.vector3_右手,
                                            vector3_骨盆 = item44.Value.vector3_骨盆,
                                            vector3_左膝 = item44.Value.vector3_左膝,
                                            vector3_右膝 = item44.Value.vector3_右膝,
                                            vector3_左脚跟 = item44.Value.vector3_左脚跟,
                                            vector3_右脚跟 = item44.Value.vector3_右脚跟,
                                            //vector3_左肩 = item44.Value.vector3_左肩,
                                            //vector3_右肩 = item44.Value.vector3_右肩,
                                            //vector3_左胯 = item44.Value.vector3_左胯,
                                            //vector3_右胯 = item44.Value.vector3_右胯,
                                            vector3_方向 = item44.Value.vector3_方向,
                                            vector3_距离坐标 = item44.Value.vector3_距离坐标,
                                            vector3_位置 = item44.Value.vector3_位置,
                                            vector3_小地图 = item44.Value.vector3_小地图,
                                            vector3_大地图 = item44.Value.vector3_大地图,
                                            vector3_自己 = item44.Value.vector3_自己,
                                        };
                                        espData2.Add(item3);
                                        if (Program.mainForm_0.Hash_黑名单.Contains(item44.Value.name.Trim()))
                                        {
                                            item44.Value.IsBlackList = true;
                                        }
                                        espData.Add(item44.Value);
                                    }
                                    if (espData.Count > 0)
                                    {
                                        EspOverlay.EspQueue.Enqueue(espData);
                                        CommonProperty.EspResetEventSlim.Set();
                                    }
                                    else
                                    {
                                        EspOverlay.Clear();
                                    }
                                    if (espData2.Count > 0)
                                    {
                                        concurrentQueue_人物.Enqueue(espData);
                                    }
                                }
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item54 in dictionary物资)
                                    {
                                        foreach (KeyValuePair<ulong, GameItems> item55 in item54.Value.dictionary_物资)
                                        {
                                            if (item55.Value.name == "")
                                            {
                                                TS.Prepare(item55.Value.ulong_4 + 物品二, 4);
                                            }
                                        }
                                    }
                                }
                                TS.Execute();
                                if (循环次数 % 50uL == 0L && CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item56 in dictionary物资)
                                    {
                                        foreach (KeyValuePair<ulong, GameItems> item57 in item56.Value.dictionary_物资)
                                        {
                                            if (item57.Value.name == "")
                                            {
                                                item57.Value.uint_0 = TS.Read<uint>(item57.Value.ulong_4 + 物品二);
                                                if (!dictionary_本人.ContainsKey(item57.Value.uint_0))
                                                {
                                                    dictionary_本人[item57.Value.uint_0] = MemGetName(item57.Value.uint_0);
                                                }
                                                item57.Value.name = dictionary_本人[item57.Value.uint_0];
                                                if (item57.Value.name == "")
                                                {
                                                    item57.Value.name = "None";
                                                }
                                            }
                                        }
                                    }
                                }
                                TS.Clear(pid, Vmm.FLAG_NOCACHE);

                                bool flag = false;
                                if (CommonProperty.战斗模式)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item59 in dictionary物资)
                                    {
                                        foreach (KeyValuePair<ulong, GameItems> item60 in item59.Value.dictionary_物资)
                                        {
                                            if (item60.Value.name != "None" && item60.Value.vector3_0.x == 0f && item60.Value.vector3_0.y == 0f && item60.Value.vector3_0.z == 0f)
                                            {
                                                flag = true;
                                                @class.Add<Vector3>(item60.Value.ulong_0 + Position);
                                            }
                                        }
                                    }
                                    foreach (KeyValuePair<ulong, GameItems> item61 in dictionary丢弃的物资)
                                    {
                                        if (item61.Value.name != "None" && item61.Value.vector3_0.x == 0f && item61.Value.vector3_0.y == 0f && item61.Value.vector3_0.z == 0f)
                                        {
                                            flag = true;
                                            @class.Add<Vector3>(item61.Value.ulong_3 + Position);
                                        }
                                    }

                                    @class.Finish();

                                    if (!flag)
                                    {
                                        foreach (KeyValuePair<ulong, Class5> item62 in dictionary物资)
                                        {
                                            foreach (GameItems value13 in item62.Value.dictionary_物资.Values)
                                            {
                                                if (!class_本人.bool_0)
                                                {
                                                    uint num53 = method_34(相减(class_本人.vector3_距离坐标, value13.vector3_1)) / 100u;
                                                    if (num53 < 10000)
                                                    {
                                                        value13.距离 = num53;
                                                    }
                                                }
                                                else
                                                {
                                                    value13.距离 = 0u;
                                                }
                                            }
                                        }
                                        foreach (GameItems value14 in dictionary丢弃的物资.Values)
                                        {
                                            if (!class_本人.bool_0)
                                            {
                                                uint num54 = method_34(相减(class_本人.vector3_距离坐标, value14.vector3_1)) / 100u;
                                                if (num54 < 10000)
                                                {
                                                    value14.距离 = num54;
                                                }
                                            }
                                            else
                                            {
                                                value14.距离 = 0u;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Vector3Int vector3Int = MemRead<Vector3Int>(this.基准值 + 世界转小地图);
                                        if (vector3Int.x != 全地图XY.x || vector3Int.y != 全地图XY.y || vector3Int.z != 全地图XY.z)
                                        {
                                            EspOverlay.Clear3();
                                            dictionary物资.Clear();
                                            dictionary丢弃的物资.Clear();
                                            flag = true;
                                            continue;
                                        }
                                        foreach (KeyValuePair<ulong, Class5> item63 in dictionary物资)
                                        {
                                            foreach (GameItems value15 in item63.Value.dictionary_物资.Values)
                                            {
                                                if (!(value15.name != "None") || value15.vector3_0.x != 0f || value15.vector3_0.y != 0f || value15.vector3_0.z != 0f)
                                                {
                                                    continue;
                                                }
                                                value15.vector3_0 = @class.Get<Vector3>(value15.ulong_0 + Position);
                                                value15.vector3_1 = 相加(value15.vector3_0);
                                                if (!class_本人.bool_0)
                                                {
                                                    uint num55 = method_34(相减(class_本人.vector3_距离坐标, value15.vector3_1)) / 100u;
                                                    if (num55 < 10000)
                                                    {
                                                        value15.距离 = num55;
                                                    }
                                                }
                                                else
                                                {
                                                    value15.距离 = 0u;
                                                }
                                            }
                                        }
                                        foreach (GameItems value16 in dictionary丢弃的物资.Values)
                                        {
                                            if (!(value16.name != "None") || value16.vector3_0.x != 0f || value16.vector3_0.y != 0f || value16.vector3_0.z != 0f)
                                            {
                                                continue;
                                            }
                                            value16.vector3_0 = @class.Get<Vector3>(value16.ulong_3 + Position);
                                            value16.vector3_1 = 相加(value16.vector3_0);
                                            if (!class_本人.bool_0)
                                            {
                                                uint num56 = method_34(相减(class_本人.vector3_距离坐标, value16.vector3_1)) / 100u;
                                                if (num56 < 10000)
                                                {
                                                    value16.距离 = num56;
                                                }
                                            }
                                            else
                                            {
                                                value16.距离 = 0u;
                                            }
                                        }
                                    }
                                }
                                foreach (KeyValuePair<ulong, Actor人物> item64 in dictionary_人物)
                                {
                                    if (item64.Value.活人 && Math.Ceiling(item64.Value.人物血量 + item64.Value.倒地血量) == 0.0)
                                    {
                                        item64.Value.活人 = false;
                                    }
                                }
                                strings_人物.Clear();
                                strings_人物2.Clear();
                                class2.玩家 = "";
                                class2.标记 = "";
                                foreach (Actor人物 value17 in dictionary_人物.Values)
                                {
                                    if (!value17.活人)
                                    {
                                        continue;
                                    }
                                    if (value17.是否人机 == 0)
                                    {
                                        Vector3 vector3_4 = value17.vector3_距离坐标;
                                        uint num57 = value17.TeamID;
                                        Vector3 vector3_5 = value17.vector3_方向;
                                        if (class_本人.bool_0)
                                        {
                                            value17.被瞄准 = 0;
                                            value17.高度 = "";
                                        }
                                        else
                                        {
                                            if ((class_本人.vector3_距离坐标.z - value17.vector3_距离坐标.z) / 100f > 2f)
                                            {
                                                value17.高度 = "▼";
                                            }
                                            else if ((class_本人.vector3_距离坐标.z - value17.vector3_距离坐标.z) / 100f < -2f)
                                            {
                                                value17.高度 = "▲";
                                            }
                                            else
                                            {
                                                value17.高度 = "";
                                            }
                                            if (!(vector3_5.x < -3600f) && !(vector3_5.x > 3600f) && !(vector3_5.y < -3600f) && vector3_5.y <= 3600f)
                                            {
                                                Vector3 vector6 = method_31(vector3_4, class_本人.vector3_距离坐标);
                                                Vector3 vector7 = method_32(vector3_5);
                                                int num58 = (int)Math.Abs(vector6.x - vector7.y);
                                                int num59 = (int)Math.Abs(vector6.y - vector7.x);
                                                if (num58 <= 3 && num59 <= 3)
                                                {
                                                    value17.被瞄准 = 1;
                                                }
                                                else
                                                {
                                                    value17.被瞄准 = 0;
                                                }
                                            }
                                            else
                                            {
                                                value17.被瞄准 = 0;
                                            }
                                        }
                                        string text3 = "";
                                        if (玩家信息)
                                        {
                                            if (游戏ID)
                                            {
                                                text3 += value17.name.Trim();
                                            }
                                            if (ShowAudience)
                                            {
                                                text3 += ((text3 == "") ? ("V:" + value17.观战人数) : ("/V:" + value17.观战人数));
                                            }
                                            if (ShowKillNum)
                                            {
                                                text3 += ((text3 == "") ? ("K:" + value17.人物杀敌) : ("/K:" + value17.人物杀敌));
                                            }
                                            if (ShowKD && dictionary_3.ContainsKey(value17.name.Trim()))
                                            {
                                                text3 += ((!(text3 == "")) ? ("/KD:" + dictionary_3[value17.name.Trim()].KD) : ("KD:" + dictionary_3[value17.name.Trim()].KD));
                                                string text33 = ((!(text3 == "")) ? ("/KD:" + dictionary_3[value17.name.Trim()].KD) : ("KD:" + dictionary_3[value17.name.Trim()].KD));
                                            }
                                            if (ShowDamageAvg && dictionary_3.ContainsKey(value17.name.Trim()))
                                            {
                                                text3 += ((text3 == "") ? ("D:" + dictionary_3[value17.name.Trim()].cs) : ("/D:" + dictionary_3[value17.name.Trim()].cs));
                                            }
                                            if (ShowRank && dictionary_3.ContainsKey(value17.name.Trim()) && dictionary_3[value17.name.Trim()].Rank != "?")
                                            {
                                                text3 += ((!(text3 == "")) ? ("/" + dictionary_3[value17.name.Trim()].Rank) : dictionary_3[value17.name.Trim()].Rank);
                                            }
                                            if (ShowSurvivalLevel)
                                            {
                                                uint num60 = value17.生存等级 + (value17.生存大等级 - 1) * 500;
                                                if (num60 < 5000)
                                                {
                                                    value17.等级 = num60;
                                                    text3 += ((!(text3 == "")) ? ("/S:" + num60) : ("S:" + num60));
                                                }
                                            }
                                            if (ShowDistance || text3 == "")
                                            {
                                                text3 += ((!(text3 == "")) ? ("/" + value17.距离 + "M") : value17.距离.ToString());
                                            }
                                        }

                                        if (CommonProperty.pgConfig.EspConfig.段位 && dictionary_3.ContainsKey(value17.name.Trim()) && dictionary_3[value17.name.Trim()].Rank != "?")
                                        {
                                            value17.段位 = dictionary_3[value17.name.Trim()].Rank;
                                        }

                                        if (CommonProperty.pgConfig.EspConfig.KD && dictionary_3.ContainsKey(value17.name.Trim()))
                                        {
                                            value17.KD = ("" + dictionary_3[value17.name.Trim()].KD);
                                        }

                                        if (Program.mainForm_0.Hash_黑名单.Contains(value17.name.Trim()))
                                        {
                                            value17.IsBlackList = true;
                                            value17.人物杀敌 = 99u;
                                        }
                                        try
                                        {
                                            string item3 = string.Format("[{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},\"{15}\",\"{16}\",\"{17}\"]", Convert.ToInt64(Math.Ceiling(vector3_4.x)), Convert.ToInt64(Math.Ceiling(vector3_4.y)), value17.距离, (num57 >= 100000) ? (num57 - 100000) : num57, Convert.ToInt64(Math.Ceiling(value17.人物血量)), Convert.ToInt64(Math.Ceiling(value17.倒地血量)), value17.人物杀敌, value17.观战人数, Convert.ToInt64(Math.Ceiling(value17.vector3_方向.y)), value17.是否友军, value17.是否人机, (value17.合作者 != 0) ? 1 : 0, (value17.name.Trim() == "") ? 1 : 0, value17.uint_9, value17.被瞄准, value17.高度, value17.name.Trim(), text3);
                                            if (vector3_4.x > 0f && vector3_4.y > 0f && vector3_4.x < 1000000f && vector3_4.y < 1000000f)
                                            {
                                                strings_人物.Add(item3);
                                            }
                                            if (value17.是否友军 == 1 && value17.vector2_雷达人物坐标.x > 0f && value17.vector2_雷达人物坐标.y > 0f && value17.vector2_雷达人物坐标.x < 1000000f && value17.vector2_雷达人物坐标.y < 1000000f)
                                            {
                                                item3 = string.Format("[{0},{1},{2}]", value17.TeamSeq + 1, value17.vector2_雷达人物坐标.x, value17.vector2_雷达人物坐标.y);
                                                strings_人物2.Add(item3);
                                            }
                                        }
                                        catch
                                        {
                                        }
                                    }
                                    else
                                    {
                                        if (!value17.活人)
                                        {
                                            continue;
                                        }
                                        string text4 = "";
                                        if (class_本人.bool_0)
                                        {
                                            value17.高度 = "";
                                        }
                                        else if ((class_本人.vector3_距离坐标.z - value17.vector3_距离坐标.z) / 100f > 2f)
                                        {
                                            value17.高度 = "▼";
                                        }
                                        else if ((class_本人.vector3_距离坐标.z - value17.vector3_距离坐标.z) / 100f < -2f)
                                        {
                                            value17.高度 = "▲";
                                        }
                                        else
                                        {
                                            value17.高度 = "";
                                        }
                                        Vector3 vector3_6 = value17.vector3_距离坐标;
                                        uint num61 = value17.TeamID;
                                        try
                                        {
                                            string item4 = string.Format("[{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},\"{15}\",\"{16}\",\"{17}\"]", Convert.ToInt64(Math.Ceiling(vector3_6.x)), Convert.ToInt64(Math.Ceiling(vector3_6.y)), value17.距离, (num61 >= 100000) ? (num61 - 100000) : num61, Convert.ToInt64(Math.Ceiling(value17.人物血量)), Convert.ToInt64(Math.Ceiling(value17.倒地血量)), 0, 0, Convert.ToInt64(Math.Ceiling(value17.vector3_方向.y)), value17.是否友军, 1, 0, 0, 0, value17.被瞄准, value17.高度, "BOT", text4);
                                            if (vector3_6.x > 0f && vector3_6.y > 0f && vector3_6.x < 1000000f && vector3_6.y < 1000000f)
                                            {
                                                strings_人物.Add(item4);
                                            }
                                        }
                                        catch
                                        {
                                        }
                                    }
                                }
                                strings_物资.Clear();
                                class2.物资 = "";
                                if (CommonProperty.战斗模式 && 雷达物资)
                                {
                                    foreach (KeyValuePair<ulong, Class5> item65 in dictionary物资)
                                    {
                                        foreach (KeyValuePair<ulong, GameItems> item66 in item65.Value.dictionary_物资)
                                        {
                                            if (dictionary_物资.ContainsKey(item66.Value.name))
                                            {
                                                if (!判断物资(item66.Value.name) || !(item66.Value.vector3_1.x > 0f) || !(item66.Value.vector3_1.y > 0f))
                                                {
                                                    continue;
                                                }
                                                string text5 = "0";
                                                string text6 = "●";
                                                if (!class_本人.bool_0)
                                                {
                                                    if ((class_本人.vector3_距离坐标.z - item66.Value.vector3_1.z) / 100f > 2f)
                                                    {
                                                        text6 = "▼";
                                                    }
                                                    else if ((class_本人.vector3_距离坐标.z - item66.Value.vector3_1.z) / 100f < -2f)
                                                    {
                                                        text6 = "▲";
                                                    }
                                                }
                                                switch (dictionary_物资[item66.Value.name].group)
                                                {
                                                    default:
                                                        if (物资0)
                                                        {
                                                            text5 = "0";
                                                            string item8 = string.Format("[\"{0}{1}\",{2},{3},\"{4}\"]", text6, dictionary_物资[item66.Value.name].shortName, item66.Value.vector3_1.x, item66.Value.vector3_1.y, text5);
                                                            strings_物资.Add(item8);

                                                        }
                                                        break;
                                                    case 1:
                                                        if (物资1)
                                                        {
                                                            text5 = "1";
                                                            string item6 = string.Format("[\"{0}{1}\",{2},{3},\"{4}\"]", text6, dictionary_物资[item66.Value.name].shortName, item66.Value.vector3_1.x, item66.Value.vector3_1.y, text5);
                                                            strings_物资.Add(item6);

                                                        }
                                                        break;
                                                    case 2:
                                                        if (物资2)
                                                        {
                                                            text5 = "2";
                                                            string item7 = string.Format("[\"{0}{1}\",{2},{3},\"{4}\"]", text6, dictionary_物资[item66.Value.name].shortName, item66.Value.vector3_1.x, item66.Value.vector3_1.y, text5);
                                                            strings_物资.Add(item7);

                                                        }
                                                        break;
                                                    case 3:
                                                        if (物资3)
                                                        {
                                                            text5 = "3";
                                                            string item5 = string.Format("[\"{0}{1}\",{2},{3},\"{4}\"]", text6, dictionary_物资[item66.Value.name].shortName, item66.Value.vector3_1.x, item66.Value.vector3_1.y, text5);
                                                            strings_物资.Add(item5);

                                                        }
                                                        break;
                                                }
                                            }
                                            else if (item66.Value.name.Trim() != "None" && !item66.Value.name.Contains("/"))
                                            {
                                                dictionary_5[item66.Value.uint_0] = new KeyValuePair<string, string>("物资", item66.Value.name);
                                            }

                                        }
                                    }


                                    foreach (KeyValuePair<ulong, GameItems> item67 in dictionary丢弃的物资)
                                    {
                                        if (!dictionary_物资.ContainsKey(item67.Value.name))
                                        {
                                            if (item67.Value.name.Trim() != "None" && !item67.Value.name.Contains("/"))
                                            {
                                                dictionary_5[item67.Value.uint_0] = new KeyValuePair<string, string>("丢弃物资", item67.Value.name);

                                            }
                                        }
                                        else
                                        {
                                            if (!判断物资(item67.Value.name) || !(item67.Value.vector3_1.x > 0f) || !(item67.Value.vector3_1.y > 0f))
                                            {
                                                continue;
                                            }
                                            string text7 = "0";
                                            string text8 = "●";
                                            if (!class_本人.bool_0)
                                            {
                                                if ((class_本人.vector3_距离坐标.z - item67.Value.vector3_1.z) / 100f > 2f)
                                                {
                                                    text8 = "▼";
                                                }
                                                else if ((class_本人.vector3_距离坐标.z - item67.Value.vector3_1.z) / 100f < -2f)
                                                {
                                                    text8 = "▲";
                                                }
                                            }
                                            switch (dictionary_物资[item67.Value.name].group)
                                            {
                                                default:
                                                    if (物资0)
                                                    {
                                                        text7 = "0";
                                                        string item12 = string.Format("[\"{0}{1}\",{2},{3},\"{4}\"]", text8, dictionary_物资[item67.Value.name].shortName, item67.Value.vector3_1.x, item67.Value.vector3_1.y, text7);
                                                        strings_物资.Add(item12);
                                                    }
                                                    break;
                                                case 1:
                                                    if (物资1)
                                                    {
                                                        text7 = "1";
                                                        string item10 = string.Format("[\"{0}{1}\",{2},{3},\"{4}\"]", text8, dictionary_物资[item67.Value.name].shortName, item67.Value.vector3_1.x, item67.Value.vector3_1.y, text7);
                                                        strings_物资.Add(item10);
                                                    }
                                                    break;
                                                case 2:
                                                    if (物资2)
                                                    {
                                                        text7 = "2";
                                                        string item11 = string.Format("[\"{0}{1}\",{2},{3},\"{4}\"]", text8, dictionary_物资[item67.Value.name].shortName, item67.Value.vector3_1.x, item67.Value.vector3_1.y, text7);
                                                        strings_物资.Add(item11);
                                                    }
                                                    break;
                                                case 3:
                                                    if (物资3)
                                                    {
                                                        text7 = "3";
                                                        string item9 = string.Format("[\"{0}{1}\",{2},{3},\"{4}\"]", text8, dictionary_物资[item67.Value.name].shortName, item67.Value.vector3_1.x, item67.Value.vector3_1.y, text7);
                                                        strings_物资.Add(item9);
                                                    }
                                                    break;
                                            }
                                        }
                                    }
                                }
                                strings_载具.Clear();
                                strings_盒子.Clear();
                                class2.载具 = "";
                                class2.盒子 = "";
                                if (CommonProperty.战斗模式)
                                {
                                    foreach (Class4 value18 in dictionary地图资源.Values)
                                    {
                                        string text9 = "●";
                                        if (!class_本人.bool_0)
                                        {
                                            if ((class_本人.vector3_距离坐标.z - value18.vector3_1.z) / 100f > 2f)
                                            {
                                                text9 = "▼";
                                            }
                                            else if ((class_本人.vector3_距离坐标.z - value18.vector3_1.z) / 100f < -2f)
                                            {
                                                text9 = "▲";
                                            }
                                        }
                                        switch (value18.种类)
                                        {
                                            case "盒子":
                                                {
                                                    string text11 = string.Format("[\"{0}\",{1},{2}]", (value18.name.Trim() == "DeathDropItemPackage_C") ? "0" : "1", value18.vector3_1.x, value18.vector3_1.y);
                                                    if (!text11.Contains("\"NaN\"") && value18.vector3_1.x > 0f && value18.vector3_1.y > 0f)
                                                    {
                                                        strings_盒子.Add(text11);
                                                    }
                                                    break;
                                                }
                                            case "载具":
                                                {
                                                    string text12 = string.Format("[\"{0}{1}\",{2},{3}]", text9, dictionary_载具[value18.name].shortName, value18.vector3_1.x, value18.vector3_1.y);
                                                    if (!text12.Contains("\"NaN\"") && value18.vector3_1.x > 0f && value18.vector3_1.y > 0f && 雷达载具)
                                                    {
                                                        strings_载具.Add(text12);
                                                    }
                                                    break;
                                                }
                                                //case "投掷":
                                                //    {
                                                //        string text10 = string.Format("[\"{0}{1}[{2}]\",{3},{4}]", text9, dictionary_投掷物[value18.name].shortName, value18.人物距离, value18.vector3_距离坐标.x, value18.vector3_距离坐标.y);
                                                //        if (!text10.Contains("\"NaN\"") && value18.vector3_距离坐标.x > 0f && value18.vector3_距离坐标.y > 0f)
                                                //        {
                                                //            strings_载具.Add(text10);
                                                //        }
                                                //        break;
                                                //    }
                                        }
                                    }

                                }
                                if (透视)
                                {
                                    List<GameItems> gameItemsList = new List<GameItems>();
                                    List<Class4> vehiclesList_载具 = new List<Class4>();
                                    if (CommonProperty.战斗模式 && !class_本人.bool_0)
                                    {
                                        foreach (Class4 value20 in dictionary地图资源.Values)
                                        {
                                            string text14 = value20.种类;
                                            if (CommonProperty.pgConfig.EspConfig.大地图 && (CommonProperty.pgConfig.EspConfig.透视载具 || CommonProperty.pgConfig.EspConfig.大地图载具))
                                            {
                                                if (text14 == "载具" && 1 < value20.距离 && value20.距离 < CommonProperty.pgConfig.EspConfig.载具距离)
                                                {
                                                    Vector2 透视坐标 = 计算透视坐标(value20.vector3_0);
                                                    value20.透视坐标 = 透视坐标;
                                                    value20.ShortName = dictionary_载具[value20.name].shortName;
                                                    vehiclesList_载具.Add(value20);
                                                }
                                            }
                                            if (CommonProperty.pgConfig.EspConfig.大地图)
                                            {
                                                if (text14 == "盒子" && 1 < value20.距离 && (value20.name == "Carapackage_RedBox_C" || value20.name == "Carapackage_FlareGun_C"))
                                                {
                                                    Vector2 透视坐标 = 计算透视坐标(value20.vector3_0);
                                                    value20.透视坐标 = 透视坐标;
                                                    vehiclesList_载具.Add(value20);
                                                }
                                            }
                                        }
                                        if (vehiclesList_载具.Count > 0)
                                        {
                                            EspOverlay.EspVehicleQueue.Enqueue(vehiclesList_载具);
                                            //CommonProperty.EspVehicleResetEventSlim.Set();
                                            CommonProperty.EspResetEventSlim.Set();
                                        }
                                        else
                                        {
                                            EspOverlay.Clear2();
                                        }
                                        if (vehiclesList_载具.Count > 0)
                                        {
                                            concurrentQueue_地图资源.Enqueue(vehiclesList_载具);
                                        }

                                        if (CommonProperty.pgConfig.EspConfig.透视物资)
                                        {
                                            foreach (Class5 value21 in dictionary物资.Values)
                                            {
                                                foreach (GameItems value22 in value21.dictionary_物资.Values)
                                                {
                                                    if (value22.距离 >= CommonProperty.pgConfig.EspConfig.物资距离 || value22.距离 == 0 || !dictionary_物资.ContainsKey(value22.name) || !dictionary_物资[value22.name].showItem)
                                                    {
                                                        continue;
                                                    }
                                                    Vector2 vector透视坐标 = 计算透视坐标(value22.vector3_0);
                                                    if (!(vector透视坐标.x < 0) && !(vector透视坐标.y < 0) && !(vector透视坐标.x > X分辨率) && !(vector透视坐标.y > Y分辨率))
                                                    {
                                                        value22.透视坐标 = vector透视坐标;
                                                        if (物资0 && dictionary_物资[value22.name].group == 0)
                                                        {
                                                            value22.group = 0;
                                                            value22.ShortName = dictionary_物资[value22.name].shortName;
                                                            gameItemsList.Add(value22);
                                                        }
                                                        if (物资1 && dictionary_物资[value22.name].group == 1)
                                                        {
                                                            value22.group = 1;
                                                            value22.ShortName = dictionary_物资[value22.name].shortName;
                                                            gameItemsList.Add(value22);
                                                        }
                                                        if (物资2 && dictionary_物资[value22.name].group == 2)
                                                        {
                                                            value22.group = 2;
                                                            value22.ShortName = dictionary_物资[value22.name].shortName;
                                                            gameItemsList.Add(value22);
                                                        }
                                                        if (物资3 && dictionary_物资[value22.name].group == 3)
                                                        {
                                                            value22.group = 3;
                                                            value22.ShortName = dictionary_物资[value22.name].shortName;
                                                            gameItemsList.Add(value22);
                                                        }
                                                    }

                                                }
                                            }
                                            foreach (GameItems value23 in dictionary丢弃的物资.Values)
                                            {
                                                if (value23.距离 >= CommonProperty.pgConfig.EspConfig.物资距离 || value23.距离 == 0 || !dictionary_物资.ContainsKey(value23.name) || !dictionary_物资[value23.name].showItem)
                                                {
                                                    continue;
                                                }
                                                Vector2 vector15 = 计算透视坐标(value23.vector3_0);
                                                if (!(vector15.x < 0) && !(vector15.y < 0) && !(vector15.x > X分辨率) && !(vector15.y > Y分辨率))
                                                {
                                                    value23.透视坐标 = vector15;
                                                    if (物资0 && dictionary_物资[value23.name].group == 0)
                                                    {
                                                        value23.group = 0;
                                                        value23.ShortName = dictionary_物资[value23.name].shortName;
                                                        gameItemsList.Add(value23);
                                                    }
                                                    if (物资1 && dictionary_物资[value23.name].group == 1)
                                                    {
                                                        value23.group = 1;
                                                        value23.ShortName = dictionary_物资[value23.name].shortName;
                                                        gameItemsList.Add(value23);
                                                    }
                                                    if (物资2 && dictionary_物资[value23.name].group == 2)
                                                    {
                                                        value23.group = 2;
                                                        value23.ShortName = dictionary_物资[value23.name].shortName;
                                                        gameItemsList.Add(value23);
                                                    }
                                                    if (物资3 && dictionary_物资[value23.name].group == 3)
                                                    {
                                                        value23.group = 3;
                                                        value23.ShortName = dictionary_物资[value23.name].shortName;
                                                        gameItemsList.Add(value23);
                                                    }
                                                }
                                            }
                                        }

                                        if (gameItemsList.Count > 0)
                                        {
                                            EspOverlay.EspGameItemQueue.Enqueue(gameItemsList);
                                            //CommonProperty.EspGameItemResetEventSlim.Set();
                                            CommonProperty.EspResetEventSlim.Set();
                                        }
                                        else
                                        {
                                            EspOverlay.Clear3();
                                        }
                                    }
                                    else
                                    {
                                        EspOverlay.Clear3();
                                        EspOverlay.Clear2();
                                    }
                                    List<Class4> vehiclesList_投掷物 = new List<Class4>();
                                    foreach (Class4 value20 in dictionary投掷物.Values)
                                    {
                                        string text14 = value20.种类;
                                        if (text14 == "投掷")
                                        {
                                            if (value20.距离 < 100 && value20.时间 > 0)
                                            {
                                                Vector2 透视坐标 = 计算透视坐标(value20.vector3_0);
                                                value20.透视坐标 = 透视坐标;
                                                value20.ShortName = dictionary_投掷物[value20.name].shortName;
                                                vehiclesList_投掷物.Add(value20);
                                            }
                                        }
                                    }
                                    if (vehiclesList_投掷物.Count > 0)
                                    {
                                        EspOverlay.ESP投掷物.Enqueue(vehiclesList_投掷物);
                                        //CommonProperty.Esp投掷物.Set();
                                        CommonProperty.EspResetEventSlim.Set();
                                    }
                                    else
                                    {
                                        EspOverlay.Clear4();
                                    }
                                }
                                strings_雷达信息.Clear();
                                class2.玩家信息 = "";
                                switch (int_0)
                                {
                                    case 1:
                                        int_0 = 0;
                                        strings_雷达信息.Add("[\"zoom\",\"U\"]");
                                        break;
                                    default:
                                        int_0 = 0;
                                        strings_雷达信息.Add("[\"zoom\",\"K\"]");
                                        break;
                                    case -1:
                                        int_0 = 0;
                                        strings_雷达信息.Add("[\"zoom\",\"D\"]");
                                        break;
                                }
                                if (玩家信息)
                                {
                                    strings_雷达信息.Add("[\"showplayinfo\",\"T\"]");
                                }
                                else
                                {
                                    strings_雷达信息.Add("[\"showplayinfo\",\"F\"]");
                                }
                                strings_雷达信息.Add("[\"FontSize\",\"" + 字体大小 + "\"]");
                                string text13 = string.Format("[{0},{1},{2},{3},{4},{5}]", 物资0 ? 1 : 0, 物资1 ? 1 : 0, 物资2 ? 1 : 0, 物资3 ? 1 : 0, CommonProperty.战斗模式 ? 1 : 0, (class_本人.当前武器名称 != "") ? class7_0.父骨骼 : 9);
                                strings_雷达信息.Add("[\"INFO\"," + text13 + "]");
                                class2.本人 = string.Format("[{0},{1},{2}],[{3},{4},{5}],[{6},{7},{8}],[{9},{10},{11}]", Math.Ceiling(vector3_.x), Math.Ceiling(vector3_.y), Math.Ceiling(vector3_.z), Math.Ceiling(vector.x), Math.Ceiling(vector.y), Math.Ceiling(vector.z), Math.Ceiling(vector2.x), Math.Ceiling(vector2.y), Math.Ceiling(vector2.z), 0, 0, 0);
                                StringBuilder stringBuilder = new StringBuilder();
                                if (CommonProperty.战斗模式)
                                {
                                    stringBuilder.Clear();
                                    foreach (string item68 in strings_物资)
                                    {
                                        if (!item68.Contains("\"NaN\""))
                                        {
                                            stringBuilder.Append(item68);
                                            stringBuilder.Append(",");
                                        }
                                    }
                                    class2.物资 = stringBuilder.ToString().TrimEnd(',');
                                    stringBuilder.Clear();
                                    foreach (string item70 in strings_载具)
                                    {
                                        if (!item70.Contains("\"NaN\""))
                                        {
                                            stringBuilder.Append(item70);
                                            stringBuilder.Append(",");
                                        }
                                    }
                                    class2.载具 = stringBuilder.ToString().TrimEnd(',');
                                    stringBuilder.Clear();
                                    foreach (string item71 in strings_盒子)
                                    {
                                        if (!item71.Contains("\"NaN\""))
                                        {
                                            stringBuilder.Append(item71);
                                            stringBuilder.Append(",");
                                        }
                                    }
                                    class2.盒子 = stringBuilder.ToString().TrimEnd(',');
                                }
                                stringBuilder.Clear();
                                foreach (string item69 in strings_人物)
                                {
                                    if (!item69.Contains("\"NaN\""))
                                    {
                                        stringBuilder.Append(item69);
                                        stringBuilder.Append(",");
                                    }
                                }
                                class2.玩家 = stringBuilder.ToString().TrimEnd(',');
                                stringBuilder.Clear();
                                foreach (string item72 in strings_人物2)
                                {
                                    if (!item72.Contains("\"NaN\""))
                                    {
                                        stringBuilder.Append(item72);
                                        stringBuilder.Append(",");
                                    }
                                }
                                class2.标记 = stringBuilder.ToString().TrimEnd(',');
                                stringBuilder.Clear();
                                foreach (string item73 in strings_雷达信息)
                                {
                                    if (!item73.Contains("\"NaN\""))
                                    {
                                        stringBuilder.Append(item73);
                                        stringBuilder.Append(",");
                                    }
                                }
                                class2.玩家信息 = stringBuilder.ToString().TrimEnd(',');
                                stringBuilder.Clear();
                                stopwatch.Stop();
                                int 主线程延迟 = (int)stopwatch.Elapsed.TotalMilliseconds;
                                左下角延迟_主线程 += 主线程延迟;
                                WebServer = WebServer.ToLower();
                                if (!WebServer.StartsWith("http://"))
                                {
                                    WebServer = "http://" + WebServer.ToLower();
                                }
                                if (!WebServer.EndsWith("/"))
                                {
                                    WebServer = WebServer.ToLower() + "/";
                                }
                                if (username == "" || MqttServer == "")
                                {
                                    结束进程();
                                }
                                if (class_本人.本人name != "")
                                {
                                    string_1 = WebServer + "?" + username + "&addr=" + MqttServer + "&id=" + class_本人.本人name;
                                }
                                else
                                {
                                    string_1 = WebServer + "?" + username + "&addr=" + MqttServer;
                                }
                                状态("网页", string_1);
                                string item17 = class2.method_0();
                                num2 += 主线程延迟;
                                if (num2 >= 30)
                                {
                                    concurrentQueue_1.Enqueue(item17);
                                    autoResetEvent_1.Set();
                                    while (num2 >= 30)
                                    {
                                        num2 -= 30;
                                    }
                                }
                                if (循环次数 == 100L)
                                {
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                                }
                                if (循环次数 == 200L)
                                {
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                                }
                                if (循环次数 == 300L)
                                {
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                                }
                                if (循环次数 == 400L)
                                {
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                                }
                                if (循环次数 == 500L)
                                {
                                    dictionary_本人.Clear();
                                    dictionary投掷物.Clear();
                                    dictionary_人物.Clear();
                                    dictionary物资.Clear();
                                    dictionary丢弃的物资.Clear();
                                    dictionary地图资源.Clear();
                                    dictionary_全.Clear();
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                                }

                                if (循环次数 % 1000uL == 0L)
                                {
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
                                    vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
                                    dictionary_本人.Clear();
                                    dictionary投掷物.Clear();
                                    dictionary_人物.Clear();
                                    if (循环次数 % 3000uL == 0L)
                                    {
                                        dictionary物资.Clear();
                                        dictionary丢弃的物资.Clear();
                                        dictionary地图资源.Clear();
                                        dictionary_全.Clear();

                                    }
                                }
                                if (CommonProperty.pgConfig.EspConfig.小地图 || CommonProperty.pgConfig.EspConfig.大地图)
                                {
                                    小地图雷达();
                                }
                                if (循环次数 % 50uL == 0L)
                                {
                                    状态("延迟", "[" + (左下角延迟_主线程 / 50).ToString("D4") + "]");
                                    左下角延迟_主线程 = 0;
                                    if (debug)
                                    {
                                        状态2("本人信息:" + JsonConvert.SerializeObject(class_本人));
                                        if (dictionary_5.Count > 0)
                                        {
                                            状态2("未启用[" + dictionary_5.Count + "]:" + JsonConvert.SerializeObject(dictionary_5));
                                        }
                                        if (dictionary物资.Count > 0)
                                        {
                                            状态2("物资组[" + dictionary物资.Count + "]:" + JsonConvert.SerializeObject(dictionary物资));
                                        }
                                        if (dictionary地图资源.Count > 0)
                                        {
                                            状态2("盒子载具[" + dictionary地图资源.Count + "]:" + JsonConvert.SerializeObject(dictionary地图资源));
                                        }
                                        if (dictionary丢弃的物资.Count > 0)
                                        {
                                            状态2("地面物资[" + dictionary丢弃的物资.Count + "]:" + JsonConvert.SerializeObject(dictionary丢弃的物资));
                                        }
                                        if (dictionary_人物.Count > 0)
                                        {
                                            状态2("玩家[" + dictionary_人物.Count + "]:" + JsonConvert.SerializeObject(dictionary_人物));
                                        }
                                    }
                                }
                                if (自瞄 || this.瞄准地址 != 0L || 主线程延迟 >= 2)
                                {
                                    continue;
                                }
                                if (!融合器)
                                {
                                    if (CommonProperty.pgConfig.EspConfig.帧延迟 > 0)
                                    {
                                        if (CommonProperty.pgConfig.EspConfig.帧延迟 > 主线程延迟)
                                        {
                                            帧率锁(CommonProperty.pgConfig.EspConfig.帧延迟);
                                        }
                                        else
                                        {
                                            帧率锁(主线程延迟);
                                        }
                                    }
                                }
                                else if (CommonProperty.pgConfig.EspConfig.帧延迟 > 主线程延迟)
                                {
                                    帧率锁(主线程延迟);
                                }
                                else
                                {
                                    帧率锁(CommonProperty.pgConfig.EspConfig.帧延迟);
                                }
                            }
                            else
                            {
                                this.基准值 = method_4(MemRead<ulong>(ulong_0 + Uworld));
                                对象指针 = method_4(MemRead<ulong>(method_4(MemRead<ulong>(this.基准值 + Leve)) + Actor));
                                Thread.Sleep(5);
                            }
                        }
                    }
                    else if (debug)
                    {
                        vmm.ConfigSet(Vmm.OPT_REFRESH_ALL, 1);

                        状态3("错误的地图[Wrong Map Name] " + 当前地图, Color.Red);
                        Thread.Sleep(3000);
                    }
                }
                else
                {
                    vmm.ConfigSet(Vmm.OPT_REFRESH_ALL, 1);

                    this.MapAddr = 0uL;
                    this.MinimapCanvasWidgetAddr = 0uL;
                    this.MapGrid = 0uL;
                    this.Slot1 = 0uL;
                    按键();
                    class2.method_1();
                    class2.地图 = "\"Range_Main\"";
                    class_本人 = new Class1();
                    hashSet_友军.Clear();
                    hashSet_白名单.Clear();
                    dictionary_本人.Clear();
                    dictionary投掷物.Clear();
                    dictionary_人物.Clear();
                    dictionary物资.Clear();
                    dictionary丢弃的物资.Clear();
                    dictionary地图资源.Clear();
                    dictionary_全.Clear();
                    状态("地图", "大厅[Lobby]", false);
                    状态("延迟", "[0000]", false);
                    状态("清理友军黑名单", "");
                    concurrentQueue_1.Enqueue(class2.method_0());
                    autoResetEvent_1.Set();
                    if (透视)
                    {
                        CommonProperty.fov = 0;
                        CommonProperty.本人观战人数 = 0;
                        EspOverlay.Clear4();
                        EspOverlay.Clear3();
                        EspOverlay.Clear2();
                        EspOverlay.Clear();
                    }
                    Thread.Sleep(200);
                }
            }
            catch (Exception)
            {
                vmm.ConfigSet(Vmm.OPT_REFRESH_ALL, 1);

                this.MapAddr = 0uL;
                this.MinimapCanvasWidgetAddr = 0uL;
                this.MapGrid = 0uL;
                this.Slot1 = 0uL;
                class2.method_1();
                class2.地图 = "\"Range_Main\"";
                class_本人 = new Class1();
                hashSet_友军.Clear();
                hashSet_白名单.Clear();
                dictionary_本人.Clear();
                dictionary投掷物.Clear();
                dictionary_人物.Clear();
                dictionary物资.Clear();
                dictionary地图资源.Clear();
                dictionary_全.Clear();
                状态("地图", "等待游戏进程[Lobby]", false);
                状态("延迟", "[0000]", false);
                状态("清理友军黑名单", "");
                concurrentQueue_1.Enqueue(class2.method_0());
                autoResetEvent_1.Set();
                if (透视)
                {
                    CommonProperty.fov = 0;
                    CommonProperty.本人观战人数 = 0;
                    EspOverlay.Clear4();
                    EspOverlay.Clear3();
                    EspOverlay.Clear2();
                    EspOverlay.Clear();
                }
                ThreadRunning = false;
                CommonProperty.GameStartSlim.Set();
                return;
            }
        }
    }

    public void 大地图()
    {
        Class9 @class = new Class9(pid, vmm);
        FMargin Offsetss;

        if (MapAddr == 0 || MapGrid == 0)
        {
            //vmm.ConfigSet(Vmm.OPT_REFRESH_ALL, 1);
            vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_MEM, 1);
            vmm.ConfigSet(Vmm.OPT_REFRESH_FREQ_TLB, 1);
            return;
        }
        @class.Add<int>(MapAddr + Visibility);
        if (IsShow)
        {
            if (Slot1 > 0)
            {
                @class.Add<FMargin>(Slot1 + LayoutData + Offsets);
                @class.Add<Vector2>(Slot1 + LayoutData + Alignment);
            }
            else
            {
                @class.Add<ulong>(MapGrid + Slot);
            }
        }
        // 获取Solt
        @class.Finish();
        if (MapAddr == 0 || MapGrid == 0) return;
        if (IsShow)
        {
            if (Slot1 > 0)
            {
                Offsetss = @class.Get<FMargin>(Slot1 + LayoutData + Offsets);
                WorldMapZoomFactor = Offsetss.Right / 1080f;
                Vector2 Alignment1 = @class.Get<Vector2>(Slot1 + LayoutData + Alignment);
                WorldMapPosition.x = (Offsetss.Right * (Alignment1.x - 0.5f) - Offsetss.Left) / 1080f / WorldMapZoomFactor * 2.0f;
                WorldMapPosition.y = (Offsetss.Bottom * (Alignment1.y - 0.5f) - Offsetss.Top) / 1080f / WorldMapZoomFactor * 2.0f;
            }
            else
            {
                Slot1 = @class.Get<ulong>(MapGrid + Slot);
            }
        }
        IsShow = @class.Get<int>(MapAddr + Visibility) == 4;
    }

    static Class11()
    {
        dictionary_物资 = new Dictionary<string, 物资info>();
        dictionary_3 = new Dictionary<string, PlayerInfo>();

        vector2_0 = new Vector2
        {
            x = 1920f,
            y = 1080f
        };
        vector2_1 = new Vector2
        {
            x = 1887f,
            y = 1054f
        };
        float_0 = 261f;
        float_1 = 461f;
        vector2_2 = new Vector2
        {
            x = vector2_1.x / vector2_0.x,
            y = vector2_1.y / vector2_0.y
        };
        vector2_3 = new Vector2
        {
            x = float_0 / vector2_0.x,
            y = float_0 / vector2_0.y
        };
        vector2_4 = new Vector2
        {
            x = vector2_2.x - vector2_3.x,
            y = vector2_2.y - vector2_3.y
        };
        vector2_5 = new Vector2
        {
            x = float_1 / vector2_0.x,
            y = float_1 / vector2_0.y
        };
        vector2_6 = new Vector2
        {
            x = vector2_2.x - vector2_5.x,
            y = vector2_2.y - vector2_5.y
        };
    }

    public void StopAll()
    {
        if (vmm != null)
        {
            vmm.Close();
        }

        ThreadRunning = false;
    }
}
