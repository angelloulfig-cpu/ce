﻿using PGE;
using PGE.Common;


namespace MultiThreadedOverlay
{
    using ImGuiNET;
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Numerics;
    using System.Reflection;

    [Obfuscation(Feature = "virtualization", Exclude = false)]
    public class EspOverlay
    {
        colDescription colDescription;
        public static uint Enemycolor = 0U;
        public static uint txtcolor = 0U;
        public bool Show = true;
        private List<Actor人物> espDataList = new List<Actor人物>();
        private List<玩家列表> esp玩家列表 = new List<玩家列表>();
        private List<Class4> esp载具list = new List<Class4>();
        private List<GameItems> esp物资List = new List<GameItems>();
        private List<Class4> esp投掷物 = new List<Class4>();
        public static ConcurrentQueue<List<玩家列表>> Esp玩家列表 = new ConcurrentQueue<List<玩家列表>>();
        public static ConcurrentQueue<List<Actor人物>> Esp人物Queue = new ConcurrentQueue<List<Actor人物>>();
        public static ConcurrentQueue<List<GameItems>> Esp物资Queue = new ConcurrentQueue<List<GameItems>>();
        public static ConcurrentQueue<List<Class4>> Esp载具Queue = new ConcurrentQueue<List<Class4>>();
        public static ConcurrentQueue<List<Class4>> ESP投掷物 = new ConcurrentQueue<List<Class4>>();
        float 血条长度 = 0;
        float 头到盆骨的距离 = 0f;
        float padding = 3;
        float barHeight = 3;
        float 血量 = 0f;
        float 骨骼粗细 = CommonProperty.espconfig.EspConfig.骨骼粗细;
        int 字体大小 = CommonProperty.espconfig.EspConfig.字体大小;
        int 物资字体大小 = CommonProperty.espconfig.EspConfig.物资字体大小;
        float 小地图大小 = CommonProperty.espconfig.EspConfig.小地图大小;
        float 大地图大小 = CommonProperty.espconfig.EspConfig.大地图大小;
        int 透视距离 = CommonProperty.espconfig.EspConfig.透视距离;
        int 手持距离 = CommonProperty.espconfig.EspConfig.手持距离;
        int 帧延迟 = CommonProperty.espconfig.EspConfig.帧延迟;
        int 物资距离 = CommonProperty.espconfig.EspConfig.物资距离;
        int 载具距离 = CommonProperty.espconfig.EspConfig.载具距离;
        int 刷新1 = CommonProperty.刷新1;
        int 刷新2 = CommonProperty.刷新2;
        bool 融合器模式 = CommonProperty.espconfig.EspConfig.融合器模式;
        bool 载具 = CommonProperty.espconfig.EspConfig.透视载具;
        bool 盒子 = CommonProperty.espconfig.EspConfig.骨灰盒;
        bool 空投 = CommonProperty.espconfig.EspConfig.空投;
        bool 大地图载具 = CommonProperty.espconfig.EspConfig.大地图载具;
        bool 物资 = CommonProperty.espconfig.EspConfig.透视物资;
        bool 被瞄射线 = CommonProperty.espconfig.EspConfig.射线;
        bool 血条开关 = CommonProperty.espconfig.EspConfig.血条;
        bool ID = CommonProperty.espconfig.EspConfig.ID;
        bool 等级 = CommonProperty.espconfig.EspConfig.等级;
        bool 编号 = CommonProperty.espconfig.EspConfig.队伍;
        bool 观战 = CommonProperty.espconfig.EspConfig.观战;
        bool 杀敌 = CommonProperty.espconfig.EspConfig.杀敌;
        bool 距离 = CommonProperty.espconfig.EspConfig.距离;
        bool 小地图透视 = CommonProperty.espconfig.EspConfig.小地图;
        bool 大地图透视 = CommonProperty.espconfig.EspConfig.大地图;
        bool 粗字体 = CommonProperty.espconfig.EspConfig.粗字体;
        bool 黑背景 = CommonProperty.espconfig.EspConfig.融合器黑背景填充;
        bool 串流透视 = CommonProperty.espconfig.EspConfig.串流透视;
        bool fov = CommonProperty.espconfig.EspConfig.FOV;
        bool 资源 = CommonProperty.战斗模式;
        bool 手持 = CommonProperty.espconfig.EspConfig.手持;
        bool KD = CommonProperty.espconfig.EspConfig.KD;
        bool 段位 = CommonProperty.espconfig.EspConfig.段位;
        bool 投掷物 = CommonProperty.espconfig.EspConfig.投掷物;
        bool 骨骼 = CommonProperty.espconfig.EspConfig.骨骼;
        bool 玩家列表 = CommonProperty.espconfig.EspConfig.玩家列表;
        bool 预警 = CommonProperty.espconfig.EspConfig.预警;
        bool 提前量 = CommonProperty.espconfig.EspConfig.提前量;
        int erbaimi = 0;
        int erbaimi1 = 0;


        private Dictionary<string, (IntPtr Handle, uint Width, uint Height)> loadedTexturesPtrs;

        Vector3 col手持 = new Vector3(CommonProperty.espconfig.EspConfig.手持颜色.x, CommonProperty.espconfig.EspConfig.手持颜色.y, CommonProperty.espconfig.EspConfig.手持颜色.z);

        Vector3 col队伍 = new Vector3(CommonProperty.espconfig.EspConfig.队伍编号.x, CommonProperty.espconfig.EspConfig.队伍编号.y, CommonProperty.espconfig.EspConfig.队伍编号.z);
        Vector3 col倒地 = new Vector3(CommonProperty.espconfig.EspConfig.倒地.x, CommonProperty.espconfig.EspConfig.倒地.y, CommonProperty.espconfig.EspConfig.倒地.z);
        Vector3 col可视 = new Vector3(CommonProperty.espconfig.EspConfig.可视.x, CommonProperty.espconfig.EspConfig.可视.y, CommonProperty.espconfig.EspConfig.可视.z);
        Vector3 col不可视 = new Vector3(CommonProperty.espconfig.EspConfig.不可视.x, CommonProperty.espconfig.EspConfig.不可视.y, CommonProperty.espconfig.EspConfig.不可视.z);
        Vector3 col危险 = new Vector3(CommonProperty.espconfig.EspConfig.危险.x, CommonProperty.espconfig.EspConfig.危险.y, CommonProperty.espconfig.EspConfig.危险.z);
        Vector3 col人机 = new Vector3(CommonProperty.espconfig.EspConfig.人机.x, CommonProperty.espconfig.EspConfig.人机.y, CommonProperty.espconfig.EspConfig.人机.z);
        Vector3 col合作者 = new Vector3(CommonProperty.espconfig.EspConfig.合作者.x, CommonProperty.espconfig.EspConfig.合作者.y, CommonProperty.espconfig.EspConfig.合作者.z);
        Vector3 col字体 = new Vector3(CommonProperty.espconfig.EspConfig.字体.x, CommonProperty.espconfig.EspConfig.字体.y, CommonProperty.espconfig.EspConfig.字体.z);
        Vector3 colA物资 = new Vector3(CommonProperty.espconfig.EspConfig.A物资.x, CommonProperty.espconfig.EspConfig.A物资.y, CommonProperty.espconfig.EspConfig.A物资.z);
        Vector3 colB物资 = new Vector3(CommonProperty.espconfig.EspConfig.B物资.x, CommonProperty.espconfig.EspConfig.B物资.y, CommonProperty.espconfig.EspConfig.B物资.z);
        Vector3 colC物资 = new Vector3(CommonProperty.espconfig.EspConfig.C物资.x, CommonProperty.espconfig.EspConfig.C物资.y, CommonProperty.espconfig.EspConfig.C物资.z);
        Vector3 colD物资 = new Vector3(CommonProperty.espconfig.EspConfig.D物资.x, CommonProperty.espconfig.EspConfig.D物资.y, CommonProperty.espconfig.EspConfig.D物资.z);
        Vector3 col载具 = new Vector3(CommonProperty.espconfig.EspConfig.col载具.x, CommonProperty.espconfig.EspConfig.col载具.y, CommonProperty.espconfig.EspConfig.col载具.z);
        Vector3 col投掷物 = new Vector3(CommonProperty.espconfig.EspConfig.col投掷物.x, CommonProperty.espconfig.EspConfig.col投掷物.y, CommonProperty.espconfig.EspConfig.col投掷物.z);

        public void Update()
        {
            if (!Show)
            {
                return;
            }
            CommonProperty.EspResetEventSlim.WaitOne();
            colDescription = new colDescription();
            Esp玩家列表.TryDequeue(out var result5);
            Esp人物Queue.TryDequeue(out var result);
            ESP投掷物.TryDequeue(out var result2);
            Esp载具Queue.TryDequeue(out var result3);
            Esp物资Queue.TryDequeue(out var result4);

            if (result != null)
            {
                espDataList = result;
            }
            if (result2 != null)
            {
                esp投掷物 = result2;
            }
            if (result3 != null)
            {
                esp载具list = result3;
            }
            if (result4 != null)
            {
                esp物资List = result4;
            }
            if (result5 != null)
            {
                esp玩家列表 = result5;
            }
        }
        private PGE.Vector2 GetFov(PGE.Vector2 pos, float angle, float len)
        {
            float rad = (float)(angle * Math.PI / 180);
            return new PGE.Vector2
            {
                x = (float)(pos.x + Math.Cos(rad) * len),
                y = (float)(pos.y + Math.Sin(rad) * len)
            };
        }

        public static void 投掷物Clear()
        {
            ESP投掷物.Clear();
            ESP投掷物.Enqueue(new List<Class4>());
            CommonProperty.Esp投掷物.Set();
        }
        public static void 载具Clear()
        {
            Esp载具Queue.Clear();
            Esp载具Queue.Enqueue(new List<Class4>());
            CommonProperty.EspVehicleResetEventSlim.Set();
        }
        public static void 物资Clear()
        {
            Esp物资Queue.Clear();
            Esp物资Queue.Enqueue(new List<GameItems>());
            CommonProperty.EspGameItemResetEventSlim.Set();
        }
        public static void 人物Clear()
        {
            Esp人物Queue.Clear();
            Esp人物Queue.Enqueue(new List<Actor人物>());
            CommonProperty.EspResetEventSlim.Set();
        }

        public static void 人物Clear1()
        {
            Esp玩家列表.Clear();
            Esp玩家列表.Enqueue(new List<玩家列表>());
            CommonProperty.EspResetEventSlim.Set();
        }

        public void 人物透视()
        {

            ImGui.SetNextWindowContentSize(ImGui.GetIO().DisplaySize);
            ImGui.SetNextWindowPos(new Vector2(0, 0));
            ImGui.Begin(
                "Background Screen",
                ref Show,
                ImGuiWindowFlags.NoInputs |
                ImGuiWindowFlags.NoBackground |
                ImGuiWindowFlags.NoBringToFrontOnFocus |
                ImGuiWindowFlags.NoCollapse |
                ImGuiWindowFlags.NoMove |
                ImGuiWindowFlags.NoScrollbar |
                ImGuiWindowFlags.NoSavedSettings |
                ImGuiWindowFlags.NoResize |
                ImGuiWindowFlags.NoTitleBar
                );
            var windowPtr = ImGui.GetWindowDrawList();

            try
            {
                erbaimi = 0;
                erbaimi1 = 0;
                foreach (var espData in espDataList)
                {
                    if (espData.距离 <= 200 && espData.距离 != 0)
                    {
                        erbaimi += 1;
                    }
                    if (espData.被瞄准 == 1)
                    {
                        erbaimi1 += 1;
                    }
                    espData.人物杀敌 = ((espData.人物杀敌 >= 99u) ? (espData.人物杀敌 - 99u) : espData.人物杀敌);

                    windowPtr.AddCircleFilled(
                        new Vector2(CommonProperty.预瞄点.x, CommonProperty.预瞄点.y),
                        4, ImGui.GetColorU32(new Vector4(0f, 1f, 0f, 0.1f)));


                    if (小地图透视 && espData.vector3_小地图.x > 0 && espData.vector3_小地图.x < CommonProperty.X分辨率 && espData.vector3_小地图.y > 0 && espData.vector3_小地图.y < CommonProperty.Y分辨率)
                    {
                        var fov = GetFov(espData.vector3_小地图, espData.人物方向.y, 5 + 小地图大小);
                        windowPtr.AddLine(
                            new Vector2(espData.vector3_小地图.x, espData.vector3_小地图.y),
                            new Vector2(fov.x, fov.y),
                            ImGui.GetColorU32(new Vector4(255, 255, 255, 1f)), 0.4f * 小地图大小);

                        windowPtr.AddCircleFilled(
                            new Vector2(espData.vector3_小地图.x, espData.vector3_小地图.y),
                            小地图大小, ImGui.GetColorU32(colDescription.GetCodeDescription((espData.TeamID > 100) ? 7 : espData.TeamID)));
                    }
                    if (大地图透视 && espData.vector3_大地图.x > 0 && espData.vector3_大地图.x < CommonProperty.X分辨率 && espData.vector3_大地图.y > 0 && espData.vector3_大地图.y < CommonProperty.Y分辨率 && CommonProperty.IsShow)
                    {
                        var fov = GetFov(espData.vector3_大地图, espData.人物方向.y, 4 + 大地图大小);
                        windowPtr.AddLine(
                            new Vector2(espData.vector3_大地图.x, espData.vector3_大地图.y),
                            new Vector2(fov.x, fov.y),
                            ImGui.GetColorU32(new Vector4(255, 255, 255, 1f)), 0.3f * 大地图大小);

                        windowPtr.AddCircleFilled(
                            new Vector2(espData.vector3_大地图.x, espData.vector3_大地图.y),
                            大地图大小, ImGui.GetColorU32(colDescription.GetCodeDescription((espData.TeamID > 100) ? 7 : espData.TeamID)));

                        string text2 = $"{espData.TeamID}";
                        int len3 = (text2.Length);
                        windowPtr.AddText(ImGui.GetFont(), 15, new Vector2
                            (espData.vector3_大地图.x - len3 * 3.2f,
                            espData.vector3_大地图.y - 8),
                            ImGui.GetColorU32(new Vector4(255, 255, 255, 1f)),
                            text2
                            );
                    }
                    if (!(espData.中心.x < 0f) && !(espData.中心.y < 0f) && !(espData.中心.x > CommonProperty.X分辨率) && !(espData.中心.y > CommonProperty.Y分辨率) && espData.距离 < 透视距离)
                    {
                        //绘制骨骼
                        if (CommonProperty.espconfig.EspConfig.骨骼)
                        {
                            //骨骼颜色
                            if (espData.是否可视 == 1)
                            {
                                if (espData.人物血量 > 0u)
                                {
                                    Enemycolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.可视.x, CommonProperty.espconfig.EspConfig.可视.y, CommonProperty.espconfig.EspConfig.可视.z, 1f));
                                    if (espData.人物杀敌 >= 4 || espData.观战人数 >= 3)
                                    {
                                        Enemycolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.危险.x, CommonProperty.espconfig.EspConfig.危险.y, CommonProperty.espconfig.EspConfig.危险.z, 1f));
                                    }
                                    if (espData.合作者 != 0)
                                    {
                                        Enemycolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.合作者.x, CommonProperty.espconfig.EspConfig.合作者.y, CommonProperty.espconfig.EspConfig.合作者.z, 1f));
                                    }
                                    if (CommonProperty.Hash_黑名单.Contains(espData.name))
                                    {
                                        Enemycolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.人机.x, CommonProperty.espconfig.EspConfig.人机.y, CommonProperty.espconfig.EspConfig.人机.z, 1f));
                                    }
                                    if (espData.人机 != 0)
                                    {
                                        Enemycolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.人机.x, CommonProperty.espconfig.EspConfig.人机.y, CommonProperty.espconfig.EspConfig.人机.z, 1f));
                                    }
                                }
                                else if (espData.倒地血量 > 0u)
                                {
                                    Enemycolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.倒地.x, CommonProperty.espconfig.EspConfig.倒地.y, CommonProperty.espconfig.EspConfig.倒地.z, 1f));
                                }
                            }
                            else
                            {
                                Enemycolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.不可视.x, CommonProperty.espconfig.EspConfig.不可视.y, CommonProperty.espconfig.EspConfig.不可视.z, 1f));
                            }

                            //画骨骼

                            windowPtr.AddLine(
                            new Vector2(espData.颈部.x, espData.颈部.y),
                            new Vector2(espData.胸部.x, espData.胸部.y),
                            Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.胸部.x, espData.胸部.y),
                                new Vector2(espData.骨盆.x, espData.骨盆.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.颈部.x, espData.颈部.y),
                                new Vector2(espData.左肩.x, espData.左肩.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.颈部.x, espData.颈部.y),
                                new Vector2(espData.右肩.x, espData.右肩.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.左肩.x, espData.左肩.y),
                                new Vector2(espData.左肘.x, espData.左肘.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.右肩.x, espData.右肩.y),
                                new Vector2(espData.右肘.x, espData.右肘.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.右肘.x, espData.右肘.y),
                                new Vector2(espData.右手.x, espData.右手.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.左肘.x, espData.左肘.y),
                                new Vector2(espData.左手.x, espData.左手.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.骨盆.x, espData.骨盆.y),
                                new Vector2(espData.左胯.x, espData.左胯.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.骨盆.x, espData.骨盆.y),
                                new Vector2(espData.右胯.x, espData.右胯.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.左胯.x, espData.左胯.y),
                                new Vector2(espData.左膝.x, espData.左膝.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.右胯.x, espData.右胯.y),
                                new Vector2(espData.右膝.x, espData.右膝.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.左膝.x, espData.左膝.y),
                                new Vector2(espData.左脚跟.x, espData.左脚跟.y),
                                Enemycolor, 骨骼粗细);

                            windowPtr.AddLine(
                                new Vector2(espData.右膝.x, espData.右膝.y),
                                new Vector2(espData.右脚跟.x, espData.右脚跟.y),
                                Enemycolor, 骨骼粗细);
                        }

                        //人物顶部绘制
                        //血条位置
                        头到盆骨的距离 = (espData.骨盆.y - espData.头部.y);
                        血条长度 = ((espData.中心.y + 头到盆骨的距离) - espData.中心.y - 头到盆骨的距离 / 2.4f);

                        if (血条长度 < 30)
                        {
                            血条长度 = 30;
                        }
                        if (血条长度 > 160)
                        {
                            血条长度 = 160;
                        }
                        var bloodBarBgRect = new Vector2();
                        Vector2 血条坐标 = new Vector2();

                        bloodBarBgRect = new Vector2
                            (espData.中心.x - (血条长度 / 2.3f),
                            espData.骨盆.y - (((espData.骨盆.y - espData.头部.y) < 4 ? 4 : (espData.骨盆.y - espData.头部.y)) > 250 ? 250 : ((espData.骨盆.y - espData.头部.y) < 4 ? 4 : (espData.骨盆.y - espData.头部.y))) * 1.4f);

                        血条坐标 = new Vector2(bloodBarBgRect.X, (bloodBarBgRect.Y < 10 ? 10 : bloodBarBgRect.Y));

                        //血条位置

                        //绘制血条
                        if (血条开关)
                        {
                            uint 血量颜色 = 0;
                            血量 = (espData.人物血量 == 0 ? espData.倒地血量 : espData.人物血量) / 100;

                            if (espData.人物血量 > 0)
                            {
                                血量 = (espData.人物血量) / 100f;
                                血量颜色 = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.队伍编号.x, CommonProperty.espconfig.EspConfig.队伍编号.y, CommonProperty.espconfig.EspConfig.队伍编号.z, 1f));
                            }
                            else if (espData.倒地血量 > 0)
                            {
                                血量 = (espData.倒地血量) / 100f;
                                血量颜色 = ImGui.GetColorU32(new Vector4(255.0f, 0.0f, 0.0f, 1f));
                            }

                            windowPtr.AddRectFilledMultiColor(
                                血条坐标 + new Vector2(padding, padding),
                                血条坐标 + new Vector2(血条长度, barHeight - padding),
                                ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                                ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                                ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                                ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f))
                                );
                            windowPtr.AddRectFilledMultiColor(
                                血条坐标 + new Vector2(padding, padding),
                                血条坐标 + new Vector2(血条长度 * 血量, barHeight - padding),
                                血量颜色,
                                血量颜色,
                                血量颜色,
                                血量颜色
                            );
                        }
                        //字体颜色
                        if (espData.人物血量 > 0u)
                        {
                            if (espData.合作者 != 0)
                            {
                                txtcolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.合作者.x, CommonProperty.espconfig.EspConfig.合作者.y, CommonProperty.espconfig.EspConfig.合作者.z, 1f));
                            }
                            else if (espData.人机 == 1)
                            {
                                txtcolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.人机.x, CommonProperty.espconfig.EspConfig.人机.y, CommonProperty.espconfig.EspConfig.人机.z, 1f));
                            }
                            else if (CommonProperty.Hash_黑名单.Contains(espData.name))
                            {
                                txtcolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.人机.x, CommonProperty.espconfig.EspConfig.人机.y, CommonProperty.espconfig.EspConfig.人机.z, 1f));

                            }
                            else if (espData.人物杀敌 >= 4 || espData.观战人数 >= 3)
                            {
                                txtcolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.危险.x, CommonProperty.espconfig.EspConfig.危险.y, CommonProperty.espconfig.EspConfig.危险.z, 1f));
                            }
                            else
                            {
                                txtcolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.字体.x, CommonProperty.espconfig.EspConfig.字体.y, CommonProperty.espconfig.EspConfig.字体.z, 1f));
                            }
                        }
                        else if (espData.倒地血量 > 0u)
                        {
                            txtcolor = ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.倒地.x, CommonProperty.espconfig.EspConfig.倒地.y, CommonProperty.espconfig.EspConfig.倒地.z, 1f));
                        }
                        //手持
                        if (手持)
                        {
                            int num1;
                            if (ID || 等级 || (段位 && espData.段位 != "") || (KD && espData.KD != ""))
                            {
                                num1 = 字体大小 * 2;
                            }
                            else
                            {
                                num1 = 字体大小;
                            }

                            string text = "";

                            if (espData.武器类型 == 0)
                            {
                                text = $"[步枪]" + text;
                            }
                            else if (espData.武器类型 == 1)
                            {
                                text = $"[连狙]" + text;
                            }
                            else if (espData.武器类型 == 2)
                            {
                                text = $"[拴狙]" + text;
                            }
                            else if (espData.武器类型 == 3)
                            {
                                text = $"[散弹]" + text;
                            }
                            else if (espData.武器类型 == 4)
                            {
                                text = $"[其它]" + text;
                            }
                            else if (espData.武器类型 == 5)
                            {
                                text = $"[雷]" + text;
                            }
                            else if (espData.武器类型 == 7)
                            {
                                text = $"[闪]" + text;
                            }
                            else
                            {
                                text = "";
                            }
                            int len2 = text.Length * 字体大小;
                            windowPtr.AddText(ImGui.GetFont(), 字体大小, new Vector2
                                (espData.中心.x - len2 / 5,
                                bloodBarBgRect.Y - num1),
                                ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.手持颜色.x, CommonProperty.espconfig.EspConfig.手持颜色.y, CommonProperty.espconfig.EspConfig.手持颜色.z, 1f)),
                                text
                                );

                        }
                        //绘制ID
                        if (ID || 等级 || 段位 || KD)
                        {
                            string text = "";
                            if (ID)
                            {
                                text += $"{espData.name[..(espData.name.Length > 7 ? 7 : espData.name.Length)]}";
                            }
                            if (等级)
                            {
                                text += $"[{espData.等级}]";
                            }
                            if (段位 && espData.段位 != "")
                            {
                                text = $"[{espData.段位}]" + text;
                            }
                            if (KD && espData.KD != "")
                            {
                                text += $"[{espData.KD}]";
                            }
                            int len2 = (text.Length * 字体大小);

                            windowPtr.AddText(ImGui.GetFont(), 字体大小, new Vector2
                                (espData.中心.x - len2 / 5,
                                bloodBarBgRect.Y - 字体大小 - 2),
                                txtcolor,
                                text
                                );
                        }
                        //绘制队伍编号
                        if (编号)
                        {
                            string text2 = $"{espData.TeamID}";
                            int len3 = (text2.Length * 字体大小);

                            windowPtr.AddText(ImGui.GetFont(), 字体大小, new Vector2
                            (bloodBarBgRect.X - len3 / 2 - 1,
                            bloodBarBgRect.Y - 字体大小 / 2 + 1),
                            ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.队伍编号.x, CommonProperty.espconfig.EspConfig.队伍编号.y, CommonProperty.espconfig.EspConfig.队伍编号.z, 1f)),
                            text2
                            );
                        }
                        //人物底部绘制
                        if (距离 || 观战 || 杀敌)
                        {
                            string text3 = "";
                            if (距离 && espData.距离 > 0)
                            {
                                text3 += $"[{espData.距离}M]";
                            }
                            if (观战 && espData.观战人数 > 0)
                            {
                                text3 += $" 观{espData.观战人数}";
                            }
                            if (杀敌 && espData.人物杀敌 > 0)
                            {
                                text3 = $"{espData.人物杀敌}杀 " + text3;
                            }
                            int len2 = (text3.Length * 字体大小);

                            windowPtr.AddText(ImGui.GetFont(), 字体大小,
                                new Vector2
                                (espData.中心.x - len2 / 5,
                                espData.中心.y + 1),
                                txtcolor,
                                text3
                                );

                        }

                        if (被瞄射线 && espData.是否可视 == 1 && espData.被瞄准 == 1)
                        {
                            windowPtr.AddLine(
                                new Vector2(espData.头部.x, espData.头部.y),
                                new Vector2((float)CommonProperty.X分辨率 / 2, (float)CommonProperty.Y分辨率 / 2),
                                Enemycolor, 骨骼粗细);
                        }
                    }
                }
            }
            catch (Exception) { }
        }
        public void 资源透视()
        {
            ImGui.SetNextWindowContentSize(ImGui.GetIO().DisplaySize);
            ImGui.SetNextWindowPos(new Vector2(0, 0));
            ImGui.Begin(
                "Background Screen",
                ref Show,
                ImGuiWindowFlags.NoInputs |
                ImGuiWindowFlags.NoBackground |
                ImGuiWindowFlags.NoBringToFrontOnFocus |
                ImGuiWindowFlags.NoCollapse |
                ImGuiWindowFlags.NoMove |
                ImGuiWindowFlags.NoScrollbar |
                ImGuiWindowFlags.NoSavedSettings |
                ImGuiWindowFlags.NoResize |
                ImGuiWindowFlags.NoTitleBar
                );

            var windowPtr = ImGui.GetWindowDrawList();
            try
            {
                if (黑背景)
                {
                    var bgPrt = ImGui.GetBackgroundDrawList();
                    bgPrt.AddRectFilled(new Vector2(0, 0), new Vector2(ImGui.GetIO().DisplaySize.X, ImGui.GetIO().DisplaySize.Y), ImGui.GetColorU32(new Vector4(0, 0, 0, 1)));
                }
                string zmpg = "";
                if (CommonProperty.espconfig.EspConfig.自瞄配置2 == true)
                {
                    zmpg = "2";
                }
                else
                {
                    zmpg = "1";
                }
                string 资源透视txt;
                string wzfz = "";
                string 战斗模式 = "";
                if (CommonProperty.战斗模式)
                {
                    战斗模式 = "关";
                }
                else
                {
                    战斗模式 = "开";
                }
                if (CommonProperty.物资A)
                {
                    wzfz += "A";
                }
                if (CommonProperty.物资B)
                {
                    wzfz += "B";
                }
                if (CommonProperty.物资C)
                {
                    wzfz += "C";
                }
                if (CommonProperty.物资D)
                {
                    wzfz += "D";
                }
                if (wzfz != "")
                {
                    资源透视txt = $"战斗模式: {战斗模式} | [{wzfz}]";
                }
                else
                {
                    资源透视txt = $"战斗模式: {战斗模式}";
                }

                windowPtr.AddText(ImGui.GetFont(), 20, new Vector2(20, 20),
                    ImGui.GetColorU32(new Vector4(1, 1, 1, 1f)),
                    ($"RAIN  {Math.Round(ImGui.GetIO().Framerate, 2)}"));
                windowPtr.AddText(ImGui.GetFont(), 20, new Vector2(20, 38),
                    ImGui.GetColorU32(new Vector4(1, 1, 1, 1f)),
                    资源透视txt);
                windowPtr.AddText(ImGui.GetFont(), 20, new Vector2(20, 56),
                    ImGui.GetColorU32(new Vector4(1, 1, 1, 1f)),
                    ($"自瞄配置: {zmpg}"));

                if (CommonProperty.本人观战人数 > 0)
                {
                    windowPtr.AddText(ImGui.GetFont(), 20, new Vector2(20, 75),
                        ImGui.GetColorU32(new Vector4(0f, 255f, 0f, 1f)),
                        ($"观战: {CommonProperty.本人观战人数}"));
                }

                if (CommonProperty.手雷倒计时 < 4.99 && CommonProperty.手雷倒计时 > 0)
                {
                    uint healthcol = ImGui.GetColorU32(new Vector4(0.0f, 255.0f, 0.0f, 1f));
                    uint healthcol2 = ImGui.GetColorU32(new Vector4(255f, 255.0f, 255f, 1f));

                    windowPtr.AddText(ImGui.GetFont(), 21, new Vector2(CommonProperty.X分辨率 / 2 - 12, CommonProperty.Y分辨率 / 2 - 58),
                        healthcol2,
                        ($"{Math.Round(CommonProperty.手雷倒计时, 1)}"));
                    血量 = (CommonProperty.手雷倒计时);
                    if (CommonProperty.手雷倒计时 > 0)
                    {
                        血量 = (CommonProperty.手雷倒计时);
                        Vector2 position = new Vector2(CommonProperty.X分辨率 / 2 - 41.5f, CommonProperty.Y分辨率 / 2 - 70);
                        windowPtr.AddRectFilledMultiColor(
                        position + new Vector2(padding, padding),
                        position + new Vector2((80 + padding), 10 - padding),
                        ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                        ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                        ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                        ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f))
                        );
                        windowPtr.AddRectFilledMultiColor(
                        position + new Vector2(padding, padding),
                        position + new Vector2(16.32f * 血量 + padding, 10 - padding),
                        healthcol,
                        healthcol,
                        healthcol,
                        healthcol
                        );
                    }
                }

                if (CommonProperty.espconfig.EspConfig.投掷物)
                {
                    foreach (var item in esp投掷物)
                    {
                        if (!(item.透视坐标.x < 0) && !(item.透视坐标.y < 0) && !(item.透视坐标.x > CommonProperty.X分辨率) && !(item.透视坐标.y > CommonProperty.Y分辨率))
                        {
                            windowPtr.AddText(ImGui.GetFont(), 字体大小, new Vector2(item.透视坐标.x - 字体大小 * 0.4f, item.透视坐标.y - 字体大小 * 0.4f), ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.col投掷物.x, CommonProperty.espconfig.EspConfig.col投掷物.y, CommonProperty.espconfig.EspConfig.col投掷物.z, 1f)), $"{item.ShortName}");
                        }
                        uint healthcol = 0;
                        血量 = (item.时间);
                        if (item.时间 > 0 && item.时间 < 4.8)
                        {
                            血量 = (item.时间);
                            healthcol = ImGui.GetColorU32(new Vector4(0.0f, 255.0f, 0.0f, 1f));
                            Vector2 position = new Vector2(item.透视坐标.x - 22f, item.透视坐标.y + 字体大小 * 1.1f);
                            windowPtr.AddRectFilledMultiColor(
                            position + new Vector2(padding, padding),
                            position + new Vector2((37 + padding), barHeight - padding),
                            ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                            ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                            ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f)),
                            ImGui.GetColorU32(new Vector4(255, 255, 255, 0.5f))
                            );
                            windowPtr.AddRectFilledMultiColor(
                            position + new Vector2(padding, padding),
                            position + new Vector2(8 * 血量 + padding, barHeight - padding),
                            healthcol,
                            healthcol,
                            healthcol,
                            healthcol
                            );
                        }

                    }

                }

                //自瞄fov
                if (fov && CommonProperty.fov > 0)
                {
                    windowPtr.AddCircle(new Vector2(CommonProperty.X分辨率 / 2, CommonProperty.Y分辨率 / 2), CommonProperty.fov, (uint)(((255 << 24) | (255 << 16) | (255 << 8) | 255) & 0xffffffffL), 0, 1);
                }

                //载具透视
                if (esp载具list.Count > 0)
                {
                    foreach (var item in esp载具list)
                    {
                        if (!(item.透视坐标.x < 0) && !(item.透视坐标.y < 0) && !(item.透视坐标.x > CommonProperty.X分辨率) && !(item.透视坐标.y > CommonProperty.Y分辨率))
                        {
                            if (CommonProperty.espconfig.EspConfig.透视载具 && item.种类 == "载具")
                            {
                                windowPtr.AddText(ImGui.GetFont(), 物资字体大小, new Vector2(item.透视坐标.x, item.透视坐标.y), ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.col载具.x, CommonProperty.espconfig.EspConfig.col载具.y, CommonProperty.espconfig.EspConfig.col载具.z, 1f)), $"{item.ShortName}[{item.距离}]");
                            }
                            if (item.种类 == "盒子")
                            {
                                if (!(item.name == "DeathDropItemPackage_C") && CommonProperty.espconfig.EspConfig.空投)
                                {
                                    windowPtr.AddText(ImGui.GetFont(), 物资字体大小, new Vector2(item.透视坐标.x, item.透视坐标.y), ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.col载具.x, CommonProperty.espconfig.EspConfig.col载具.y, CommonProperty.espconfig.EspConfig.col载具.z, 1f)), $"空投箱[{item.距离}]");
                                }
                                else if (item.距离 < 50 && CommonProperty.espconfig.EspConfig.骨灰盒)
                                {
                                    windowPtr.AddText(ImGui.GetFont(), 物资字体大小, new Vector2(item.透视坐标.x, item.透视坐标.y), ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.col载具.x, CommonProperty.espconfig.EspConfig.col载具.y, CommonProperty.espconfig.EspConfig.col载具.z, 1f)), $"骨灰盒[{item.距离}]");
                                }
                            }
                        }
                        if (item.vector3_大地图.x > 0 && item.vector3_大地图.x < CommonProperty.X分辨率 && item.vector3_大地图.y > 0 && item.vector3_大地图.y < CommonProperty.Y分辨率)
                        {
                            if (大地图载具 && item.种类 == "载具")
                            {
                                string text2 = $"{item.ShortName}";
                                int len3 = (text2.Length);
                                windowPtr.AddText(ImGui.GetFont(), 8 + 大地图大小, new Vector2
                                    (item.vector3_大地图.x - len3 * 3.2f,
                                    item.vector3_大地图.y - 11),
                                    ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.col载具.x, CommonProperty.espconfig.EspConfig.col载具.y, CommonProperty.espconfig.EspConfig.col载具.z, 1f)),
                                    text2
                                    );
                            }
                            if (item.种类 == "盒子" && !(item.name == "DeathDropItemPackage_C"))
                            {
                                windowPtr.AddRectFilled(
                                    new Vector2(item.vector3_大地图.x - 11, item.vector3_大地图.y - 7),
                                    new Vector2(item.vector3_大地图.x + 11, item.vector3_大地图.y + 7), ImGui.GetColorU32(new Vector4(1, 0f, 0f, 0.5f)));
                                string text2 = $"空投";
                                int len3 = (text2.Length);
                                windowPtr.AddText(ImGui.GetFont(), 8 + 大地图大小, new Vector2
                                    (item.vector3_大地图.x - 11,
                                    item.vector3_大地图.y - 8.5f),
                                    ImGui.GetColorU32(new Vector4(1, 1, 1, 1f)),
                                    text2
                                    );
                            }
                        }
                    }
                }
                //物资透视
                if (CommonProperty.espconfig.EspConfig.透视物资 && esp物资List.Count > 0)
                {
                    foreach (var item in esp物资List)
                    {
                        if (item.group == 0)
                        {
                            windowPtr.AddText(ImGui.GetFont(), 物资字体大小, new Vector2(item.透视坐标.x, item.透视坐标.y), ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.A物资.x, CommonProperty.espconfig.EspConfig.A物资.y, CommonProperty.espconfig.EspConfig.A物资.z, 1f)), $"{item.ShortName}[{item.距离}]");
                        }
                        if (item.group == 1)
                        {
                            windowPtr.AddText(ImGui.GetFont(), 物资字体大小, new Vector2(item.透视坐标.x, item.透视坐标.y), ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.B物资.x, CommonProperty.espconfig.EspConfig.B物资.y, CommonProperty.espconfig.EspConfig.B物资.z, 1f)), $"{item.ShortName}[{item.距离}]");
                        }
                        if (item.group == 2)
                        {
                            windowPtr.AddText(ImGui.GetFont(), 物资字体大小, new Vector2(item.透视坐标.x, item.透视坐标.y), ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.C物资.x, CommonProperty.espconfig.EspConfig.C物资.y, CommonProperty.espconfig.EspConfig.C物资.z, 1f)), $"{item.ShortName}[{item.距离}]");
                        }
                        if (item.group == 3)
                        {
                            windowPtr.AddText(ImGui.GetFont(), 物资字体大小, new Vector2(item.透视坐标.x, item.透视坐标.y), ImGui.GetColorU32(new Vector4(CommonProperty.espconfig.EspConfig.D物资.x, CommonProperty.espconfig.EspConfig.D物资.y, CommonProperty.espconfig.EspConfig.D物资.z, 1f)), $"{item.ShortName}[{item.距离}]");
                        }
                    }
                }

                if (CommonProperty.espconfig.EspConfig.预警)
                {
                    windowPtr.AddRectFilled(
                        new Vector2(CommonProperty.X分辨率 / 2 - 165, CommonProperty.Y分辨率 - 25),
                        new Vector2(CommonProperty.X分辨率 / 2 + 165, CommonProperty.Y分辨率 - 25 + 30), ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 0.5f)));

                    windowPtr.AddText(ImGui.GetFont(), 20, new Vector2(CommonProperty.X分辨率 / 2 - 150, CommonProperty.Y分辨率 - 28),
                        ImGui.GetColorU32(new Vector4(255f, 255f, 0f, 1f)),
                        ($"附近有: {erbaimi} 个敌人  |  {erbaimi1}人正在瞄准你  |  迷雾人数: {CommonProperty.迷雾人数}"));
                }
            }
            catch { }
            //融合器黑背景

        }

        public void 菜单()
        {
            ImGui.SetNextWindowSize(new Vector2(550, 650));
            ImGui.SetNextWindowPos(new Vector2(20, 110));
            ImGui.Begin("RAIN(HOME)",
                ImGuiWindowFlags.NoResize |
                ImGuiWindowFlags.NoBackground);

            if (ImGui.Button("保存配置"))
            {
                CommonProperty.刷新1 = 刷新1;
                CommonProperty.刷新2 = 刷新2;
                CommonProperty.espconfig.EspConfig.玩家列表 = 玩家列表;
                CommonProperty.espconfig.EspConfig.物资字体大小 = 物资字体大小;
                CommonProperty.espconfig.EspConfig.串流透视 = 串流透视;
                CommonProperty.espconfig.EspConfig.大地图大小 = 大地图大小;
                CommonProperty.espconfig.EspConfig.小地图大小 = 小地图大小;
                CommonProperty.espconfig.EspConfig.大地图载具 = 大地图载具;
                CommonProperty.espconfig.EspConfig.粗字体 = 粗字体;
                CommonProperty.espconfig.EspConfig.投掷物 = 投掷物;
                CommonProperty.espconfig.EspConfig.透视距离 = 透视距离;
                CommonProperty.espconfig.EspConfig.手持距离 = 手持距离;
                CommonProperty.espconfig.EspConfig.物资距离 = 物资距离;
                CommonProperty.espconfig.EspConfig.载具距离 = 载具距离;
                CommonProperty.espconfig.EspConfig.帧延迟 = 帧延迟;
                CommonProperty.espconfig.EspConfig.射线 = 被瞄射线;
                CommonProperty.espconfig.EspConfig.血条 = 血条开关;
                CommonProperty.espconfig.EspConfig.ID = ID;
                CommonProperty.espconfig.EspConfig.队伍 = 编号;
                CommonProperty.espconfig.EspConfig.距离 = 距离;
                CommonProperty.espconfig.EspConfig.骨骼粗细 = 骨骼粗细;
                CommonProperty.espconfig.EspConfig.字体大小 = 字体大小;
                CommonProperty.espconfig.EspConfig.融合器黑背景填充 = 黑背景;
                CommonProperty.espconfig.EspConfig.FOV = fov;
                CommonProperty.espconfig.EspConfig.透视载具 = 载具;
                CommonProperty.espconfig.EspConfig.骨灰盒 = 盒子;
                CommonProperty.espconfig.EspConfig.空投 = 空投;
                CommonProperty.espconfig.EspConfig.大地图载具 = 大地图载具;
                CommonProperty.espconfig.EspConfig.透视物资 = 物资;
                CommonProperty.espconfig.EspConfig.小地图 = 小地图透视;
                CommonProperty.espconfig.EspConfig.大地图 = 大地图透视;
                CommonProperty.espconfig.EspConfig.杀敌 = 杀敌;
                CommonProperty.espconfig.EspConfig.观战 = 观战;
                CommonProperty.espconfig.EspConfig.等级 = 等级;
                CommonProperty.espconfig.EspConfig.融合器模式 = 融合器模式;
                CommonProperty.espconfig.EspConfig.手持 = 手持;
                CommonProperty.espconfig.EspConfig.KD = KD;
                CommonProperty.espconfig.EspConfig.段位 = 段位;
                CommonProperty.espconfig.EspConfig.提前量 = 提前量;
                CommonProperty.espconfig.EspConfig.预警 = 预警;
                CommonProperty.espconfig.EspConfig.手持颜色 = new PGE.Vector3()
                {
                    x = col手持.X,
                    y = col手持.Y,
                    z = col手持.Z
                };
                CommonProperty.espconfig.EspConfig.队伍编号 = new PGE.Vector3()
                {
                    x = col队伍.X,
                    y = col队伍.Y,
                    z = col队伍.Z
                };
                CommonProperty.espconfig.EspConfig.倒地 = new PGE.Vector3()
                {
                    x = col倒地.X,
                    y = col倒地.Y,
                    z = col倒地.Z
                };
                CommonProperty.espconfig.EspConfig.可视 = new PGE.Vector3()
                {
                    x = col可视.X,
                    y = col可视.Y,
                    z = col可视.Z
                };
                CommonProperty.espconfig.EspConfig.不可视 = new PGE.Vector3()
                {
                    x = col不可视.X,
                    y = col不可视.Y,
                    z = col不可视.Z
                };
                CommonProperty.espconfig.EspConfig.危险 = new PGE.Vector3()
                {
                    x = col危险.X,
                    y = col危险.Y,
                    z = col危险.Z
                };
                CommonProperty.espconfig.EspConfig.人机 = new PGE.Vector3()
                {
                    x = col人机.X,
                    y = col人机.Y,
                    z = col人机.Z
                };
                CommonProperty.espconfig.EspConfig.合作者 = new PGE.Vector3()
                {
                    x = col合作者.X,
                    y = col合作者.Y,
                    z = col合作者.Z
                };
                CommonProperty.espconfig.EspConfig.字体 = new PGE.Vector3()
                {
                    x = col字体.X,
                    y = col字体.Y,
                    z = col字体.Z
                };
                CommonProperty.espconfig.EspConfig.A物资 = new PGE.Vector3()
                {
                    x = colA物资.X,
                    y = colA物资.Y,
                    z = colA物资.Z
                };
                CommonProperty.espconfig.EspConfig.B物资 = new PGE.Vector3()
                {
                    x = colB物资.X,
                    y = colB物资.Y,
                    z = colB物资.Z
                };
                CommonProperty.espconfig.EspConfig.C物资 = new PGE.Vector3()
                {
                    x = colC物资.X,
                    y = colC物资.Y,
                    z = colC物资.Z
                };
                CommonProperty.espconfig.EspConfig.D物资 = new PGE.Vector3()
                {
                    x = colD物资.X,
                    y = colD物资.Y,
                    z = colD物资.Z
                };
                CommonProperty.espconfig.EspConfig.col载具 = new PGE.Vector3()
                {
                    x = col载具.X,
                    y = col载具.Y,
                    z = col载具.Z
                };
                CommonProperty.espconfig.EspConfig.col投掷物 = new PGE.Vector3()
                {
                    x = col投掷物.X,
                    y = col投掷物.Y,
                    z = col投掷物.Z
                };
                CommonProperty.SaveConfig();
            }

            if (ImGui.TreeNode("人物"))
            {
                if (ImGui.Checkbox("骨骼", ref 骨骼))
                {
                    CommonProperty.espconfig.EspConfig.骨骼 = 骨骼;
                }
                ImGui.SameLine();
                ImGui.Checkbox("名字", ref ID);
                ImGui.SameLine();
                ImGui.Checkbox("距离", ref 距离);
                ImGui.SameLine();
                ImGui.Checkbox("血条", ref 血条开关);
                ImGui.SameLine();
                ImGui.Checkbox("队伍", ref 编号);
                ImGui.SameLine();
                ImGui.Checkbox("观战", ref 观战);
                ImGui.SameLine();
                ImGui.Checkbox("杀敌", ref 杀敌);
                //ImGui.SameLine();
                ImGui.Checkbox("等级", ref 等级);
                ImGui.SameLine();
                if (ImGui.Checkbox("段位", ref 段位))
                {
                    CommonProperty.espconfig.EspConfig.段位 = 段位;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("手持", ref 手持))
                {
                    CommonProperty.espconfig.EspConfig.手持 = 手持;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("KD  ", ref KD))
                {
                    CommonProperty.espconfig.EspConfig.KD = KD;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("小地图", ref 小地图透视))
                {
                    CommonProperty.espconfig.EspConfig.小地图 = 小地图透视;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("大地图", ref 大地图透视))
                {
                    CommonProperty.espconfig.EspConfig.大地图 = 大地图透视;
                }
                //ImGui.SameLine();
                if (ImGui.Checkbox("投掷物预警", ref 投掷物))
                {
                    CommonProperty.espconfig.EspConfig.投掷物 = 投掷物;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("被瞄射线", ref 被瞄射线))
                {
                    CommonProperty.espconfig.EspConfig.射线 = 被瞄射线;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("自瞄范围", ref fov))
                {
                    CommonProperty.espconfig.EspConfig.FOV = fov;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("瞄准提前量", ref 提前量))
                {
                    CommonProperty.espconfig.EspConfig.提前量 = 提前量;
                }
                ImGui.SliderInt("透视距离", ref 透视距离, 100, 1000);
                //ImGui.SliderInt("手持距离", ref 手持距离, 50, 300);
                ImGui.SliderFloat("骨骼粗细", ref 骨骼粗细, 0.5f, 3.0f);
                ImGui.SliderFloat("小地图圆", ref 小地图大小, 1, 15);
                ImGui.SliderFloat("大地图圆", ref 大地图大小, 1, 15);
                ImGui.SliderInt("文字大小", ref 字体大小, 10, 40);

                if (ImGui.ColorEdit3("队伍/血条", ref col队伍))
                {
                    CommonProperty.espconfig.EspConfig.队伍编号 = new PGE.Vector3()
                    {
                        x = col队伍.X,
                        y = col队伍.Y,
                        z = col队伍.Z
                    };
                }
                if (ImGui.ColorEdit3("手持", ref col手持))
                {
                    CommonProperty.espconfig.EspConfig.手持颜色 = new PGE.Vector3()
                    {
                        x = col手持.X,
                        y = col手持.Y,
                        z = col手持.Z
                    };
                }
                if (ImGui.ColorEdit3("可视敌人", ref col可视))
                {
                    CommonProperty.espconfig.EspConfig.可视 = new PGE.Vector3()
                    {
                        x = col可视.X,
                        y = col可视.Y,
                        z = col可视.Z
                    };
                }
                if (ImGui.ColorEdit3("不视敌人", ref col不可视))
                {
                    CommonProperty.espconfig.EspConfig.不可视 = new PGE.Vector3()
                    {
                        x = col不可视.X,
                        y = col不可视.Y,
                        z = col不可视.Z
                    };
                }
                if (ImGui.ColorEdit3("倒地敌人", ref col倒地))
                {
                    CommonProperty.espconfig.EspConfig.倒地 = new PGE.Vector3()
                    {
                        x = col倒地.X,
                        y = col倒地.Y,
                        z = col倒地.Z
                    };
                }
                if (ImGui.ColorEdit3("高危敌人", ref col危险))
                {
                    CommonProperty.espconfig.EspConfig.危险 = new PGE.Vector3()
                    {
                        x = col危险.X,
                        y = col危险.Y,
                        z = col危险.Z
                    };
                }
                if (ImGui.ColorEdit3("人机/黑名单", ref col人机))
                {
                    CommonProperty.espconfig.EspConfig.人机 = new PGE.Vector3()
                    {
                        x = col人机.X,
                        y = col人机.Y,
                        z = col人机.Z
                    };
                }
                if (ImGui.ColorEdit3("合作者", ref col合作者))
                {
                    CommonProperty.espconfig.EspConfig.合作者 = new PGE.Vector3()
                    {
                        x = col合作者.X,
                        y = col合作者.Y,
                        z = col合作者.Z
                    };
                }
                if (ImGui.ColorEdit3("投掷物", ref col投掷物))
                {
                    CommonProperty.espconfig.EspConfig.col投掷物 = new PGE.Vector3()
                    {
                        x = col投掷物.X,
                        y = col投掷物.Y,
                        z = col投掷物.Z
                    };
                }
                if (ImGui.ColorEdit3("文字", ref col字体))
                {
                    CommonProperty.espconfig.EspConfig.字体 = new PGE.Vector3()
                    {
                        x = col字体.X,
                        y = col字体.Y,
                        z = col字体.Z
                    };
                }
                ImGui.TreePop();
            }

            if (ImGui.TreeNode("物资"))
            {
                if (ImGui.Checkbox("载具", ref 载具))
                {
                    CommonProperty.espconfig.EspConfig.透视载具 = 载具;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("物资", ref 物资))
                {
                    CommonProperty.espconfig.EspConfig.透视物资 = 物资;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("盒子", ref 盒子))
                {
                    CommonProperty.espconfig.EspConfig.骨灰盒 = 盒子;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("空投", ref 空投))
                {
                    CommonProperty.espconfig.EspConfig.空投 = 空投;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("大地图载具", ref 大地图载具))
                {
                    CommonProperty.espconfig.EspConfig.大地图载具 = 大地图载具;
                }

                ImGui.SliderInt("物资距离", ref 物资距离, 50, 150);
                ImGui.SliderInt("载具距离", ref 载具距离, 100, 1000);
                ImGui.SliderInt("文字大小", ref 物资字体大小, 10, 40);
                if (ImGui.ColorEdit3("A物资", ref colA物资))
                {
                    CommonProperty.espconfig.EspConfig.A物资 = new PGE.Vector3()
                    {
                        x = colA物资.X,
                        y = colA物资.Y,
                        z = colA物资.Z
                    };
                }
                if (ImGui.ColorEdit3("B物资", ref colB物资))
                {
                    CommonProperty.espconfig.EspConfig.B物资 = new PGE.Vector3()
                    {
                        x = colB物资.X,
                        y = colB物资.Y,
                        z = colB物资.Z
                    };
                }
                if (ImGui.ColorEdit3("C物资", ref colC物资))
                {
                    CommonProperty.espconfig.EspConfig.C物资 = new PGE.Vector3()
                    {
                        x = colC物资.X,
                        y = colC物资.Y,
                        z = colC物资.Z
                    };
                }
                if (ImGui.ColorEdit3("D物资", ref colD物资))
                {
                    CommonProperty.espconfig.EspConfig.D物资 = new PGE.Vector3()
                    {
                        x = colD物资.X,
                        y = colD物资.Y,
                        z = colD物资.Z
                    };
                }
                if (ImGui.ColorEdit3("载具", ref col载具))
                {
                    CommonProperty.espconfig.EspConfig.col载具 = new PGE.Vector3()
                    {
                        x = col载具.X,
                        y = col载具.Y,
                        z = col载具.Z
                    };
                }

                ImGui.TreePop();
            }

            if (ImGui.TreeNode("全局"))
            {

                if (ImGui.Checkbox("透视", ref 串流透视))
                {
                    CommonProperty.espconfig.EspConfig.串流透视 = 串流透视;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("字体加粗", ref 粗字体))
                {
                    CommonProperty.espconfig.EspConfig.粗字体 = 粗字体;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("ESP人物列表", ref 玩家列表))
                {
                    CommonProperty.espconfig.EspConfig.玩家列表 = 玩家列表;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("预警", ref 预警))
                {
                    CommonProperty.espconfig.EspConfig.预警 = 预警;
                }
                ImGui.SliderInt("延迟", ref 帧延迟, 0, 5);

                if (ImGui.Checkbox("融合器模式", ref 融合器模式))
                {
                    CommonProperty.espconfig.EspConfig.融合器模式 = 融合器模式;
                }
                ImGui.SameLine();
                if (ImGui.Checkbox("黑背景填充", ref 黑背景))
                {
                    CommonProperty.espconfig.EspConfig.融合器黑背景填充 = 黑背景;
                }

                ImGui.TreePop();
            }

            //ImGui.SameLine();

            ImGui.End();
        }

        enum SortOrder
        {
            None,
            Ascending,
            Descending
        }

        public void 人物列表()
        {
            ImGui.SetNextWindowSize(new Vector2(500, 215));
            ImGui.SetNextWindowPos(new Vector2(CommonProperty.X分辨率 - 500, 50));
            bool isCollapsed = !ImGui.Begin(
                "玩家列表",
                ref Show,
                ImGuiWindowFlags.NoResize | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoBackground);

            if (!Show || isCollapsed)
            {
                //ImGui.End();
                if (!Show)
                {
                    //Close();
                }
                return;
            }
            if (ImGui.BeginTable("table", 7, ImGuiTableFlags.Sortable | ImGuiTableFlags.Borders))
            {
                ImGui.TableSetupColumn("队伍", ImGuiTableColumnFlags.DefaultSort | ImGuiTableColumnFlags.WidthFixed, 50.0f);
                ImGui.TableSetupColumn("ID", ImGuiTableColumnFlags.NoSort | ImGuiTableColumnFlags.WidthFixed, 100.0f);
                ImGui.TableSetupColumn("等级", ImGuiTableColumnFlags.DefaultSort | ImGuiTableColumnFlags.WidthFixed, 50.0f);
                ImGui.TableSetupColumn("段位", ImGuiTableColumnFlags.DefaultSort | ImGuiTableColumnFlags.WidthFixed, 50.0f);
                ImGui.TableSetupColumn("KD", ImGuiTableColumnFlags.DefaultSort | ImGuiTableColumnFlags.WidthFixed, 50.0f);
                ImGui.TableSetupColumn("伤害", ImGuiTableColumnFlags.DefaultSort | ImGuiTableColumnFlags.WidthFixed, 50.0f);
                //ImGui.TableSetupColumn("杀敌", ImGuiTableColumnFlags.NoSort | ImGuiTableColumnFlags.WidthFixed, 50.0f);
                ImGui.TableSetupColumn("操作", ImGuiTableColumnFlags.DefaultSort | ImGuiTableColumnFlags.WidthFixed, 50.0f);

                ImGui.TableHeadersRow();
                var specs = ImGui.TableGetSortSpecs();

                if (specs.SpecsDirty)
                {
                    switch (specs.Specs.ColumnIndex)
                    {
                        case 0:
                            if (specs.Specs.SortDirection == ImGuiSortDirection.Descending)
                            {
                                esp玩家列表 = esp玩家列表.OrderByDescending(p => p.TeamID).ToList();
                            }
                            else
                            {
                                esp玩家列表 = esp玩家列表.OrderBy(p => p.TeamID).ToList();
                            }
                            break;
                        case 2:
                            if (specs.Specs.SortDirection == ImGuiSortDirection.Descending)
                            {
                                esp玩家列表 = esp玩家列表.OrderByDescending(p => p.等级).ToList();
                            }
                            else
                            {
                                esp玩家列表 = esp玩家列表.OrderBy(p => p.等级).ToList();
                            }
                            break;
                        case 4:
                            if (specs.Specs.SortDirection == ImGuiSortDirection.Descending)
                            {
                                esp玩家列表 = esp玩家列表.OrderByDescending(p => p.KD).ToList();
                            }
                            else
                            {
                                esp玩家列表 = esp玩家列表.OrderBy(p => p.KD).ToList();
                            }
                            break;
                        case 5:
                            if (specs.Specs.SortDirection == ImGuiSortDirection.Descending)
                            {
                                esp玩家列表 = esp玩家列表.OrderByDescending(p => p.伤害).ToList();
                            }
                            else
                            {
                                esp玩家列表 = esp玩家列表.OrderBy(p => p.伤害).ToList();
                            }
                            break;
                    }
                }


                var isUpdate = false;
                foreach (var data in esp玩家列表)
                {
                    if (data.死亡)
                    {
                        continue;
                    }

                    ImGui.TableNextRow();

                    ImGui.TableNextColumn();
                    ImGui.Text(data.TeamID.ToString());

                    ImGui.TableNextColumn();
                    ImGui.Text(data.name.ToString());

                    ImGui.TableNextColumn();
                    ImGui.Text(data.等级.ToString());

                    ImGui.TableNextColumn();
                    ImGui.Text(data.段位.ToString());

                    ImGui.TableNextColumn();
                    ImGui.Text(data.KD.ToString());

                    ImGui.TableNextColumn();
                    ImGui.Text(data.伤害.ToString());

                    ImGui.TableNextColumn();
                    var btnText = "默认";

                    if (CommonProperty.Hash_黑名单.Contains(data.name))
                    {
                        btnText = "黑名单";
                    }
                    else if (CommonProperty.Hash_队友.Contains(data.name))
                    {
                        btnText = "白名单";
                    }
                    if (ImGui.Button($"{btnText}##{data.name}"))
                    {
                        if (CommonProperty.Hash_黑名单.Contains(data.name))
                        {
                            CommonProperty.Hash_黑名单.Remove(data.name);
                            CommonProperty.Hash_队友.Add(data.name);
                        }
                        else if (CommonProperty.Hash_队友.Contains(data.name))
                        {
                            CommonProperty.Hash_黑名单.Remove(data.name);
                            CommonProperty.Hash_队友.Remove(data.name);
                        }
                        else
                        {
                            CommonProperty.Hash_黑名单.Add(data.name);
                        }
                        isUpdate = true;
                    }

                }

                if (isUpdate)
                {
                    using (StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "\\config\\BlackList.ini"))
                    {
                        foreach (string item in CommonProperty.Hash_黑名单)
                        {
                            streamWriter.WriteLine(item.Trim());
                        }
                    }
                    using (StreamWriter streamWriter = new StreamWriter(CommonProperty.path + "\\config\\whitelist.ini"))
                    {
                        foreach (string item in CommonProperty.HashSet_白名单)
                        {
                            streamWriter.WriteLine(item.Trim());
                        }
                    }
                }

                ImGui.EndTable();
            }
            ImGui.End();
        }
    }
}