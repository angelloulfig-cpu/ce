﻿namespace MultiThreadedOverlay
{
    using ClickableTransparentOverlay;
    using ImGuiNET;
    using PGE.Common;
    using System;
    using System.Threading;

    /// <summary>
    /// 人物透视 Loop and Logic Loop are independent from each other. 
    /// </summary>
    public class SampleOverlay : Overlay
    {
        private volatile State state;
        private readonly Thread logicThread;


        public SampleOverlay()
        {
            state = new State();
            logicThread = new Thread(() =>
            {
                while (state.IsRunning)
                {
                    LogicUpdate(0);
                }
            });
            logicThread.Start();
        }

        public override void Close()
        {
            base.Close();
            this.state.IsRunning = false;
        }

        private void LogicUpdate(float updateDeltaTicks)
        {
            if (state.RequestLogicThreadSleep)
            {
                Thread.Sleep(TimeSpan.FromSeconds(state.SleepInSeconds));
                state.RequestLogicThreadSleep = false;
            }
            if (state.LogicThreadCloseOverlay)
            {
                Close();
                state.LogicThreadCloseOverlay = false;
            }
            state.EspOverlay.Update();

        }



        protected override void Render()
        {
            var deltaSeconds = ImGui.GetIO().DeltaTime;
            if (!state.Visible)
            {
                state.ReappearTimeRemaining -= deltaSeconds;
                if (state.ReappearTimeRemaining < 0)
                {
                    state.Visible = true;
                }
                return;
            }
            //state.RenderFramesCounter.Increment();

            if (state.EspOverlay.Show && CommonProperty.espconfig.EspConfig.串流透视)
            {
                state.EspOverlay.人物透视();
                state.EspOverlay.资源透视();
            }
            if (CommonProperty.菜单)
            {
                state.EspOverlay.菜单();
            }
            if (CommonProperty.espconfig.EspConfig.玩家列表)
            {
                state.EspOverlay.人物列表();
            }
            return;
        }
    }
}
